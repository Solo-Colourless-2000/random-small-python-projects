import posixpath
import sys
from urllib.parse import unquote


def resolve(raw):
    first = unquote(raw, errors="strict")
    second = unquote(first, errors="strict")
    if not second.isascii() or not second.isprintable():
        raise ValueError("Use printable ASCII paths.")
    target = posixpath.normpath(second)
    weak = ".." not in first.split("/")
    fixed = target.startswith("/public/")
    return first, target, weak, fixed


def main():
    if len(sys.argv) != 2 or not sys.argv[1].startswith("/public/"):
        print("Usage: script /public/PATH", file=sys.stderr)
        return 2
    raw = sys.argv[1]
    if len(raw) > 160 or not raw.isascii() or not raw.isprintable():
        print("Use a printable ASCII path of up to 160 characters.", file=sys.stderr)
        return 2
    try:
        first, target, weak, fixed = resolve(raw)
    except ValueError:
        print("Invalid decoded path.", file=sys.stderr)
        return 2
    print(f"First decode: {first}")
    print(f"Target: {target}")
    print(f"Early check: {weak}")
    print(f"Target check: {fixed}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
