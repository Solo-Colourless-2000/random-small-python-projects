"""A classic Snake game with a C simulation engine and Tkinter GUI."""
