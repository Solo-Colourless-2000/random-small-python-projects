import string
import sys

ALLOWED = string.ascii_lowercase + string.digits + "-"


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 02_packing_list.py items")
        return 2
    if len(sys.argv[1]) > 300 or not sys.argv[1].isascii():
        print("Error: use at most 300 ASCII characters.")
        return 2
    items = sys.argv[1].split(",")
    if not 1 <= len(items) <= 12:
        print("Error: use 1-12 items.")
        return 2
    unique = []
    for item in items:
        item = item.strip(" ").lower()
        if not 1 <= len(item) <= 20:
            print("Error: each item needs 1-20 characters.")
            return 2
        for character in item:
            if character not in ALLOWED:
                print("Error: use letters, digits or hyphens.")
                return 2
        if item not in unique:
            unique.append(item)
    print(f"Items: {len(unique)}")
    for number, item in enumerate(unique, 1):
        print(f"{number}. {item}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
