"""Verify 25 independently themed reviews from a single JUnit-backed test run.
Run with an X display or xvfb-run.
"""
import re
import subprocess
import sys
import tempfile
import xml.etree.ElementTree as ET
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
ENG=ROOT/'tests'/'test_engine.py'
GUI=ROOT/'tests'/'test_ui.py'

def ids(file,nums):
    src=file.read_text(encoding='utf8')
    found=re.findall(r'^def (test_\d\d_[^(]+)\(',src,flags=re.M)
    result=[]
    for n in nums:
        match=[t for t in found if t.startswith(f'test_{n:02}_')]
        if len(match)!=1:raise AssertionError(f'{file}: {n} is missing/duplicate')
        result.append(f'{file}::{match[0]}')
    return result

checks=[
 ('01 / ABI and initialization',ENG,[1,2,3,4]),
 ('02 / hostile spawning and cover clearance',ENG,[5,6]),
 ('03 / wave escalation and commander',ENG,[7,8]),
 ('04 / movement and diagonal normalization',ENG,[9,10,11]),
 ('05 / world boundaries and tank collision',ENG,[12,13]),
 ('06 / aiming and trigger discipline',ENG,[14,15,16]),
 ('07 / swept-hit scoring and combo flow',ENG,[17,18,19,20]),
 ('08 / destructible cover',ENG,[21,22,24]),
 ('09 / steel ricochet',ENG,[23]),
 ('10 / incoming damage and invulnerability',ENG,[25,26,27]),
 ('11 / repairs and weapon stat upgrades',ENG,[28,29,30,31]),
 ('12 / boost dash and regeneration',ENG,[32,33,34,35,36]),
 ('13 / EMP attack and cooldown',ENG,[37,38,39,40,41]),
 ('14 / pickup effect and mobility',ENG,[42,43,44]),
 ('15 / death state and invalid input',ENG,[45,46]),
 ('16 / determinism, capacity and bridge initialization',ENG,[47,48,61]),
 ('17 / randomized extended play and public bridge',ENG,[49,50]),
 ('18 / obstacles block fire; boss volleys',ENG,[51,52,53,54,55]),
 ('19 / timestep and upgrade limits',ENG,[56,57,58,59,60]),
 ('20 / title deployment and initial display',GUI,[1,2,3,4]),
 ('21 / controls, focus and pause',GUI,[5,6,7,8,9,10,11,12,13,14]),
 ('22 / reward cards and input safeguards',GUI,[15,16,17,18]),
 ('23 / replay and saved progress',GUI,[19,20,21,22]),
 ('24 / window layout and simulation clocks',GUI,[23,24,25,26,27,28]),
 ('25 / state-by-state visible UI render',GUI,[29,30]),
]

def main():
    start=int(sys.argv[1]) if len(sys.argv)>1 else 1
    stop=int(sys.argv[2]) if len(sys.argv)>2 else len(checks)
    if not 1<=start<=stop<=len(checks):
        raise ValueError('Pass range must be between 1 and 25')
    chosen=checks[start-1:stop]
    # Collect every individual case once, then compare JUnit results against
    # every theme. Spawning 25 separate pytest processes adds no coverage and
    # can take minutes on slower PCs despite identical assertions.
    selected={node for _,location,nums in chosen for node in ids(location,nums)}
    with tempfile.TemporaryDirectory(prefix='steelfront-25-') as temp:
        report=Path(temp)/'audit.xml'
        command=[sys.executable,'-m','pytest','-q','--tb=short',
                 '--junitxml',str(report),*sorted(selected)]
        result=subprocess.run(command,cwd=ROOT,text=True,capture_output=True,timeout=120)
        if result.returncode or not report.exists():
            print(result.stdout+result.stderr,file=sys.stderr)
            return 1
        good={case.get('name') for case in ET.parse(report).iter('testcase')
              if case.find('failure') is None and case.find('error') is None
              and case.find('skipped') is None}
    log=ROOT/'tests'/'audit_results.txt'
    lines=[]
    for label,location,numbers in chosen:
        required={Path(node.split('::')[0]).name+':'+node.split('::')[1]
                  for node in ids(location,numbers)}
        # Python testcase names are unique among the selected suites.
        passed=all(entry.partition(':')[2] in good for entry in required)
        verdict='PASS' if passed else 'FAIL'
        lines.append(f'{verdict}  {label}  |  {len(numbers)} tests')
        print(f'{verdict}: {label} ({len(numbers)} tests)',flush=True)
    mode='w' if start==1 else 'a'
    with log.open(mode,encoding='utf-8') as f:
        f.write('\n'.join(lines)+'\n')
    number=sum(row.startswith('PASS') for row in lines)
    print(f'Completed this invocation: {number}/{len(chosen)} themed passes')
    return 0 if number==len(chosen) else 1

if __name__=='__main__':sys.exit(main())
