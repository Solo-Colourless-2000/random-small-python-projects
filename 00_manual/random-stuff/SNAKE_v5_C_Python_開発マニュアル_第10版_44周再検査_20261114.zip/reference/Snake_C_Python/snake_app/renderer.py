"""Stateless game drawing with an explicit view model and declarative buttons.

This layer does not move the snake, save scores, or perform game transitions.
"""
from __future__ import annotations

from dataclasses import dataclass
import math
import tkinter as tk

from snake_app.engine import Direction, Frame, Status
from snake_app.storage import DIFFICULTIES
from snake_app.config import (
    WINDOW_WIDTH, WINDOW_HEIGHT, COLUMNS, ROWS, CELL, BOARD_X, BOARD_Y,
    BOARD_WIDTH, BOARD_HEIGHT, BG, BOARD_BG, GRID, WHITE, MUTED, GREEN,
    BODY_A, BODY_B, FOOD, PANEL, OUTLINE, animation_progress, game_interval,
)

Hitbox = tuple[float, float, float, float, str]


@dataclass(frozen=True)
class RenderState:
    frame: Frame
    previous: Frame
    mode: str
    difficulty: str
    scores: dict[str, int]
    pause_reason: str
    save_warning: bool
    flash_end: float
    last_step: float


class SnakeRenderer:
    def __init__(self, canvas: tk.Canvas) -> None:
        self.canvas = canvas
        self._hitboxes: list[Hitbox] = []
        self._view: RenderState

    def _rounded_rect(self, x0: float, y0: float, x1: float, y1: float,
                      radius: float, *, fill: str, outline: str = "",
                      width: float = 1, tags: tuple[str, ...] = ()) -> int:
        r = min(radius, (x1 - x0) / 2, (y1 - y0) / 2)
        points = [x0+r,y0, x1-r,y0, x1,y0, x1,y0+r,
                  x1,y1-r, x1,y1, x1-r,y1, x0+r,y1,
                  x0,y1, x0,y1-r, x0,y0+r, x0,y0]
        return self.canvas.create_polygon(points, smooth=True, splinesteps=12,
                                          fill=fill, outline=outline, width=width, tags=tags)

    def _text(self, x: float, y: float, value: str, size: int = 12, *,
              color: str = WHITE, weight: str = "normal", anchor: str = "center",
              family: str = "DejaVu Sans") -> None:
        self.canvas.create_text(x, y, text=value, fill=color,
                                font=(family, size, weight), anchor=anchor)

    def _button(self, x: float, y: float, width: float, height: float,
                label: str, action: str, *,
                selected: bool = False, font_size: int = 12) -> None:
        self._hitboxes.append((x, y, x + width, y + height, action))
        fill = GREEN if selected else "#263b4d"
        ink = "#0d2a28" if selected else WHITE
        self._rounded_rect(x, y, x + width, y + height, 9, fill=fill,
                           outline=GREEN if selected else "#40586a")
        self.canvas.create_text(x + width / 2, y + height / 2,
                                text=label, font=("DejaVu Sans", font_size, "bold"),
                                fill=ink)

    def draw(self, state: RenderState, now: float) -> list[Hitbox]:
        self._view = state
        self.canvas.delete("all")
        self._hitboxes.clear()
        c = self.canvas
        c.create_rectangle(0, 0, WINDOW_WIDTH, WINDOW_HEIGHT, fill=BG, outline="")
        self._text(BOARD_X, 52, "SNAKE", 29, weight="bold", anchor="w")
        c.create_line(BOARD_X, 105, BOARD_X + BOARD_WIDTH, 105,
                      fill="#263847", width=1)
        if self._view.save_warning:
            self._text(BOARD_X + BOARD_WIDTH, 95, "BEST SCORE NOT SAVED", 9,
                       color=FOOD, anchor="e", weight="bold")
        for x, title, value in ((425, "SCORE", self._view.frame.score),
                                 (555, "BEST", self._view.scores[self._view.difficulty])):
            self._text(x, 37, title, 10, color=MUTED, anchor="w", weight="bold")
            self._text(x, 70, f"{value:03d}", 22, anchor="w", weight="bold")
        self._text(708, 37, "SPEED", 10, color=MUTED, anchor="w", weight="bold")
        self._text(708, 69, self._view.difficulty, 12, anchor="w", weight="bold")

        c.create_rectangle(BOARD_X - 3, BOARD_Y - 3,
                           BOARD_X + BOARD_WIDTH + 3, BOARD_Y + BOARD_HEIGHT + 3,
                           fill="#152534", outline="#355061", width=2)
        c.create_rectangle(BOARD_X, BOARD_Y,
                           BOARD_X + BOARD_WIDTH, BOARD_Y + BOARD_HEIGHT,
                           fill=BOARD_BG, outline="")
        for col in range(1, COLUMNS):
            x = BOARD_X + col * CELL
            c.create_line(x, BOARD_Y, x, BOARD_Y + BOARD_HEIGHT, fill=GRID)
        for row in range(1, ROWS):
            y = BOARD_Y + row * CELL
            c.create_line(BOARD_X, y, BOARD_X + BOARD_WIDTH, y, fill=GRID)

        self._draw_food(now)
        self._draw_snake(now)
        if now < self._view.flash_end:
            c.create_rectangle(BOARD_X + 2, BOARD_Y + 2,
                               BOARD_X + BOARD_WIDTH - 2, BOARD_Y + BOARD_HEIGHT - 2,
                               outline="#6eae8b", width=3)

        self._text(BOARD_X, 623, f"LENGTH  {len(self._view.frame.body):03d} / {COLUMNS * ROWS}",
                   9, color=MUTED, anchor="w", weight="bold")
        self._text(BOARD_X + BOARD_WIDTH, 623, "EAT  •  GROW  •  SURVIVE",
                   9, color=MUTED, anchor="e")
        c.create_line(BOARD_X, 638, BOARD_X + BOARD_WIDTH, 638, fill="#263847")
        self._text(BOARD_X, 665, "ARROWS / WASD   MOVE", 10,
                   color=MUTED, anchor="w", weight="bold")
        self._text(388, 665, "SPACE   PAUSE", 10, color=MUTED, anchor="w")
        self._text(561, 665, "R   RESTART", 10, color=MUTED, anchor="w")
        self._text(BOARD_X + BOARD_WIDTH, 665, "ESC   MENU", 10,
                   color=MUTED, anchor="e")

        if self._view.mode != "playing":
            self._draw_overlay()
        return list(self._hitboxes)

    def _animation_progress(self, now: float) -> float:
        return animation_progress(self._view.mode, now, self._view.last_step,
                                  game_interval(self._view.difficulty, self._view.frame.score))

    def _draw_snake(self, now: float) -> None:
        fraction = self._animation_progress(now)
        body = self._view.frame.body
        old = self._view.previous.body
        for i in range(len(body) - 1, -1, -1):
            current_x, current_y = body[i]
            old_x, old_y = old[min(i, len(old) - 1)]
            x = old_x + (current_x - old_x) * fraction
            y = old_y + (current_y - old_y) * fraction
            px = BOARD_X + x * CELL
            py = BOARD_Y + y * CELL
            head = i == 0
            inset = 2.0 if head else 3.0
            color = GREEN if head else (BODY_A if i % 2 else BODY_B)
            self._rounded_rect(px + inset, py + inset,
                               px + CELL - inset, py + CELL - inset,
                               6, fill=color)
            if head:
                self._draw_eyes(px + CELL / 2, py + CELL / 2, self._view.frame.direction)

    def _draw_eyes(self, cx: float, cy: float, direction: Direction) -> None:
        if direction in (Direction.LEFT, Direction.RIGHT):
            dx = 5 if direction == Direction.RIGHT else -5
            points = [(cx + dx, cy - 5), (cx + dx, cy + 5)]
        else:
            dy = 5 if direction == Direction.DOWN else -5
            points = [(cx - 5, cy + dy), (cx + 5, cy + dy)]
        for x, y in points:
            self.canvas.create_oval(x - 2, y - 2, x + 2, y + 2,
                                    fill="#153f39", outline="")

    def _draw_food(self, now: float) -> None:
        food = self._view.frame.food
        # Keep the eaten food visible until the head reaches it visually.
        if (self._view.previous.score < self._view.frame.score and
                self._animation_progress(now) < 0.55):
            food = self._view.previous.food
        if food is None:
            return
        fx, fy = food
        x = BOARD_X + (fx + 0.5) * CELL
        y = BOARD_Y + (fy + 0.5) * CELL
        pulse = math.sin(now * 5.2) if self._view.mode == "playing" else 0.0
        halo = 10.5 + pulse * 1.2
        self.canvas.create_oval(x - halo, y - halo, x + halo, y + halo,
                                fill="#654343", outline="")
        self.canvas.create_oval(x - 7.2, y - 7.2, x + 7.2, y + 7.2,
                                fill=FOOD, outline="")
        self.canvas.create_oval(x - 3, y - 4, x + 0, y - 1,
                                fill="#ffddba", outline="")

    def _draw_overlay(self) -> None:
        c = self.canvas
        # Stipple is supported by Tk on Windows, macOS and X11.
        c.create_rectangle(BOARD_X, BOARD_Y, BOARD_X + BOARD_WIDTH,
                           BOARD_Y + BOARD_HEIGHT,
                           fill="#050c13", stipple="gray75", outline="")
        if self._view.mode == "menu":
            x0, y0, x1, y1 = 236, 216, 614, 531
            self._rounded_rect(x0, y0, x1, y1, 16, fill=PANEL, outline=OUTLINE, width=2)
            self._text(425, 267, "SNAKE", 31, weight="bold")
            self._text(425, 309, "CHOOSE SPEED", 10, color=MUTED, weight="bold")
            for i, name in enumerate(DIFFICULTIES):
                self._button(270 + i * 107, 338, 98, 41, name,
                             f"difficulty:{name}",
                             selected=self._view.difficulty == name, font_size=10)
            self._button(335, 411, 180, 50, "PLAY", "start", selected=True,
                         font_size=16)
            self._text(425, 493, "ENTER  START   |   1 / 2 / 3  SPEED", 10,
                       color=MUTED)
        elif self._view.mode == "paused":
            self._rounded_rect(271, 270, 579, 467, 16,
                               fill=PANEL, outline=OUTLINE, width=2)
            self._text(425, 325, self._view.pause_reason, 24, weight="bold")
            self._button(338, 364, 174, 47, "RESUME", "resume",
                         selected=True, font_size=13)
            self._text(425, 439, "SPACE  RESUME", 10, color=MUTED)
        elif self._view.mode == "over":
            self._rounded_rect(251, 239, 599, 494, 16,
                               fill=PANEL, outline=OUTLINE, width=2)
            headline = "YOU WIN" if self._view.frame.status == Status.WON else "GAME OVER"
            self._text(425, 287, headline, 27, weight="bold")
            self._text(425, 332, f"SCORE  {self._view.frame.score:03d}     BEST  {self._view.scores[self._view.difficulty]:03d}",
                       12, color=MUTED, weight="bold")
            self._button(330, 365, 190, 49, "RESTART", "start",
                         selected=True, font_size=14)
            self._text(425, 458, "ENTER  RESTART   |   ESC  MENU", 10,
                       color=MUTED)

