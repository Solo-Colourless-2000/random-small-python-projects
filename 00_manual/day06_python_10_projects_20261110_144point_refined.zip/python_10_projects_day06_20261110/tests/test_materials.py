import ast
from collections import Counter
from html.parser import HTMLParser
import json
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest

from cases import CASES


ROOT = Path(__file__).resolve().parents[1]
MANUAL = ROOT / "python_10_projects_day06_manual.html"


class Manual(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.ids = Counter()
        self.anchors = []
        self.chapters = []
        self.checks = []
        self.sources = {}
        self.line_numbers = {}
        self.internal_assets = []
        self.code = None
        self.feed(text)
        self.close()

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        identity = attrs.get("id")
        if identity:
            self.ids[identity] += 1
        if tag == "section" and "chapter" in attrs.get("class", "").split():
            self.chapters.append(identity)
        if tag == "a" and attrs.get("href", "").startswith("#"):
            self.anchors.append(attrs["href"][1:])
        if tag == "input" and "data-check" in attrs:
            self.checks.append(attrs["data-check"])
        if tag in ("script", "img", "iframe") and attrs.get("src"):
            self.internal_assets.append(attrs["src"])
        if tag == "link" and attrs.get("rel") == "stylesheet":
            self.internal_assets.append(attrs.get("href"))
        if tag == "code" and "data-kind" in attrs:
            self.code = identity
            self.sources[self.code] = ""
            self.line_numbers[self.code] = []
        if tag == "span" and self.code and "data-line" in attrs:
            self.line_numbers[self.code].append(int(attrs["data-line"]))

    def handle_data(self, data):
        if self.code:
            self.sources[self.code] += data

    def handle_endtag(self, tag):
        if tag == "code":
            self.code = None


class MaterialTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.page = Manual(MANUAL.read_text(encoding="utf-8"))

    def test_chapters_ids_and_static_navigation(self):
        self.assertEqual(len(self.page.chapters), 20)
        self.assertEqual(self.page.chapters, self.page.checks)
        self.assertFalse([name for name, count in self.page.ids.items() if count != 1])
        self.assertFalse(set(self.page.anchors) - self.page.ids.keys())
        self.assertEqual(self.page.internal_assets, [])
        self.assertIn(MANUAL.name, (ROOT / "README.txt").read_text())

    def test_ascii_and_python_310_grammar(self):
        files = sorted(ROOT.glob("projects/*.py"))
        self.assertEqual(len(files), 10)
        for path in files + list(ROOT.glob("tests/*.py")) + list(ROOT.glob("samples/*")):
            with self.subTest(path=path.name):
                self.assertTrue(path.name.isascii())
                text = path.read_bytes().decode("ascii")
                self.assertNotIn("\r", text)
                if path.suffix == ".py":
                    ast.parse(text, filename=path.name, feature_version=(3, 10))
        for text in self.page.sources.values():
            self.assertTrue(text.isascii())

    def test_40_chunks_10_appendices_and_physical_line_numbers(self):
        for index, path in enumerate(sorted(ROOT.glob("projects/*.py")), 1):
            with self.subTest(path=path.name):
                num = f"{index:02}"
                step_ids = [f"step-{num}-{step}" for step in range(1, 5)]
                joined = "".join(self.page.sources[id_] for id_ in step_ids)
                appendix = self.page.sources[f"src-{num}"]
                self.assertEqual(joined.encode("ascii"), path.read_bytes())
                self.assertEqual(appendix, joined)
                lines = list(range(1, joined.count("\n") + 1))
                steps = [line for id_ in step_ids for line in self.page.line_numbers[id_]]
                self.assertEqual(steps, lines)
                self.assertEqual(self.page.line_numbers[f"src-{num}"], lines)
                for number, line in enumerate(joined.splitlines(), 1):
                    if line:
                        self.assertIn(f"src-{num}-L{number}", self.page.anchors)

    def test_practice_files_reconstructed_from_html(self):
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            (folder / "practice").mkdir()
            shutil.copytree(ROOT / "samples", folder / "samples")
            for index, (name, cases) in enumerate(CASES.items(), 1):
                with self.subTest(name=name):
                    practice = Path("practice", name + ".py")
                    joined = "".join(self.page.sources[f"step-{index:02}-{step}"] for step in range(1, 5))
                    (folder / practice).write_bytes(joined.encode("ascii"))
                    args, code, stdout, stderr = cases[0]
                    result = subprocess.run([sys.executable, "-S", str(practice), *args],
                                            cwd=folder, capture_output=True, text=True, timeout=6)
                    self.assertEqual((result.returncode, result.stdout, result.stderr), (code, stdout, stderr))

    def test_measured_transcripts_in_manual(self):
        measured = json.loads((ROOT / "verification" / "cli_observations.json").read_text())
        self.assertEqual(set(measured), set(CASES))
        blocks = set(self.page.sources.values())
        for name, records in measured.items():
            self.assertEqual(len(records), len(CASES[name]))
            for i, record in enumerate(records):
                args, code, stdout, stderr = CASES[name][i]
                self.assertEqual((record["args"], record["code"], record["stdout"], record["stderr"]),
                                 (args, code, stdout, stderr))
            for i in (0, 1):
                self.assertIn(records[i]["stdout"], blocks)

    def test_beginner_notes_and_glossary_are_complete(self):
        for number in range(1, 11):
            with self.subTest(project=number):
                num = f"{number:02}"
                self.assertIn(f"beginner-{num}", self.page.ids)
                for position in range(1, 5):
                    self.assertIn(f"beginner-{num}-{position}", self.page.ids)
        for position in range(1, 15):
            self.assertIn(f"glossary-extra-{position}", self.page.ids)
        self.assertIn("common-execution", self.page.ids)
        self.assertIn("common-execution-4", self.page.ids)

    def test_handoff_has_all_distinct_entries_and_next_volume(self):
        history = json.loads((ROOT / "PROJECT_HISTORY.json").read_text())
        self.assertEqual((history["last_completed_volume"], history["next_volume"]), (6, 7))
        items = history["projects"]
        self.assertEqual(len({entry["id"] for entry in items}), 60)
        self.assertEqual(len(items), 60)
        self.assertEqual(sum(entry["day"] == "day06" for entry in items), 10)
        self.assertIn("day07", (ROOT / "HANDOFF_PROMPT.txt").read_text())


class AdditionalRevisionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.page = Manual(MANUAL.read_text(encoding="utf-8"))
        cls.source = MANUAL.read_text(encoding="utf-8")

    def test_all_10_walkthroughs_have_3_independent_notes(self):
        for index in range(1, 11):
            name = f"{index:02}"
            with self.subTest(project=name):
                self.assertIn(f"reasoning-{name}", self.page.ids)
                for part in range(1, 4):
                    self.assertIn(f"reasoning-{name}-{part}", self.page.ids)
        self.assertEqual(self.source.count('class="reasoning-lab"'), 10)

    def test_15_glossary_terms_indexed_for_search(self):
        for index in range(1, 16):
            self.assertIn(f"glossary-second-{index}", self.page.ids)
            self.assertIn(f'data-find="" id="glossary-second-{index}"', self.source)

    def test_revised_links_and_delivery_filename(self):
        self.assertIn('const match = /^p(\\d{2})-step[1-4]$/', self.source)
        self.assertIn('match[1]', self.source)
        self.assertNotIn('step.slice(1, 3)', self.source)
        self.assertIn('unzip day06_python_10_projects_20261110_144point_refined.zip', self.source)
        self.assertIn('diff -u', self.source)
        self.assertIn('file://', self.source)


class ThirdRevisionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.source = MANUAL.read_text(encoding="utf-8")
        cls.page = Manual(cls.source)

    def test_all_ten_projects_have_traced_values_and_searchable_labels(self):
        for number in range(1, 11):
            with self.subTest(project=number):
                num = f"{number:02}"
                for suffix in ("", "-title", "-intro", "-takeaway"):
                    self.assertIn("trace-" + num + suffix, self.page.ids)
                self.assertIn(f'class="trace-lab" id="trace-{num}"', self.source)
        self.assertEqual(self.source.count('class="trace-lab"'), 10)

    def test_revised_sample_code_in_every_manual_location(self):
        source = (ROOT / "projects" / "06_upload_probe.py").read_text("ascii")
        self.assertIn('Path(__file__).resolve().parent.parent / "samples"', source)
        self.assertNotIn('path = Path("samples") / FILES[sys.argv[1]]', self.page.sources['src-06'])
        self.assertIn('Path(__file__).resolve().parent.parent / "samples"', self.page.sources["src-06"])
        self.assertEqual(self.page.sources["src-06"], source)

    def test_debugging_explains_test_target_and_indentation(self):
        for id_ in ("debugging-practice", "debugging-practice-1", "debugging-practice-2", "debugging-practice-3"):
            self.assertIn(id_, self.page.ids)
        self.assertIn("diff -u", self.source)
        self.assertIn("practice/", self.source)
        self.assertIn("__file__", self.source)
        for n in range(1, 5):
            self.assertIn(f"glossary-third-{n}", self.page.ids)

    def test_trace_table_row_counts_and_concrete_clues(self):
        import re
        for i in range(1, 11):
            with self.subTest(project=i):
                pattern = rf'<aside class="trace-lab" id="trace-{i:02}"[^>]*>(.*?)</aside>'
                section = re.search(pattern, self.source, flags=re.DOTALL)
                self.assertIsNotNone(section)
                content = section.group(1)
                self.assertIn('<table>', content)
                body = content.split('<tbody>', 1)[1].split('</tbody>', 1)[0]
                head = content.split('<thead>', 1)[1].split('</thead>', 1)[0]
                self.assertGreaterEqual(body.count('<tr>'), 3)
                self.assertEqual(head.count('<th scope="col">'), 3)
        for label in ("/public/%252e%252e/private/notes", "none", "trap-app.example.test", "edge-a", "readline(64)"):
            self.assertIn(label, self.source)
