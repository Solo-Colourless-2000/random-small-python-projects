import sys
import zlib

SECRET = b"token=LABDEMO"
GUESSES = (b"token=LABDEMO", b"token=XXXXXXX")


def sizes(shared):
    result = []
    for guess in GUESSES:
        if shared:
            encoded = zlib.compress(SECRET + b"|" + guess)
            size = len(encoded)
        else:
            size = len(zlib.compress(SECRET)) + len(zlib.compress(guess))
        result.append(size)
    return result


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ("shared", "separate"):
        print("Usage: script shared|separate", file=sys.stderr)
        return 2
    good, bad = sizes(sys.argv[1] == "shared")
    print(f"Equal input lengths: {len(GUESSES[0]) == len(GUESSES[1])}")
    print(f"Matching guess is smaller: {good < bad}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
