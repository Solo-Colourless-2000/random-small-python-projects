"""Fifth edition: semantics, pedagogy, and source-to-manual regression tests."""
from pathlib import Path
from bs4 import BeautifulSoup
from fractions import Fraction
import json
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
PROJECTS = sorted((ROOT / 'projects').glob('*.py'))
MANUAL = ROOT / 'python_10_projects_day03_manual.html'


def run(number, *args, stdin=''):
    return subprocess.run([sys.executable,str(PROJECTS[number-1]),*args],
                          text=True,input=stdin,capture_output=True,timeout=8,cwd=ROOT)


class FifthReview(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.soup = BeautifulSoup(MANUAL.read_text(encoding='utf-8'), 'html.parser')

    def test_bespoke_traces_and_learning_warnings_ten_projects(self):
        for n in range(1,11):
            with self.subTest(project=n):
                container = self.soup.select_one(f'#fifth-deep-dive-{n:02d}')
                self.assertIsNotNone(container)
                self.assertEqual(len(container.select('table.fifth-worked-trace thead th')),4)
                self.assertGreaterEqual(len(container.select('table.fifth-worked-trace tbody tr')),3)
                self.assertIn('\u9593\u9055\u3048\u3084\u3059\u3044\u70b9', container.get_text())
                self.assertIn('\u7df4\u7fd2\uff1a',container.get_text())
                self.assertIn('\u8aad\u307f\u89e3\u304f\u30dd\u30a4\u30f3\u30c8',container.get_text())

    def test_line_by_line_contextual_semantics_still_correspond(self):
        for n in range(1,11):
            f = PROJECTS[n-1]
            source = f.read_text(encoding='ascii')
            code = self.soup.select_one(f'#src{n:02d}').get_text()
            self.assertEqual(source,code)
            self.assertEqual(source,''.join(self.soup.select_one(f'#p{n:02d}-chunk{i}').get_text() for i in range(1,5)))
            for scope in (f'#p{n:02d} table.line-explanation-table tbody tr',f'#full-{n:02d} table.line-explanation-table tbody tr'):
                rows=self.soup.select(scope)
                self.assertEqual(len(rows),sum(bool(line.strip()) for line in source.splitlines()))
                self.assertTrue(all(r.select_one('details.syntax-breakdown') for r in rows))

    def test_error_warnings_and_removed_wrong_json_claim(self):
        p7=self.soup.select_one('#p07').get_text(' ',strip=True)
        self.assertIn('\u91cd\u8907\u3092\u691c\u51fa\u3057\u3001\u51fa\u529b\u3092\u4f5c\u3089\u305a\u7d42\u4e862\u3067\u62d2\u5426',p7)
        self.assertIn('JSON\u306e\u6587\u5b57\u5217\u3068\u3057\u3066\u6587\u6cd5\u304c\u6b63\u3057\u304f\u3066\u3082',p7)
        self.assertNotIn('\u5916\u90e8\u304b\u3089\u53d7\u3051\u53d6\u308bJSON\u3067\u306f\u305d\u306e\u5236\u9650\u306b\u3082\u6ce8\u610f\u3057\u307e\u3059\u3002',p7)
        p6=self.soup.select_one('#p06').get_text(' ',strip=True)
        self.assertIn('\u6539\u884c\u3092\u6b63\u898f\u5316\u3057\u305f\u5f8c\u306e\u6587\u5b57\u6570',p6)
        self.assertIn('\u30d0\u30a4\u30c8\u6570\u3084\u30d5\u30a1\u30a4\u30eb\u306e\u751f\u30c7\u30fc\u30bf\u306e\u6587\u5b57\u6570',p6)

    def test_bespoke_contextual_parentheses_and_keyword_args(self):
        rows=self.soup.select('#appendix-a table.line-explanation-table tbody tr')
        terms={}
        for row in rows:
            tds=row.find_all('td',recursive=False)
            if len(tds)!=3:continue
            code=tds[1].get_text(' ',strip=True)
            if code not in terms:terms[code]=tds[2].get_text(' ',strip=True)
        self.assertIn('\u4eee\u5f15\u6570\u4e00\u89a7',terms['def main():'])
        self.assertIn('\u4f8b\u5916\u578b\u3092\u3072\u3068\u307e\u3068\u3081',terms['except (OSError, UnicodeError):'])
        self.assertIn('\u30bf\u30d7\u30eb',terms['for text in (sys.argv[1], sys.argv[3]):'])
        self.assertIn('\u30ad\u30fc\u30ef\u30fc\u30c9\u5f15\u6570',terms['tasks = json.loads(text, object_pairs_hook=reject_duplicate_keys)'])
        self.assertIn('\u30b9\u30e9\u30a4\u30b9',terms['merged.extend(left[i:])'])
        self.assertIn('f\u6587\u5b57\u5217',terms['print(f"0: {state}")'])

    def test_bit_model_and_ascii_caveat(self):
        result=run(1,'13')
        self.assertEqual((result.returncode,result.stdout.splitlines()[-1]),(0,'On bits: 3'))
        self.assertEqual(run(1,'\uff11\uff12').returncode,0)  # int accepts some Unicode decimal digits.
        self.assertEqual(run(1,'256').returncode,2)

    def test_sorted_merge_accepts_unicode_int_but_preserves_counts(self):
        result=run(5,'1, 2','\uff13,3')
        self.assertEqual(result.returncode,0)
        self.assertEqual(result.stdout,'Merged: 1 2 3 3\n')
        self.assertEqual(run(5,'2,1','1').returncode,2)

    def test_text_diff_normalized_character_limit_not_byte_limit(self):
        with tempfile.TemporaryDirectory() as tmp:
            left,right=Path(tmp)/'left.txt',Path(tmp)/'right.txt'
            left.write_bytes(b'\r\n'*4096)
            right.write_bytes(b'\n'*4096)
            self.assertEqual(run(6,str(left),str(right)).stdout,'No differences.\n')
            self.assertEqual(run(6,str(left),str(right)).returncode,0)
            left.write_bytes(b'\r\n'*4097)
            self.assertEqual(run(6,str(left),str(right)).returncode,2)

    def test_json_duplicate_keys_nested_or_top_and_no_output(self):
        cases=['[{"name":"A","done":false,"done":true}]',
               '[{"name":"A","name":"B","done":false}]',
               '[{"name":"A","done":false,"other":{"k":1,"k":2}}]']
        with tempfile.TemporaryDirectory() as tmp:
            a=Path(tmp)/'in.json';b=Path(tmp)/'out.md'
            for data in cases:
                with self.subTest(data=data):
                    a.write_text(data,encoding='utf-8')
                    p=run(7,str(a),str(b))
                    self.assertEqual((p.returncode,p.stderr),(2,''))
                    self.assertFalse(b.exists())
            a.write_text('[{"name":"A","done":true}]',encoding='utf-8')
            self.assertEqual(run(7,str(a),str(b)).returncode,0)
            self.assertEqual(b.read_bytes(),b'- [x] A\n')
            self.assertEqual(run(7,str(a),str(b)).returncode,1)
            self.assertEqual(b.read_bytes(),b'- [x] A\n')

    def test_queue_split_and_boundary(self):
        r=run(8,stdin='add   Ada\nadd Bob\nnext\nshow\nquit\n')
        self.assertEqual(r.returncode,0)
        self.assertIn('Serving: Ada',r.stdout)
        self.assertIn('Waiting: Bob',r.stdout)
        self.assertEqual(run(8,stdin='show\n'*50).returncode,2)

    def test_fraction_zero_and_rule90_exact_trace(self):
        self.assertEqual(run(9,'1/3','+','1/6').stdout,
                         'Result: 1/2\nNumerator: 1\nDenominator: 2\n')
        self.assertEqual(run(9,'1','/','0/5').returncode,2)
        self.assertEqual(run(9,'10001/10001','+','0').returncode,2)
        self.assertEqual(run(10,'00100','2').stdout,'0: 00100\n1: 01010\n2: 10001\n')


if __name__=='__main__':unittest.main()
