Python day05 | 10 Mini Projects | 2026-11-10
============================================================
Final archive: day05_python_10_projects_20261110_critical_review_34rounds.zip
Start here: python_10_projects_day05_manual.html

WHAT IS INCLUDED
- 10 runnable Python learning tools in projects/
- 20-section Japanese HTML manual with 40 typing stages and a source appendix
- A purpose/use-case explanation before every project
- 30 critical-thinking cases with actual program output (3 per project)
- Sample input files in samples/, exercises in practice/
- 97 passing unittest cases (65 previous + 32 new) in tests/
- 34 substantive review items and browser evidence in verification/
- REVIEW_REPORT.txt for findings, test results, and limitations

FIRST STEPS (run inside the extracted archive directory)
  python3 --version
  pwd
  ls
  mkdir -p practice
  vim practice/01_check_digit.py

In vim press i, type STEP 01-04 from the HTML manual, then Esc, :wq, Enter.
Do not type line numbers or paste the full completed code after the stages.
Run your copy with:
  python3 practice/01_check_digit.py 123
  echo $?

To run the provided reference implementation instead:
  python3 projects/01_check_digit.py 123

Other reference commands:
  python3 projects/02_html_card.py 'A < B & "C"' practice/card.html
  python3 projects/03_moving_average.py 3 2,4,6,8,10
  python3 projects/04_tic_tac_toe.py XXXOO....
  python3 projects/05_insertion_sort.py 4,1,3
  python3 projects/06_undo_note.py < samples/note_input.txt
  python3 projects/07_http_request.py samples/request.txt
  python3 projects/08_ini_filter.py samples/filter.ini 5,12,30,40
  python3 projects/09_newton_root.py 2
  python3 projects/10_dice_table.py 2

The HTML card (Project 02) uses exclusive create mode. Never reuse an existing
output filename when expecting success. Pick a new name such as card_2.html.
All paths above are relative to this folder, not to the HTML opened in browser.

Status codes: 0 = success, 1 = I/O or interruption, 2 = invalid input/limit.
Program output, source comments, filenames, commands and test code are ASCII.
Japanese text appears in the HTML teaching material and verification records.

TESTS
  python3 -m unittest discover -s tests -v

Project 06 has an interrupt test and file permission test that should be run as
an ordinary POSIX user, rather than as root, to avoid skipping relevant cases.
The original files are preserved in projects/. The 30 special input exercises
use separate temporary workspaces during automated verification.

REQUIREMENTS / LIMITS
- Python >= 3.10, standard library only; no pip modules for student use.
- Base instructions focus on Linux and vim/nvim. Screenshots are not required.
- This is training software, not production security or network software.
- HTTP parsing deliberately accepts a restricted educational grammar; a
  reported success does not prove formal HTTP compliance or valid DNS names.
- A Luhn check digit detects some data entry mistakes, not identity or integrity.
- Python 3.10 syntax checking is not Python 3.10 runtime testing.
- Audit procedures, failures corrected and environment are in REVIEW_REPORT.txt.
