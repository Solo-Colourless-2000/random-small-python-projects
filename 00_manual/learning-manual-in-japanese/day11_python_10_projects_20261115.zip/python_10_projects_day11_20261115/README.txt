Pythonペネトレーションテスト実習 day11
作成日 2026-11-15（日本時間）

最初に python_10_projects_day11_manual.html をブラウザーで開いてください。
ZIPを展開し、ターミナルを python_10_projects_day11_20261115/ に移動します。
現在地を pwd で、projects/ と samples/ が見えることを ls で確認します。

python3 --version
pwd
ls
mkdir -p practice
vim practice/01_option_boundary.py

vimでは i で入力を開始し、Esc で戻って :wq とEnterで保存します。
字下げは半角スペース4個。全4工程を同じ実習ファイルへ追記します。
vimはnvimに置き換えられます。完成版はprojects/、自分で書く場所はpractice/です。

python3 practice/01_option_boundary.py option

完成版の試験入力（教材ルートで実行）
python3 projects/01_option_boundary.py option
python3 projects/02_response_crlf.py split
python3 projects/03_xml_namespace.py foreign
python3 projects/04_zip_duplicate.py duplicate
python3 projects/05_acl_order.py blocked
python3 projects/06_regex_partitions.py short
python3 projects/07_snapshot_alias.py shallow
python3 projects/08_transaction_stop.py early
python3 projects/09_udp_ratio.py small
python3 projects/10_short_reads.py fragmented

同じコマンドを再実行できます。配布物への書き込みはありません。
CLIは固定ケース名だけを受け取ります。
全入力は公開fixture。09のみ自作のIPv4ループバックUDPへ1要求・1応答します。その他はオフラインのメモリ内実験です。
終了値は0が実験完了、2が入力・構造の失敗、08のDB・09の通信自体の失敗は1です。

python3 -m unittest discover -s tests -v

点検の範囲と実行環境は REVIEW_REPORT.txt、詳細は verification/ を参照してください。
次回はday12です。
