import json
import sys

CASES = {"name": '{"display":"Alicia"}', "role": '{"display":"Alicia","role":"admin"}', "empty": '{}'}
BASE = {"display": "Alice", "role": "reader"}


def apply_update(raw, restricted):
    changes = json.loads(raw)
    result = BASE.copy()
    for key, value in changes.items():
        if not restricted or key == "display":
            result[key] = value
    return result


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script name|role|empty", file=sys.stderr)
        return 2
    raw = CASES[sys.argv[1]]
    weak = apply_update(raw, False)
    guarded = apply_update(raw, True)
    print(f"All fields: {weak['display']} / {weak['role']}")
    print(f"Allowed fields: {guarded['display']} / {guarded['role']}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
