import sys

CASES = {"masked": bytes.fromhex("8183010203044d4341"), "plain": bytes.fromhex("81034c4142"), "short": bytes.fromhex("8183010203044d")}


def inspect(frame):
    if len(frame) < 2 or frame[0] != 0x81:
        raise ValueError("Unsupported header.")
    masked = bool(frame[1] & 0x80)
    length = frame[1] & 0x7f
    offset = 6 if masked else 2
    if length > 20 or len(frame) != offset + length:
        raise ValueError("Invalid lab length.")
    payload = bytearray(frame[offset:])
    if masked:
        key = frame[2:6]
        for index in range(length):
            payload[index] ^= key[index % 4]
    return bytes(payload).decode("ascii"), masked


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script masked|plain|short", file=sys.stderr)
        return 2
    try:
        text, allowed = inspect(CASES[sys.argv[1]])
    except ValueError:
        print("Invalid lab WebSocket frame.", file=sys.stderr)
        return 2
    print(f"Payload: {text}")
    print(f"Client mask rule: {allowed}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
