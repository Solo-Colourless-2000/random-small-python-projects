import json
import string
import sys
from pathlib import Path

ALLOWED = string.ascii_letters + string.digits + " -"


def reject_duplicate_keys(pairs):
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError("Duplicate JSON key")
        result[key] = value
    return result


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 07_json_checklist.py input.json output.md")
        return 2
    try:
        with Path(sys.argv[1]).open("r", encoding="utf-8") as stream:
            text = stream.read(4097)
        if len(text) > 4096:
            raise ValueError
        tasks = json.loads(text, object_pairs_hook=reject_duplicate_keys)
    except (OSError, UnicodeError):
        print("Error: cannot read the UTF-8 input.")
        return 1
    except ValueError:
        print("Error: use valid JSON within 4096 characters.")
        return 2
    if not isinstance(tasks, list) or not 1 <= len(tasks) <= 8:
        print("Error: use a list of 1-8 tasks.")
        return 2
    lines = []
    for task in tasks:
        if not isinstance(task, dict) or set(task) != {"name", "done"}:
            print("Error: each task needs name and done only.")
            return 2
        name = task["name"]
        if not isinstance(name, str) or not 1 <= len(name) <= 30:
            print("Error: name needs 1-30 characters.")
            return 2
        if not name.strip() or any(ch not in ALLOWED for ch in name):
            print("Error: name needs ASCII letters, digits, spaces or hyphens.")
            return 2
        if not isinstance(task["done"], bool):
            print("Error: done must be true or false.")
            return 2
        mark = "x" if task["done"] else " "
        lines.append(f"- [{mark}] {name}")
    try:
        with Path(sys.argv[2]).open("x", encoding="utf-8", newline="\n") as stream:
            stream.write("\n".join(lines) + "\n")
    except OSError:
        print("Error: cannot create output; choose a new path.")
        return 1
    print(f"Saved: {sys.argv[2]}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
