import sys


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 03_moving_average.py width values")
        return 2
    try:
        if len(sys.argv[1]) > 2 or len(sys.argv[2]) > 40:
            raise ValueError
        width = int(sys.argv[1])
        values = []
        for part in sys.argv[2].split(","):
            value = int(part)
            if not 0 <= value <= 100:
                raise ValueError
            values.append(value)
        if not 1 <= width <= 5 or not width <= len(values) <= 10:
            raise ValueError
    except ValueError:
        print("Error: width 1-5; use width to 10 integers from 0 to 100.")
        return 2
    for start in range(len(values) - width + 1):
        window = values[start:start + width]
        average = sum(window) / width
        end = start + width - 1
        print(f"Window {start}-{end}: {average:.2f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
