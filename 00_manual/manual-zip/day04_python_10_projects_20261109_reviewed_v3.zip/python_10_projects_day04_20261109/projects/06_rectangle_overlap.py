import sys


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 06_rectangle_overlap.py x1,y1,x2,y2 x1,y1,x2,y2")
        return 2
    rectangles = []
    try:
        for text in sys.argv[1:]:
            if len(text) > 20:
                raise ValueError
            parts = text.split(",")
            if len(parts) != 4:
                raise ValueError
            values = []
            for part in parts:
                value = int(part)
                if not -20 <= value <= 20:
                    raise ValueError
                values.append(value)
            x1, y1, x2, y2 = values
            if x1 >= x2 or y1 >= y2:
                raise ValueError
            rectangles.append(values)
    except ValueError:
        print("Error: use four integers -20..20 with x1<x2 and y1<y2.")
        return 2
    first, second = rectangles
    left = max(first[0], second[0])
    right = min(first[2], second[2])
    bottom = max(first[1], second[1])
    top = min(first[3], second[3])
    width = max(0, right - left)
    height = max(0, top - bottom)
    print(f"Width: {width}")
    print(f"Height: {height}")
    print(f"Area: {width * height}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
