import sys

FIRST = b"ROLE=USR"
SECOND = b"ROLE=ADM"
KEY = b"LAB-KEY!"
OTHER = b"ALT-KEY!"


def xor(left, right):
    if len(left) != len(right):
        raise ValueError("Lengths differ.")
    result = bytearray()
    for a, b in zip(left, right):
        result.append(a ^ b)
    return bytes(result)


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ("reuse", "separate"):
        print("Usage: script reuse|separate", file=sys.stderr)
        return 2
    first_cipher = xor(FIRST, KEY)
    second_key = KEY if sys.argv[1] == "reuse" else OTHER
    second_cipher = xor(SECOND, second_key)
    recovered = xor(xor(first_cipher, second_cipher), FIRST)
    print(f"Recovered bytes: {recovered.hex()}")
    print(f"Matches second plaintext: {recovered == SECOND}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
