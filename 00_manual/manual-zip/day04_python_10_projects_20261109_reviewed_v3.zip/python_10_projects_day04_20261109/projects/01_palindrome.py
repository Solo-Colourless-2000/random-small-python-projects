import string
import sys


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 01_palindrome.py text")
        return 2
    text = sys.argv[1]
    if not 1 <= len(text) <= 80:
        print("Error: use 1-80 letters and spaces.")
        return 2
    for character in text:
        if character not in string.ascii_letters + " ":
            print("Error: use ASCII letters and spaces only.")
            return 2
    cleaned = text.lower().replace(" ", "")
    if not cleaned:
        print("Error: include at least one letter.")
        return 2
    backward = cleaned[::-1]
    print(f"Normalized: {cleaned}")
    print(f"Reversed: {backward}")
    if cleaned == backward:
        print("Palindrome")
    else:
        print("Not a palindrome.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
