from io import BytesIO
import sys
import warnings
import zipfile


def inspect_archive(duplicate):
    with BytesIO() as memory:
        with warnings.catch_warnings():
            warnings.filterwarnings("ignore", message="Duplicate name:.*", category=UserWarning)
            with zipfile.ZipFile(memory, "w") as archive:
                archive.writestr("config.txt", b"mode=safe")
                if duplicate:
                    archive.writestr("config.txt", b"mode=debug")
        with zipfile.ZipFile(memory, "r") as archive:
            infos = archive.infolist()
            first = archive.read(infos[0])
            by_name = archive.read("config.txt")
            names = set()
            for info in infos:
                names.add(info.filename)
        return first, by_name, len(names) == len(infos)


def main():
    cases = {"duplicate": True, "single": False}
    if len(sys.argv) != 2 or sys.argv[1] not in cases:
        print("Usage: script duplicate|single", file=sys.stderr)
        return 2
    first, used, unique = inspect_archive(cases[sys.argv[1]])
    print(f"First member: {first.decode('ascii')}")
    print(f"By-name member: {used.decode('ascii')}")
    print(f"Unique-name gate: {unique}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
