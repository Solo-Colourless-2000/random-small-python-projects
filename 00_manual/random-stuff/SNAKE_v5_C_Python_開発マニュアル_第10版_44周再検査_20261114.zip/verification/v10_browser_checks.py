from pathlib import Path
from playwright.sync_api import sync_playwright
import json,time,traceback
R=Path(__file__).resolve().parent.parent
f=next(R.glob('*.html'))
out=R/'verification'/'v10_browser_previews';out.mkdir(exist_ok=True)
report={'file':f.name,'checks':[],'errors':[],'screenshots':[],'environment':'Chromium via page.set_content; file:// blocked by administrator; storage and clipboard emulated'}
HTML=f.read_text(encoding='utf8')
STUB="""() => { const values={}; Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:(k)=>values[k]??null,setItem:(k,v)=>{values[k]=String(v);},removeItem:(k)=>{delete values[k];}}}); Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:async(t)=>{window.__copied=t}}}); }"""
def add(width,name,ok,detail=None):
 report['checks'].append({'width':width,'test':name,'passed':bool(ok),'detail':str(detail) if detail is not None else ''})
try:
 with sync_playwright() as p:
  browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  for width in (1440,1024,768,393,360):
   page=browser.new_page(viewport={'width':width,'height':900},device_scale_factor=1)
   page.on('pageerror', lambda e: report['errors'].append(str(e)))
   page.evaluate(STUB)
   page.set_content(HTML,wait_until='load',timeout=30000)
   add(width,'headings visible',page.locator('h1').count()>0)
   dimensions=page.evaluate('({doc:document.documentElement.scrollWidth,window:window.innerWidth})')
   add(width,'whole-page width fits viewport',dimensions['doc']<=dimensions['window']+1,dimensions)
   if width==1440:
    page.locator('[data-target="phase-03"]').click()
   else:
    page.locator('#menuButton').click()
    add(width,'mobile drawer opened',page.locator('#sidebar').evaluate('(e)=>e.classList.contains("open")'))
    page.locator('#sidebar [data-target="phase-03"]').click()
    add(width,'mobile drawer closes on chapter selection',not page.locator('#sidebar').evaluate('(e)=>e.classList.contains("open")'))
   add(width,'chapter navigation',page.locator('#phase-03').evaluate('(e)=>e.classList.contains("active")'))
   # Verify source code samples are inside their own scrolling region rather than overflowing entire page.
   clipped=page.evaluate('''() => {const el=document.querySelector('#phase-03 .code-wrap pre');return el && getComputedStyle(el).overflowX !== 'visible'}''')
   add(width,'source code isolated horizontally',clipped)
   page.screenshot(path=str(out/f'v10_phase3_{width}.png'))
   report['screenshots'].append(f'v10_phase3_{width}.png')
   page.locator('#searchButton').click()
   add(width,'search input visible',page.locator('#searchInput').is_visible())
   page.locator('#searchInput').fill('snake_tick')
   add(width,'search returns results',page.locator('#searchResults .search-result').count()>0)
   page.keyboard.press('Escape') if width==1440 else page.locator('#searchClose').click()
   if width==1440:
    page.locator('[data-target="prototype"]').click()
    box=page.locator('input[data-progress]').first
    old=box.is_checked();box.check() if not old else box.uncheck();new=box.is_checked()
    page.set_content(HTML,wait_until='load')
    add(width,'progress localStorage persists',page.locator('input[data-progress]').first.is_checked()==new)
    # Undo the modification for screenshots unaffected by manual reading progress.
    box=page.locator('input[data-progress]').first
    box.uncheck() if not old else box.check()
    page.locator('#searchButton').click();page.locator('#searchInput').fill('uint32_t')
    first=page.locator('#searchResults .search-result').first
    add(width,'search finds uint32_t',first.count()>0)
   page.close()
  browser.close()
except Exception as e:
 report['errors'].append(str(e));report['traceback']=traceback.format_exc()
(R/'verification'/'v10_browser_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
print('PASSED',sum(i['passed'] for i in report['checks']),'of',len(report['checks']),'browser checks')
print('Errors:',report['errors'][:3]);print('Failed:',[i for i in report['checks'] if not i['passed']][:10])
if report['errors'] or any(not x['passed'] for x in report['checks']):raise SystemExit(1)
