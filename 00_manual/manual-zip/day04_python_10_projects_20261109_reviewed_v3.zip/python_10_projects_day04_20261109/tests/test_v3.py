"""Self-contained regression tests for the third day04 manual revision."""
from html import unescape
from pathlib import Path
import re
import shlex
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
HTML = ROOT / 'python_10_projects_day04_manual.html'
MANUAL = HTML.read_text(encoding='utf-8')


def lab(number):
    token = f'id="v3-lab-{number:02d}"'
    section = MANUAL.split(token, 1)[1].split('</section>', 1)[0]
    code = [unescape(part) for part in re.findall(r'<pre><code[^>]*>(.*?)</code></pre>', section, re.DOTALL)]
    if len(code) != 2:
        raise AssertionError(f'Lab {number} has {len(code)} code blocks, expected 2')
    return code


class NewLessons(unittest.TestCase):
    def test_01_new_lab(self): self.exercise(1)
    def test_02_new_lab(self): self.exercise(2)
    def test_03_new_lab(self): self.exercise(3)
    def test_04_new_lab(self): self.exercise(4)
    def test_05_new_lab(self): self.exercise(5)
    def test_06_new_lab(self): self.exercise(6)
    def test_07_new_lab(self): self.exercise(7)
    def test_08_new_lab(self): self.exercise(8)
    def test_09_new_lab(self): self.exercise(9)
    def test_10_new_lab(self): self.exercise(10)

    def exercise(self, number):
        command, expected = lab(number)
        parts = shlex.split(command.strip())
        self.assertEqual(parts[0], 'python3')
        path = ROOT / parts[1]
        self.assertTrue(path.is_file())
        self.assertEqual(number, int(path.name[:2]))
        with tempfile.TemporaryDirectory() as work:
            wd = Path(work)
            (wd / 'practice').mkdir()
            # The supplemental roster example reads the bundled sample files.
            cwd = wd if number == 8 else ROOT
            data = 'scissors\n' if number == 9 else ''
            result = subprocess.run([sys.executable, str(path), *parts[2:]], cwd=cwd,
                                    input=data, text=True, capture_output=True, timeout=10)
            self.assertEqual(result.returncode, 0, result.stderr)
            self.assertEqual(result.stdout, expected)
            self.assertEqual(result.stderr, '')
            if number == 8:
                output = wd / 'practice/tone_440_125.wav'
                self.assertEqual(len(output.read_bytes()), 2044)
                # Invoking again must not replace the original file.
                original = output.read_bytes()
                retry = subprocess.run([sys.executable, str(path), *parts[2:]], cwd=wd,
                                       input='', text=True, capture_output=True, timeout=10)
                self.assertEqual(retry.returncode, 1)
                self.assertEqual(output.read_bytes(), original)

    def test_11_numeric_grammar_claim(self):
        self.assertEqual(int('1_0'), 10)
        self.assertEqual(int('\uff11\uff12'), 12)
        with self.assertRaises(ValueError): int('1.0')
        for phrase in ('int("1_0")', 'int("\uff11\uff12")', 'int("1.0")'):
            self.assertIn(phrase, MANUAL)

    def test_12_explanation_of_length_rejection(self):
        snippets = re.findall(r'<tr><td>24</td><td>\s+raise ValueError</td><td>(.*?)</td></tr>', MANUAL)
        snippets = [x for x in snippets if '\u540d\u524d\u306e\u9577\u3055\u304c0\u6587\u5b57' in x]
        self.assertEqual(len(snippets), 2)
        self.assertTrue(all('13\u6587\u5b57\u4ee5\u4e0a' in x for x in snippets))
        self.assertTrue(all('25\u301c26\u884c' in x for x in snippets))

    def test_13_corrected_cycle_and_geometry(self):
        self.assertIn('\u958b\u59cb\u6642\u523b0\u5206', MANUAL)
        self.assertIn('\u3082\u3046\u4e00\u65b9\u304c0\u306a\u3089\u9762\u7a4d\u306f0', MANUAL)

    def test_14_new_samples_and_manual_links(self):
        self.assertEqual((ROOT / 'samples/roster_extra_a.txt').read_bytes(), b' Ada \nBOB\nbob\n')
        self.assertEqual((ROOT / 'samples/roster_extra_b.txt').read_bytes(), b'ada\nEVE\n')
        self.assertEqual(MANUAL.count('class="v3-lab card"'), 10)
        self.assertEqual(MANUAL.count('class="v3-inline-fact"'), 1)
        self.assertIn('day04_python_10_projects_20261109_reviewed_v3.zip', MANUAL)
        self.assertNotIn('day04_python_10_projects_20261109_reviewed_v2.zip', MANUAL)

    def test_15_lab_markup_consistency(self):
        for number in range(1,11):
            with self.subTest(number=number):
                start = MANUAL.index(f'id="v3-lab-{number:02d}"')
                section = MANUAL[start:MANUAL.index('</section>', start)]
                self.assertEqual(section.count('class="copy js-only"'), 2)
                self.assertEqual(section.count('class="copy-fallback"'), 2)
                self.assertEqual(section.count('<details>'), 1)
                self.assertEqual(section.count('<summary>'), 1)
                command, expected = lab(number)
                self.assertTrue(command.endswith('\n'))
                self.assertTrue(expected.endswith('\n'))


if __name__ == '__main__':
    unittest.main()
