"""Additional long-form randomized gameplay verification, without Tk GUI."""
from __future__ import annotations
import math
import random
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from constants import ARENA_BOTTOM, ARENA_LEFT, ARENA_RIGHT, ARENA_TOP
from support import create_game

TOTAL = 0
for seed in (31, 44, 67, 121, 216, 535):
    g = create_game(seed)
    rng = random.Random(seed * 712 + 11)
    g.player.invulnerable = 999
    for frame in range(3600):
        if frame % 33 == 0:
            g.keys = {rng.choice(('w', 's', 'a', 'd', 'left', 'right', 'up', 'down'))}
        if frame % 83 == 0:
            g.dash()
        if frame % 107 == 0:
            g.pulse()
        if frame % 137 == 0:
            g.mouse_down = not g.mouse_down
        if g.enemies and frame % 2 == 0:
            e = min(g.enemies, key=lambda e: (e.x - g.player.x) ** 2 +
                    (e.y - g.player.y) ** 2)
            g.mouse_x, g.mouse_y = e.x, e.y
        g.tick(1 / 60)
        if g.state == 'upgrade':
            assert len(g.upgrades_offered) == 3
            g.apply_upgrade(rng.randrange(3))
        assert g.state == 'playing'
        p = g.player
        assert 0 <= p.hp <= p.max_hp and 0 <= p.energy <= 100
        assert ARENA_LEFT + p.radius <= p.x <= ARENA_RIGHT - p.radius
        assert ARENA_TOP + p.radius <= p.y <= ARENA_BOTTOM - p.radius
        assert len(g.particles) <= 300
        assert len({e.uid for e in g.enemies}) == len(g.enemies)
        assert all(math.isfinite(b.x) and math.isfinite(b.y) for b in g.bullets)
        assert all(not e.dead and e.hp > 0 for e in g.enemies)
        TOTAL += 1
    print(f'Seed {seed}: 3600 frames, wave {g.wave}, kills {g.total_kills}, score {g.score}')
print(f'ADVERSARIAL CAMPAIGN: {TOTAL} frames, all invariants passed')
