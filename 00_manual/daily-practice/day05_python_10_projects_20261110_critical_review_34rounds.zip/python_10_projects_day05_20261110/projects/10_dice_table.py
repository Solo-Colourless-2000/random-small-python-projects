import sys


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 10_dice_table.py faces")
        return 2
    try:
        if len(sys.argv[1]) > 2:
            raise ValueError
        faces = int(sys.argv[1])
        if not 2 <= faces <= 6:
            raise ValueError
    except ValueError:
        print("Error: faces must be an integer from 2 to 6.")
        return 2
    counts = {}
    for first in range(1, faces + 1):
        for second in range(1, faces + 1):
            score = first + second
            counts[score] = counts.get(score, 0) + 1
    total = faces ** 2
    for score in range(2, 2 * faces + 1):
        percent = counts[score] / total * 100
        print(f"Sum {score}: {counts[score]}/{total} = {percent:.1f}%")
    print(f"Outcomes: {total}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
