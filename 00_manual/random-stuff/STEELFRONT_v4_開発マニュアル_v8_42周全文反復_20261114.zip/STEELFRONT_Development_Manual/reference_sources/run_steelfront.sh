#!/bin/sh
cd "$(dirname "$0")" || exit 1
if command -v python3 >/dev/null 2>&1; then
    exec python3 main.py
fi
printf '%s\n' 'Python 3 is not installed. See README.md.' >&2
exit 1
