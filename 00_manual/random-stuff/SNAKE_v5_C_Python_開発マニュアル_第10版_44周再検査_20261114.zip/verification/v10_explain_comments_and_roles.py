from pathlib import Path
from bs4 import BeautifulSoup
import re,json
R=Path(__file__).resolve().parent.parent
DOC=next(R.glob('*.html'));s=BeautifulSoup(DOC.read_text(encoding='utf8'),'html.parser')
ROLES={
'experiments/grid_probe.py:draw':'試作のキャンバス描画を消してから、マス目と現在のpositionにある1マスを描き直す',
'experiments/grid_probe.py:on_key':'Tkのキーイベントから上下左右の入力を読み、positionを盤面範囲内で更新してdrawを呼ぶ',
'build.py:library_path':'実行OSに合わせてsnake_core.dll/libsnake_core.so/libsnake_core.dylibの出力パスを返す',
'build.py:compiler_candidates':'環境変数CCとgcc/clang/ccを候補にし、PATHで実在するコンパイラだけを返す',
'snake_app/engine.py:_validated_seed':'Noneならシードを新たに作り、それ以外はboolを拒否して32ビット符号なし整数の範囲を検査する',
'snake_app/engine.py:__init__':'引数の盤面サイズを検査し、Cライブラリを読み込み、座標配列とゲームポインタを確保する',
'snake_app/engine.py:close':'C側のSnakeGameポインタを一度だけ解放し、以降の操作では閉鎖済みエラーとする',
'snake_app/engine.py:__enter__':'with構文の開始時にエンジン自身を返す',
'snake_app/engine.py:__exit__':'with構文を抜けるときcloseを呼びCの確保領域を解放する',
'snake_app/engine.py:_handle':'Cのハンドルが存在するか確認してから返す。close後には使えない',
'snake_app/engine.py:reset':'乱数seedを検査してCのsnake_resetへ渡し、体とスコアを初期化する',
'snake_app/engine.py:turn':'Directionの値だけを受け付けてCへ渡し、方向予約の受理結果をboolで返す',
'snake_app/config.py:game_interval':'難易度ごとの初期移動間隔を元に、スコアによる加速を適用し下限を守って秒数を返す',
'snake_app/config.py:animation_progress':'前の論理tickから現在までの経過時間を0〜1へ丸め、描画を滑らかに補間する',
'snake_app/storage.py:save_path':'Windows/macOS/Linuxごとのユーザーデータディレクトリを選び、SnakeCPython/highscores.jsonのPathを返す',
'snake_app/renderer.py:__init__':'TkのCanvasを受け取り、描画に使う参照とボタンのヒットボックス一覧を保持する',
'snake_app/renderer.py:_rounded_rect':'角丸形状の制御点を計算してCanvasに多角形を描く',
'snake_app/renderer.py:_text':'テキスト文字列と座標・色・フォントをCanvasへ渡して描く',
'snake_app/renderer.py:_button':'見た目のボタンを描き、クリック判定矩形とactionを登録する',
'snake_app/renderer.py:draw':'現在のRenderStateをCanvasに描き直し、クリック可能領域のHitboxリストを返す',
'snake_app/renderer.py:_animation_progress':'最後の移動からの時間を補間値へ変え、蛇の移動アニメーションに渡す',
'snake_app/renderer.py:_draw_snake':'蛇の体の各セルを描画し、前後フレームの位置を補間する',
'snake_app/renderer.py:_draw_eyes':'頭と方向に応じて目の位置を変えCanvasへ描く',
'snake_app/renderer.py:_draw_food':'餌をCanvasに描き、食べた瞬間の表示も必要に応じて残す',
'snake_app/renderer.py:_draw_overlay':'メニュー、ポーズ、ゲーム終了の状態に合わせて画面の上に案内を表示する',
'snake_app/ui.py:__init__':'Tkウィンドウ、Cエンジン、描画器、スコア保存を束ね、途中の例外時には所有リソースを適切に解放する',
'snake_app/ui.py:run':'Tkのmainloopへ入り、ウィンドウが閉じるまでイベントを処理する',
'snake_app/ui.py:_save_if_dirty':'未保存スコアをロック付きで保存し、失敗時には警告を残す',
'snake_app/ui.py:close':'予約済みのafterを取り消し、所有しているエンジン・Tkウィンドウを片付ける',
'snake_app/ui.py:_start':'ゲーム状態をリセットしてplayingへ切り替え、時間と描画用Frameを更新する',
'snake_app/ui.py:_menu':'スコアを保存してエンジンをリセットし、メニューへ戻る',
'snake_app/ui.py:_pause_toggle':'playingとpausedを切り替え、再開時の移動時計を現在に合わせる',
'snake_app/ui.py:_on_focus_out':'プレイ中にフォーカスを失ったらAUTO-PAUSEDへ移行させる',
'snake_app/ui.py:_set_cursor':'ボタン上かどうかに応じてマウスポインタの形を更新する',
'snake_app/ui.py:_on_canvas_click':'クリック位置とヒットボックスを比較し、開始・再開・難易度選択を振り分ける',
'snake_app/ui.py:_on_canvas_motion':'マウス位置がボタン矩形内か確認しカーソルを変える',
'snake_app/ui.py:_on_canvas_leave':'Canvasから離れたマウスのカーソル表示を通常へ戻す',
'snake_app/ui.py:_interval':'現在の難易度と得点から移動間隔を計算する',
'snake_app/ui.py:_animation_progress':'現在時刻とlast_stepから描画の進み具合を計算する',
'snake_app/ui.py:_loop':'移動時計から必要tick数を求め、上限付きで移動し、保存・描画・次回予約を行う',
'snake_app/ui.py:_draw':'Frameから描画用RenderStateを作りRenderer.drawに渡す',
'snake_app/ui.py:_choose':'メニューにいる間だけEASY/NORMAL/HARDの選択を受け付ける',
'main.py:main':'CビルドとGUIの読み込み・起動を処理し、失敗時には読みやすいエラーメッセージを返す',
'tests/test_architecture.py:imported_modules':'Pythonのソースを解析してimportしているモジュールの集合を取り出す',
'tests/test_engine.py:engine':'テスト用SnakeEngineを構築し、後片付け対象へ登録する',
'tests/test_ui.py:close':'テスト内で外部から渡したモックエンジンが閉じられたかを記録する',
'tests/test_ui.py:new_root':'GUIテスト用に新しいTkルートを生成し、表示できることを確認する',
}
COMMENT={
'build.py:37':'環境変数CCの書式が壊れていても、標準候補のgcc/clang/ccを探す処理まで止めないという設計意図。',
'build.py:58':'共有ライブラリは完成パスへ直接書かず、一時フォルダで別名のままビルドするという方針。',
'build.py:59':'コンパイルが途中で中断しても、次回起動が不完全な共有ライブラリを読み込まないようにする理由。',
'snake_app/engine.py:63':'OSやCPU構成を変更したあと、古い共有ライブラリを読み込めなければ強制再ビルドを試みる。',
'snake_app/config.py:18':'画面更新頻度が多少変わっても、経過時間に応じた移動を追い付かせる設計。ただし回数には上限を設ける。',
'snake_app/config.py:19':'PCのスリープ復帰などで長時間経過した場合、遅れた移動を一気に実行して連続死亡させないため。',
'snake_app/engine.py:95':'Pythonの大きすぎる整数をctypesへ渡して切り詰められる前に、盤面サイズを検証するという意図。',
'snake_app/engine.py:100':'C側でゲーム領域を確保する前に、Python側のFrame取得用配列を用意する順序の理由。',
'snake_app/engine.py:101':'Python側の確保がMemoryErrorになっても、まだCのゲーム領域を確保していないのでネイティブメモリが残らない。',
'snake_app/config.py:44':'時間設定が異常でも0除算や不正補間で描画ループが落ちないようガードする目的。',
'snake_app/storage.py:54':'Windowsのmsvcrt.lockingはファイルの現在位置からバイト範囲をロックする、という重要な前提。',
'snake_app/storage.py:55':'初めての保存で.lockが空ファイルでも、ロック対象となる1バイトを作ってからロックする。',
'snake_app/storage.py:84':'一時ファイルへ書いてから原子的に置換すると、読み手が途中まで書かれたJSONを見にくくなる。',
'snake_app/storage.py:85':'ロック中に既存スコアを再読込・統合するのは、別プロセスで高得点が記録されたときの更新消失を防ぐため。',
'snake_app/ui.py:35':'初回snapshotまたはスコア読込の失敗も起動失敗として扱い、作りかけのゲームを放置しない。',
'snake_app/ui.py:36':'すでに確保したCエンジンと、自分が作成したTkルートを例外時にも解放する必要がある。',
'snake_app/ui.py:42':'呼出し元から渡されたTkルートやエンジンはGameAppの所有物ではないため勝手に破棄しない。',
'snake_app/ui.py:68':'focus_setはウィンドウマネージャのフォーカス規則に従う。focus_forceは他アプリからフォーカスを奪う恐れがある。',
'snake_app/renderer.py:161':'餌を食べた直後でも、蛇の頭が画面上で餌の位置へ届くまで食べ物の見た目を短く残す。',
'snake_app/ui.py:80':'別のゲームインスタンスが高得点を書いていた可能性があるので、保存時にはファイル側の得点も考慮する。',
'snake_app/ui.py:81':'ディスク上の最新高得点と、このプロセスの表示中スコアの整合性を取るための説明。',
'snake_app/renderer.py:181':'Tkのstippleによる透過調表現はWindows/macOS/X11のTkで利用できるという互換性の注意。',
'main.py:16':'Tkinterのimportを起動処理内に遅延させ、GUIがない環境でも起動失敗の原因を表示できるようにする。',
'snake_app/ui.py:225':'移動するたびにlast_stepをnowへ戻すと、少しずつ端数を捨て、画面更新頻度に移動が引きずられる。',
'snake_app/ui.py:226':'約30FPSなどで125msごとに動くとき、端数の消失による速度低下を避けるため、intervalずつ時刻を進める。',
'snake_app/ui.py:231':'OSのサスペンド復帰やデバッガによる停止は、プレイヤーが操作していた時間として数えない。',
'snake_app/ui.py:232':'長時間停止後は時計を再開時点へ戻し、壁際でも予期しない1マス移動を起こさない。',
'snake_app/ui.py:253':'処理負荷でGUIが遅れたとき、積み残したtickを無制限に消化し続けないための方針。',
'snake_app/ui.py:254':'1フレームで何度も移動し続ける状態が固定化しないよう、最大追いつき回数を制限する。',
'tests/test_architecture.py:59':'アーキテクチャ検査は現プロジェクトの役割分離を守るルールであって、どのゲームにも当てはまる法則ではない。',
'tests/test_engine.py:196':'Hamilton閉路をたどり、実際に生成された餌を食べながら成長して盤面を埋める統合テストの考え方。',
'tests/test_engine.py:197':'成長・衝突回避・勝利条件までを同じテストで追う。餌を人工的に配置するだけの単体テストと区別する。',
'tests/test_campaign.py:12':'8×8の64マスを1回ずつ通過するHamilton閉路を使い、体が伸びても自分に当たらない動線を作る。',
'tests/test_campaign.py:13':'64マスが全てヘビで埋まるまで、通常の餌生成と食事を繰り返して勝利することを確認する。',
'tests/test_model.py:30':'短時間に複数の方向入力を与える厳しい状況で、方向キューの受理・拒否の規則を試す。',
'tests/test_storage.py:104':'読込み→最高点統合の時間を意図的に引き延ばし、同時保存で起こり得る競合を再現する。',
'tests/test_storage.py:105':'os.replaceだけではJSONの破損は防いでも、古い内容に基づく上書き更新の消失までは防げない。',
'tests/test_ui.py:18':'UIテストはプレイヤーのホームにある実際の記録を一切変更しないよう、一時保存先に分離する。',
'tests/test_ui.py:194':'頭のすぐ前に餌が現れる再現可能な乱数seedを探し、食事処理のUIテストを安定させる。',
'tests/test_ui.py:313':'40msごとに画面が更新されるが、蛇は125ms間隔で動く状態を再現して時計の精度を試す。',
'tests/test_ui.py:314':'古い実装が移動を160/320/480msのようなフレーム境界へ丸めた問題を説明している。',
'tests/test_ui.py:315':'修正後は125/250/375msという理論上の移動タイミングを保つ設計を検査する。',
'tests/test_ui.py:338':'長い処理停止から戻った直後、古い実装が意図せずtickを1回進めた問題を示す。',
'tests/test_ui.py:339':'壁際なら意図しない1マス進行がゲームオーバーになるため、時間の停止分を無視する必要がある。',
}
changes=[]
for a in s.select('article.lesson-step'):
 fname=a.h2.get_text(' ',strip=True).split(' L')[0]
 for row in a.select('table.line-analysis tr:has(code.one-line)'):
  code=row.select_one('code.one-line').get_text(' ',strip=True)
  n=int(re.search(r'L(\d+)',row.td.get_text(' ',strip=True)).group(1))
  p=row.select_one('p.syntactic')
  if not p:continue
  old=p.get_text(' ',strip=True)
  if '次の処理が必要な理由や異常時の動作を説明する' in old:
   new=COMMENT.get(f'{fname}:{n}')
   if new:p.string='このコメントは実行されない。'+new; changes.append((fname,n,'translated_comment'))
  if code.startswith('def '):
   m=re.match(r'def\s+(\w+)',code)
   key=fname+':'+m.group(1) if m else ''
   if key in ROLES and 'の機能を提供する' in old:
    p.string=old.replace(m.group(1)+'の機能を提供する。',ROLES[key]+'。')
    changes.append((fname,n,'role'))
  if old=='例外分岐または条件分岐の処理ブロックを開始する。直前のtry/ifとの対応を確認する。':
   q=code.strip()
   if q=='try:':new='tryの下に失敗し得る処理をまとめる。例外が発生したら対応するexceptまたはfinallyへ制御が移る。'
   elif q=='else:':new='直前のif/elifの条件がいずれも偽の場合、次のインデントしたブロックを実行する。tryのelseなら例外なしで完了した場合だけ実行する。'
   elif q=='finally:':new='例外の有無やreturnにかかわらず、後片付けとして次のインデントした処理を実行する。'
   else:new=None
   if new:p.string=new;changes.append((fname,n,'control_flow'))
DOC.write_text(str(s),encoding='utf8')
(R/'verification/v10_comments_roles.json').write_text(json.dumps({'count':len(changes),'items':changes},ensure_ascii=False,indent=2),encoding='utf8')
print('comments roles and blocks corrected',len(changes))
