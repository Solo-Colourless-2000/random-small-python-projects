"""Pure Tkinter Canvas renderer. Shapes and typography, no external art assets."""
from __future__ import annotations
import math
import random
import tkinter as tk
from constants import (
    ARENA_BOTTOM, ARENA_LEFT, ARENA_RIGHT, ARENA_TOP,
    BG, BLUE, CYAN, GREEN, GRID, HEIGHT, MUTED, ORANGE,
    PANEL_EDGE, RED, TEXT, UPGRADES, WIDTH, YELLOW,
)
from mechanics import clamp, format_seconds, unit


class Renderer:
    def __init__(self, canvas: tk.Canvas):
        self.c = canvas
        visual_rng = random.Random(1397)
        self.stars = [(visual_rng.randrange(ARENA_LEFT+12,ARENA_RIGHT-12),
                       visual_rng.randrange(ARENA_TOP+12,ARENA_BOTTOM-12),
                       visual_rng.uniform(.3,2.1),visual_rng.uniform(0,6.28))
                      for _ in range(58)]
        self.sx = self.sy = 0

    def box(self, x1, y1, x2, y2, fill, outline='', width=1):
        self.c.create_rectangle(x1,y1,x2,y2,fill=fill,outline=outline,width=width)

    def line(self, x1,y1,x2,y2,color,width=1, **kwargs):
        self.c.create_line(x1,y1,x2,y2,fill=color,width=width,**kwargs)

    def circle(self,x,y,r,fill='',outline='',width=1):
        self.c.create_oval(x-r,y-r,x+r,y+r,fill=fill,outline=outline,width=width)

    def label(self, x,y,text,size=12,color=TEXT,weight='normal',anchor='center',family='Arial',**kwargs):
        self.c.create_text(x,y,text=text,fill=color,font=(family,size,weight),anchor=anchor,**kwargs)

    def world_circle(self,x,y,r,fill='',outline='',width=1):
        self.circle(x+self.sx,y+self.sy,r,fill,outline,width)

    def world_line(self,x1,y1,x2,y2,color,width=1,**kwargs):
        self.line(x1+self.sx,y1+self.sy,x2+self.sx,y2+self.sy,color,width,**kwargs)

    def world_polygon(self,points,fill='',outline='',width=1):
        coords = []
        for x,y in points:
            coords.extend((x+self.sx,y+self.sy))
        self.c.create_polygon(*coords,fill=fill,outline=outline,width=width)

    @staticmethod
    def poly(x, y, radius, sides, rotation=0):
        return [(x+math.cos(rotation+i*math.tau/sides)*radius,
                 y+math.sin(rotation+i*math.tau/sides)*radius) for i in range(sides)]

    @staticmethod
    def oriented(x, y, angle, local):
        c,s = math.cos(angle),math.sin(angle)
        return [(x+a*c-b*s, y+a*s+b*c) for a,b in local]

    def draw(self, game):
        self.c.delete('all')
        self.sx = self.sy = 0
        self.background(game.global_time)
        if game.state == 'menu':
            self.menu(game)
            return
        if game.shake and game.state == 'playing':
            self.sx = math.sin(game.global_time*109)*game.shake
            self.sy = math.cos(game.global_time*127)*game.shake*.7
        self.draw_world(game)
        self.sx = self.sy = 0
        self.hud(game)
        if game.state == 'playing':
            self.crosshair(game)
            if game.banner_timer:
                self.wave_banner(game)
            if game.notification_time:
                self.label(WIDTH/2,HEIGHT-101,game.notification,size=12,color=GREEN,weight='bold')
            if game.elapsed < 7.5:
                self.label(WIDTH/2,HEIGHT-84,'WASD MOVE    •    MOUSE AIM + HOLD CLICK FIRE    •    SPACE DASH    •    E PULSE',
                           size=10,color=MUTED,weight='bold')
        elif game.state == 'paused':
            self.pause_screen()
        elif game.state == 'upgrade':
            self.upgrade_screen(game)
        elif game.state == 'gameover':
            self.game_over_screen(game)

    def background(self,t):
        c=self.c
        self.box(0,0,WIDTH,HEIGHT,BG)
        self.box(ARENA_LEFT-2,ARENA_TOP-2,ARENA_RIGHT+2,ARENA_BOTTOM+2,'#0a202e',PANEL_EDGE,2)
        self.box(ARENA_LEFT,ARENA_TOP,ARENA_RIGHT,ARENA_BOTTOM,'#071723')
        # Subtle moving technical grid, deliberately subdued behind combat.
        offset = (t*4)%46
        for x in range(ARENA_LEFT+26, ARENA_RIGHT,46):
            self.line(x,ARENA_TOP,x,ARENA_BOTTOM,GRID)
        for y in range(ARENA_TOP+int(offset),ARENA_BOTTOM,46):
            self.line(ARENA_LEFT,y,ARENA_RIGHT,y,GRID)
        for x in range(ARENA_LEFT+26, ARENA_RIGHT,92):
            for y in range(ARENA_TOP+24,ARENA_BOTTOM,92):
                self.circle(x,y,1,'#244253')
        for x,y,r,phase in self.stars:
            intensity = math.sin(t*1.8+phase)
            self.circle(x,y,r*.48 if intensity<0 else r*.72,
                        '#244557' if intensity<0 else '#356276')
        # Arena corner brackets.
        for x,sign in [(ARENA_LEFT+7,1),(ARENA_RIGHT-7,-1)]:
            for y,ysign in [(ARENA_TOP+7,1),(ARENA_BOTTOM-7,-1)]:
                self.line(x,y,x+sign*25,y,CYAN,2)
                self.line(x,y,x,y+ysign*25,CYAN,2)

    def draw_world(self,game):
        for ring in game.rings:
            fraction = ring.life/ring.max_life
            if fraction < .28:
                color = '#294759'
            else:
                color = ring.color
            self.world_circle(ring.x,ring.y,ring.radius,outline=color,
                              width=max(1,int(ring.width*fraction)))
        for item in game.pickups:
            self.draw_pickup(item,game.global_time)
        for b in game.bullets:
            self.world_line(b.x-b.vx*.023,b.y-b.vy*.023,b.x,b.y,
                            b.color,3)
            self.world_circle(b.x,b.y,b.radius,fill=b.color)
        for e in game.enemies:
            self.draw_enemy(e,game)
        self.draw_player(game)
        for p in game.particles:
            fraction = p.ttl/p.max_ttl
            if fraction <= 0:
                continue
            radius = max(.55,p.size*fraction)
            col = p.color if fraction > .32 else '#355366'
            self.world_circle(p.x,p.y,radius,fill=col)

    def draw_player(self,game):
        p = game.player
        dx, dy = unit(game.mouse_x-p.x, game.mouse_y-p.y)
        if not (dx or dy):
            dx, dy = 0, -1
        a = math.atan2(dy, dx)
        if p.dash_time:
            self.world_circle(p.x,p.y,27,outline=CYAN,width=2)
        elif p.invulnerable:
            self.world_circle(p.x,p.y,23,outline=BLUE,width=2)
            self.world_circle(p.x,p.y,29,outline='#28516b')
        # Thruster flicker responds to motion.
        v = math.hypot(p.vx,p.vy)
        if v > 25:
            trail = 12+math.sin(game.global_time*43)*5
            self.world_polygon(self.oriented(p.x,p.y,a,
                [(-13,-8),(-15-trail*.65,0),(-13,8)]), fill='#1d5e7e')
            self.world_polygon(self.oriented(p.x,p.y,a,
                [(-14,-4),(-14-trail,0),(-14,4)]), fill=CYAN)
        self.world_circle(p.x,p.y,21,outline='#226078')
        self.world_polygon(self.oriented(p.x,p.y,a,
            [(21,0),(-9,-14),(-6,-5),(-17,-12),(-13,0),(-17,12),(-6,5),(-9,14)]),
            fill='#124659',outline=CYAN,width=2)
        self.world_polygon(self.oriented(p.x,p.y,a,[(14,0),(-7,-7),(-4,0),(-7,7)]),fill='#b5ffff')
        self.world_circle(p.x,p.y,4,fill=CYAN)
        if p.shot_flash:
            ux,uy=math.cos(a),math.sin(a)
            self.world_circle(p.x+ux*26,p.y+uy*26,8,fill=YELLOW)
            self.world_line(p.x+ux*29,p.y+uy*29,p.x+ux*46,p.y+uy*46,YELLOW,3)

    def draw_enemy(self,e,game):
        a = math.atan2(game.player.y-e.y,game.player.x-e.x)
        x,y,r=e.x,e.y,e.radius
        color = TEXT if e.hit_flash else e.color
        self.world_circle(x,y,r+6,outline='#2c4651')
        if e.kind == 'hunter':
            self.world_polygon(self.oriented(x,y,a,[(r+2,0),(-r,-r*.86),(-r*.52,0),(-r,r*.86)]),
                               fill='#532537',outline=color,width=2)
            self.world_circle(x,y,4,fill=color)
        elif e.kind == 'runner':
            self.world_polygon(self.oriented(x,y,a,[(r+5,0),(0,-r),(-r-2,0),(0,r)]),
                               fill='#47234c',outline=color,width=2)
            self.world_line(x-math.cos(a)*6,y-math.sin(a)*6,x+math.cos(a)*9,y+math.sin(a)*9,color,2)
        elif e.kind == 'gunner':
            self.world_polygon(self.poly(x,y,r+1,6,a),fill='#193749',outline=color,width=2)
            self.world_circle(x,y,r*.5,fill='#244a64',outline=color)
            self.world_line(x,y,x+math.cos(a)*23,y+math.sin(a)*23,color,4)
        elif e.kind == 'bruiser':
            self.world_polygon(self.poly(x,y,r,6,a),fill='#503326',outline=color,width=3)
            self.world_polygon(self.poly(x,y,r*.6,4,a+math.pi/4),fill='#794b2e',outline=YELLOW,width=2)
            self.world_circle(x,y,4,fill=YELLOW)
            if e.rush_time > 0:
                self.world_circle(x,y,r+11,outline=RED,width=3)
        elif e.kind == 'warden':
            angle=game.global_time*.6
            self.world_circle(x,y,r+15,outline='#655539',width=3)
            for i in range(12):
                s=angle+i*math.tau/12
                self.world_line(x+math.cos(s)*(r+8),y+math.sin(s)*(r+8),
                                x+math.cos(s)*(r+18),y+math.sin(s)*(r+18),color,3)
            self.world_polygon(self.poly(x,y,r,8,angle),fill='#463829',outline=color,width=3)
            self.world_polygon(self.poly(x,y,r*.62,6,-angle),fill='#705238',outline=ORANGE,width=2)
            self.world_circle(x,y,12,fill=YELLOW)
            self.world_circle(x,y,5,fill='#fff5d0')
        if e.hp < e.max_hp or e.kind == 'warden':
            w = max(30,e.radius*2.6)
            ratio=clamp(e.hp/e.max_hp,0,1)
            bar_y = max(ARENA_TOP + 5, y - r - 18)
            bar_x = clamp(x - w/2, ARENA_LEFT + 5, ARENA_RIGHT - 5 - w)
            self.box(bar_x+self.sx,bar_y+self.sy,bar_x+w+self.sx,bar_y+5+self.sy,'#304052')
            if ratio>0:
                self.box(bar_x+self.sx,bar_y+self.sy,
                         bar_x+w*ratio+self.sx,bar_y+5+self.sy,color)

    def draw_pickup(self,item,t):
        x,y=item.x,item.y+math.sin(t*4+item.x)*3
        color=GREEN if item.kind == 'repair' else BLUE
        self.world_circle(x,y,17,outline=color,width=2)
        if item.kind == 'repair':
            self.world_line(x-7,y,x+7,y,color,4)
            self.world_line(x,y-7,x,y+7,color,4)
        else:
            self.world_polygon([(x,y-10),(x+8,y),(x,y+10),(x-8,y)],
                               fill='#173a62',outline=color,width=2)
            self.world_circle(x,y,3,fill=color)

    def hud(self,game):
        p=game.player
        self.box(0,0,WIDTH,72,'#091926')
        self.line(0,71,WIDTH,71,PANEL_EDGE,2)
        self.label(35,24,'N E O N   / /   R I F T',17,CYAN,'bold','w')
        self.label(36,48,'A R E N A   S U R V I V A L',9,MUTED,anchor='w',family='Courier New')
        self.label(555,24,f'{game.score:08,}',22,TEXT,'bold',family='Courier New')
        self.label(555,49,'S C O R E',9,MUTED,'bold',family='Courier New')
        self.label(WIDTH-35,24,f'WAVE  {game.wave:02}',18,YELLOW,'bold','e')
        self.label(WIDTH-35,50,f'{format_seconds(game.elapsed)}   //   {game.total_kills} ELIM',10,MUTED,anchor='e',family='Courier New')
        self.box(0,HEIGHT-48,WIDTH,HEIGHT,'#0a1b29')
        self.line(0,HEIGHT-49,WIDTH,HEIGHT-49,PANEL_EDGE,2)
        self.label(35,HEIGHT-30,'HULL',10,MUTED,'bold','w')
        self.box(95,HEIGHT-38,295,HEIGHT-23,'#21313e')
        hp_ratio=clamp(p.hp/p.max_hp,0,1)
        self.box(95,HEIGHT-38,95+200*hp_ratio,HEIGHT-23,GREEN if hp_ratio>.3 else RED)
        self.label(305,HEIGHT-30,f'{int(max(0,p.hp))}/{int(p.max_hp)}',11,TEXT,anchor='w',family='Courier New')
        self.label(443,HEIGHT-30,'DASH',10,MUTED,'bold','w')
        self.box(493,HEIGHT-38,600,HEIGHT-23,'#23333d')
        dash_ratio=1 if p.dash_cd<=0 else 1-p.dash_cd/p.dash_recharge
        self.box(493,HEIGHT-38,493+107*clamp(dash_ratio,0,1),HEIGHT-23,CYAN)
        self.label(646,HEIGHT-30,'PULSE  [E]',10,MUTED,'bold','w')
        self.box(729,HEIGHT-38,851,HEIGHT-23,'#23333d')
        self.box(729,HEIGHT-38,729+122*(p.energy/100),HEIGHT-23,BLUE)
        self.label(862,HEIGHT-30,f'{int(p.energy):02d}%',11,TEXT,anchor='w',family='Courier New')
        if game.combo>1 and game.combo_timer:
            multiplier=1+min(game.combo-1,15)*.12
            self.label(WIDTH-36,HEIGHT-29,f'×{multiplier:.1f}  COMBO',12,YELLOW,'bold','e')

    def crosshair(self,game):
        x=clamp(game.mouse_x,ARENA_LEFT,ARENA_RIGHT)
        y=clamp(game.mouse_y,ARENA_TOP,ARENA_BOTTOM)
        if y < ARENA_TOP or y > ARENA_BOTTOM:
            return
        self.circle(x,y,9,outline=CYAN,width=1)
        for a in (0,math.pi/2,math.pi,math.pi*1.5):
            c,s=math.cos(a),math.sin(a)
            self.line(x+c*13,y+s*13,x+c*22,y+s*22,CYAN,2)
        self.circle(x,y,1.8,fill=TEXT)

    def dark_overlay(self):
        # Tk has no alpha Canvas fills; densely stippled curtain keeps the field visible.
        self.c.create_rectangle(ARENA_LEFT,ARENA_TOP,ARENA_RIGHT,ARENA_BOTTOM,
                                fill='#020a12',outline='',stipple='gray50')
        self.c.create_rectangle(ARENA_LEFT,ARENA_TOP,ARENA_RIGHT,ARENA_BOTTOM,
                                fill='#03101b',outline='',stipple='gray25')

    def button(self,x,y,width,text,subtitle=''):
        self.box(x-width/2,y-28,x+width/2,y+28,'#0e485b',CYAN,2)
        self.label(x,y-4,text,17,TEXT,'bold')
        if subtitle:
            self.label(x,y+16,subtitle,9,'#9bd0d5')

    def menu(self,game):
        cx,cy=WIDTH/2,291
        t=game.global_time
        self.circle(cx,cy,131,outline='#173c4d',width=2)
        self.circle(cx,cy,112,outline='#1e596c',width=2)
        for i in range(20):
            a=i*math.tau/20+t*.3
            self.line(cx+math.cos(a)*118,cy+math.sin(a)*118,
                      cx+math.cos(a)*133,cy+math.sin(a)*133,
                      CYAN if i%5==0 else '#326176',2)
        for k in range(3):
            a=t*(.5+k*.21)+k*math.tau/3
            self.line(cx+math.cos(a)*67,cy+math.sin(a)*67,
                      cx+math.cos(a+.27)*86,cy+math.sin(a+.27)*86,CYAN,4)
        self.c.create_polygon(*sum(([v for v in pt] for pt in self.poly(cx,cy,62,6,t*.23)),[]),
                              fill='#0e3547',outline=CYAN,width=3)
        self.label(cx,cy-7,'N',68,CYAN,'bold')
        self.label(cx,cy+39,'/  07  /',11,MUTED,'bold',family='Courier New')
        self.label(cx,117,'NEON RIFT',37,TEXT,'bold')
        self.label(cx,155,'ARENA SURVIVAL',11,CYAN,'bold')
        self.label(cx,462,'MOVE.  SHOOT.  SURVIVE.',12,MUTED,'bold')
        self.button(cx,534,284,'START MISSION','PRESS ENTER  /  CLICK')
        self.label(cx,590,'WASD  MOVE     MOUSE  AIM & SHOOT     SPACE  DASH     E  ENERGY PULSE',
                   10,TEXT,'bold')
        self.label(cx,HEIGHT-82,f'PERSONAL BEST   {game.best:08,}',11,YELLOW,'bold',family='Courier New')
        if game.record_save_failed:
            self.label(cx,HEIGHT-24,'WARNING: HIGH SCORE NOT SAVED',10,RED,'bold')

    def wave_banner(self,game):
        t=game.banner_timer
        if t < .25:
            color=MUTED
        else:
            color=YELLOW if game.wave%5==0 else CYAN
        self.c.create_rectangle(310,102,810,164,fill='#0b2130',outline=color,width=2)
        self.label(WIDTH/2,132,game.banner,19,color,'bold')

    def pause_screen(self):
        self.dark_overlay()
        self.box(337,238,783,466,'#0b202d',PANEL_EDGE,2)
        self.label(WIDTH/2,299,'PAUSED',36,CYAN,'bold')
        self.label(WIDTH/2,360,'GAME PAUSED',14,MUTED)
        self.label(WIDTH/2,408,'PRESS P OR ESC TO RESUME',14,TEXT,'bold')

    def upgrade_screen(self,game):
        self.dark_overlay()
        self.label(WIDTH/2,157,f'WAVE {game.wave:02}  CLEARED',24,GREEN,'bold')
        self.label(WIDTH/2,203,'CHOOSE ONE SYSTEM UPGRADE',27,TEXT,'bold')
        self.label(WIDTH/2,243,'FREE HULL REPAIR +10  /  ENERGY +20',11,MUTED,'bold')
        for index,key in enumerate(game.upgrades_offered):
            name,description,color=UPGRADES[key]
            x=98+index*314
            self.box(x,292,x+294,500,'#0d2434',PANEL_EDGE,2)
            self.box(x+15,305,x+279,335,'#163d4e')
            self.label(x+27,320,f'0{index+1}  //  SYSTEM MODULE',10,color,'bold','w',family='Courier New')
            self.circle(x+147,392,31,outline=color,width=3)
            symbol={'overclock':'»','tungsten':'✦','reinforced':'+','thrusters':'↑',
                    'scatter':'×','capacitor':'⚡','medkit':'+','phase':'◇'}[key]
            self.label(x+147,391,symbol,26,color,'bold')
            self.label(x+147,447,name,15,TEXT,'bold')
            self.label(x+147,479,description,11,MUTED)
        self.label(WIDTH/2,556,'PRESS 1 / 2 / 3   OR   CLICK A CARD',14,CYAN,'bold')
        self.label(WIDTH/2,592,'NEXT WAVE STARTS IMMEDIATELY AFTER SELECTION',10,MUTED)
        if game.record_save_failed:
            self.label(WIDTH/2,620,'WARNING: HIGH SCORE NOT SAVED',11,RED,'bold')

    def game_over_screen(self,game):
        self.dark_overlay()
        self.box(305,148,815,560,'#0b202f',PANEL_EDGE,2)
        self.label(WIDTH/2,208,'SIGNAL LOST',35,RED,'bold')
        self.label(WIDTH/2,244,'RUN COMPLETE',12,MUTED,'bold')
        self.line(365,270,755,270,PANEL_EDGE,2)
        self.label(406,317,'FINAL SCORE',12,MUTED,'bold')
        self.label(718,317,f'{game.score:08,}',24,TEXT,'bold',anchor='e',family='Courier New')
        self.label(406,367,'WAVES REACHED',12,MUTED,'bold')
        self.label(718,367,f'{game.wave:02}',24,YELLOW,'bold',anchor='e',family='Courier New')
        self.label(406,417,'ELIMINATIONS',12,MUTED,'bold')
        self.label(718,417,str(game.total_kills),24,CYAN,'bold',anchor='e',family='Courier New')
        self.label(560,457,f'PERSONAL BEST   {game.best:08,}',12,GREEN,'bold',family='Courier New')
        if game.record_save_failed:
            self.label(560,550,'WARNING: HIGH SCORE NOT SAVED',10,RED,'bold')
        self.button(WIDTH/2,510,296,'REDEPLOY','PRESS ENTER  /  CLICK')
