"""Enemy spawning, pursuit, ranged attacks and boss patterns.

EnemyAIMixin is composed into Game; no Tk dependencies live here.
"""
from __future__ import annotations

import math

from constants import ORANGE
from entities import Bullet, Enemy, Ring
from mechanics import boundary_spawn, distance_sq, in_arena, unit


class EnemyAIMixin:
    def spawn_enemy(self, kind: str) -> None:
        margin = 68 if kind == 'warden' else (32 if kind == 'bruiser' else 26)
        # Prefer separated spawn points, but never sacrifice player safety
        # to achieve it. Existing enemies can crowd the perimeter on long runs.
        candidates = [boundary_spawn(self.rng, margin) for _ in range(24)]
        far = [point for point in candidates if
               distance_sq(point[0], point[1], self.player.x, self.player.y) >= 230 ** 2]
        choices = far if far else candidates
        radius = 43 if kind == 'warden' else (24 if kind == 'bruiser' else 17)

        alive = [e for e in self.enemies if not e.dead]

        def clearance(point: tuple[float, float]) -> float:
            if not alive:
                return 100.0
            return min(math.sqrt(distance_sq(point[0], point[1], e.x, e.y))
                       - radius - e.radius for e in alive)

        pos = max(choices, key=lambda point:
                  (min(100.0, clearance(point)),
                   distance_sq(point[0], point[1], self.player.x, self.player.y)))
        self.next_enemy_id += 1
        enemy = Enemy(kind, *pos, uid=self.next_enemy_id,
                      orbit=self.rng.choice((-1, 1)))
        enemy.shot_timer = self.rng.uniform(.9, 1.5)
        enemy.charge_timer = self.rng.uniform(2, 3.5)
        if kind == 'warden':
            enemy.max_hp = enemy.hp = 750 + 100 * (self.wave // 5)
        self.enemies.append(enemy)
        self.rings.append(Ring(enemy.x, enemy.y, 6, enemy.radius + 24,
                               .38, .38, enemy.color))

    def update_enemies(self, dt: float) -> None:
        p = self.player
        for e in self.enemies:
            if e.dead:
                continue
            e.prev_x, e.prev_y = e.x, e.y
            e.age += dt
            e.hit_flash = max(0, e.hit_flash - dt)
            e.stun = max(0, e.stun - dt)
            e.shot_timer -= dt
            e.charge_timer -= dt
            e.rush_time = max(0, e.rush_time - dt)
            dx, dy = unit(p.x - e.x, p.y - e.y)
            dist = math.sqrt(distance_sq(e.x, e.y, p.x, p.y))
            if e.stun > 0:
                e.vx *= max(0, 1 - 4 * dt)
                e.vy *= max(0, 1 - 4 * dt)
            elif e.kind == 'hunter':
                e.vx, e.vy = dx * e.speed, dy * e.speed
            elif e.kind == 'runner':
                side = math.sin(e.age * 5 + e.uid) * .6
                ux, uy = unit(dx - dy * side, dy + dx * side)
                e.vx, e.vy = ux * e.speed, uy * e.speed
            elif e.kind == 'gunner':
                pressure = 1 if dist > 290 else (-1 if dist < 210 else 0)
                ux, uy = unit(dx * pressure - dy * .64 * e.orbit,
                              dy * pressure + dx * .64 * e.orbit)
                e.vx, e.vy = ux * e.speed, uy * e.speed
                if e.shot_timer <= 0 and dist < 700:
                    self.enemy_shoot(e, math.atan2(dy, dx), count=1, speed=270)
                    e.shot_timer = self.rng.uniform(1.25, 1.85)
            elif e.kind == 'bruiser':
                if e.rush_time > 0:
                    pass  # Maintain committed charge direction.
                elif e.charge_timer <= 0 and dist < 450:
                    e.rush_time = .48
                    e.charge_timer = self.rng.uniform(3.3, 4.6)
                    e.vx, e.vy = dx * 390, dy * 390
                    self.rings.append(Ring(e.x, e.y, e.radius,
                                           e.radius + 32, .25, .25, ORANGE))
                else:
                    e.vx, e.vy = dx * e.speed, dy * e.speed
            elif e.kind == 'warden':
                pressure = 1 if dist > 285 else (-.4 if dist < 180 else 0)
                ux, uy = unit(dx * pressure - dy * .4, dy * pressure + dx * .4)
                e.vx, e.vy = ux * e.speed, uy * e.speed
                if e.shot_timer <= 0:
                    angle = math.atan2(dy, dx)
                    if int(e.age * 1.4) % 2 == 0:
                        self.enemy_shoot(e, angle, count=5, spread=.22, speed=285)
                    else:
                        for k in range(12):
                            self.enemy_shoot(e, math.tau * k / 12 + e.age * .32,
                                             count=1, speed=215)
                    e.shot_timer = max(.8, 1.6 - (1 - e.hp / e.max_hp) * .55)
                    self.shake = max(self.shake, 2.0)
            e.x += e.vx * dt
            e.y += e.vy * dt
            e.x, e.y = in_arena(e.x, e.y, e.radius + 2)
        self.enemies = [e for e in self.enemies if not e.dead]

    def enemy_shoot(self, e: Enemy, angle: float, *, count: int = 1,
                    spread: float = .15, speed: float = 260) -> None:
        for j in range(count):
            a = angle + (j - (count - 1) / 2) * spread
            ux, uy = math.cos(a), math.sin(a)
            self.bullets.append(Bullet(e.x + ux * (e.radius + 9),
                                       e.y + uy * (e.radius + 9),
                                       ux * speed, uy * speed, 5.8,
                                       10 if e.kind != 'warden' else 15,
                                       3.9, False, e.color, fresh=True))
        self.emit(e.x, e.y, e.color, 3, speed=90, ttl=.2, size=2.5)
