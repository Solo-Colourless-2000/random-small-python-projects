Pythonペネトレーションテスト実習 day09
作成日 2026-11-13（日本時間）

最初に python_10_projects_day09_manual.html をブラウザーで開いてください。
ZIPを展開し、ターミナルを python_10_projects_day09_20261113/ に移動します。
現在地を pwd で、projects/ と samples/ が見えることを ls で確認します。

python3 --version
pwd
ls
mkdir -p practice
vim practice/01_account_oracle.py

vimでは i で入力を開始し、Esc で戻って :wq とEnterで保存します。
字下げは半角スペース4個。全4工程を同じ実習ファイルへ追記します。
vimはnvimに置き換えられます。完成版はprojects/、自分で書く場所はpractice/です。

python3 practice/01_account_oracle.py known

完成版の試験入力（教材ルートで実行）
python3 projects/01_account_oracle.py known
python3 projects/02_trace_echo.py token
python3 projects/03_seed_prediction.py known
python3 projects/04_reused_xor.py reuse
python3 projects/05_basic_decode.py normal
python3 projects/06_compression_oracle.py shared
python3 projects/07_unlinked_handle.py unlink
python3 projects/08_tls_trust.py unchecked
python3 projects/09_range_budget.py repeat
python3 projects/10_ws_mask.py masked

同じコマンドを再実行できます。配布物への書き込みはありません。
CLIは固定ケース名だけを受け取ります。
02と08は自作のIPv4ループバックへだけ接続します。07は自作一時領域を使います。
08はsamples/lab_cert.pemとsamples/lab_key.pemを同梱fixtureとして使います。
終了値は0が実験完了、2が入力エラー・固定構造の解析失敗、02・07・08のI/O失敗は1です。

python3 -m unittest discover -s tests -v

点検の範囲と実行環境は REVIEW_REPORT.txt、詳細は verification/ を参照してください。
次回はday10です。
