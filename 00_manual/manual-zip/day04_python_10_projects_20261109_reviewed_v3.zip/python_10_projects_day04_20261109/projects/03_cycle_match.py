import sys


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 03_cycle_match.py first second")
        return 2
    periods = []
    try:
        for text in sys.argv[1:]:
            if len(text) > 4:
                raise ValueError
            period = int(text)
            if not 1 <= period <= 120:
                raise ValueError
            periods.append(period)
    except ValueError:
        print("Error: periods must be integers from 1 to 120.")
        return 2
    first, second = periods
    a = first
    b = second
    while b != 0:
        remainder = a % b
        a = b
        b = remainder
    common = first // a * second
    print(f"GCD: {a}")
    print(f"Together after: {common} minutes")
    print(f"First cycles: {common // first}")
    print(f"Second cycles: {common // second}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
