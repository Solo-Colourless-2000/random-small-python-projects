"""Offline browser DOM/rendering checks. Does not validate file: navigation."""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'python_10_projects_day07_manual.html').read_text(encoding='utf-8')
RESULTS=[]
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    for width in [1280, 390, 320]:
        page=browser.new_page(viewport={'width':width,'height':850})
        errors=[]
        page.on('pageerror', lambda error: errors.append(str(error)))
        page.set_content(HTML, wait_until='load')
        page.wait_for_timeout(160)
        assert page.locator('html.js').count()==1, 'JavaScript not initialized'
        assert page.locator('.chapter.active').count()==1, 'Expected one active chapter'
        page.locator('#search').fill('format_map')
        count=page.locator('#matches li').count()
        assert count>=2, f'No search hits at width {width}'
        page.locator('#clear-search').click()
        page.evaluate("location.hash='#p05'")
        page.wait_for_timeout(160)
        assert page.locator('#p05.active').count()==1
        guide=page.locator('#p05 .worked-guide')
        guide.locator('summary').click()
        assert guide.get_attribute('open') is not None
        assert guide.locator('tbody tr').count()==5
        page.locator('#larger').click()
        page.locator('#wrap').click()
        page.locator('#focus').click()
        assert page.locator('body.focused.wrap').count()==1
        geometry=page.evaluate('''() => ({viewport:innerWidth, scroll:document.documentElement.scrollWidth,
          tableCount:document.querySelectorAll('.worked-table').length,
          chapterCount:document.querySelectorAll('section.chapter').length})''')
        assert geometry['scroll']<=geometry['viewport']+1, f'Horizontal page overflow at {width}: {geometry}'
        assert geometry['tableCount']==10 and geometry['chapterCount']==20
        assert not errors, f'Browser JavaScript exceptions: {errors}'
        if width==390:
            page.screenshot(path=str(ROOT/'verification'/'second_mobile_390.png'), full_page=False)
        if width==1280:
            page.screenshot(path=str(ROOT/'verification'/'second_desktop_1280.png'), full_page=False)
        RESULTS.append({'viewport':width,'search_hits_before_clear':count,
                        'worked_rows':guide.locator('tbody tr').count(), 'geometry':geometry,
                        'javascript_errors':errors, 'status':'PASS'})
        page.close()
    browser.close()
(ROOT/'verification'/'second_browser_check.json').write_text(json.dumps({
    'method':'Chromium set_content() offline DOM rendering; not a file:// navigation test',
    'results':RESULTS},indent=2)+'\n')
print('browser results:',RESULTS)
