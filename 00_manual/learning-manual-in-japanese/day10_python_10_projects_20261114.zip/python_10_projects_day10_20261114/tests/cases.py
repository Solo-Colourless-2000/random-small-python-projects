CASES = {
    "01_unsigned_jwt": [
        (["admin"], 0, "Decode-only admin: True\nSigned-only gate: False\n", ""),
        (["user"], 0, "Decode-only admin: False\nSigned-only gate: False\n", ""),
        (["broken"], 2, "", "Invalid lab JWT.\n"),
    ],
    "02_expiry_edge": [
        (["equal"], 0, "Clock: 100\nInclusive gate: True\nExclusive gate: False\n", ""),
        (["before"], 0, "Clock: 99\nInclusive gate: True\nExclusive gate: True\n", ""),
        (["after"], 0, "Clock: 101\nInclusive gate: False\nExclusive gate: False\n", ""),
        (["zero"], 0, "Clock: 0\nInclusive gate: True\nExclusive gate: True\n", ""),
    ],
    "03_method_override": [
        (["override"], 0, "Effective method: DELETE\nOuter gate: True\nEffective gate: False\n", ""),
        (["plain"], 0, "Effective method: POST\nOuter gate: True\nEffective gate: True\n", ""),
        (["direct"], 0, "Effective method: DELETE\nOuter gate: False\nEffective gate: False\n", ""),
        (["read"], 0, "Effective method: GET\nOuter gate: False\nEffective gate: False\n", ""),
    ],
    "04_unicode_identity": [
        (["wide"], 0, "Raw name: '\\uff41dmin'\nLookup name: 'admin'\nRaw reservation gate: True\nCanonical reservation gate: False\n", ""),
        (["plain"], 0, "Raw name: 'admin'\nLookup name: 'admin'\nRaw reservation gate: False\nCanonical reservation gate: False\n", ""),
        (["other"], 0, "Raw name: 'guest'\nLookup name: 'guest'\nRaw reservation gate: True\nCanonical reservation gate: True\n", ""),
        (["empty"], 0, "Raw name: ''\nLookup name: ''\nRaw reservation gate: False\nCanonical reservation gate: False\n", ""),
    ],
    "05_json_bool": [
        (["bool"], 0, "Parsed type: bool\nSubclass gate: True\nExact integer gate: False\n", ""),
        (["integer"], 0, "Parsed type: int\nSubclass gate: True\nExact integer gate: True\n", ""),
        (["zero"], 0, "Parsed type: int\nSubclass gate: False\nExact integer gate: False\n", ""),
        (["float"], 0, "Parsed type: float\nSubclass gate: False\nExact integer gate: False\n", ""),
        (["null"], 0, "Parsed type: NoneType\nSubclass gate: False\nExact integer gate: False\n", ""),
        (["broken"], 2, "", "Invalid lab JSON.\n"),
    ],
    "06_nan_gate": [
        (["nan"], 0, "Finite: False\nOutside-only gate: True\nFinite range gate: False\n", ""),
        (["normal"], 0, "Finite: True\nOutside-only gate: True\nFinite range gate: True\n", ""),
        (["lower"], 0, "Finite: True\nOutside-only gate: True\nFinite range gate: True\n", ""),
        (["upper"], 0, "Finite: True\nOutside-only gate: True\nFinite range gate: True\n", ""),
        (["negative"], 0, "Finite: True\nOutside-only gate: False\nFinite range gate: False\n", ""),
        (["large"], 0, "Finite: True\nOutside-only gate: False\nFinite range gate: False\n", ""),
        (["infinity"], 0, "Finite: False\nOutside-only gate: False\nFinite range gate: False\n", ""),
        (["broken"], 2, "", "Invalid lab number.\n"),
    ],
    "07_state_binding": [
        (["cross"], 0, "Any-session gate: True\nBound-session gate: False\n", ""),
        (["own"], 0, "Any-session gate: True\nBound-session gate: True\n", ""),
        (["unknown"], 0, "Any-session gate: False\nBound-session gate: False\n", ""),
        (["empty"], 0, "Any-session gate: False\nBound-session gate: False\n", ""),
    ],
    "08_workflow_order": [
        (["skip"], 0, "Ungated shipments: 1\nState-gated shipments: 0\nRejected steps: 1\n", ""),
        (["normal"], 0, "Ungated shipments: 1\nState-gated shipments: 1\nRejected steps: 0\n", ""),
        (["repeat"], 0, "Ungated shipments: 2\nState-gated shipments: 1\nRejected steps: 1\n", ""),
        (["empty"], 0, "Ungated shipments: 0\nState-gated shipments: 0\nRejected steps: 0\n", ""),
    ],
    "09_terminal_controls": [
        (["escape"], 0, "Raw representation: 'user=\\x1b[31mguest'\nControl count: 1\nVisible log: user=\\x1b[31mguest\n", ""),
        (["plain"], 0, "Raw representation: 'user=guest'\nControl count: 0\nVisible log: user=guest\n", ""),
        (["newline"], 0, "Raw representation: 'user=guest\\nstatus=OK'\nControl count: 1\nVisible log: user=guest\\x0astatus=OK\n", ""),
        (["empty"], 0, "Raw representation: ''\nControl count: 0\nVisible log: \n", ""),
    ],
    "10_dns_pointers": [
        (["backref"], 0, "Name: 'lab'\n", ""),
        (["plain"], 0, "Name: 'lab'\n", ""),
        (["cycle"], 2, "", "Invalid lab DNS name.\n"),
        (["short"], 2, "", "Invalid lab DNS name.\n"),
        (["past"], 2, "", "Invalid lab DNS name.\n"),
        (["root"], 0, "Name: ''\n", ""),
    ],
}

USAGE = [
    "admin|user|broken", "before|equal|after|zero", "override|plain|direct|read",
    "wide|plain|other|empty", "bool|integer|zero|float|null|broken",
    "nan|normal|lower|upper|negative|large|infinity|broken", "cross|own|unknown|empty",
    "skip|normal|repeat|empty", "escape|plain|newline|empty", "cycle|backref|plain|short|past|root",
]

for cases, usage in zip(CASES.values(), USAGE):
    for args in ([], ["bad"], [""], [cases[0][0][0], "extra"]):
        cases.append((args, 2, "", f"Usage: script {usage}\n"))
