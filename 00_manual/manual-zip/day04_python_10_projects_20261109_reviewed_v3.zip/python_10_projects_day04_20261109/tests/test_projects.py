from collections import Counter
import contextlib
import importlib.util
import io
import math
import os
from pathlib import Path
import random
import re
import select
import signal
import struct
import subprocess
import sys
import tempfile
import time
import unittest
import wave

ROOT = Path(__file__).resolve().parents[1]
FILES = sorted((ROOT / "projects").glob("*.py"))
RUNS = []


def run(number, args=(), data="", cwd=None):
    result = subprocess.run([sys.executable, str(FILES[number - 1]), *args], input=data, text=True, capture_output=True, cwd=cwd or ROOT, timeout=5)
    RUNS.append({"project": number, "args": list(args), "input": data, "status": result.returncode, "stdout": result.stdout, "stderr": result.stderr})
    return result


class Programs(unittest.TestCase):
    def check(self, number, args, status, output, data="", cwd=None):
        result = run(number, args, data, cwd)
        self.assertEqual(result.returncode, status, result.stderr)
        self.assertEqual(result.stdout, output)
        self.assertEqual(result.stderr, "")
        return result

    def errors(self, number, cases, data=""):
        for args in cases:
            with self.subTest(args=args):
                result = run(number, args, data)
                self.assertEqual(result.returncode, 2)
                self.assertIn("Error:", result.stdout)
                self.assertEqual(result.stderr, "")

    def test_01_palindrome_known(self):
        self.check(1, ["Never odd or even"], 0, "Normalized: neveroddoreven\nReversed: neveroddoreven\nPalindrome\n")
        self.check(1, ["python"], 0, "Normalized: python\nReversed: nohtyp\nNot a palindrome.\n")

    def test_01_palindrome_boundaries(self):
        self.check(1, ["A"], 0, "Normalized: a\nReversed: a\nPalindrome\n")
        text = "a" * 80
        self.check(1, [text], 0, f"Normalized: {text}\nReversed: {text}\nPalindrome\n")
        self.check(1, [" Level "], 0, "Normalized: level\nReversed: level\nPalindrome\n")

    def test_01_palindrome_invalid(self):
        self.errors(1, [[""], [" "], ["a" * 81], ["hello!"], ["a1"], ["a\tb"]])

    def test_02_caesar_known_and_inverse(self):
        self.check(2, ["Az-9", "3"], 0, "Shift: 3\nResult: Dc-9\n")
        self.check(2, ["Dc-9", "23"], 0, "Shift: 23\nResult: Az-9\n")
        alphabet = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz"
        forward = run(2, [alphabet, "17"])
        encoded = forward.stdout.splitlines()[1].removeprefix("Result: ")
        reverse = run(2, [encoded, "9"])
        self.assertEqual(reverse.stdout.splitlines()[1], "Result: " + alphabet)
        self.assertEqual((forward.returncode, reverse.returncode), (0, 0))

    def test_02_caesar_boundaries(self):
        self.check(2, ["Az-9", "0"], 0, "Shift: 0\nResult: Az-9\n")
        self.check(2, ["Aa", "25"], 0, "Shift: 25\nResult: Zz\n")
        self.check(2, [" " + "a" * 78 + "~", "1"], 0, "Shift: 1\nResult:  " + "b" * 78 + "~\n")

    def test_02_caesar_invalid(self):
        self.errors(2, [["", "1"], ["a" * 81, "1"], ["A\nB", "1"], ["A\tB", "1"], ["A", "-1"], ["A", "26"], ["A", ""], ["A", "nan"], ["A", "1.0"], ["A", "0000"]])

    def test_03_cycles_known(self):
        self.check(3, ["6", "8"], 0, "GCD: 2\nTogether after: 24 minutes\nFirst cycles: 4\nSecond cycles: 3\n")

    def test_03_cycles_model_and_limits(self):
        for first in [1, 2, 6, 7, 8, 119, 120]:
            for second in [1, 2, 6, 7, 8, 119, 120]:
                with self.subTest(first=first, second=second):
                    result = run(3, [str(first), str(second)])
                    values = [int(line.split(": ")[1].split()[0]) for line in result.stdout.splitlines()]
                    gcd, common, count_a, count_b = values
                    self.assertEqual(result.returncode, 0)
                    self.assertEqual(gcd, math.gcd(first, second))
                    self.assertEqual(common, math.lcm(first, second))
                    self.assertEqual(first * count_a, second * count_b)
                    self.assertEqual(first * count_a, common)
                    self.assertEqual(result.stderr, "")

    def test_03_cycles_invalid(self):
        self.errors(3, [["0", "8"], ["-1", "8"], ["121", "8"], ["8", "121"], ["", "8"], ["1.5", "8"], ["a", "8"], ["12345", "8"]])

    def test_04_search_known(self):
        self.check(4, ["42"], 0, "Range: [0, 9); middle=4; value=23\nRange: [5, 9); middle=7; value=56\nRange: [5, 7); middle=6; value=42\nFound at index: 6\n")

    def test_04_search_all_targets(self):
        numbers = [3, 7, 11, 18, 23, 31, 42, 56, 70]
        for target in range(100):
            with self.subTest(target=target):
                result = run(4, [str(target)])
                self.assertEqual(result.returncode, 0)
                expected = f"Found at index: {numbers.index(target)}" if target in numbers else "Not found."
                self.assertEqual(result.stdout.splitlines()[-1], expected)
                ranges = result.stdout.splitlines()[:-1]
                previous_width = 10
                for line in ranges:
                    match = re.fullmatch(r"Range: \[(\d+), (\d+)\); middle=(\d+); value=(\d+)", line)
                    self.assertIsNotNone(match)
                    lower, upper, middle, value = map(int, match.groups())
                    self.assertLess(lower, upper)
                    self.assertLess(upper - lower, previous_width)
                    self.assertTrue(0 <= lower <= middle < upper <= 9)
                    self.assertEqual(value, numbers[middle])
                    previous_width = upper - lower
                self.assertLessEqual(len(ranges), 4)
                self.assertEqual(result.stderr, "")

    def test_04_search_invalid(self):
        self.errors(4, [["-1"], ["100"], [""], ["NaN"], ["2.0"], ["0000"]])

    def test_05_rosters_known(self):
        self.check(5, ["samples/roster_a.txt", "samples/roster_b.txt"], 0, "Both: bob\nFirst only: ada, cyd\nSecond only: dee\n")

    def test_05_rosters_empty_duplicates_and_limits(self):
        with tempfile.TemporaryDirectory() as directory:
            first, second = Path(directory) / "a.txt", Path(directory) / "b.txt"
            cases = [("", "", "Both: (none)\nFirst only: (none)\nSecond only: (none)\n"), (" Ada \nADA\nbob\n", "aDa\n", "Both: ada\nFirst only: bob\nSecond only: (none)\n"), ("a\r\nb\r\n", "b", "Both: b\nFirst only: a\nSecond only: (none)\n"), (" " * 10 + ("a" * 12 + "\n") * 10, "", "Both: (none)\nFirst only: " + "a" * 12 + "\nSecond only: (none)\n")]
            for a, b, expected in cases:
                with self.subTest(a=a, b=b):
                    first.write_bytes(a.encode("ascii"))
                    second.write_bytes(b.encode("ascii"))
                    self.check(5, [str(first), str(second)], 0, expected)
                    self.assertEqual(first.read_bytes(), a.encode("ascii"))
                    self.assertEqual(second.read_bytes(), b.encode("ascii"))

    def test_05_rosters_file_and_content_errors(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            first, second = base / "a.txt", base / "b.txt"
            second.write_text("Bob\n", encoding="ascii")
            self.check(5, [str(first), str(second)], 1, "Error: cannot read UTF-8 rosters.\n")
            self.check(5, [str(base), str(second)], 1, "Error: cannot read UTF-8 rosters.\n")
            first.write_bytes(bytes([255]))
            self.check(5, [str(first), str(second)], 1, "Error: cannot read UTF-8 rosters.\n")
            for data in ["\n", " \n", "Ada1\n", "a" * 13, "a\n" * 11, " " * 11 + ("a" * 12 + "\n") * 10]:
                with self.subTest(data=data):
                    first.write_text(data, encoding="ascii")
                    self.check(5, [str(first), str(second)], 2, "Error: use at most 10 names, 1-12 letters each, within 140 characters.\n")
            first.write_text(chr(0x212A) + "\n", encoding="utf-8")
            self.check(5, [str(first), str(second)], 2, "Error: use at most 10 names, 1-12 letters each, within 140 characters.\n")

    def test_06_rectangles_known(self):
        self.check(6, ["0,0,4,3", "2,1,5,4"], 0, "Width: 2\nHeight: 2\nArea: 4\n")
        self.check(6, ["0,0,2,2", "2,0,4,2"], 0, "Width: 0\nHeight: 2\nArea: 0\n")

    def test_06_rectangles_grid_model(self):
        rectangles = [(-20, -20, 20, 20), (-2, -1, 3, 4), (0, 0, 1, 1), (3, 4, 5, 6), (-5, -4, -3, -2)]
        for first in rectangles:
            for second in rectangles:
                with self.subTest(first=first, second=second):
                    result = run(6, [",".join(map(str, first)), ",".join(map(str, second))])
                    values = dict(line.split(": ") for line in result.stdout.splitlines())
                    occupied_a = {(x, y) for x in range(first[0], first[2]) for y in range(first[1], first[3])}
                    occupied_b = {(x, y) for x in range(second[0], second[2]) for y in range(second[1], second[3])}
                    self.assertEqual(int(values["Area"]), len(occupied_a & occupied_b))
                    self.assertGreaterEqual(int(values["Width"]), 0)
                    self.assertGreaterEqual(int(values["Height"]), 0)
                    self.assertEqual(result.returncode, 0)
                    self.assertEqual(result.stderr, "")

    def test_06_rectangles_invalid(self):
        self.errors(6, [["", "0,0,1,1"], ["0,0,0,1", "0,0,1,1"], ["1,0,0,1", "0,0,1,1"], ["0,1,1,0", "0,0,1,1"], ["0,0,1", "0,0,1,1"], ["0,,1,1", "0,0,1,1"], ["0,0,21,1", "0,0,1,1"], ["-21,0,1,1", "0,0,1,1"], ["0,0,1.0,1", "0,0,1,1"], ["0" * 21, "0,0,1,1"]])

    def test_07_coins_known(self):
        self.check(7, ["12"], 0, "10x0 5x0 1x12\n10x0 5x1 1x7\n10x0 5x2 1x2\n10x1 5x0 1x2\nCombinations: 4\n")
        self.check(7, ["0"], 0, "10x0 5x0 1x0\nCombinations: 1\n")

    def test_07_coins_all_amounts(self):
        for amount in range(31):
            with self.subTest(amount=amount):
                result = run(7, [str(amount)])
                rows = result.stdout.splitlines()
                actual = set()
                for row in rows[:-1]:
                    match = re.fullmatch(r"10x(\d+) 5x(\d+) 1x(\d+)", row)
                    self.assertIsNotNone(match)
                    tens, fives, ones = map(int, match.groups())
                    self.assertEqual(10 * tens + 5 * fives + ones, amount)
                    actual.add((tens, fives, ones))
                # Independent model enumerates every coin count, including ones.
                expected = {(t, f, o) for t in range(4) for f in range(7) for o in range(31) if 10 * t + 5 * f + o == amount}
                self.assertEqual(actual, expected)
                self.assertEqual(len(rows) - 1, len(actual))
                self.assertEqual(rows[-1], f"Combinations: {len(expected)}")
                self.assertEqual(result.returncode, 0)
                self.assertEqual(result.stderr, "")

    def test_07_coins_invalid(self):
        self.errors(7, [["-1"], ["31"], [""], ["one"], ["2.5"], ["0000"]])

    def inspect_wav(self, path, frames):
        with wave.open(str(path), "rb") as stream:
            self.assertEqual((stream.getnchannels(), stream.getsampwidth(), stream.getframerate(), stream.getnframes(), stream.getcomptype()), (1, 2, 8000, frames, "NONE"))
            data = stream.readframes(frames + 1)
        self.assertEqual(len(data), frames * 2)
        raw = path.read_bytes()
        self.assertEqual(raw[:4], b"RIFF")
        self.assertEqual(raw[8:12], b"WAVE")
        self.assertEqual(struct.unpack("<I", raw[4:8])[0] + 8, len(raw))
        values = struct.unpack("<" + "h" * frames, data)
        self.assertEqual(values[0], 0)
        self.assertTrue(all(-8000 <= value <= 8000 for value in values))
        return values

    def test_08_wav_known_header_and_wave(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "tone.wav"
            self.check(8, ["1000", "200", str(output)], 0, f"Saved: {output}\nFrames: 1600\nRate: 8000 Hz\n")
            values = self.inspect_wav(output, 1600)
            self.assertEqual(len(output.read_bytes()), 3244)
            expected_period = [0, 5656, 8000, 5656, 0, -5656, -8000, -5656]
            for i, value in enumerate(values):
                self.assertLessEqual(abs(value - expected_period[i % 8]), 1)
            rms = math.sqrt(sum(value * value for value in values) / len(values))
            self.assertAlmostEqual(rms, 8000 / math.sqrt(2), delta=1)

    def test_08_wav_boundaries(self):
        with tempfile.TemporaryDirectory() as directory:
            for frequency in [100, 2000]:
                for duration in [100, 500]:
                    with self.subTest(frequency=frequency, duration=duration):
                        output = Path(directory) / f"tone_{frequency}_{duration}.wav"
                        result = run(8, [str(frequency), str(duration), str(output)])
                        self.assertEqual(result.returncode, 0)
                        self.assertEqual(result.stderr, "")
                        frames = {100: 800, 500: 4000}[duration]
                        self.inspect_wav(output, frames)

    def test_08_wav_exclusive(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "existing.wav"
            output.write_bytes(b"KEEP")
            self.check(8, ["1000", "200", str(output)], 1, "Error: cannot create WAV; choose a new path.\n")
            self.assertEqual(output.read_bytes(), b"KEEP")

    def test_08_wav_io_errors(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            self.check(8, ["1000", "200", str(base)], 1, "Error: cannot create WAV; choose a new path.\n")
            self.check(8, ["1000", "200", str(base / "missing/tone.wav")], 1, "Error: cannot create WAV; choose a new path.\n")

    def test_08_wav_invalid_no_file(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "tone.wav"
            for frequency, duration in [("99", "200"), ("2001", "200"), ("1000", "99"), ("1000", "501"), ("", "200"), ("1000", ""), ("nan", "200"), ("1000", "inf"), ("1000.0", "200"), ("00000", "200")]:
                with self.subTest(frequency=frequency, duration=duration):
                    self.errors(8, [[frequency, duration, str(output)]])
                    self.assertFalse(output.exists())

    def test_09_rps_known(self):
        self.check(9, ["7"], 0, "Your hand (rock/paper/scissors): Computer: paper\nYou lose.\n", "rock\n")
        self.check(9, ["7"], 0, "Your hand (rock/paper/scissors): Computer: paper\nTie\n", " PAPER \n")

    def test_09_rps_all_nine_pairs(self):
        hands = ("rock", "paper", "scissors")
        seeds = {}
        for seed in range(100):
            seeds.setdefault(random.Random(seed).choice(hands), seed)
        self.assertEqual(set(seeds), set(hands))
        winning = {("rock", "scissors"), ("paper", "rock"), ("scissors", "paper")}
        for computer, seed in seeds.items():
            for hand in hands:
                with self.subTest(hand=hand, computer=computer, seed=seed):
                    result = run(9, [str(seed)], hand + "\n")
                    expected = "Tie" if hand == computer else "You win." if (hand, computer) in winning else "You lose."
                    self.assertEqual(result.stdout, f"Your hand (rock/paper/scissors): Computer: {computer}\n{expected}\n")
                    self.assertEqual(result.returncode, 0)
                    self.assertEqual(result.stderr, "")

    def test_09_rps_seed_and_raw_limits(self):
        for seed in [0, 9999]:
            with self.subTest(seed=seed):
                result = run(9, [str(seed)], " " * 16 + "rock\n")
                self.assertEqual(result.returncode, 0)
                self.assertEqual(result.stderr, "")
        self.errors(9, [["-1"], ["10000"], [""], ["nan"], ["1.5"]])

    def test_09_rps_invalid_hand(self):
        for data in ["\n", " \n", "lizard\n", "rock paper\n", " " * 17 + "rock\n"]:
            with self.subTest(data=data):
                self.errors(9, [["7"]], data)

    def test_09_rps_eof(self):
        self.check(9, ["7"], 1, "Your hand (rock/paper/scissors): \nStopped.\n", "")

    @unittest.skipUnless(os.name == "posix", "POSIX signal test")
    def test_09_rps_interrupt(self):
        process = subprocess.Popen([sys.executable, "-u", str(FILES[8]), "7"], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        data = b""
        deadline = time.monotonic() + 5
        try:
            while not data.endswith(b": "):
                self.assertLess(time.monotonic(), deadline)
                ready, _, _ = select.select([process.stdout], [], [], .1)
                if ready:
                    chunk = os.read(process.stdout.fileno(), 4096)
                    self.assertTrue(chunk)
                    data += chunk
            process.send_signal(signal.SIGINT)
            rest, error = process.communicate(timeout=5)
            data += rest
            self.assertEqual(process.returncode, 1)
            self.assertEqual(data, b"Your hand (rock/paper/scissors): \nStopped.\n")
            self.assertEqual(error, b"")
            RUNS.append({"project": 9, "args": ["7"], "signal": "SIGINT", "status": 1, "stdout": data.decode(), "stderr": ""})
        finally:
            if process.poll() is None:
                process.kill()
                process.communicate()

    def test_10_hanoi_known(self):
        self.check(10, ["2"], 0, "Move 1: A -> B\nMove 2: A -> C\nMove 1: B -> C\nMoves: 3\n")
        self.check(10, ["1"], 0, "Move 1: A -> C\nMoves: 1\n")

    def test_10_hanoi_legal_model_all_sizes(self):
        for disks in range(1, 5):
            with self.subTest(disks=disks):
                result = run(10, [str(disks)])
                pegs = {"A": list(range(disks, 0, -1)), "B": [], "C": []}
                rows = result.stdout.splitlines()
                for row in rows[:-1]:
                    match = re.fullmatch(r"Move (\d+): ([ABC]) -> ([ABC])", row)
                    self.assertIsNotNone(match)
                    disk = int(match[1])
                    source, target = match[2], match[3]
                    self.assertNotEqual(source, target)
                    self.assertTrue(pegs[source])
                    self.assertEqual(pegs[source][-1], disk)
                    if pegs[target]:
                        self.assertLess(disk, pegs[target][-1])
                    pegs[source].pop()
                    pegs[target].append(disk)
                self.assertEqual(pegs, {"A": [], "B": [], "C": list(range(disks, 0, -1))})
                self.assertEqual(len(rows) - 1, 2 ** disks - 1)
                self.assertEqual(rows[-1], f"Moves: {2 ** disks - 1}")
                self.assertEqual(result.returncode, 0)
                self.assertEqual(result.stderr, "")

    def test_10_hanoi_invalid(self):
        self.errors(10, [["0"], ["-1"], ["5"], [""], ["a"], ["1.5"], ["000"]])

    def test_argument_counts(self):
        required = {1: ["a"], 2: ["a", "1"], 3: ["1", "2"], 4: ["1"], 5: ["a", "b"], 6: ["0,0,1,1", "0,0,1,1"], 7: ["1"], 8: ["1000", "200", "out.wav"], 9: ["7"], 10: ["1"]}
        for number, args in required.items():
            for wrong in [[], args + ["extra"]]:
                with self.subTest(number=number, args=wrong):
                    result = run(number, wrong)
                    self.assertEqual(result.returncode, 2)
                    self.assertTrue(result.stdout.startswith("Usage:"))
                    self.assertEqual(result.stderr, "")

    def test_import_has_no_side_effects(self):
        for file in FILES:
            with self.subTest(file=file.name):
                code = "import importlib.util; s=importlib.util.spec_from_file_location('lesson', " + repr(str(file)) + "); m=importlib.util.module_from_spec(s); s.loader.exec_module(m)"
                result = subprocess.run([sys.executable, "-c", code], text=True, capture_output=True, timeout=5, cwd=ROOT)
                self.assertEqual((result.returncode, result.stdout, result.stderr), (0, "", ""))

    @unittest.skipIf(os.name != "posix" or os.geteuid() == 0, "needs non-root POSIX permissions")
    def test_file_permission_failures(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            source = base / "a.txt"
            source.write_text("Ada\n", encoding="ascii")
            source.chmod(0)
            try:
                self.check(5, [str(source), str(source)], 1, "Error: cannot read UTF-8 rosters.\n")
            finally:
                source.chmod(0o600)
            folder = base / "locked"
            folder.mkdir()
            folder.chmod(0o500)
            try:
                self.check(8, ["1000", "200", str(folder / "tone.wav")], 1, "Error: cannot create WAV; choose a new path.\n")
                self.assertFalse((folder / "tone.wav").exists())
            finally:
                folder.chmod(0o700)


if __name__ == "__main__":
    unittest.main()
