import sys

CASES = {"cycle": (b"\xc0\x00", 0), "backref": (b"\x03lab\x00\xc0\x00", 5), "plain": (b"\x03lab\x00", 0), "short": (b"\xc0", 0), "past": (b"\xc0\xff", 0), "root": (b"\x00", 0)}


def read_name(packet, position):
    seen = set()
    for step in range(8):
        if position in seen or not 0 <= position < len(packet):
            raise ValueError("Cycle or bad offset")
        seen.add(position)
        size = packet[position]
        if size & 0xC0 == 0xC0:
            if position + 1 >= len(packet):
                raise ValueError("Short pointer")
            position = ((size & 0x3F) << 8) | packet[position + 1]
            continue
        if size == 0:
            return ""
        end = position + 1 + size
        if size > 63 or end >= len(packet) or packet[end] != 0:
            raise ValueError("Unsupported label")
        return packet[position + 1:end].decode("ascii")
    raise ValueError("Hop budget exceeded")


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script cycle|backref|plain|short|past|root", file=sys.stderr)
        return 2
    packet, position = CASES[sys.argv[1]]
    try:
        name = read_name(packet, position)
    except (ValueError, UnicodeError):
        print("Invalid lab DNS name.", file=sys.stderr)
        return 2
    print(f"Name: {ascii(name)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
