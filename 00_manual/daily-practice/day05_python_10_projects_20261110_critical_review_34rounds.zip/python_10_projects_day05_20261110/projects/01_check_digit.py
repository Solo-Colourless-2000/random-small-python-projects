import sys


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 01_check_digit.py digits")
        return 2
    payload = sys.argv[1]
    if not 1 <= len(payload) <= 12:
        print("Error: use 1-12 ASCII digits.")
        return 2
    for character in payload:
        if character not in "0123456789":
            print("Error: use ASCII digits only.")
            return 2
    total = 0
    for position, character in enumerate(payload[::-1]):
        digit = int(character)
        if position % 2 == 0:
            digit *= 2
            if digit > 9:
                digit -= 9
        total += digit
    check = (-total) % 10
    print(f"Check digit: {check}")
    print(f"Number: {payload}{check}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
