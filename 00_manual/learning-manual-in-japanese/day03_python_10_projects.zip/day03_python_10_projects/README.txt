Pythonミニプロジェクト教材 day03 / 2026-11-08 (Asia/Tokyo)
================================================================
最初に開くHTML：python_10_projects_day03_manual.html
ZIP名：day03_python_10_projects_20261111_fifth_review_36rounds.zip（第5回改訂版）

ZIPを別フォルダーへ展開し、このREADMEとHTMLがある教材ルートを
ターミナルの現在地にします。HTMLを開く操作では現在地は変わりません。
HTMLはCSS/JavaScriptを内蔵し、外部サービスなしで読めます。

Linux / Python 3.10以上を想定、標準ライブラリのみ。
初回版の実行確認：Debian GNU/Linux 13、Python 3.12.14、Linux x86_64。
再監査の実行環境：Linux/Python 3.13（root、権限検査のみ非root）。
Python 3.10実機、Arch/Mint/Kali実機は未確認です。
新規導入後は基本実習をオフラインで進められます。
基本実習250分、準備・休憩・確認込み5〜6時間が目安です。
入力速度で変わり、初学者による時間の実測はしていません。
任意の復習とPython/vimの新規導入時間は基本実習と別枠です。

最初の確認（教材ルートで）：
python3 --version
pwd
ls
mkdir -p practice
vim practice/01_bit_inspector.py

vim操作：
1. 上のvimコマンドで開く。
2. iを押して挿入モードへ。
3. HTMLのSTEP 01〜04を同じファイルへ上から入力する。
4. Escでノーマルモードへ。
5. :wqを入力してEnter。保存して終了。
6. ターミナルで次を実行。
python3 practice/01_bit_inspector.py 13

:wqはvim内の操作です。シェル/Pythonのコードではありません。
字下げは4スペース、UTF-8のプレーンテキスト、拡張子.pyです。
行番号は入力せず、完成版を工程の末尾へ重ねて貼りません。
保存のみ:w、変更を捨てる:q!、取り消しu、末尾から再開G→o。
貼り付けで字下げが増えるならEsc→:set paste→Enter→i、
貼り付け後はEsc→:set nopaste→Enterとします。
Neovimではvimをnvimへ置き換えられます。

projects/は完成版、practice/は自分で入力する場所です。
自分の作品を実行するときは以下のprojects/をpractice/へ変えます。
全作品は独立し、前の作品の生成物は不要です。

完成版の実行例（教材ルートで、各コマンドは独立）：
python3 projects/01_bit_inspector.py 13
python3 projects/02_packing_list.py "Pen, book, pen, CUP"
python3 projects/03_run_encoder.py AAABBA
python3 projects/04_bracket_checker.py "([])"
python3 projects/05_sorted_merge.py "1,4,4" "2,3,8"
python3 projects/06_text_diff.py samples/before.txt samples/after.txt
python3 projects/07_json_checklist.py samples/tasks.json practice/checklist.md
python3 projects/08_service_queue.py < samples/queue_input.txt
python3 projects/09_fraction_calculator.py 1/3 + 1/6
python3 projects/10_cell_generations.py 00100 2

作品07の保存内容を確認：
cat practice/checklist.md

diff -u samples/checklist_expected.md practice/checklist.md

同じコマンドの再実行：
作品07以外は、そのまま同じコマンドで実行できます。
作品07は上書きを防ぐため、新しい出力名を指定します。
python3 projects/07_json_checklist.py samples/tasks.json practice/checklist_2.md

作品08を対話で試す場合：
python3 projects/08_service_queue.py
起動後に add Ada、add Bob、next、show、quit を1行ずつ入力。
リダイレクトしたstdoutには端末の入力エコーを含みません。
EOF/Ctrl+Cは終了1、無効コマンドは終了2です。

終了ステータスは各コマンドの直後に次で確認します。
echo $?
成功0、ファイルI/O・中断1、入力の個数・形式・範囲2です。
差分や括弧不一致の検出は正常な検査結果なので終了0です。

同梱のテスト（教材ルートで）：
python3 -m unittest discover -s tests -v

テストはprojects版と教材の整合性を確認します。
practiceの手入力版はHTMLの基本例とdiffで照合してください。
例：
diff -u projects/01_bit_inspector.py practice/01_bit_inspector.py

ファイル：
python_10_projects_day03_manual.html  全20章、40工程、完成ソース・各行の構文分解
projects/                           完成コード10本
practice/                           自分で入力する場所（初期は空）
samples/                            比較・JSON・対話のASCIIサンプル
tests/                              unittestによる実行・整合性検査
verification/                       これまでの監査記録、今回の追加24観点監査と検証結果
PROJECT_HISTORY.json                確認できたday01〜day03の題材台帳
REVIEW_REPORT.txt                   最終の検証範囲・結果・制限
HANDOFF_PROMPT.txt                  次回番号と累積台帳の引き継ぎ

最終件数はREVIEW_REPORT.txtとverification/current_unittest.logを参照。
ブラウザー検証用Playwrightは学習者の基本実習や同梱テストには不要です。
コピー不可時は手動欄でCtrl+A/Ctrl+C、保存不可時は紙に進捗を控えます。

履歴の保存：
/Daily-PJは利用できないため、作業領域/workspace/python_dailyに台帳を保持。
今回の照会では「Pythonミニプロジェクト教材」の既存自動タスクが
見つからず、保存プロンプトは更新していません。新規タスクも作りません。
HANDOFF_PROMPT.txtを次回の実行時に添えてください。

今回の再監査対象：day03（2026-11-08、日本時間）。次回：day04。
直近の改訂：10作品全件を対象に追加22周（220判定＋全体5判定）すべてPASS。
作品09の約分前の分子・分母検査と作品10のASCII世代数検査を修正。
作品01〜10にケース別の詳説と試行例を追加し、コード・行解説も再同期。
自動テストは通常ユーザー権限で53件成功、失敗0・エラー0・スキップ0。
詳しい記録：REVIEW_REPORT.txt、verification/audit_second_22_rounds.json、
verification/current_unittest.log、verification/current_browser_review.json。
前回の24観点監査記録も履歴として保持。古いテストログは今回の成績ではありません。

【第3回の追加再監査・2026-11-08】
さらに24観点×10作品＝240件の作品別監査と5件の全体チェックを実施。
作品02はstrip(" ")を使って前後のASCIIスペースだけを除去するよう修正し、
タブなどの制御文字を拒否する回帰テストを加えました。
作品05はsorted(values)を用いた入力検査の説明を正確に修正しました。
10作品の各章に、具体的な追加説明・実測コマンド・stdout・終了コードを追加。
新規テストはtests/test_third_review.pyです。
第3回当時の通常ユーザー権限unittestは59件、失敗0・エラー0・スキップ0。
第3回当時の結果はverification/audit_third_24_rounds.json、
verification/third_unittest.log、verification/third_browser_review.jsonを参照。
従来のaudit_second_22_rounds.jsonや旧ログは履歴であり、最新版の検証ではありません。

【第4回改訂・2026-11-11】
添付された第3回改訂ZIPだけを編集元として使用しています。
作品07：JSON内の重複キーを検出し、入力エラー2で拒否する補助関数を追加しました。
従来の「重複したキーは後勝ち」という制限を解消しました。
全10作品：コードのすべての非空行を対象に、キーワード・変数・式・記号を
分解して解説する折りたたみ欄を工程説明と付録Aの両方へ追加しました。
全746欄の折りたたみ説明に対応します（実際のコード非空行373行×2）。
加えて状態追跡と問いを含む演習を10作品に新設しました。
作品09/10：逐行解説テーブルのHTML構造を修復しました。
モバイルではコードの長い行を崩さず、表の内側を横スクロールできます。
既存の旧監査ログは履歴です。第4回当時の確認結果は
verification/fourth_audit_45_checks.json、fourth_browser_review.json、
verification/fourth_unittest.log、verification/previous_REVIEW_REPORT_fourth_review.txtを参照してください。
45観点の再現：教材ルートで python3 verification/fourth_audit_45_checks.py
元ZIP未保存なら原本依存の3観点はSKIPとなります。完全に再現するには
python3 verification/fourth_audit_45_checks.py /元のZIPへのパス
を実行してください（この監査にはbeautifulsoup4の別途インストールが必要）。

第4回改訂の最終実測：45観点PASS、unittest 69件成功（失敗0・エラー0・スキップ0）、Chromium 3画面幅合格。

【第5回改訂・2026-11-11】
修正元はユーザーがこの会話で添付した第4回改訂ZIPのみです。
projects/の10本のPythonプログラムは今回、実装仕様と実測が一致していたため
変更しませんでした。HTMLマニュアルと新規テスト、検証手順を更新しました。

・10作品すべてに実際の値を追う4列の段階表、よくある誤解、確認課題を追加。
・全40工程の定型的なつなぎ説明を、コードの動作に合う個別説明へ書き換え。
・全746件の構文分解で、関数呼び出し/定義の括弧、exceptでまとめる括弧、
  スライス、空リストと添字、forのin、f文字列の波括弧などを文脈で説明。
・関数のキーワード引数encoding/newline/object_pairs_hookは、
  左辺変数への代入とは区別し、基礎章へ記号の読み分け表（12例）を追加。
・作品07の本文に残った重複キーについての旧説明を訂正。
・作品06の改行正規化後の文字数制限を説明。生バイト長の制限ではありません。

検証：verification/fifth_36_review_rounds.py は個別に36の重点点検を実施します。
10作品の実装/通常例、10作品の異常例、10作品の教材とコードの逐行照合、
全体の内部リンク・HTML・外部依存・サンプル・説明の6点です。
これは36回の「人手による全ページ通読」を意味しません。
結果：verification/fifth_36_review_rounds.json

新規回帰テスト：tests/test_fifth_review.py（10件）。
全回帰テスト：python3 -m unittest discover -s tests -v
ブラウザー：verification/fifth_browser_review.json
最終結果と再現範囲はREVIEW_REPORT.txtを参照してください。
ブラウザーの自動確認には別途Playwright・Chromiumが必要ですが、
教材の基本実習とunittestはPython標準ライブラリで進められます。
