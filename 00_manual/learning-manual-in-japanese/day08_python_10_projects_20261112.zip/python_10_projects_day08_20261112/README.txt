Pythonペネトレーションテスト実習 day08
作成日 2026-11-12（日本時間）

最初に python_10_projects_day08_manual.html をブラウザーで開いてください。
ZIPを展開し、ターミナルを python_10_projects_day08_20261112/ に移動します。
現在地を pwd で、projects/ と samples/ が見えることを ls で確認します。

python3 --version
pwd
ls
mkdir -p practice
vim practice/01_symlink_scope.py

vimでは i で入力を開始し、Esc で戻って :wq とEnterで保存します。
字下げは半角スペース4個。全4工程を同じ実習ファイルへ追記します。
vimはnvimに置き換えられます。完成版はprojects/、自分で書く場所はpractice/です。

python3 practice/01_symlink_scope.py normal

完成版の試験入力（教材ルートで実行）
python3 projects/01_symlink_scope.py linked
python3 projects/02_shell_boundary.py separator
python3 projects/03_csrf_probe.py cross
python3 projects/04_zip_budget.py repeat
python3 projects/05_http_framing.py ambiguous
python3 projects/06_csv_formula.py formula
python3 projects/07_path_selection.py prepend
python3 projects/08_offline_guess.py hit
python3 projects/09_lost_update.py interleave
python3 projects/10_dns_wildcard.py deep

同じコマンドを再実行できます。配布物への書き込みはありません。
CLIは固定のケース名だけを受け取ります。
01・07は自分で作る一時領域へ合成ファイルを保存し、終了時に削除します。
02はLinuxの/bin/shで固定の表示コマンドだけを実行します。作成したlabtoolは実行しません。
終了値は0が実験完了、2がCLI入力エラーまたは固定構造の解析失敗、01・02・04・07の環境失敗は1です。

python3 -m unittest discover -s tests -v

点検の範囲と実行環境は REVIEW_REPORT.txt、詳細は verification/ を参照してください。
次回はday09です。
