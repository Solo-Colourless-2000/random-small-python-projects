CASES = {
    "01_option_boundary": [
        (["option"], 0, "Direct option count: 1\nDirect filenames: []\nSeparated option count: 0\nSeparated filenames: ['--debug']\n", ""),
        (["normal"], 0, "Direct option count: 0\nDirect filenames: ['note.txt']\nSeparated option count: 0\nSeparated filenames: ['note.txt']\n", ""),
        (["empty"], 0, "Direct option count: 0\nDirect filenames: ['']\nSeparated option count: 0\nSeparated filenames: ['']\n", ""),
        (["unknown"], 2, "", "Invalid lab option.\n"),
    ],
    "02_response_crlf": [
        (["split"], 0, "Header count: 2\nExtra header seen: True\nNo-newline gate: False\n", ""),
        (["plain"], 0, "Header count: 1\nExtra header seen: False\nNo-newline gate: True\n", ""),
        (["lf"], 0, "Header count: 1\nExtra header seen: False\nNo-newline gate: False\n", ""),
        (["empty"], 0, "Header count: 1\nExtra header seen: False\nNo-newline gate: True\n", ""),
    ],
    "03_xml_namespace": [
        (["foreign"], 0, "Local-name admin: True\nExpanded-name admin: False\n", ""),
        (["trusted"], 0, "Local-name admin: True\nExpanded-name admin: True\n", ""),
        (["bare"], 0, "Local-name admin: True\nExpanded-name admin: False\n", ""),
        (["broken"], 2, "", "Invalid lab XML.\n"),
    ],
    "04_zip_duplicate": [
        (["duplicate"], 0, "First member: mode=safe\nBy-name member: mode=debug\nUnique-name gate: False\n", ""),
        (["single"], 0, "First member: mode=safe\nBy-name member: mode=safe\nUnique-name gate: True\n", ""),
    ],
    "05_acl_order": [
        (["blocked"], 0, "Broad-first decision: allow\nException-first decision: deny\n", ""),
        (["neighbor"], 0, "Broad-first decision: allow\nException-first decision: allow\n", ""),
        (["outside"], 0, "Broad-first decision: deny\nException-first decision: deny\n", ""),
        (["broken"], 2, "", "Invalid lab address.\n"),
    ],
    "06_regex_partitions": [
        (["short"], 0, "Ambiguous partitions: 8\nLinear positions: 4\nNested pattern rejects: True\nFlat pattern rejects: True\n", ""),
        (["long"], 0, "Ambiguous partitions: 128\nLinear positions: 8\nNested pattern rejects: True\nFlat pattern rejects: True\n", ""),
        (["edge"], 0, "Ambiguous partitions: 1\nLinear positions: 1\nNested pattern rejects: True\nFlat pattern rejects: True\n", ""),
    ],
    "07_snapshot_alias": [
        (["shallow"], 0, "Shared details: True\nRecorded role: admin\nLive role: admin\n", ""),
        (["deep"], 0, "Shared details: False\nRecorded role: user\nLive role: admin\n", ""),
        (["unchanged"], 0, "Shared details: True\nRecorded role: user\nLive role: user\n", ""),
    ],
    "08_transaction_stop": [
        (["early"], 0, "Balances: 30,60\nTotal: 90\nConserved: False\n", ""),
        (["atomic"], 0, "Balances: 40,60\nTotal: 100\nConserved: True\n", ""),
    ],
    "09_udp_ratio": [
        (["small"], 0, "Request payload bytes: 1\nResponse payload bytes: 60\nPayload ratio: 60\n", ""),
        (["equal"], 0, "Request payload bytes: 60\nResponse payload bytes: 60\nPayload ratio: 1\n", ""),
    ],
    "10_short_reads": [
        (["fragmented"], 0, "Direct body: b'L'\nExact body: b'LAB'\nBodies equal: False\n", ""),
        (["empty"], 0, "Direct body: b''\nExact body: b''\nBodies equal: True\n", ""),
        (["maximum"], 0, "Direct body: b'A'\nExact body: b'ABCDEFGH'\nBodies equal: False\n", ""),
        (["short"], 2, "", "Invalid lab frame.\n"),
        (["oversize"], 2, "", "Invalid lab frame.\n"),
        (["header"], 2, "", "Invalid lab frame.\n"),
    ],
}

USAGE = [
    "option|normal|empty|unknown", "split|plain|lf|empty", "foreign|trusted|bare|broken",
    "duplicate|single", "blocked|neighbor|outside|broken", "short|long|edge", "shallow|deep|unchanged",
    "early|atomic", "small|equal", "fragmented|empty|maximum|short|oversize|header",
]
for cases, usage in zip(CASES.values(), USAGE):
    for args in ([], ["bad"], [""], [cases[0][0][0], "extra"]):
        cases.append((args, 2, "", f"Usage: script {usage}\n"))
