"""Tk Canvas rendering layer: backgrounds, world entities, HUD, screen overlays."""
import math
import random
import time
import tkinter as tk
from arena_config import C, UPGRADES, SCREEN_W, SCREEN_H, OX, OY
from c_bridge import WORLD_W, WORLD_H
from arena_menus import ArenaMenus

class ArenaRenderer(ArenaMenus):
    def cr(self,*args,**kw):
        kw.setdefault('tags',self.draw_tag)
        return self.canvas.create_rectangle(*args,**kw)

    def ct(self,*args,**kw):
        kw.setdefault('tags',self.draw_tag)
        kw.setdefault('font',('Consolas',12))
        return self.canvas.create_text(*args,**kw)

    def co(self,*args,**kw):
        kw.setdefault('tags',self.draw_tag)
        return self.canvas.create_oval(*args,**kw)

    def cl(self,*args,**kw):
        kw.setdefault('tags',self.draw_tag)
        return self.canvas.create_line(*args,**kw)

    def cp(self,*args,**kw):
        kw.setdefault('tags',self.draw_tag)
        return self.canvas.create_polygon(*args,**kw)

    def _create_background(self):
        c=self.canvas
        c.create_rectangle(0,0,SCREEN_W,SCREEN_H,fill=C['bg'],outline='',tags='static')
        c.create_rectangle(OX-4,OY-4,OX+WORLD_W+4,OY+WORLD_H+4,
                           fill='#071018',outline='#2e5961',width=2,tags='static')
        c.create_rectangle(OX,OY,OX+WORLD_W,OY+WORLD_H,
                           fill=C['floor'],outline='',tags='static')
        r=random.Random(66020)
        for _ in range(95):
            x=r.uniform(OX+10,OX+WORLD_W-10);y=r.uniform(OY+10,OY+WORLD_H-10)
            rr=r.uniform(8,34)
            c.create_oval(x-rr,y-rr*.55,x+rr,y+rr*.55,outline='#1a2d37',width=1,tags='static')
            c.create_arc(x-rr*.7,y-rr*.38,x+rr*.7,y+rr*.38,
                         start=r.randint(0,300),extent=r.randint(45,140),
                         outline='#223742',style=tk.ARC,tags='static')
        for x in range(0,WORLD_W+1,40):
            color='#1c333d' if x%200==0 else '#182b35'
            c.create_line(OX+x,OY,OX+x,OY+WORLD_H,fill=color,tags='static')
        for y in range(0,WORLD_H+1,40):
            color='#1c333d' if y%200==0 else '#182b35'
            c.create_line(OX,OY+y,OX+WORLD_W,OY+y,fill=color,tags='static')
        for _ in range(270):
            x=r.randrange(OX+6,OX+WORLD_W-6);y=r.randrange(OY+6,OY+WORLD_H-6)
            c.create_line(x,y,x+r.randint(-4,4),y+r.randint(-2,2),
                          fill=r.choice(['#233940','#273d41','#182c33']),tags='static')
        # Framing / world boundary marks.
        for x in range(OX+25,OX+WORLD_W,110):
            c.create_line(x,OY-3,x+33,OY-3,fill='#315c65',width=2,tags='static')
            c.create_line(x,OY+WORLD_H+3,x+33,OY+WORLD_H+3,fill='#315c65',width=2,tags='static')
        for x,y,xx,yy in [(OX,OY,OX+18,OY+18),(OX+WORLD_W,OY,OX+WORLD_W-18,OY+18),
                          (OX,OY+WORLD_H,OX+18,OY+WORLD_H-18),
                          (OX+WORLD_W,OY+WORLD_H,OX+WORLD_W-18,OY+WORLD_H-18)]:
            c.create_line(x,yy,x,y,xx,y,fill=C['cyan'],width=3,tags='static')
        c.create_rectangle(0,0,SCREEN_W,105,fill='#0b1720',outline='',tags='static')
        c.create_line(60,106,1220,106,fill='#31545e',width=2,tags='static')
        c.create_rectangle(0,741,SCREEN_W,SCREEN_H,fill='#09141d',outline='',tags='static')
        c.create_line(60,744,1220,744,fill='#29444f',width=2,tags='static')
        if self.scale!=1.0:
            c.scale('static',0,0,self.scale,self.scale)

    def panel(self,x,y,w,h,fill='#101d26',outline='#355761',tag=None):
        tag=tag or self.draw_tag
        self.cr(x,y,x+w,y+h,fill=fill,outline=outline,width=1,tags=tag)
        self.cl(x+1,y+1,x+19,y+1,fill=C['cyan'],width=2,tags=tag)
        self.cl(x+1,y+1,x+1,y+17,fill=C['cyan'],width=2,tags=tag)
        self.cl(x+w-19,y+h-1,x+w-1,y+h-1,fill=C['cyan'],width=2,tags=tag)

    def text(self,x,y,txt,size=12,color=None,weight='normal',anchor='center',tag=None):
        font=('Consolas',max(7,round(size*self.scale)),weight)
        # Text font scales independently because Canvas.scale does not resize fonts.
        return self.ct(x,y,text=txt,fill=color or C['text'],anchor=anchor,font=font,tags=tag or self.draw_tag)

    def bar(self,x,y,w,h,ratio,fill,back='#263740',outline='#3a5661'):
        ratio=max(0,min(1,ratio))
        self.cr(x,y,x+w,y+h,fill=back,outline=outline,width=1)
        if ratio>0.0001:
            self.cr(x+2,y+2,x+2+(w-4)*ratio,y+h-2,fill=fill,outline='')
            self.cl(x+3,y+3,x+3+(w-6)*ratio,y+3,fill='#f2f3cf',width=1)

    @staticmethod
    def oriented(cx,cy,hx,hy,angle,ox=0,oy=0):
        cos,sin=math.cos(angle),math.sin(angle)
        coords=[]
        for u,v in [(-hx,-hy),(hx,-hy),(hx,hy),(-hx,hy)]:
            u+=ox;v+=oy
            coords.extend((cx+u*cos-v*sin,cy+u*sin+v*cos))
        return coords

    def draw_tank(self,x,y,angle,turret,radius,enemy_type=-1,flash=0,stun=0,invuln=0):
        player=enemy_type==-1
        boss=enemy_type==3
        scale=radius/23.0
        if player:
            hull='#358c82';light='#75ddc5';track='#22353a';edge='#b4f1da';barrel='#aecbc0'
        elif enemy_type==0:
            hull='#aa635c';light='#fda87c';track='#352c33';edge='#e8a596';barrel='#eac2aa'
        elif enemy_type==1:
            hull='#ba8460';light='#f2b477';track='#3c3438';edge='#efcf96';barrel='#e4bea5'
        elif enemy_type==2:
            hull='#765c7d';light='#ce97c4';track='#303039';edge='#bc9ebf';barrel='#d9c0c5'
        else:
            hull='#b34753';light='#ff9c8a';track='#362936';edge='#ffbbb0';barrel='#f1c4b0'
        if flash>0:
            hull='#f4dbb4';light='#ffffff'
        if stun>0:
            self.co(x-33*scale,y-33*scale,x+33*scale,y+33*scale,
                    outline='#9ab5fd',width=2)
        if invuln>0 and player:
            self.co(x-35,y-35,x+35,y+35,outline='#a4efea',width=2)
        self.co(x-24*scale,y-14*scale+6,x+27*scale,y+18*scale+6,
                fill='#0b151c',outline='')
        for side in (-1,1):
            self.cp(self.oriented(x,y,22*scale,7*scale,angle,0,side*17*scale),
                    fill=track,outline='#5d6970',width=1)
            for offset in (-14,-5,5,14):
                pts=self.oriented(x,y,2.2*scale,6.4*scale,angle,offset*scale,side*17*scale)
                self.cp(pts,fill='#526871' if player else '#70676b',outline='')
        self.cp(self.oriented(x,y,25*scale,15*scale,angle),
                fill=hull,outline=edge,width=2)
        self.cp(self.oriented(x,y,18*scale,9.3*scale,angle,1*scale,0),
                fill=light,outline='')
        self.cp(self.oriented(x,y,13*scale,5.5*scale,angle,-4*scale,0),
                fill=hull,outline='')
        # Small front light markings clarify direction independent of the turret.
        for side in (-1,1):
            fpx=x+math.cos(angle)*21*scale-math.sin(angle)*side*9*scale
            fpy=y+math.sin(angle)*21*scale+math.cos(angle)*side*9*scale
            self.co(fpx-2.0*scale,fpy-2.0*scale,fpx+2.0*scale,fpy+2.0*scale,
                    fill='#ffefb0' if player else '#ff9b72',outline='')
        # Traverse independently of the hull.
        self.cp(self.oriented(x,y,(35 if boss else 31)*scale,5.5*scale,turret,13*scale,0),
                fill=barrel,outline='#1a3034',width=1)
        self.cp(self.oriented(x,y,12*scale,11*scale,turret,-1*scale,0),
                fill=hull,outline=edge,width=2)
        self.co(x-5.5*scale,y-5.5*scale,x+5.5*scale,y+5.5*scale,
                fill=track,outline=light,width=2)
        if boss:
            self.co(x-25,y-25,x+25,y+25,outline='#ff686e',width=2,dash=(5,5))

    def draw_obstacles(self,s):
        for i in range(s.obstacle_count):
            o=s.obstacles[i]
            if not o.active:continue
            x=OX+o.x;y=OY+o.y
            self.cr(x+5,y+7,x+o.w+5,y+o.h+7,fill='#0a1319',outline='')
            if o.kind==0:
                self.cr(x,y,x+o.w,y+o.h,fill='#4a6470',outline='#a0b7ad',width=2)
                self.cr(x+6,y+6,x+o.w-6,y+o.h-6,fill='#354c58',outline='#597681')
                if o.w>o.h:
                    self.cl(x+12,y+o.h/2,x+o.w-12,y+o.h/2,fill='#6c8690',width=2)
                else:
                    self.cl(x+o.w/2,y+9,x+o.w/2,y+o.h-9,fill='#6c8690',width=2)
                for dx in (7,o.w-7):
                    for dy in (7,o.h-7):
                        self.co(x+dx-2,y+dy-2,x+dx+2,y+dy+2,
                                fill='#96b4b4',outline='')
            else:
                damaged=o.hp<90
                self.cr(x,y,x+o.w,y+o.h,fill='#716349' if damaged else '#877553',
                        outline='#c2ac7a',width=2)
                self.cr(x+5,y+5,x+o.w-5,y+o.h-5,fill='#66583d',outline='#a08d60')
                self.cl(x+7,y+7,x+o.w-7,y+o.h-7,fill='#a99c76',width=2)
                self.cl(x+o.w-7,y+7,x+7,y+o.h-7,fill='#a99c76',width=2)
                if damaged:
                    self.cl(x+o.w/2,y+8,x+o.w*.35,y+o.h*.6,x+o.w*.7,y+o.h-8,
                            fill='#e4d1a5',width=2)

    def draw_bullets(self,s):
        for b in s.bullets:
            if not b.active:continue
            x=OX+b.x;y=OY+b.y
            color=C['gold'] if b.owner==0 else C['red']
            self.cl(OX+b.prev_x,OY+b.prev_y,x,y,fill=color,width=4 if b.owner==0 else 3)
            self.co(x-7,y-7,x+7,y+7,outline=color,width=2)
            self.co(x-3.3,y-3.3,x+3.3,y+3.3,fill='#fff9d7' if b.owner==0 else '#ffd9ca',outline='')

    def draw_pickups(self,s):
        for p in s.pickups:
            if not p.active:continue
            x=OX+p.x;y=OY+p.y
            glow=4*math.sin(s.time*6.2)
            col=C['green'] if p.kind==0 else C['cyan']
            self.co(x-16-glow/3,y-16-glow/3,x+16+glow/3,y+16+glow/3,
                    outline=col,width=2)
            self.cp([x,y-10,x+10,y,x,y+10,x-10,y],fill='#17333a',outline=col,width=2)
            if p.kind==0:
                self.cr(x-6,y-1.5,x+6,y+1.5,fill=col,outline='')
                self.cr(x-1.5,y-6,x+1.5,y+6,fill=col,outline='')
            else:
                self.cp([x+1,y-7,x-5,y+1,x,y+1,x-2,y+7,x+6,y-2,x+1,y-2],
                        fill=col,outline='')

    def draw_particles(self):
        for p in self.particles:
            x=OX+p.x;y=OY+p.y
            if x<OX or x>OX+WORLD_W or y<OY or y>OY+WORLD_H:continue
            decay=p.life/p.maximum
            size=max(.6,p.size*decay)
            if p.kind=='smoke':
                self.co(x-size,y-size,x+size,y+size,outline=p.color)
            else:
                self.cl(x-p.vx*.011*decay,y-p.vy*.011*decay,x+p.vx*.006*decay,
                        y+p.vy*.006*decay,fill=p.color,width=max(1,round(size*.6)))
        for t in self.floats:
            if OX<=OX+t.x<=OX+WORLD_W and OY<=OY+t.y<=OY+WORLD_H:
                self.text(OX+t.x,OY+t.y,t.text,13,t.color,'bold')

    def refresh_cover(self,s):
        # Static scenery is cached until a destructible crate is damaged.
        # Otherwise Canvas would need to recreate ~100 unchanged shapes every frame.
        signature=tuple((o.active, round(o.hp, 1) if o.kind else 0)
                        for o in list(s.obstacles)[:s.obstacle_count])
        if signature==self._cover_signature:
            return
        self._cover_signature=signature
        self.canvas.delete('cover')
        self.draw_obstacles(s)
        self.canvas.addtag_withtag('cover','dynamic')
        self.canvas.dtag('cover','dynamic')
        if self.scale!=1.0:
            self.canvas.scale('cover',0,0,self.scale,self.scale)

    def draw_world(self,s):
        self.draw_pickups(s)
        self.draw_bullets(s)
        for e in s.enemies:
            if not e.active:continue
            x=OX+e.x;y=OY+e.y
            self.draw_tank(x,y,e.angle,e.turret,e.radius,e.type,e.flash,e.stun)
            bw=52 if e.type!=3 else 90
            if e.hp<e.max_hp or e.type==3:
                self.cr(x-bw/2,y-e.radius-18,x+bw/2,y-e.radius-12,
                        fill='#2e3034',outline='')
                self.cr(x-bw/2,y-e.radius-18,x-bw/2+bw*(e.hp/e.max_hp),y-e.radius-12,
                        fill='#ff7f78' if e.type!=3 else '#ffad8f',outline='')
        if s.player_alive:
            p=s.player
            self.draw_tank(OX+p.x,OY+p.y,p.angle,p.turret,p.radius,flash=p.flash,
                           invuln=s.invulnerability)
            # Mouse aiming ring and target ticks.
            x,y=self.pointer
            if OX<x<OX+WORLD_W and OY<y<OY+WORLD_H and self.screen in ('PLAYING','INTRO'):
                self.co(x-13,y-13,x+13,y+13,outline=C['cyan'],width=1)
                for dx,dy in ((0,-20),(0,20),(-20,0),(20,0)):
                    self.cl(x+dx*.72,y+dy*.72,x+dx,y+dy,fill=C['cyan'],width=2)
        self.draw_particles()

    def draw_hud(self,s):
        self.text(80,13,'FIELD SYSTEMS  /  ONLINE',11,C['muted'],'bold',anchor='nw')
        self.text(80,30,'STEEL',27,C['text'],'bold',anchor='nw')
        self.text(207,30,'FRONT',27,C['cyan'],'bold',anchor='nw')
        self.text(352,18,'WAVE',12,C['muted'],'bold',anchor='nw')
        self.text(353,37,f'{s.wave:02}',33,C['gold'],'bold',anchor='nw')
        self.text(449,18,'HOSTILES',12,C['muted'],'bold',anchor='nw')
        self.text(450,40,f'{s.enemy_count:02}',28,C['red'],'bold',anchor='nw')
        self.text(605,18,'COMBO',12,C['muted'],'bold',anchor='nw')
        self.text(604,41,f'x{s.combo}' if s.combo>1 else '---',26,C['gold'] if s.combo>1 else C['steel'],'bold',anchor='nw')
        self.text(791,18,'KILLS',12,C['muted'],'bold',anchor='nw')
        self.text(792,41,f'{s.kills:03}',25,C['text'],'bold',anchor='nw')
        self.text(981,18,'TACTICAL SCORE',12,C['muted'],'bold',anchor='nw')
        self.text(978,39,f'{s.score:08}',31,C['gold'],'bold',anchor='nw')
        self.text(80,79,'HULL',10,C['muted'],'bold',anchor='nw')
        self.bar(132,81,179,12,s.player.hp/max(s.player.max_hp,1),
                 C['green'] if s.player.hp>45 else C['red'])
        self.text(320,78,f'{math.ceil(s.player.hp)}/{math.ceil(s.player.max_hp)}',11,C['text'],anchor='nw')
        self.text(400,79,'DASH',10,C['muted'],'bold',anchor='nw')
        self.bar(448,81,159,12,s.dash_energy/100,C['cyan'])
        self.text(617,79,f'{round(s.dash_energy)}%',10,C['text'],anchor='nw')
        self.text(699,79,'EMP',10,C['muted'],'bold',anchor='nw')
        ratio=1.0-s.pulse_cooldown/max(.01,s.pulse_cooldown_max)
        self.bar(737,81,166,12,ratio,C['blue'])
        self.text(911,79,'READY' if ratio>=1 else f'{s.pulse_cooldown:.1f}s',11,
                  C['cyan'] if ratio>=1 else C['muted'],anchor='nw')
        if s.focus_timer > 0:
            self.text(1140,81,f'FOCUS {s.focus_timer:.1f}s',11,C['amber'],'bold',anchor='ne')
        if s.wave>0:
            if self.scale<.70:
                # Two HUD rows clip on displays below ~800px wide.
                self.text(83,766,'WASD MOVE  /  MOUSE AIM  /  CLICK FIRE  /  SHIFT DASH  /  E EMP  /  P PAUSE',
                          10,C['text'],anchor='nw')
                self.text(1188,766,'C / PYTHON',10,C['cyan'],'bold',anchor='ne')
            else:
                self.text(83,762,'W A S D / ARROWS   MOVE     |     MOUSE   AIM     |     LMB / SPACE   FIRE',
                          12,C['text'],'bold',anchor='nw')
                self.text(83,782,'SHIFT   BOOST DASH         E   EMP SHOCKWAVE         P / ESC   PAUSE',
                          11,C['muted'],anchor='nw')
                self.text(1188,763,'C / PYTHON',11,C['cyan'],'bold',anchor='ne')
                self.text(1188,782,'CORE 04  //  60 Hz',10,C['muted'],anchor='ne')

    def render(self):
        c=self.canvas
        c.delete('dynamic')
        s=self.engine.state
        self.refresh_cover(s)
        self.draw_world(s)
        if self.screen=='TITLE':
            c.delete('hud')
        elif time.perf_counter()-self.hud_last_updated>.095 or self.screen!=self.last_rendered_screen:
            c.delete('hud')
            self.draw_tag='hud'
            self.draw_hud(s)
            self.draw_tag='dynamic'
            if self.scale!=1.0:c.scale('hud',0,0,self.scale,self.scale)
            self.hud_last_updated=time.perf_counter()
        if self.clear_timer is not None and self.screen=='PLAYING':
            self.cr(449,334,831,410,fill='#0d2a2b',outline=C['cyan'],width=2)
            self.text(640,361,'SECTOR SECURED',22,C['cyan'],'bold')
            self.text(640,393,'UPGRADE MODULE INBOUND',12,C['muted'])
        if self.screen=='TITLE':self.title_screen()
        elif self.screen=='INTRO':self.intro_overlay(s)
        elif self.screen=='PAUSED':self.pause_screen()
        elif self.screen=='UPGRADE':self.upgrade_screen(s)
        elif self.screen=='GAMEOVER':self.gameover_screen(s)
        if self.flash_timer>0 and self.screen in ('PLAYING','INTRO'):
            self.cr(OX,OY,OX+WORLD_W,OY+WORLD_H,
                    fill='#b95c60',stipple='gray12',outline='')
        if self.scale!=1.0:
            c.scale('dynamic',0,0,self.scale,self.scale)
        self.last_rendered_screen=self.screen
        if self.screen=='UPGRADE':
            mx,my=self.pointer
            self.last_rendered_hover=next((i for i,(l,t,r,b) in enumerate(self.card_bounds)
                                             if l<=mx<=r and t<=my<=b),None)
        else:self.last_rendered_hover=None

