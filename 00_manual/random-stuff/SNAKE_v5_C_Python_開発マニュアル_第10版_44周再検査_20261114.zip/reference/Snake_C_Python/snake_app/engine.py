"""Type-safe Python interface to the C engine (one snapshot call per frame)."""
from __future__ import annotations

import ctypes as ct
from dataclasses import dataclass
from enum import IntEnum
from pathlib import Path
import secrets


class Direction(IntEnum):
    UP = 0
    RIGHT = 1
    DOWN = 2
    LEFT = 3


class Status(IntEnum):
    RUNNING = 0
    LOST = 1
    WON = 2


class Event(IntEnum):
    MOVED = 0
    ATE = 1
    DIED = 2
    VICTORY = 3
    NOOP = 4


class _CCell(ct.Structure):
    _fields_ = [("x", ct.c_int), ("y", ct.c_int)]


class _CSnapshot(ct.Structure):
    _fields_ = [("width", ct.c_int), ("height", ct.c_int),
                ("length", ct.c_int), ("food_x", ct.c_int),
                ("food_y", ct.c_int), ("score", ct.c_int),
                ("direction", ct.c_int), ("status", ct.c_int)]


@dataclass(frozen=True)
class Frame:
    width: int
    height: int
    body: tuple[tuple[int, int], ...]
    food: tuple[int, int] | None
    score: int
    direction: Direction
    status: Status


def load_library(path: Path | None = None) -> ct.CDLL:
    auto_built = path is None
    if auto_built:
        from build import ensure_library
        path = ensure_library()
    assert path is not None
    try:
        lib = ct.CDLL(str(path))
    except OSError:
        # Recover from an old binary after a system or architecture upgrade.
        if not auto_built:
            raise
        from build import ensure_library
        lib = ct.CDLL(str(ensure_library(force=True)))
    lib.snake_create.argtypes = (ct.c_int, ct.c_int, ct.c_uint32)
    lib.snake_create.restype = ct.c_void_p
    lib.snake_destroy.argtypes = (ct.c_void_p,)
    lib.snake_destroy.restype = None
    lib.snake_reset.argtypes = (ct.c_void_p, ct.c_uint32)
    lib.snake_reset.restype = None
    lib.snake_set_direction.argtypes = (ct.c_void_p, ct.c_int)
    lib.snake_set_direction.restype = ct.c_int
    lib.snake_tick.argtypes = (ct.c_void_p,)
    lib.snake_tick.restype = ct.c_int
    lib.snake_snapshot.argtypes = (ct.c_void_p, ct.POINTER(_CSnapshot),
                                   ct.POINTER(_CCell), ct.c_int)
    lib.snake_snapshot.restype = ct.c_int
    return lib


def _validated_seed(seed: int | None) -> int:
    if seed is None:
        return secrets.randbits(32)
    if type(seed) is not int or not 0 <= seed <= 0xFFFFFFFF:
        raise ValueError("seed must be a 32-bit unsigned integer")
    return seed


class SnakeEngine:
    def __init__(self, width: int = 26, height: int = 18, *,
                 library: ct.CDLL | None = None, seed: int | None = None) -> None:
        # Validate before ctypes can truncate an out-of-range Python integer.
        if (type(width) is not int or type(height) is not int or
                not 8 <= width <= 64 or not 8 <= height <= 64):
            raise ValueError("Board width and height must each be 8..64 integers")
        initial_seed = _validated_seed(seed)
        # Allocate the Python snapshot buffer before the C allocation. If this
        # raises MemoryError, no native state is left orphaned.
        self._cells = (_CCell * (width * height))()
        self._lib = library if library is not None else load_library()
        self._ptr: int | None = self._lib.snake_create(width, height, initial_seed)
        if not self._ptr:
            raise MemoryError("C engine could not allocate game state")

    def close(self) -> None:
        if self._ptr is not None:
            self._lib.snake_destroy(self._ptr)
            self._ptr = None

    def __enter__(self) -> SnakeEngine:
        return self

    def __exit__(self, *_: object) -> None:
        self.close()

    def _handle(self) -> int:
        if self._ptr is None:
            raise RuntimeError("Snake engine is already closed")
        return self._ptr

    def reset(self, *, seed: int | None = None) -> None:
        self._lib.snake_reset(self._handle(), _validated_seed(seed))

    def turn(self, direction: Direction) -> bool:
        if not isinstance(direction, Direction):
            raise ValueError("direction must be a Direction value")
        return bool(self._lib.snake_set_direction(self._handle(), int(direction)))

    def tick(self) -> Event:
        return Event(self._lib.snake_tick(self._handle()))

    def snapshot(self) -> Frame:
        native = _CSnapshot()
        ok = self._lib.snake_snapshot(self._handle(), ct.byref(native),
                                      self._cells, len(self._cells))
        if not ok:
            raise RuntimeError("C engine snapshot failed")
        body = tuple((self._cells[i].x, self._cells[i].y) for i in range(native.length))
        return Frame(native.width, native.height, body,
                     None if native.food_x < 0 else (native.food_x, native.food_y),
                     native.score, Direction(native.direction), Status(native.status))
