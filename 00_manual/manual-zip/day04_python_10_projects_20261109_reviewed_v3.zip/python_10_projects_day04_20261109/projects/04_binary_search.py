import sys

NUMBERS = (3, 7, 11, 18, 23, 31, 42, 56, 70)


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 04_binary_search.py target")
        return 2
    try:
        if len(sys.argv[1]) > 3:
            raise ValueError
        target = int(sys.argv[1])
        if not 0 <= target <= 99:
            raise ValueError
    except ValueError:
        print("Error: target must be an integer from 0 to 99.")
        return 2
    lower = 0
    upper = len(NUMBERS)
    while lower < upper:
        middle = (lower + upper) // 2
        value = NUMBERS[middle]
        print(f"Range: [{lower}, {upper}); middle={middle}; value={value}")
        if value == target:
            print(f"Found at index: {middle}")
            return 0
        if value < target:
            lower = middle + 1
        else:
            upper = middle
    print("Not found.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
