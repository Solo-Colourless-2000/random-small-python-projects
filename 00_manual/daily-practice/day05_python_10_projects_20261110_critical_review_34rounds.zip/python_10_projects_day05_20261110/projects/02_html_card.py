import html
import sys
from pathlib import Path


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 02_html_card.py text output.html")
        return 2
    text = sys.argv[1]
    if not 1 <= len(text) <= 80:
        print("Error: use 1-80 printable ASCII characters.")
        return 2
    for character in text:
        if not 32 <= ord(character) <= 126:
            print("Error: text must be printable ASCII.")
            return 2
    safe = html.escape(text, quote=True)
    page = '<!doctype html>\n<html lang="en">\n'
    page += '<meta charset="utf-8">\n<title>Text card</title>\n'
    page += '<body><p>' + safe + '</p></body>\n</html>\n'
    try:
        with Path(sys.argv[2]).open("x", encoding="utf-8", newline="\n") as stream:
            stream.write(page)
    except OSError:
        print("Error: cannot create HTML; choose a new path.")
        return 1
    print(f"Saved: {sys.argv[2]}")
    print(f"Text length: {len(text)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
