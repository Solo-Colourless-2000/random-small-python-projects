"""Optional browser interactions with local HTML, no website navigation.

Chromium administrator policy blocks both file:// and local HTTP navigation here.
HTML is loaded by Playwright set_content; storage is an in-memory shim that is
explicitly NOT equivalent to browser-backed persistent localStorage.
Requires Playwright and Chromium outside the Python standard-library labs.
"""
import json
from pathlib import Path
from playwright.sync_api import sync_playwright

ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'python_10_projects_day06_manual.html').read_text('utf-8')
REPORT=ROOT/'verification'
STORAGE_SHIM=r'''() => {
 window.__memory_storage = {};
 Object.defineProperty(window, 'localStorage', { configurable:true, value: {
  getItem(k){return Object.prototype.hasOwnProperty.call(window.__memory_storage,k)?window.__memory_storage[k]:null},
  setItem(k,v){window.__memory_storage[k]=String(v)},
  removeItem(k){delete window.__memory_storage[k]}
 }});
}'''


def load(page):
    page.set_content(HTML,wait_until='load')
    page.wait_for_timeout(100)


def go(page,fragment):
    page.evaluate('(v) => {location.hash = v}',fragment)
    page.wait_for_timeout(65)


def main():
    results=[]
    errors=[]
    with sync_playwright() as playwright:
        browser=playwright.chromium.launch(headless=True,executable_path='/usr/bin/chromium',
            args=['--no-sandbox','--disable-dev-shm-usage'])
        for width in (320,390,768,1440):
            ctx=browser.new_context(viewport={'width':width,'height':900})
            page=ctx.new_page()
            page.on('pageerror',lambda e: errors.append(str(e)))
            page.evaluate(STORAGE_SHIM)
            load(page)
            initial=page.evaluate('''() => ({width:innerWidth,scroll:document.documentElement.scrollWidth,
              caseLabs:document.querySelectorAll('details.case-lab').length,
              active:document.querySelectorAll('.chapter.active').length,
              saved:document.getElementById('storage-status').innerText})''')
            assert initial['scroll'] <=width, (width,initial)
            assert initial['caseLabs']==10 and initial['active']==1, initial
            assert '\u4fdd\u5b58\u3057\u307e\u3059' in initial['saved'], initial
            if width in (390,1440):
                page.screenshot(path=str(REPORT/f'layout_144point_{width}.png'))
            go(page,'#p01')
            page.locator('#verified-cases-01 summary').click()
            assert page.locator('#verified-cases-01').get_attribute('open') is not None
            assert 'Early check' in page.locator('#verified-cases-01').inner_text()
            if width in (390, 1440):
                page.screenshot(path=str(REPORT/f'case_examples_144point_{width}.png'))
            page.locator('input[data-check="p01"]').check()
            assert '1 / 20' in page.locator('#progress').inner_text()
            load(page)
            assert page.locator('input[data-check="p01"]').is_checked()
            if width<=850:page.locator('#menu').click()
            page.locator('#reset').click()
            assert not page.locator('input[data-check="p01"]').is_checked()
            page.evaluate('''() => localStorage.setItem('python-daily-day06-20261110-v1', '{corrupt')''')
            load(page)
            assert '\u4fdd\u5b58\u3057\u307e\u3059' in page.locator('#storage-status').inner_text()
            assert page.evaluate('''() => JSON.parse(localStorage.getItem('python-daily-day06-20261110-v1')) !== null''')
            for project in (2,6,9):
                go(page,f'#p{project:02}')
                assert page.locator(f'#p{project:02}').evaluate('(e)=>e.classList.contains("active")')
                assert page.locator(f'#verified-cases-{project:02}').count()==1
            page.locator('#search').fill('\u8a3c\u660e\u3067\u304d\u306a\u3044\u3053\u3068')
            assert page.locator('#results').is_visible()
            found=page.locator('#results li').count()
            assert found>=10, found
            page.locator('#results li a').first.click()
            assert page.locator('#results').is_hidden()
            go(page,'#p02')
            page.locator('#p02 .copy').first.click()
            page.wait_for_timeout(100)
            status=page.locator('#p02 .copy-status').first.inner_text()
            assert ('\u30b3\u30d4\u30fc\u3057\u307e\u3057\u305f' in status or '\u30b3\u30fc\u30c9\u3092\u9078\u629e' in status),status
            # Link navigation and dynamically generated return targets.
            rounds=0
            pairs=[(2,step) for step in range(1,5)]
            if width==1440:
                pairs += [(project,step) for project in range(1,11) for step in range(1,5)]
            for project,step in pairs:
                go(page,f'#p{project:02}-step{step}')
                page.locator(f'#p{project:02}-step{step} a[data-source]').click()
                page.wait_for_timeout(95)
                if not page.locator('#appendix-a').evaluate('(e)=>e.classList.contains("active")'):
                    raise AssertionError('appendix navigation failed '+str((width,project,step,page.url,page.evaluate('location.hash'))))
                page.locator('#source-return').click()
                page.wait_for_timeout(95)
                assert page.locator(f'#p{project:02}').evaluate('(e)=>e.classList.contains("active")')
                rounds+=1
            results.append({'viewport_width':width,'document_width':initial['scroll'],
              'case_labs':initial['caseLabs'],'search_hits':found,
              'source_roundtrips':rounds,'mock_storage_reload':True,'recovered_corrupt_storage':True,
              'copy_feedback':status})
            ctx.close()
        browser.close()
    assert not errors,errors
    payload={'mode':'set_content_with_simulated_localStorage',
      'tested_file_scheme':False,'tested_local_http_scheme':False,
      'tested_real_localStorage_persistence':False,
      'js_exceptions':errors,'results':results}
    (REPORT/'browser_fourth_check.json').write_text(json.dumps(payload,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print(json.dumps(payload,ensure_ascii=False,indent=2))


if __name__=='__main__':main()
