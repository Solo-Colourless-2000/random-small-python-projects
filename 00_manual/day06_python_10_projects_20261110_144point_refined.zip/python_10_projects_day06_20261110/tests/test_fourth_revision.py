"""Fourth edition: executed examples and reader-visible corrections, standard library only."""
from html import unescape
from pathlib import Path
import re
import subprocess
import sys
import unittest

from cases import CASES

ROOT = Path(__file__).resolve().parents[1]
DOC = (ROOT / 'python_10_projects_day06_manual.html').read_text(encoding='utf-8')
README = (ROOT / 'README.txt').read_text(encoding='utf-8')
ARCHIVE = 'day06_python_10_projects_20261110_144point_refined.zip'


class FourthEditionTests(unittest.TestCase):
    def test_thirty_examples_are_executed_and_match_visible_results(self):
        for i, (name, cases) in enumerate(CASES.items(), 1):
            section = re.search(rf'<details class="case-lab" id="verified-cases-{i:02d}">(.*?)</details>', DOC, re.S)
            self.assertIsNotNone(section, name)
            text = section.group(1)
            examples = re.findall(r'<li id="case-\d\d-[1-3]">(.*?)</li>', text, re.S)
            self.assertEqual(len(examples), 3, name)
            for piece, (args, code, stdout, stderr) in zip(examples, (cases[0], cases[1], cases[-1])):
                with self.subTest(project=name, args=args):
                    run = subprocess.run([sys.executable, '-S', str(ROOT / 'projects' / (name + '.py')), *args],
                                         cwd=ROOT, capture_output=True, text=True, timeout=6)
                    self.assertEqual((run.returncode, run.stdout, run.stderr), (code, stdout, stderr))
                    visible = re.search(r'<pre class="case-output">(.*?)</pre>', piece, re.S)
                    self.assertIsNotNone(visible)
                    expected = (stdout if stdout else '(\u6a19\u6e96\u51fa\u529b\u306a\u3057)\n') + ('[stderr]\n' + stderr if stderr else '')
                    self.assertEqual(unescape(visible.group(1)), expected)
                    self.assertIn(f'\u7d42\u4e86\u5024 <strong>{code}</strong>', piece)

    def test_30_examples_are_discoverable_by_unique_ids(self):
        for i in range(1, 11):
            for part in range(1, 4):
                self.assertEqual(DOC.count(f'id="case-{i:02d}-{part}"'), 1)
            for label in ('title', 'intro', 'interpret', 'limit'):
                self.assertEqual(DOC.count(f'id="verified-cases-{i:02d}-{label}"'), 1)

    def test_relative_sample_path_explained_accurately(self):
        self.assertIn('__file__', README)
        self.assertIn('\u73fe\u5728\u5730\uff08pwd\uff09\u304c\u5225\u306e\u5834\u6240\u3067\u3082', README)
        self.assertIn('\u7aef\u672b\u306e\u73fe\u5728\u5730\u3092\u5909\u66f4\u3059\u308b\u5fc5\u8981\u306f\u306a\u3044', DOC)
        self.assertNotIn('Project 06\u306f\u6559\u6750\u306e\u30eb\u30fc\u30c8\u3067\u5b9f\u884c\u3059\u308b', DOC)

    def test_download_filename_and_audit_provenance_consistent(self):
        self.assertIn('unzip ' + ARCHIVE, DOC)
        self.assertIn('unzip ' + ARCHIVE, README)
        self.assertIn('\u7b2c4\u6b21\u518d\u76e3\u67fb\u7248', DOC)
        self.assertIn('\u300c144\u89b3\u70b9\u300d', DOC)

    def test_storage_status_is_updated_after_successful_write(self):
        self.assertIn('localStorage.setItem(key, JSON.stringify(state));\n      storage = true;', DOC)
        self.assertIn('storage = false;', DOC)
        self.assertIn('get("storage-status").textContent = storage', DOC)

    def test_every_project_explains_results_and_limits(self):
        for i in range(1, 11):
            start = DOC.index(f'id="verified-cases-{i:02d}"')
            end = DOC.index('</details>', start)
            sec = DOC[start:end]
            self.assertIn('\u5dee\u304c\u751f\u307e\u308c\u308b\u7406\u7531\uff1a', sec)
            self.assertIn('\u3053\u306e\u5b9f\u9a13\u3067\u8a3c\u660e\u3067\u304d\u306a\u3044\u3053\u3068\uff1a', sec)
            self.assertIn('\u7d42\u4e86\u5024', sec)


if __name__ == '__main__':
    unittest.main()
