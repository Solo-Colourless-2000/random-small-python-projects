from io import BytesIO
import sys

CASES = {"fragmented": b"\x03LAB", "empty": b"\x00", "maximum": b"\x08ABCDEFGH", "short": b"\x03LA", "oversize": b"\x09ABCDEFGHI", "header": b""}


def read_some(stream, count):
    return stream.read(min(count, 1))


def read_exact(stream, count):
    result = b""
    while len(result) < count:
        part = read_some(stream, count - len(result))
        if not part:
            raise EOFError("Short lab frame")
        result += part
    return result


def frame(packet, exact):
    with BytesIO(packet) as stream:
        size = read_exact(stream, 1)[0]
        if size > 8:
            raise ValueError("Lab length limit")
        if exact:
            return read_exact(stream, size)
        return read_some(stream, size)


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script fragmented|empty|maximum|short|oversize|header", file=sys.stderr)
        return 2
    packet = CASES[sys.argv[1]]
    try:
        direct = frame(packet, False)
        exact = frame(packet, True)
    except (ValueError, EOFError):
        print("Invalid lab frame.", file=sys.stderr)
        return 2
    print(f"Direct body: {ascii(direct)}")
    print(f"Exact body: {ascii(exact)}")
    print(f"Bodies equal: {direct == exact}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
