from pathlib import Path
from playwright.sync_api import sync_playwright
import json,traceback
R=Path(__file__).resolve().parent.parent
p=next(R.glob('*.html'));html=p.read_text(encoding='utf8')
out={'environment':'Chromium /usr/bin/chromium, set_content (file:// blocked); storage and clipboard not tested','checks':[],'errors':[]}
def check(name,ok,info=None):out['checks'].append({'test':name,'passed':bool(ok),'details':info})
try:
 with sync_playwright() as pl:
  b=pl.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox'])
  page=b.new_page(viewport={'width':393,'height':850})
  page.set_default_timeout(3000)
  page.on('pageerror',lambda e:out['errors'].append(str(e)))
  page.set_content(html,wait_until='domcontentloaded',timeout=12000)
  check('h1 exists',page.locator('h1').count()>0)
  dim=page.evaluate('({body:document.documentElement.scrollWidth,client:document.documentElement.clientWidth})')
  check('mobile page width',dim['body']<=dim['client']+1,dim)
  page.locator('#menuButton').click(timeout=3000)
  check('drawer opens',page.locator('#sidebar').evaluate('(x)=>x.classList.contains("open")'))
  page.locator('#sidebar [data-target="phase-03"]').click(timeout=3000)
  check('chapter changes',page.locator('#phase-03').evaluate('(x)=>x.classList.contains("active")'))
  check('drawer closes',not page.locator('#sidebar').evaluate('(x)=>x.classList.contains("open")'))
  page.screenshot(path=str(R/'verification/v10_mobile_393.png'),timeout=10000)
  page.locator('#searchButton').click(timeout=3000)
  check('search visible',page.locator('#searchInput').is_visible())
  page.locator('#searchInput').fill('snake_tick',timeout=3000)
  check('search finds items',page.locator('#searchResults .search-result').count()>0)
  page.close();b.close()
except Exception as e:out['errors'].append(str(e));out['traceback']=traceback.format_exc()
(R/'verification/v10_browser_mobile_smoke.json').write_text(json.dumps(out,ensure_ascii=False,indent=2))
print(json.dumps({'passed':sum(x['passed'] for x in out['checks']),'total':len(out['checks']),'errors':out['errors'][:1]},ensure_ascii=False))
