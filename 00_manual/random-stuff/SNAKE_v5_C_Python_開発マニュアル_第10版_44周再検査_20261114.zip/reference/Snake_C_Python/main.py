"""Entry point: python main.py"""
from __future__ import annotations

import sys


def main() -> int:
    try:
        from snake_app.ui import GameApp
        GameApp().run()
        return 0
    except (RuntimeError, ImportError) as exc:
        print(f"Snakeを起動できません: {exc}", file=sys.stderr)
        return 1
    except Exception as exc:
        # Import Tkinter lazily, so a missing GUI also produces a readable error.
        try:
            import tkinter as tk
        except ImportError:
            tk = None
        if tk is not None and isinstance(exc, tk.TclError):
            print("画面を開けません。GUIデスクトップ環境で実行してください。", file=sys.stderr)
            return 1
        raise


if __name__ == "__main__":
    raise SystemExit(main())
