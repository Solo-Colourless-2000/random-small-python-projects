import sys

TRUSTED = "https://app.example.test"
SUFFIX = "app.example.test"


def headers(origin):
    weak = origin if origin.endswith(SUFFIX) else "(omitted)"
    strict = origin if origin == TRUSTED else "(omitted)"
    return weak, strict


def main():
    if len(sys.argv) != 2:
        print("Usage: script ORIGIN", file=sys.stderr)
        return 2
    origin = sys.argv[1]
    if not 1 <= len(origin) <= 120 or not origin.isascii() or not origin.isprintable() or " " in origin:
        print("Use 1 to 120 printable ASCII characters without spaces.", file=sys.stderr)
        return 2
    weak, strict = headers(origin)
    print(f"Suffix ACAO: {weak}")
    print(f"Exact ACAO: {strict}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
