Pythonペネトレーションテスト実習 day07
作成日 2026-11-11（日本時間）

最初に python_10_projects_day07_manual.html をブラウザーで開いてください。
ZIPを展開し、ターミナルを python_10_projects_day07_20261111/ に移動します。
現在地を pwd で、projects/ と samples/ が見えることを ls で確認します。

python3 --version
pwd
ls
mkdir -p practice
vim practice/01_query_pollution.py

vimでは i で入力を開始し、Esc で戻って :wq とEnterで保存します。
字下げは半角スペース4個。全4工程を同じ実習ファイルへ追記します。
vimはnvimに置き換えられます。完成版はprojects/、自分で書く場所はpractice/です。

python3 practice/01_query_pollution.py target=public

完成版の試験入力（教材ルートで実行）
python3 projects/01_query_pollution.py 'target=public&target=private'
python3 projects/02_mass_assignment.py role
python3 projects/03_regex_probe.py wild
python3 projects/04_token_replay.py valid
python3 projects/05_quantity_probe.py -1
python3 projects/06_cache_poison.py poison
python3 projects/07_session_fixation.py login
python3 projects/08_pickle_inspector.py global
python3 projects/09_xml_expansion.py entity
python3 projects/10_template_probe.py nested

同じコマンドを再実行できます。配布物への書き込みはありません。
全作品の入力はコード内の固定ケース、01と05のみ短いCLI値も使います。
ファイルやネットワークへの書込みは行いません。
終了値は0が実験完了、2がCLI入力エラーまたは指定fixtureの解析失敗です。

python3 -m unittest discover -s tests -v

点検の範囲と実行環境は REVIEW_REPORT.txt、詳細は verification/ を参照してください。
次回はday08です。

改訂版の追加情報 (2026-11-11)
このZIPのHTMLは、全10作品の245非空行に詳しい構文・記号解説を増補した版です。
各Projectの「初学者向け・実行前の読み解きガイド」を開き、値の流れを確認してから
4工程を自分で入力するのがおすすめです。付録Aでは行の役割と構文の内訳を併読できます。
初心者向けの追加用語は第17章、追加実測と監査記録は第20章です。
詳しい変更履歴と38観点の点検結果は REVISION_REPORT.txt をご覧ください。
元の完成ソースは無変更です。実行試験は既存26件 + 追加16件 = 42件です。

第2改訂版の追加情報（2026-11-11）
全10作品に「さらに深く理解する」の具体的な評価表を追加しました。
条件式・戻り値・副作用を実際の値で追えるようにし、付録Aの重要53行の説明を増補しています。
Python 3.10文法の完成ソースは保持。全40工程と完成ソースは一致しています。
新規 tests/test_second_revision.py の14件を含めた総数は56件です。
追加の検証ログ・再実行用スクリプト・ブラウザー確認記録は verification/second_* に保存。
変更点と実測の限界は SECOND_REVISION_REPORT.txt を参照してください。
