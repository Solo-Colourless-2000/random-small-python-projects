"""Checks for purpose-first learning content added in the second audit.

All checks are against the supplied day05 teaching artifact, not other files.
"""
from html.parser import HTMLParser
from pathlib import Path
import json
import re
import unittest

ROOT = Path(__file__).resolve().parents[1]
HTML = ROOT / 'python_10_projects_day05_manual.html'


class PurposeParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.ids = set()
        self.purpose_ids = []
        self.purpose_text = {}
        self.outputs = {}
        self.current_project = None
        self.context = []
        self.stack = []
        self.feed(HTML.read_text(encoding='utf-8'))

    def handle_starttag(self, tag, attrs):
        d = dict(attrs)
        ident = d.get('id', '')
        if ident:
            self.ids.add(ident)
        if tag == 'section':
            m = re.fullmatch(r'p(\d{2})', ident)
            if m:
                self.current_project = int(m.group(1))
        if 'tool-purpose' in d.get('class', '').split():
            self.purpose_ids.append(self.current_project)
        self.stack.append((tag, ident, d.get('class', '')))

    def handle_data(self, data):
        if not self.stack:
            return
        for tag, ident, css in self.stack:
            if ident.startswith('purpose-'):
                self.purpose_text[ident] = self.purpose_text.get(ident, '') + data
        if any('tool-output' in css.split() for tag, ident, css in self.stack):
            if self.current_project:
                self.outputs[self.current_project] = self.outputs.get(self.current_project, '') + data

    def handle_endtag(self, tag):
        # HTML is well-formed in this lesson; close the most recent matching tag.
        for i in range(len(self.stack) - 1, -1, -1):
            if self.stack[i][0] == tag:
                del self.stack[i:]
                break
        if tag == 'section':
            self.current_project = None


class PurposeContent(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.html = HTML.read_text(encoding='utf-8')
        cls.parser = PurposeParser()
        cls.examples = json.loads((ROOT / 'verification/examples.json').read_text())

    def test_one_purpose_card_per_project(self):
        self.assertEqual(self.parser.purpose_ids, list(range(1, 11)))

    def test_purpose_card_has_seven_different_explanations(self):
        names = ('what', 'when', 'how', 'result', 'limits', 'terms', 'try')
        for n in range(1, 11):
            for name in names:
                with self.subTest(n=n, name=name):
                    text = self.parser.purpose_text[f'purpose-{n:02d}-{name}']
                    self.assertGreater(len(text.strip()), 18)

    def test_purpose_output_is_exactly_example_output(self):
        for n, item in enumerate(self.examples, 1):
            with self.subTest(n=n):
                self.assertEqual(self.parser.outputs[n], item['normal']['stdout'])

    def test_all_ten_example_invocations_present(self):
        for n, item in enumerate(self.examples, 1):
            with self.subTest(n=n):
                file = sorted((ROOT / 'projects').glob('*.py'))[n - 1]
                self.assertIn('projects/' + file.name, self.html)
                self.assertIn('purpose-' + f'{n:02d}-how', self.html)

    def test_quick_index_has_ten_links(self):
        for n in range(1, 11):
            self.assertIn('href="#p%02d"' % n, self.html)
        self.assertIn('\u4f55\u306b\u4f7f\u3046\uff1f', self.html)

    def test_new_setup_uses_actual_zip_name(self):
        current = 'day05_python_10_projects_20261110_critical_review_34rounds.zip'
        self.assertIn('unzip ' + current, self.html)
        self.assertIn(current, (ROOT / 'README.txt').read_text(encoding='utf-8'))
        self.assertNotIn('unzip day05_python_10_projects_20261110.zip', self.html)

    def test_provenance_not_inflated(self):
        self.assertIn('\u4eca\u56de\u306e\u518d\u76e3\u67fb\u3067\u53c2\u7167\u30fb\u4fee\u6b63\u3057\u305f\u4e00\u6b21\u8cc7\u6599', self.html)
        self.assertNotIn('\u5b9f\u6a5f\u78ba\u8a8d\u3057\u305fOS\u306fDebian GNU/Linux 13\u3001Python\u306f3.12.14', self.html)

    def test_lesson_has_20_chapters_and_no_external_resources(self):
        self.assertEqual(len(re.findall(r'<section\b[^>]*class="chapter"', self.html)), 20)
        self.assertFalse(re.search(r'<(?:script|iframe|img)\b[^>]*\bsrc=', self.html))
        self.assertFalse(re.search(r'<link\b[^>]*\bhref=', self.html))


if __name__ == '__main__':
    unittest.main()
