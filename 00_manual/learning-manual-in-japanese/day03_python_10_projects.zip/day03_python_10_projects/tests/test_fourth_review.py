"""Fourth review: regression checks for data parsing, teaching detail and input invariants."""
from pathlib import Path
from html.parser import HTMLParser
import json
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'projects' / '07_json_checklist.py'
DOC = (ROOT / 'python_10_projects_day03_manual.html').read_text(encoding='utf-8')


class TeachingParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.ids = []
        self.classes = []

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        if 'id' in attrs:
            self.ids.append(attrs['id'])
        if 'class' in attrs:
            self.classes.extend(attrs['class'].split())


def invoke_json(text, output_preexists=False):
    with tempfile.TemporaryDirectory() as temporary:
        root = Path(temporary)
        input_path = root / 'input.json'
        output_path = root / 'output.md'
        input_path.write_text(text, encoding='utf-8')
        if output_preexists:
            output_path.write_bytes(b'keep existing\n')
        result = subprocess.run(
            [sys.executable, str(SOURCE), str(input_path), str(output_path)],
            capture_output=True, text=True, timeout=10,
        )
        output_bytes = output_path.read_bytes() if output_path.exists() else None
        return (result.returncode, result.stdout, result.stderr, output_bytes)


class FourthReview(unittest.TestCase):
    def test_duplicate_bool_key_is_rejected(self):
        code, stdout, stderr, data = invoke_json('[{"name":"Tea","done":false,"done":true}]')
        self.assertEqual((code,stdout,stderr,data),
                         (2,'Error: use valid JSON within 4096 characters.\n','',None))

    def test_duplicate_name_key_is_rejected(self):
        code, stdout, stderr, data = invoke_json('[{"name":"Tea","name":"Milk","done":false}]')
        self.assertEqual((code,data), (2,None))
        self.assertTrue(stdout.startswith('Error:'))
        self.assertEqual(stderr,'')

    def test_nested_duplicate_key_is_rejected(self):
        self.assertEqual(invoke_json('[{"name":"Tea","done":false,"other":{"x":1,"x":2}}]')[0],2)

    def test_separate_tasks_can_have_matching_field_names(self):
        code, _, _, data = invoke_json('[{"name":"Tea","done":false},{"name":"Cake","done":true}]')
        self.assertEqual((code,data),(0,b'- [ ] Tea\n- [x] Cake\n'))

    def test_original_valid_input_unchanged(self):
        sample=(ROOT/'samples'/'tasks.json').read_text(encoding='ascii')
        self.assertEqual(invoke_json(sample)[3],(ROOT/'samples'/'checklist_expected.md').read_bytes())

    def test_duplicate_never_overwrites_existing_file(self):
        code, _, _, data=invoke_json('[{"name":"Tea","done":true,"done":false}]',True)
        self.assertEqual((code,data),(2,b'keep existing\n'))

    def test_valid_input_refuses_overwrite(self):
        code, _, _, data=invoke_json('[{"name":"Tea","done":true}]',True)
        self.assertEqual((code,data),(1,b'keep existing\n'))

    def test_doc_explains_syntax_in_all_ten_projects(self):
        parser=TeachingParser();parser.feed(DOC)
        self.assertEqual(parser.classes.count('syntax-breakdown'), 746)
        self.assertEqual(parser.classes.count('worked-trace'),10)
        for n in range(1,11):
            self.assertIn(f'guided-p{n:02d}',parser.ids)

    def test_doc_has_no_obsolete_duplicate_limitation(self):
        self.assertNotIn('\u3053\u306e\u6559\u6750\u306f\u91cd\u8907\u30ad\u30fc\u62d2\u5426\u307e\u3067\u306f\u5b9f\u88c5\u3057\u3066\u3044\u306a\u3044', DOC)
        self.assertNotIn('JSON\u306e\u91cd\u8907\u30ad\u30fc\u306f\u6a19\u6e96json\u306e\u65e2\u5b9a\u3067\u6700\u5f8c\u306e\u5024\u306b\u306a\u308a\u307e\u3059\u3002',DOC)
        self.assertIn('object_pairs_hook=reject_duplicate_keys', DOC)

    def test_new_function_is_small_and_uses_valueerror(self):
        source=SOURCE.read_text(encoding='ascii')
        self.assertIn('def reject_duplicate_keys(pairs):',source)
        self.assertIn('raise ValueError("Duplicate JSON key")',source)
        self.assertIn('except ValueError:',source)


if __name__=='__main__':
    unittest.main()
