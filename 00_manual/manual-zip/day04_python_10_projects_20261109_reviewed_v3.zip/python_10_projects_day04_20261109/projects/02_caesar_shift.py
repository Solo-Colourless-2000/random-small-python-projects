import string
import sys


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 02_caesar_shift.py text shift")
        return 2
    text = sys.argv[1]
    if not 1 <= len(text) <= 80:
        print("Error: text needs 1-80 printable ASCII characters.")
        return 2
    for character in text:
        if not 32 <= ord(character) <= 126:
            print("Error: text must be printable ASCII.")
            return 2
    try:
        if len(sys.argv[2]) > 3:
            raise ValueError
        shift = int(sys.argv[2])
        if not 0 <= shift <= 25:
            raise ValueError
    except ValueError:
        print("Error: shift must be an integer from 0 to 25.")
        return 2
    result = ""
    for character in text:
        if character in string.ascii_letters:
            base = ord("a")
            if character.isupper():
                base = ord("A")
            position = ord(character) - base
            shifted = (position + shift) % 26
            result += chr(base + shifted)
        else:
            result += character
    print(f"Shift: {shift}")
    print(f"Result: {result}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
