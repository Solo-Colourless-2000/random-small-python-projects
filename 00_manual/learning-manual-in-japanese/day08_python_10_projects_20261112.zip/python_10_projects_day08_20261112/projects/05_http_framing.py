import sys

CASES = {"length": (4, False, b"PING"), "ambiguous": (0, True, b"0\r\n\r\nNEXT"), "short": (4, False, b"PI")}


def boundaries(length, chunked, body):
    if len(body) < length:
        raise ValueError("Incomplete body.")
    front = length
    back = length
    if chunked:
        if not body.startswith(b"0\r\n\r\n"):
            raise ValueError("Unsupported lab chunks.")
        back = 5
    decision = "reject" if chunked else "accept"
    return front, back, decision


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script length|ambiguous|short", file=sys.stderr)
        return 2
    try:
        front, back, decision = boundaries(*CASES[sys.argv[1]])
    except ValueError:
        print("Invalid lab framing.", file=sys.stderr)
        return 2
    print(f"Front boundary: {front}")
    print(f"Back boundary: {back}")
    print(f"Ambiguity policy: {decision}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
