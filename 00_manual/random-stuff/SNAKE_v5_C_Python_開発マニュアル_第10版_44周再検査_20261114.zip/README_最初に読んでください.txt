SNAKE v5 C + Python 開発マニュアル 第10版
2026-11-14

【最初に】
SNAKE_v5_C_Python_ゼロから作る開発マニュアル.html をブラウザで開く。
全97工程（試作5＋本編92）のコードを段階的に入力し、複数ファイルを行き来しながらC＋PythonのSnakeを完成させる日本語教材。
reference/Snake_C_Python/ が完成ゲームの同梱ソース。checkpoints/phase-01.zip～phase-11.zip が章末の再現用スナップショット。

【第10版で重点的に修正した問題】
・Pythonのclass宣言の丸括弧を関数呼出しと説明していた誤りを修正。
・Cの1行に2個ある代入文を1つの代入式として説明した誤りを修正。
・Pythonのテスト用変数eを例外/イベントと誤説明する箇所を修正。
・call/assign/import/function definitionの汎用説明を、実際のメソッドや引数・結果の意味に改訂。
・Pythonの型注釈のコロンとブロック開始のコロンを区別。
・ゲームの方向予約、尻尾への衝突、餌の乱数、ctypesのABI、保存ロックについて、実際の値を追う14件の詳細解説を追加。
・英語のソースコメントをその実装の意図がわかる日本語説明に改訂。

【レビュー周回数】
verification/v10_44_full_rounds.json: 44周の独立した再スキャン。各周で2,665行のコードと説明、21,045件の構成要素説明、92工程、23完成ソース、11チェックポイント、および複数の技術的な検査を通過。
verification/v10_44_rounds.log: 実行時の周回ログ。
verification/V10_EDITORIAL_REVIEW.md: 個別修正の理由・レビュー方法・検証上の限界。
44周は実際に44回ループを走らせた複数観点のプログラムによる全量再検査。40観点を40周と数えたものではない。一方で人間が全行を44回手で読んだという意味でもない。修正には別途ソースの読解と実際のケース検討を加えている。

【実装と動作確認】
python verification/reconstruct_and_verify.py
上記で92工程と23ファイルのバイト一致・11章の途中チェックポイントを再確認できる。
reference/Snake_C_Python で python build.py と xvfb-run -a python -m unittest discover -s tests -v によりGUI込み107テストを実行・成功。
verification/v10_build.log、verification/v10_full_tests.log を参照。

【ブラウザ表示の制約】
ChromiumのPC幅1440pxでは章移動・検索・コード枠の横スクロールを確認。
Chromiumの393pxでは目次開閉・章移動・検索・横はみ出し（7項目）を確認。
ただし、実行環境がfile://直接アクセスをブロックしたため、HTMLをpage.set_contentで挿入した代替検査となる。
進捗の永続化、OSクリップボード、全てのOS・ブラウザの実機動作までは保証していない。
verification/v10_browser_report.jsonは一度失敗した試験記録、verification/v10_browser_mobile_smoke.jsonは完了したモバイル試験の記録。

【旧版の記録】
verification/history_v9/ の資料は第9版の履歴であり、第10版の検証結果ではない。

【内容の保証範囲】
ソースバイト一致と検証テスト合格は確認済み。あらゆる日本語の解説の正しさまで機械的な回数で保証するものではない。第10版で見つけた不備は修正したが、未知の誤りが残る可能性はある。
