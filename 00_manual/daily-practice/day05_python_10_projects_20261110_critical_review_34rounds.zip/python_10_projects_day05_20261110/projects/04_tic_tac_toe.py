import sys

LINES = ((0, 1, 2), (3, 4, 5), (6, 7, 8),
         (0, 3, 6), (1, 4, 7), (2, 5, 8),
         (0, 4, 8), (2, 4, 6))


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 04_tic_tac_toe.py board")
        return 2
    board = sys.argv[1]
    if len(board) != 9 or any(ch not in "XO." for ch in board):
        print("Error: board needs nine X, O or . characters.")
        return 2
    x_count = board.count("X")
    o_count = board.count("O")
    if x_count not in (o_count, o_count + 1):
        print("Error: invalid turn counts.")
        return 2
    winners = set()
    for a, b, c in LINES:
        if board[a] != "." and board[a] == board[b] == board[c]:
            winners.add(board[a])
    if len(winners) > 1:
        print("Error: both players cannot win.")
        return 2
    if ("X" in winners and x_count != o_count + 1) or ("O" in winners and x_count != o_count):
        print("Error: winner and turn counts disagree.")
        return 2
    if "X" in winners:
        print("X wins")
    elif "O" in winners:
        print("O wins")
    elif "." in board:
        print("Ongoing")
    else:
        print("Draw")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
