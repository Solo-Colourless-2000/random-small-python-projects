"""Independent regression checks for the second day03 review."""

import contextlib
from fractions import Fraction
import importlib.util
import io
import itertools
import json
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
FILES = sorted((ROOT / 'projects').glob('*.py'))
MODULES = {}
for index, path in enumerate(FILES, 1):
    spec = importlib.util.spec_from_file_location('review_' + str(index), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    MODULES[index] = module


def invoke(number, *arguments):
    buffer = io.StringIO()
    argv = [FILES[number - 1].name, *arguments]
    with patch.object(sys, 'argv', argv), contextlib.redirect_stdout(buffer):
        code = MODULES[number].main()
    return code, buffer.getvalue()


class ExtendedReview(unittest.TestCase):
    def test_p01_all_byte_values(self):
        for value in range(256):
            code, output = invoke(1, str(value))
            self.assertEqual(code, 0)
            self.assertIn(f'Binary: {value:08b}\n', output)
            self.assertTrue(output.endswith(f'On bits: {value.bit_count()}\n'))
            lines = output.splitlines()
            self.assertEqual([int(x.rsplit(': ', 1)[1]) for x in lines[1:9]],
                             [(value >> i) & 1 for i in range(8)])

    def test_p02_unicode_then_dedup(self):
        for bad in ('\u212a', '\u0130', '\u00a0', '\u2009', 'a,\u212a'):
            self.assertEqual(invoke(2, bad)[0], 2)
        self.assertEqual(invoke(2, 'Pen, pen, CUP'), (0, 'Items: 2\n1. pen\n2. cup\n'))

    def test_p03_independent_reconstruction(self):
        randomizer = random.Random(1003)
        for _ in range(250):
            word = ''.join(randomizer.choices('ABC', k=randomizer.randint(1, 80)))
            code, output = invoke(3, word)
            self.assertEqual(code, 0)
            groups = output.splitlines()[0].removeprefix('Runs: ').split(' ')
            self.assertEqual(''.join(letter * int(count) for letter, count in
                                     (group.split(':') for group in groups)), word)
            self.assertTrue(output.endswith(f'Length: {len(word)}\n'))

    def test_p04_compare_to_separate_stack(self):
        def expected(source):
            stack = []
            for pos, ch in enumerate(source, 1):
                if ch in '([':
                    stack.append(ch)
                elif not stack or (stack.pop(), ch) not in (('(', ')'), ('[', ']')):
                    return f'Mismatch at {pos}\n'
            return 'Unclosed\n' if stack else 'Balanced\n'
        for length in range(1, 6):
            for letters in itertools.product('()[]', repeat=length):
                source = ''.join(letters)
                self.assertEqual(invoke(4, source), (0, expected(source)))

    def test_p05_sorted_merge_independent(self):
        rnd = random.Random(1005)
        for _ in range(350):
            left = sorted(rnd.randint(-99, 99) for _ in range(rnd.randint(1, 8)))
            right = sorted(rnd.randint(-99, 99) for _ in range(rnd.randint(1, 8)))
            code, output = invoke(5, ','.join(map(str, left)), ','.join(map(str, right)))
            self.assertEqual((code, output), (0, 'Merged: ' + ' '.join(map(str, sorted(left + right))) + '\n'))

    def test_p06_newline_caveat_and_no_write(self):
        with tempfile.TemporaryDirectory() as tmp:
            first, second = Path(tmp) / 'first.txt', Path(tmp) / 'second.txt'
            first.write_bytes(b'A\r\n')
            second.write_bytes(b'A')
            self.assertEqual(invoke(6, str(first), str(second)), (0, 'No differences.\n'))
            self.assertEqual((first.read_bytes(), second.read_bytes()), (b'A\r\n', b'A'))
            second.write_bytes(b'B\n')
            code, stdout = invoke(6, str(first), str(second))
            self.assertEqual(code, 0)
            self.assertIn('-A\n', stdout)
            self.assertIn('+B\n', stdout)

    def test_p07_protected_write_and_duplicate_rejection(self):
        with tempfile.TemporaryDirectory() as tmp:
            directory = Path(tmp)
            source, target = directory / 'a.json', directory / 'b.md'
            source.write_text('[{"name":"Alpha","done":true,"done":false}]', encoding='utf-8')
            self.assertEqual(invoke(7, str(source), str(target))[0], 2)
            self.assertFalse(target.exists())
            source.write_text('[{"name":"Alpha","done":false}]', encoding='utf-8')
            self.assertEqual(invoke(7, str(source), str(target))[0], 0)
            self.assertEqual(target.read_bytes(), b'- [ ] Alpha\n')
            self.assertEqual(invoke(7, str(source), str(target))[0], 1)
            self.assertEqual(target.read_bytes(), b'- [ ] Alpha\n')
            source.write_text('[{"name":"Alpha","done":1}]', encoding='utf-8')
            other = directory / 'other.md'
            self.assertEqual(invoke(7, str(source), str(other))[0], 2)
            self.assertFalse(other.exists())

    def test_p08_queue_fifo_and_limit(self):
        def run(data):
            return subprocess.run([sys.executable, str(FILES[7])], input=data,
                                  text=True, capture_output=True, timeout=10)
        output = run('add Ada\nadd Bob\nnext\nnext\nquit\n')
        self.assertEqual(output.returncode, 0)
        self.assertLess(output.stdout.find('Serving: Ada'), output.stdout.find('Serving: Bob'))
        self.assertEqual(run('show\n' * 50).returncode, 2)
        self.assertEqual(run('show\n' * 49 + 'quit\n').returncode, 0)

    def test_p09_input_bounds_checked_before_reduction(self):
        for source in ('20000/20000', '2/20000', '20000/2', '0/10001',
                       '-20000/20000', '1/0', '1/-2', '0/0'):
            with self.subTest(source=source):
                code, output = invoke(9, source, '+', '0')
                self.assertEqual(code, 2)
                self.assertTrue(output.startswith('Error:'))
        rnd = random.Random(1009)
        for _ in range(350):
            a, b, c, d = [rnd.randint(1, 10000) for _ in range(4)]
            numer = rnd.choice((-1, 1)) * a
            operator = rnd.choice(('+', '-', '*', '/'))
            code, output = invoke(9, f'{numer}/{b}', operator, f'{c}/{d}')
            x, y = Fraction(numer, b), Fraction(c, d)
            answer = {'+': lambda: x + y, '-': lambda: x - y,
                      '*': lambda: x * y, '/': lambda: x / y}[operator]()
            self.assertEqual((code, output),
                             (0, f'Result: {answer}\nNumerator: {answer.numerator}\nDenominator: {answer.denominator}\n'))

    def test_p10_ascii_and_synchronous_update(self):
        for value in ('\uff11', ' 1', '+1', '01', '9', '-1', '', '2.0'):
            self.assertEqual(invoke(10, '00100', value)[0], 2)
        rnd = random.Random(1010)
        for _ in range(250):
            size = rnd.randint(3, 21)
            original = ''.join(rnd.choices('01', k=size))
            rounds = rnd.randint(0, 8)
            code, output = invoke(10, original, str(rounds))
            self.assertEqual(code, 0)
            states = [part.split(': ')[1] for part in output.splitlines()]
            self.assertEqual(len(states), rounds + 1)
            self.assertEqual(states[0], original)
            for old, new in zip(states, states[1:]):
                self.assertEqual(new, ''.join('1' if
                                 (old[i - 1] if i else '0') !=
                                 (old[i + 1] if i + 1 < len(old) else '0')
                                 else '0' for i in range(len(old))))


if __name__ == '__main__':
    unittest.main()
