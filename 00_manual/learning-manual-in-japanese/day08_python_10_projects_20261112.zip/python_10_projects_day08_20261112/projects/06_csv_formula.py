import csv
import io
import sys

CASES = {"word": "report", "formula": "=SUM(1,2)", "negative": "-5"}


def round_trip(cell):
    stream = io.StringIO(newline="")
    writer = csv.writer(stream, quoting=csv.QUOTE_ALL, lineterminator="\n")
    writer.writerow([cell])
    text = stream.getvalue()
    recovered = next(csv.reader(io.StringIO(text, newline="")))[0]
    suspicious = recovered.lstrip().startswith(("=", "+", "-", "@"))
    return text, recovered, suspicious


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script word|formula|negative", file=sys.stderr)
        return 2
    text, recovered, suspicious = round_trip(CASES[sys.argv[1]])
    print(f"CSV text: {text!r}")
    print(f"Recovered cell: {recovered!r}")
    print(f"Formula-like prefix: {suspicious}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
