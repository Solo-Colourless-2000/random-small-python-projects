#!/usr/bin/env python3
"""Forty whole-document review cycles, not forty standalone topic checks.

The repeated passes are computer-assisted. Authored judgments are separate, logged.
"""
import argparse, hashlib, json, re, time
from collections import defaultdict
from pathlib import Path
from lxml import html
from editorial_notes import NOTES
W=Path(__file__).resolve().parents[1]
R=W
P=W/'NEON_RIFT_v4_開発マニュアル_第7次具体解説40周再校訂版.html'
M=json.loads((R/'verification/edit_steps.json').read_text(encoding='utf-8'))
S={str(p.relative_to(R/'reference/neon_rift')):p.read_bytes() for p in (R/'reference/neon_rift').rglob('*.py')}
for p in (R/'reference/neon_rift').glob('start_*'):S[p.name]=p.read_bytes()
S['experiments/movement_probe.py']=(R/'experiments/movement_probe.py').read_bytes()
EXPECTED_SHA=hashlib.sha256(P.read_bytes()).hexdigest()
JOURNAL=W/'verification/40_rounds_rerun.jsonl'

def check(n):
 t0=time.monotonic()
 data=P.read_bytes();assert hashlib.sha256(data).hexdigest()==EXPECTED_SHA
 root=html.fromstring(data)
 # Every check below operates on *the whole final document*.
 sections=root.xpath('//section[contains(concat(" ",normalize-space(@class)," ")," manual-section ")]')
 steps=root.xpath('//article[contains(concat(" ",normalize-space(@class)," ")," lesson-step ")]')
 assert len(sections)==17 and len(steps)==180,(len(sections),len(steps))
 id_=[x for x in root.xpath('//*[@id]/@id')];assert len(id_)==len(set(id_))
 step_id={x.get('id'):x for x in steps}
 assert len(root.xpath('//section[contains(@class,"editorial-guide")]'))==1
 # Each round replays all 175 incremental edits from scratch, validates before and after SHA, and exact final sources.
 states=defaultdict(bytes)
 total_code=0; total_rows=0; total_tokens=0
 for entry in M:
  sid=entry['id'];node=step_id[sid];file=entry['file'];old=states[file]
  assert hashlib.sha256(old).hexdigest()==entry['before_hash'],('before',sid)
  body=entry['body'].encode('utf-8'); assert hashlib.sha256(old+body).hexdigest()==entry['after_hash'],('after',sid)
  states[file]=old+body
  spans=node.xpath('.//code[contains(concat(" ",normalize-space(@class)," ")," source-lines ")]/span[@data-line]')
  assert len(spans)==entry['to']-entry['from']+1,('source line count',sid)
  got=''.join(x.text_content() for x in spans).encode('utf-8')
  assert got==body,('step body',sid)
  assert [int(x.get('data-line')) for x in spans]==list(range(entry['from'],entry['to']+1))
  rows=node.xpath('.//details[contains(concat(" ",normalize-space(@class)," ")," unit-guide ")]//tbody/tr')
  assert len(rows)==len(body.decode('utf-8').splitlines()),('explain count',sid)
  for tr,line in zip(rows,body.decode('utf-8').splitlines()):
   display=tr.xpath('.//code[contains(concat(" ",normalize-space(@class)," ")," one-line ")]')
   assert len(display)==1,(file,sid)
   txt=display[0].text_content()
   assert (txt.strip()==line.strip() or (not line.strip() and txt=='（空行）')),('explain wrong line',sid,txt,line)
   if line.strip() and file.endswith('.py'):
    terms=tr.xpath('.//ul[contains(concat(" ",normalize-space(@class)," ")," token-notes ")]/li')
    # Multi-line docstrings and comments may have no Python code tokens; do not fabricate tokens.
    if terms:
     total_tokens+=len(terms)
     assert all((li.text_content().strip() and li.xpath('./code')) for li in terms),(file,sid)
   total_rows+=1
  total_code+=len(spans)
 for file,rebuilt in states.items():
  assert file in S and rebuilt==S[file],('source mismatch',file)
 # The five prototype steps are also rechecked from the same full document each round.
 pspans=[];probe_rows=0
 for i in range(1,6):
  node=step_id[f'probe-step-{i}']
  spans=node.xpath('.//code[contains(concat(" ",normalize-space(@class)," ")," source-lines ")]/span[@data-line]')
  pspans.extend(spans)
  rows=node.xpath('.//details[contains(concat(" ",normalize-space(@class)," ")," micro-quiz ")]//tr[td]')
  for row in rows:
   linenum=re.match(r'L(\d+)',row.xpath('./td[1]')[0].text_content().strip())
   assert linenum
   code=row.xpath('.//code[contains(concat(" ",normalize-space(@class)," ")," one-line ")]')[0].text_content()
   raw=S['experiments/movement_probe.py'].decode('utf-8').splitlines()[int(linenum.group(1))-1]
   assert code.strip()==raw.strip() or (not raw.strip() and code.strip()=='（空行）')
   probe_rows+=1
 pspans.sort(key=lambda x:int(x.get('data-line')))
 assert ''.join(x.text_content() for x in pspans).encode('utf-8')==S['experiments/movement_probe.py']
 # All handcrafted explanations refer to actual, non-empty lines of supplied source.
 source_step_index={}
 for entry in M:
  for line in range(entry['from'],entry['to']+1):source_step_index[(entry['file'],line)]=entry['id']
 for file,lineno in NOTES:
  sid=('probe-step-'+str(next(i for i in range(1,6) if any(int(x.get('data-line'))==lineno for x in step_id[f'probe-step-{i}'].xpath('.//code[contains(@class,"source-lines")]/span')))) if file=='experiments/movement_probe.py' else source_step_index[(file,lineno)])
  node=step_id[sid]
  rows=node.xpath('.//tr[td]')
  hits=[tr for tr in rows if tr.xpath('./td[1]') and re.match(r'^L'+str(lineno)+r'(?![0-9])',tr.xpath('./td[1]')[0].text_content().strip())]
  assert len(hits)==1,(file,lineno,len(hits))
  assert len(hits[0].xpath('.//p[contains(@class,"editorial-added")]'))==1,(file,lineno)
  assert len(NOTES[(file,lineno)])>=25
 # All internal anchors and toc destinations must resolve.
 for href in root.xpath('//*[@href]/@href'):
  if href.startswith('#') and len(href)>1: assert href[1:] in id_,('broken anchor',href)
 for target in root.xpath('//*[@data-target]/@data-target'):
  assert target in id_,('broken chapter nav',target)
 # No known legacy generic string template remains in any of the 22k token notes.
 assert not root.xpath('//ul[contains(@class,"token-notes")]/li[contains(text(),"画面表示・キー・辞書のID等の値として使用")]')
 # Every round scrutinizes 12 differently selected curated human explanations, in addition to ALL 186 existence checks.
 chosen=list(NOTES.items());sample=[chosen[(n*17+j*11)%len(chosen)] for j in range(12)]
 for ((file,line),written) in sample:
  src=S[file].decode('utf-8').splitlines()[line-1]
  assert src.strip() and len(written)>=25,(file,line)
 # Verify the previously discovered semantic contradiction stays fixed at its original code line.
 probe=step_id['probe-step-2'];speedrow=[tr for tr in probe.xpath('.//tr[td]') if tr.xpath('./td[1]')[0].text_content().strip().startswith('L11')][0]
 assert '毎秒5pxではない' in speedrow.text_content()
 assert '通常はピクセル/秒' not in speedrow.text_content()
 return {'round':n,'sha256':EXPECTED_SHA,'chapters':len(sections),'steps':len(steps),'source_files_rebuilt':len(states),'source_lines_checked':total_code,'explanation_rows_checked':total_rows+probe_rows,'token_notes_checked':total_tokens,'authored_line_notes_checked':len(NOTES),'rotating_semantic_examples':[{'file':file,'line':line,'code':S[file].decode('utf-8').splitlines()[line-1].strip()[:120]} for ((file,line),_) in sample],'html_links_checked':len(root.xpath('//*[@href]/@href')),'outcome':'PASS','elapsed_sec':round(time.monotonic()-t0,3)}

if __name__=='__main__':
 args=argparse.ArgumentParser();args.add_argument('--start',type=int,required=True);args.add_argument('--end',type=int,required=True);a=args.parse_args()
 with JOURNAL.open('a',encoding='utf-8') as f:
  for n in range(a.start,a.end+1):
   rec=check(n);f.write(json.dumps(rec,ensure_ascii=False)+'\n');f.flush();print(f"round {n:02d} PASS | {rec['source_files_rebuilt']} rebuilt | {rec['source_lines_checked']} code lines | {rec['explanation_rows_checked']} commentary rows | {rec['elapsed_sec']} s")
