"""Rerun every published CLI case from the revised package."""
import json
from pathlib import Path
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tests"))
from cases import CASES

observed = json.loads((ROOT / "verification" / "cli_observations.json").read_text())
count=0
for name,cases in CASES.items():
    for idx,(args, expected_code, expected_out, expected_err) in enumerate(cases):
        result=subprocess.run(
            [sys.executable, "-S", str(ROOT / "projects" / (name + ".py")), *args],
            cwd=ROOT, text=True, capture_output=True, encoding="ascii", timeout=6,
            stdin=subprocess.DEVNULL,
        )
        actual=(result.returncode,result.stdout,result.stderr)
        expected=(expected_code,expected_out,expected_err)
        assert actual == expected, (name,idx,actual,expected)
        baseline=observed[name][idx]
        assert (baseline["args"],baseline["code"],baseline["stdout"],baseline["stderr"]) == (args,*expected),name
        count+=1
assert count==59,count
print(f"PASS: {count} CLI cases, stdout/stderr/status and baseline observations confirmed")
