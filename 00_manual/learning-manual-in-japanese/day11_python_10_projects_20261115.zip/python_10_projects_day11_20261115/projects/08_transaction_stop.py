from contextlib import closing
import sqlite3
import sys


def stopped_transfer(early_commit):
    with closing(sqlite3.connect(":memory:")) as database:
        with database:
            database.execute("CREATE TABLE wallet (id INTEGER, balance INTEGER)")
            database.executemany("INSERT INTO wallet VALUES (?, ?)", [(1, 40), (2, 60)])
        try:
            with database:
                database.execute("UPDATE wallet SET balance = balance - 10 WHERE id = 1")
                if early_commit:
                    database.commit()
                raise ValueError("planned stop before credit")
        except ValueError:
            rows = database.execute("SELECT balance FROM wallet ORDER BY id").fetchall()
        return rows[0][0], rows[1][0]


def main():
    cases = {"early": True, "atomic": False}
    if len(sys.argv) != 2 or sys.argv[1] not in cases:
        print("Usage: script early|atomic", file=sys.stderr)
        return 2
    try:
        first, second = stopped_transfer(cases[sys.argv[1]])
    except sqlite3.Error:
        print("Database lab failed.", file=sys.stderr)
        return 1
    print(f"Balances: {first},{second}")
    print(f"Total: {first + second}")
    print(f"Conserved: {first + second == 100}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
