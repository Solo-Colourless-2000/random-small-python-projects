import copy
import sys


def capture(deep, change):
    event = {"actor": "guest", "details": {"role": "user"}}
    if deep:
        snapshot = copy.deepcopy(event)
    else:
        snapshot = event.copy()
    shared = snapshot["details"] is event["details"]
    if change:
        event["details"]["role"] = "admin"
    return shared, snapshot["details"]["role"], event["details"]["role"]


def main():
    cases = {"shallow": (False, True), "deep": (True, True), "unchanged": (False, False)}
    if len(sys.argv) != 2 or sys.argv[1] not in cases:
        print("Usage: script shallow|deep|unchanged", file=sys.stderr)
        return 2
    deep, change = cases[sys.argv[1]]
    shared, recorded, live = capture(deep, change)
    print(f"Shared details: {shared}")
    print(f"Recorded role: {recorded}")
    print(f"Live role: {live}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
