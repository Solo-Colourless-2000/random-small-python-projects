import socket
import sys

BANNERS = {"lab": b"LAB/1 ready\r\n", "other": b"NOTICE ready\r\n"}


def capture(banner):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as listener:
        listener.bind(("127.0.0.1", 0))
        listener.listen(1)
        listener.settimeout(2.0)
        address = listener.getsockname()
        with socket.create_connection(address, timeout=2.0) as client:
            peer, _ = listener.accept()
            with peer:
                if peer.getpeername() != client.getsockname():
                    raise OSError("Unexpected local peer.")
                peer.settimeout(2.0)
                peer.sendall(banner)
            with client.makefile("rb") as stream:
                return stream.readline(64)


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in BANNERS:
        print("Usage: script lab|other", file=sys.stderr)
        return 2
    try:
        line = capture(BANNERS[sys.argv[1]])
    except OSError:
        print("Loopback experiment failed.", file=sys.stderr)
        return 1
    if not line.endswith(b"\n"):
        print("Missing complete banner.", file=sys.stderr)
        return 1
    print(f"Banner: {line!r}")
    print(f"Known prefix: {line.startswith(b'LAB/1 ')}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
