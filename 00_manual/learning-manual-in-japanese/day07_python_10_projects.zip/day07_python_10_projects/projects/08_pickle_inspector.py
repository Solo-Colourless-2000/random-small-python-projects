import pickletools
import sys

CASES = {"text": b"S'hello'\n.", "global": b"cbuiltins\nlen\n.", "trailing": b"S'hello'\n.EXTRA", "broken": b"?"}
REVIEW = {"GLOBAL", "STACK_GLOBAL", "REDUCE", "BUILD", "NEWOBJ", "NEWOBJ_EX", "INST", "OBJ"}


def inspect(data):
    flags = []
    stop = -1
    for opcode, _, position in pickletools.genops(data):
        if opcode.name in REVIEW:
            flags.append(opcode.name)
        if opcode.name == "STOP":
            stop = position
    return ",".join(flags) or "(none)", stop + 1 < len(data)


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script text|global|trailing|broken", file=sys.stderr)
        return 2
    try:
        flags, trailing = inspect(CASES[sys.argv[1]])
    except ValueError:
        print("Invalid pickle stream.", file=sys.stderr)
        return 2
    print(f"Review opcodes: {flags}")
    print(f"Trailing bytes: {trailing}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
