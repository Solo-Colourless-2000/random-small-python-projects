"""Probe visual text clipping under an Xvfb display (optional Pillow screenshots)."""
import sys
import tempfile
from pathlib import Path
from PIL import ImageGrab
import tkinter as tk
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from main import TankArena
from arena_config import UPGRADES

with tempfile.TemporaryDirectory(prefix='steelfront-resolution-') as td:
    TankArena._save_path=staticmethod(lambda:Path(td)/'save.json')
    root=tk.Tk();app=TankArena(root)
    report=[]
    for screen in ('TITLE','PLAYING','PAUSED','UPGRADE','GAMEOVER'):
        if screen=='PLAYING':app.new_game()
        if screen=='UPGRADE':app.start_upgrade_screen()
        app.screen=screen;app.render();root.update()
        clipped=[]
        for ident in app.canvas.find_all():
            if app.canvas.type(ident)!='text':continue
            box=app.canvas.bbox(ident)
            if box and (box[0]<-1 or box[1]<-1 or box[2]>app.w+2 or box[3]>app.h+2):
                clipped.append((app.canvas.itemcget(ident,'text')[:32],box))
        report.append((screen,len(clipped)))
        if clipped:print('TEXT CLIPPING',screen,clipped[:8])
        if screen=='UPGRADE' and len(sys.argv)>1:
            ImageGrab.grab().crop((0,0,app.w,app.h)).save(sys.argv[1])
    # Each upgrade card, including the longest text, must stay within its card.
    card_fail=[]
    app.screen='UPGRADE'
    for offset in range(len(UPGRADES)):
        app.upgrade_choices=[(offset+i)%len(UPGRADES) for i in range(3)]
        app.render();root.update_idletasks()
        for idx,(left,top,right,bottom) in enumerate(app.card_bounds):
            for item in app.canvas.find_withtag('dynamic'):
                if app.canvas.type(item)!='text':continue
                coords=app.canvas.coords(item)
                if not coords:continue
                x,y=coords[:2]
                if not (left*app.scale-1<=x<=right*app.scale+1 and
                        (top+22)*app.scale<=y<=(bottom-20)*app.scale):
                    continue
                box=app.canvas.bbox(item)
                if box and (box[0]<left*app.scale-2 or box[2]>right*app.scale+2 or
                            box[3]>(bottom-11)*app.scale+1):
                    card_fail.append((offset,idx,app.canvas.itemcget(item,'text'),box))
    if card_fail: print('CARD CLIPPING:',card_fail[:8])
    print('DISPLAY',root.winfo_screenwidth(),root.winfo_screenheight(),
          'WINDOW',app.w,app.h,'TEXT_CLIPPING',report,'CARD_CLIPPING',len(card_fail))
    app.close()
    if any(n for _,n in report) or card_fail:raise SystemExit(2)
