"""Fourth edition: 36 explicit mechanical review perspectives.

Each perspective also rechecks ten completed scripts against 40 HTML chunks and
10 appendices. This is not a claim of 36 human full-text readings.
Run with Python standard library: python3 verification/audit_fourth_36.py
"""
import ast
import importlib.util
import json
from html import unescape
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import tempfile
from contextlib import closing
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
from cases import CASES
from test_materials import Manual

DOC = (ROOT / 'python_10_projects_day06_manual.html').read_text('utf-8')
PAGE = Manual(DOC)
PROJ = sorted((ROOT / 'projects').glob('*.py'))
README = (ROOT / 'README.txt').read_text('utf-8')
ZIP = 'day06_python_10_projects_20261110_deep_review_v5.zip'


def insist(value, what):
    if not value:
        raise AssertionError(what)


def module(num):
    spec = importlib.util.spec_from_file_location(f'fourth_{num}', PROJ[num - 1])
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


def run(num, *args, cwd=ROOT):
    return subprocess.run([sys.executable, '-S', str(PROJ[num - 1]), *args],
                          cwd=cwd, capture_output=True, text=True, timeout=7)


def full_reconcile(num):
    insist(len(PROJ) == 10 and len(PAGE.chapters) == 20, 'inventory')
    for index, path in enumerate(PROJ, 1):
        name = f'{index:02d}'
        source = path.read_bytes()
        steps = ''.join(PAGE.sources[f'step-{name}-{part}'] for part in range(1, 5)).encode('ascii')
        appendix = PAGE.sources[f'src-{name}'].encode('ascii')
        insist(source == steps == appendix, f'pass {num} {name} source/steps/appendix drift')
        lines = [item for step in range(1, 5) for item in PAGE.line_numbers[f'step-{name}-{step}']]
        insist(lines == list(range(1, source.count(b'\n') + 1)), f'pass {num} {name} numbering')


def c01():
    insist(module(1).resolve('/public/%252e%252e/private/notes') ==
           ('/public/%2e%2e/private/notes', '/private/notes', True, False), 'double decode')


def c02():
    m = module(2)
    with closing(sqlite3.connect(':memory:')) as db:
        db.execute('CREATE TABLE notes(label TEXT)')
        db.executemany('INSERT INTO notes VALUES (?)', [('blue',), ('red',)])
        for key, expect in [('blue', (1, 1)), ('none', (0, 0)), ("none' OR '1'='1", (2, 0))]:
            insist(m.count_rows(db, key) == expect, 'SQL '+key)


def c03():
    m = module(3)
    for args, expect in [(('alice', '101'), ('200', '200')),
                         (('alice', '102'), ('200', '403')),
                         (('bob', '102'), ('200', '200')),
                         (('alice', '103'), ('404', '404'))]:
        insist(m.compare(*args) == expect, 'object comparison '+repr(args))


def c04():
    m = module(4)
    insist(m.headers('https://app.example.test') ==
           ('https://app.example.test', 'https://app.example.test'), 'trusted origin')
    insist(m.headers('https://trap-app.example.test') ==
           ('https://trap-app.example.test', '(omitted)'), 'spoof origin')


def c05():
    m = module(5)
    insist(m.follow('https://public.example.test/jump', False) == 'read inside-note', 'initial scope only')
    insist(m.follow('https://public.example.test/jump', True) ==
           'blocked https://inside.example.test/info', 'per-hop scope')
    insist(m.follow('https://public.example.test/loop', True) == 'hop limit', 'redirect loop')


def c06():
    m = module(6)
    cases = [('header.gif', (True, True)), ('fake.gif', (True, False)),
             ('header.txt', (False, True)), ('short.gif', (True, False))]
    for name, result in cases:
        insist(m.compare(ROOT / 'samples' / name)[1:] == result, 'file '+name)


def c07():
    m = module(7)
    import hmac
    insist(hmac.compare_digest(m.tag(m.ORIGINAL), m.tag(m.ORIGINAL)), 'valid original tag')
    insist(not hmac.compare_digest(m.tag(m.ORIGINAL), m.tag(m.ALTERED)), 'invalid altered tag')


def c08():
    m = module(8)
    insist(m.decisions(m.CASES['same']) == 'allow allow deny', 'same bucket')
    insist(m.decisions(m.CASES['rotate']) == 'allow allow allow', 'rotating bucket')
    insist(m.decisions(m.ACCOUNT) == 'allow allow deny', 'account bucket')


def c09():
    m = module(9)
    for val, expected in [('0000', (False, 1)), ('4800', (False, 3)),
                          ('4820', (False, 4)), ('4827', (True, 4))]:
        insist(m.early_count(val) == expected, 'early comparison '+val)
        insist(m.full_count(val) == (expected[0], 4), 'full comparison '+val)


def c10():
    m = module(10)
    insist(m.capture(m.BANNERS['lab']) == b'LAB/1 ready\r\n', 'loopback lab')
    insist(m.capture(m.BANNERS['other']) == b'NOTICE ready\r\n', 'loopback other')


def c11():
    m = module(1)
    for raw in ('/public/%00', '/public/%ff', '/public/%0a'):
        try:
            m.resolve(raw)
        except ValueError:
            continue
        raise AssertionError('decoder control accepted '+raw)
    insist(m.resolve('/public/../publicity/notes')[-1] is False, 'prefix sibling')


def c12():
    m = module(2)
    with closing(sqlite3.connect(':memory:')) as db:
        db.execute('CREATE TABLE notes(label TEXT)')
        db.executemany('INSERT INTO notes VALUES (?)', [('blue',), ('red',)])
        insist(m.count_rows(db, "blue' OR 1=1 --") == (2, 0), 'second SQL contrast')


def c13():
    p = run(3, 'alice', '\uff11\uff12\uff13')
    insist(p.returncode == 2 and p.stdout == '' and 'ASCII ID' in p.stderr, 'unicode ID')


def c14():
    m = module(4)
    for origin in ('http://app.example.test', 'https://app.example.test:8443',
                   'https://xapp.example.test'):
        insist(m.headers(origin)[1] == '(omitted)', 'exact origin boundary '+origin)


def c15():
    m = module(5)
    class Protected(dict):
        def get(self, target):
            insist(not target.startswith('https://inside.example.test/'), 'fixture looked up before scope check')
            return super().get(target)
    with patch.object(m, 'PAGES', Protected(m.PAGES)):
        insist(m.follow('https://public.example.test/jump', True).startswith('blocked '), 'redirect guard')


def c16():
    with tempfile.TemporaryDirectory() as dirpath:
        a = run(6, 'header', cwd=dirpath)
    b = run(6, 'header')
    insist((a.returncode, a.stdout, a.stderr) == (b.returncode, b.stdout, b.stderr), 'cwd independent')


def c17():
    m = module(7)
    with patch.object(m, 'LAB_KEY', bytes([11]) * 20):
        insist(m.tag(b'Hi There').hex() ==
               'b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7', 'HMAC vector')


def c18():
    m = module(8)
    insist(m.decisions(('a', 'b', 'a', 'a')) == 'allow allow allow deny', 'per label state')
    insist(m.decisions(('a',)) == 'allow' and m.decisions(()) == '', 'state reset')


def c19():
    m = module(9)
    for wrong in ('', '48', '482', '48270'):
        for func in (m.early_count, m.full_count):
            try:
                func(wrong)
            except ValueError:
                continue
            raise AssertionError('length allowed '+repr(wrong))


def c20():
    m = module(10)
    insist(m.capture(b'A' * 70 + b'\n') == b'A' * 64, 'banner max bytes')
    insist(m.capture(b'') == b'', 'banner closed early')
    with patch.object(m, 'capture', return_value=b'partial'):
        with patch.object(sys, 'argv', ['file.py', 'lab']):
            with patch('builtins.print'):
                insist(m.main() == 1, 'incomplete banner status')


def c21():
    insist(len(PAGE.chapters) == 20 and PAGE.chapters == PAGE.checks, 'chapter progress order')
    insist(len(set(PAGE.chapters)) == 20, 'unique chapters')


def c22():
    insist(len([k for k in PAGE.sources if re.fullmatch(r'step-\d\d-[1-4]', k)]) == 40, 'steps')
    insist(len([k for k in PAGE.sources if re.fullmatch(r'src-\d\d', k)]) == 10, 'appendices')


def c23():
    for i, path in enumerate(PROJ, 1):
        n = f'{i:02d}'
        actual = path.read_text('ascii')
        insist(PAGE.sources[f'src-{n}'] == actual, 'appendix '+n)
        for line, content in enumerate(actual.splitlines(), 1):
            if content:
                insist(f'src-{n}-L{line}' in PAGE.anchors, 'source jump '+n+':'+str(line))


def c24():
    insist(all(count == 1 for count in PAGE.ids.values()), 'duplicate HTML IDs')
    insist(not set(PAGE.anchors).difference(PAGE.ids.keys()), 'broken in-page anchor')


def c25():
    insist(PAGE.internal_assets == [], 'online dependency in static page')
    insist('<meta charset="utf-8"' in DOC, 'UTF-8 declaration')
    insist('color-scheme: dark' in DOC, 'dark mode')


def c26():
    for path in PROJ + list((ROOT / 'tests').glob('*.py')):
        insist(path.read_bytes().isascii(), 'non-ASCII in Python '+path.name)
        ast.parse(path.read_text('ascii'), feature_version=(3, 10))


def c27():
    allow = {'posixpath', 'sys', 'sqlite3', 'contextlib', 'urllib.parse', 'pathlib', 'hmac', 'socket'}
    for path in PROJ:
        tree = ast.parse(path.read_text('ascii'))
        used = [x.module for x in ast.walk(tree) if isinstance(x, ast.ImportFrom)]
        used += [alias.name for x in ast.walk(tree) if isinstance(x, ast.Import) for alias in x.names]
        insist(set(used) <= allow, 'unexpected source dependency '+path.name)


def c28():
    for i in range(1, 11):
        n = f'{i:02d}'
        insist(DOC.count(f'class="case-lab" id="verified-cases-{n}"') == 1, 'case block '+n)
        for j in range(1, 4):
            insist(DOC.count(f'id="case-{n}-{j}"') == 1, 'case '+n+'-'+str(j))


def c29():
    count = 0
    for i, (name, cases) in enumerate(CASES.items(), 1):
        m = re.search(rf'<details class="case-lab" id="verified-cases-{i:02d}">(.*?)</details>', DOC, re.S)
        insist(m is not None, 'case section '+name)
        chunks = re.findall(r'<li id="case-\d\d-[1-3]">(.*?)</li>', m.group(1), re.S)
        insist(len(chunks) == 3, 'three scenarios '+name)
        for fragment, (args, code, stdout, stderr) in zip(chunks, (cases[0], cases[1], cases[-1])):
            ret = run(i, *args)
            insist((ret.returncode, ret.stdout, ret.stderr) == (code, stdout, stderr), 'CLI '+name)
            expected = (stdout if stdout else '(\u6a19\u6e96\u51fa\u529b\u306a\u3057)\n') + ('[stderr]\n' + stderr if stderr else '')
            visible = re.search(r'<pre class="case-output">(.*?)</pre>', fragment, re.S)
            insist(visible and unescape(visible.group(1)) == expected, 'HTML output '+name)
            insist(f'\u7d42\u4e86\u5024 <strong>{code}</strong>' in fragment, 'HTML status '+name)
            count += 1
    insist(count == 30, 'thirty executed cases')


def c30():
    insist('Project 06\u306f\u6559\u6750\u306e\u30eb\u30fc\u30c8\u3067\u5b9f\u884c\u3059\u308b' not in DOC, 'stale cwd advice')
    insist('\u7aef\u672b\u306e\u73fe\u5728\u5730\u3092\u5909\u66f4\u3059\u308b\u5fc5\u8981\u306f\u306a\u3044' in DOC, 'precise cwd advice')


def c31():
    insist('unzip '+ZIP in README and 'unzip '+ZIP in DOC, 'current ZIP filename')
    insist('vim' in README and 'practice/' in README and 'projects/' in README, 'first steps')


def c32():
    insist('localStorage.setItem(key, JSON.stringify(state));\n      storage = true;' in DOC, 'storage recovery state')
    insist('aria-pressed' in DOC and 'aria-expanded' in DOC, 'interactive state')


def c33():
    total = 0
    for i, (_,cases) in enumerate(CASES.items(), 1):
        for args, code, out, err in cases:
            got = run(i, *args)
            insist((got.returncode, got.stdout, got.stderr) == (code,out,err), f'59 matrix {i}:{args}')
            total += 1
    insist(total == 59, '59 cases')


def c34():
    m = module(9)
    hist = [0,0,0,0]
    for x in range(10000):
        trial = f'{x:04d}'
        match, n = m.early_count(trial)
        insist(match == (trial == '4827') and m.full_count(trial) == (match,4), 'oracle '+trial)
        hist[n-1] += 1
    insist(hist == [9000,900,90,10], 'oracle distribution')


def c35():
    for i in range(1, 11):
        n = f'{i:02d}'
        for prefix in ('beginner-', 'reasoning-', 'trace-', 'verified-cases-'):
            insist(prefix+n in DOC, 'missing explanation '+prefix+n)
        for label in ('title','intro','interpret','limit'):
            insist(f'id="verified-cases-{n}-{label}"' in DOC, 'case interpretation '+n)


def c36():
    hist=json.loads((ROOT / 'PROJECT_HISTORY.json').read_text('utf-8'))
    insist(hist['last_completed_volume']==6 and hist['next_volume']==7, 'volume sequence')
    insist(len(hist['projects'])==60, 'ledger count')
    insist('day07' in (ROOT / 'HANDOFF_PROMPT.txt').read_text(), 'next volume guidance')
    insist(all('raise SystemExit(main())' in p.read_text('ascii') for p in PROJ), 'entrypoint')


CHECKS = [globals()[f'c{x:02d}'] for x in range(1, 37)]
LABELS = [
    'Two-stage decoding and path boundary','SQLite normal, missing and injection contrast',
    'Object existence and owner authorization','Origin suffix spoof and exact allow',
    'Redirect entry and all-hop scope','Four synthetic upload samples',
    'HMAC normal and tampered content','Header and account keyed rate limits',
    'Early vs full comparison examples','Loopback banners two types',
    'Invalid decoded bytes and sibling path','Alternate SQL injection fixture',
    'Full-width Unicode IDs refused','Origin scheme port and spoof variants',
    'Redirect blocked before internal lookup','Upload script independent of process cwd',
    'RFC HMAC-SHA256 known test vector','Rate-bucket state isolation',
    'Oracle direct-call length guard','TCP banner read bound and incomplete response',
    'Chapter inventory and checkboxes','40 HTML steps plus ten appendices',
    'Line-level source anchors','Unique DOM identifiers and valid fragments',
    'Offline static HTML and dark mode','ASCII-only code and Python 3.10 parse',
    'Standard-library-only project imports','Thirty case examples and unique anchors',
    'All thirty displayed examples vs actual CLI','No outdated upload directory advice',
    'Current filename and first-run README','Persistent UI state and semantics',
    'Entire 59-case CLI observation matrix','Exhaustive 10000-code comparison oracle',
    'Four layers of explanatory material on all labs','Complete ledger and next-volume handoff',
]
assert len(CHECKS) == len(LABELS) == 36


def main():
    outcomes=[]
    for n,(check,label) in enumerate(zip(CHECKS,LABELS),1):
        full_reconcile(n)
        check()
        outcomes.append({'number':n,'label':label,'passed':True,'all_sources_and_steps_rechecked':True})
        print(f'FOURTH ROUND {n:02d}: PASS | {label} | code/steps/appendix 10/40/10')
    output=ROOT/'verification'/'audit_fourth_36.json'
    output.write_text(json.dumps({'count':36,'passed':36,'outcomes':outcomes,
            'disclaimer':'36 distinct mechanical checks, not 36 human full-text readings'},indent=2)+'\n',encoding='ascii')
    print('ALL 36 FOURTH-ROUND PERSPECTIVES: PASS')


if __name__=='__main__':
    main()
