"""35 full-material sweeps with different focused acceptance checks.
No third-party packages. All 10 sources and the full manual are re-read on each sweep.
"""
import ast
from collections import Counter
import hashlib
from html.parser import HTMLParser
from html import unescape
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT/'tests'))
from test_materials import Manual

class DetailParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.classes = []
        self.details = 0
        self.summaries = 0
        self.checks = []
        self.feed((ROOT/'python_10_projects_day05_manual.html').read_text(encoding='utf-8'))
    def handle_starttag(self, tag, attrs):
        d = dict(attrs)
        self.classes.extend(d.get('class','').split())
        if tag=='details': self.details+=1
        if tag=='summary': self.summaries+=1
        if tag=='input' and 'data-check' in d: self.checks.append(d['data-check'])


def materials():
    text = (ROOT/'python_10_projects_day05_manual.html').read_text(encoding='utf-8')
    manual = Manual(text)
    sources = sorted((ROOT/'projects').glob('*.py'))
    cases = json.loads((ROOT/'verification/round4_lab_cases.json').read_text(encoding='utf-8'))
    return text, manual, sources, cases


def always(text, manual, sources, cases):
    # Full sweep: re-read and check all ten source-to-steps-to-appendix relationships.
    assert len(sources)==10 and len(cases)==10
    assert len(manual.chapters)==20 and len(manual.steps)==40
    assert len(manual.ids)==len(set(manual.ids))
    assert all(href[1:] in set(manual.ids) for href in manual.links if href.startswith('#'))
    assert not manual.external_assets
    for n, file in enumerate(sources,1):
        raw=file.read_bytes()
        assert raw.isascii() and raw.endswith(b'\n') and b'\t' not in raw
        ast.parse(raw.decode('ascii'), feature_version=(3,10))
        assert raw==manual.code[f'src{n:02d}'].encode('ascii')
        assert raw==''.join(manual.code[f'p{n:02d}-chunk{k}'] for k in range(1,5)).encode('ascii')
        assert f'purpose-{n:02d}-what' in manual.ids
        assert f'walkthrough-{n:02d}' in manual.ids
        assert f'transfer-{n:02d}' in manual.ids
        assert cases[n-1]['number']==n and cases[n-1]['stdout'] in unescape(text)
        expected={str(i):line for i,line in enumerate(raw.decode('ascii').splitlines(),1) if line.strip()}
        for kind in ('full','steps'):
            rows=[row for context,row in manual.rows if context and (context==f'full-{n:02d}' if kind=='full' else context.startswith(f'p{n:02d}-step'))]
            assert len(rows)==len(expected)
            assert all(len(row)==3 and expected.get(row[0])==row[1] and row[2].strip() for row in rows)
    return True

checks=[
 ('Count and exact ordering of the ten source files',lambda t,m,s,c: all(p.name.startswith(f'{n:02d}_') for n,p in enumerate(s,1))),
 ('Source encoding and line endings',lambda t,m,s,c: all(p.read_bytes().isascii() and b'\r' not in p.read_bytes() and p.read_bytes().endswith(b'\n') for p in s)),
 ('Python 3.10 source parsing',lambda t,m,s,c: all(ast.parse(p.read_text(),feature_version=(3,10)) is not None for p in s)),
 ('Current Python source compilation',lambda t,m,s,c: all(compile(p.read_text(),str(p),'exec') is not None for p in s)),
 ('Standard library imports',lambda t,m,s,c: all(n.names[0].name in {'sys','html','pathlib','configparser','math','string'} for p in s for n in ast.walk(ast.parse(p.read_text())) if isinstance(n,ast.Import))),
 ('Every source has a guarded entry point',lambda t,m,s,c: all('if __name__ == "__main__":' in p.read_text() for p in s)),
 ('Exactly four chapters of code steps per project',lambda t,m,s,c: all(all(f'p{n:02d}-step{k}' in m.steps for k in range(1,5)) for n in range(1,11))),
 ('Four step chunks concatenate to each actual source',lambda t,m,s,c: all(''.join(m.code[f'p{n:02d}-chunk{k}'] for k in range(1,5)).encode('ascii')==p.read_bytes() for n,p in enumerate(s,1))),
 ('Full appendix examples match actual files',lambda t,m,s,c: all(m.code[f'src{n:02d}'].encode('ascii')==p.read_bytes() for n,p in enumerate(s,1))),
 ('Every nonblank source line is explained in the steps',lambda t,m,s,c: all(len([r for id,r in m.rows if id and id.startswith(f'p{n:02d}-step')])==sum(bool(x.strip()) for x in p.read_text().splitlines()) for n,p in enumerate(s,1))),
 ('Every nonblank source line is explained in the appendix',lambda t,m,s,c: all(len([r for id,r in m.rows if id==f'full-{n:02d}'])==sum(bool(x.strip()) for x in p.read_text().splitlines()) for n,p in enumerate(s,1))),
 ('Exactly twenty chapter sections',lambda t,m,s,c: len(m.chapters)==20),
 ('No duplicate HTML identifiers',lambda t,m,s,c: len(m.ids)==len(set(m.ids))),
 ('All local anchor targets exist',lambda t,m,s,c: all(x[1:] in set(m.ids) for x in m.links if x.startswith('#'))),
 ('No JavaScript or CSS external dependency',lambda t,m,s,c: not m.external_assets and '@import' not in t),
 ('Purpose panels contain ten clear labels',lambda t,m,s,c: t.count('class="tool-purpose"')==10),
 ('Purpose panels contain all seven learning fields',lambda t,m,s,c: all(all(f'purpose-{n:02d}-{x}' in m.ids for x in ('what','when','how','result','limits','terms','try')) for n in range(1,11))),
 ('Previously added deep explanations survive',lambda t,m,s,c: all(f'walkthrough-{n:02d}' in m.ids for n in range(1,11))),
 ('New independent case labs exist for all ten',lambda t,m,s,c: all(f'transfer-{n:02d}' in m.ids for n in range(1,11))),
 ('Lab expected standard output matches recorded measurements',lambda t,m,s,c: all(case['stdout'] in unescape(t) for case in c)),
 ('Lab answer disclosure is available without JavaScript',lambda t,m,s,c: t.count('class="lab-answer"')==10 and t.count('\u5b9f\u6e2c\u3057\u305f\u51fa\u529b\u3068\u89e3\u8aac\u3092\u958b\u304f')==10),
 ('Lab and step code is ASCII only',lambda t,m,s,c: all(v.isascii() for v in m.code.values())),
 ('Self-study questions and corresponding answers',lambda t,m,s,c: all(t.count(x)>=10 for x in ('\u6700\u521d\u306b\u4e88\u60f3\uff1a','\u306a\u305c\u305d\u3046\u306a\u308b\uff1f','\u7406\u89e3\u3092\u9032\u3081\u308b\u8ffd\u52a0\u8ab2\u984c\uff1a'))),
 ('All ten lab commands match the referenced source',lambda t,m,s,c: all(case['filename'] in t and case['filename']==s[n-1].name for n,case in enumerate(c,1))),
 ('Sample HTTP file includes Host',lambda t,m,s,c: 'Host:' in (ROOT/'samples/request.txt').read_text('ascii')),
 ('Invalid HTTP sample lacks Host',lambda t,m,s,c: 'Host:' not in (ROOT/'samples/request_no_host.txt').read_text('ascii')),
 ('INI example bounds are ordered and readable',lambda t,m,s,c: 'minimum=10' in (ROOT/'samples/filter.ini').read_text('ascii') and 'maximum=30' in (ROOT/'samples/filter.ini').read_text('ascii')),
 ('Invalid INI bounds are intentionally reversed',lambda t,m,s,c: 'minimum=30' in (ROOT/'samples/filter_invalid.ini').read_text('ascii') and 'maximum=10' in (ROOT/'samples/filter_invalid.ini').read_text('ascii')),
 ('Printed percent may differ from exact probability',lambda t,m,s,c: '99.9%' in t and '1+2+3+2+1=9' in t),
 ('Previous Newton zero misconception stays corrected',lambda t,m,s,c: '\u221a0\u306f\u53b3\u5bc6\u306b0\u3068\u5206\u304b\u308b' in t and '\u3044\u304d\u306a\u308a0\u3067\u5272\u3063\u3066\u3057\u307e\u3046\u304b\u3089' in t),
 ('README shows currently distributed ZIP name',lambda t,m,s,c: 'ZIP\u540d\uff1aday05_python_10_projects_20261110_critical_review_34rounds.zip' in (ROOT/'README.txt').read_text('utf-8')),
 ('New test suite uses ASCII in Python sources',lambda t,m,s,c: all(p.read_bytes().isascii() for p in (ROOT/'tests').glob('*.py'))),
 ('New verification case file encodes ten measured cases',lambda t,m,s,c: len(c)==10 and all(case['status']==0 and case['stderr']=='' for case in c)),
 ('Tool purpose for HTTP states offline limitation',lambda t,m,s,c: '\u901a\u4fe1\u305b\u305a\u5f62\u5f0f\u3092\u8ffd\u3046\u5b9f\u7fd2' in t),
 ('Navigation and checkboxes exist for each project',lambda t,m,s,c: all(f'p{n:02d}' in m.chapters and f'data-check="p{n:02d}"' in t for n in range(1,11))),
]

def main():
    result=[]
    for pass_no,(name,focused) in enumerate(checks,1):
        try:
            # A fresh full material parse and full ten-project mapping check for EVERY pass.
            text,manual,sources,cases=materials()
            always(text,manual,sources,cases)
            if not focused(text,manual,sources,cases): raise AssertionError(name)
            status='PASS'; error=''
        except Exception as exc:
            status='FAIL';error=f'{type(exc).__name__}: {exc}'
        result.append({'pass':pass_no,'focus':name,'scope':'Full manual and ten project sources scanned; focused check then executed','status':status,'error':error})
        print(f'{pass_no:02d}/{len(checks)} {status} {name}')
    out={'passes':len(result),'passed':sum(x['status']=='PASS' for x in result), 'failed':sum(x['status']=='FAIL' for x in result),'scope':'35 fresh machine validation sweeps; not a claim of 35 independent human word-by-word readings.','results':result}
    (ROOT/'verification/round4_audit_35_passes.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    return 1 if out['failed'] else 0

if __name__=='__main__':
    raise SystemExit(main())
