from playwright.sync_api import sync_playwright
from pathlib import Path
import json, datetime
ROOT=Path(__file__).resolve().parents[1]
html=(ROOT/'python_10_projects_day04_manual.html').read_text(encoding='utf-8')
chapters=['cover','usage','setup','basics','schedule']+[f'p{i:02d}' for i in range(1,11)]+['trouble','glossary','references','appendix-a','appendix-b']
widths=[320,390,600,768,901,1440]
res={'browser':'chromium','delivery':'set_content due to sandbox file/http navigation blocked','screen_sizes':widths,'chapters':chapters,'layout_checks':[],'interactions':[],'warnings':[],'generated_at_utc':datetime.datetime.now(datetime.timezone.utc).isoformat()}
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for w in widths:
  page=b.new_page(viewport={'width':w,'height':820});page.set_default_timeout(8000)
  errors=[];page.on('pageerror',lambda exc:errors.append(str(exc)))
  page.set_content(html,wait_until='load',timeout=15000)
  for ch in chapters:
   page.evaluate('(ident) => {location.hash="#"+ident}',ch)
   page.wait_for_function('(ident) => document.querySelector(".chapter.active")?.id === ident',arg=ch,timeout=5000)
   page.wait_for_timeout(15)
   row=page.evaluate('''() => {
   const c=document.querySelector('.chapter.active');
   const doc=document.documentElement;
   const h=document.querySelector('header');
   const visible=[...c.querySelectorAll('h2,h3,table,pre,.step,.deep-dive,.precision-notes')].filter(e => e.getClientRects().length);
   const outside=visible.filter(e=>{let r=e.getBoundingClientRect();return r.left < -1 || r.right > innerWidth + 1;}).map(e=>e.tagName+'.'+e.className);
   const tooWideTables=[...c.querySelectorAll('.table-wrap')].filter(e => e.scrollWidth > e.clientWidth + 3 && e.getClientRects().length);
   return {active:c.id,doc_width:doc.scrollWidth,viewport:innerWidth,header_height:h.offsetHeight,outside_visible_blocks:outside,scrolling_tables:tooWideTables.length,undocumented_scroll_tables:tooWideTables.filter(t=> !t.classList.contains('scrollable-table')).length,unlabelled_code_scroll:[...c.querySelectorAll('.codebox')].filter(e=>{const x=e.querySelector('pre');return x&&x.getClientRects().length&&x.scrollWidth>x.clientWidth+3&&!e.querySelector('.scroll-hint:not([hidden])')}).length};
   }''')
   row['width']=w;res['layout_checks'].append(row)
  # A representative screenshot of the guide and one project on mobile/desktop.
  if w in [320,390,1440]:
   page.evaluate('''() => {location.hash='#p05'}''')
   page.wait_for_function("document.querySelector('.chapter.active')?.id === 'p05'")
   page.screenshot(path=str(ROOT/f'verification/v2_p05_{w}_viewport.png'),full_page=False)
   page.locator('#p05 .deep-dive').screenshot(path=str(ROOT/f'verification/v2_p05_{w}_lesson.png'),timeout=10000)
  # Header overlap bounds
  overlaps=page.evaluate('''() => {let visible=[...document.querySelector('header').children].filter(x=>getComputedStyle(x).display!=='none').map(x=>x.getBoundingClientRect());let out=[];for(let i=0;i<visible.length;i++)for(let j=i+1;j<visible.length;j++)if(Math.min(visible[i].right,visible[j].right)-Math.max(visible[i].left,visible[j].left)>2&&Math.min(visible[i].bottom,visible[j].bottom)-Math.max(visible[i].top,visible[j].top)>2)out.push([i,j]);return out}''')
  res['interactions'].append({'width':w,'name':'header overlap','pass':not overlaps,'overlaps':overlaps})
  res['interactions'].append({'width':w,'name':'JavaScript errors','pass':not errors,'errors':errors})
  if w in (320,390,901):
   if w<=900:
    page.locator('#menu').click()
    menuopen=page.evaluate("document.querySelector('nav').classList.contains('open')")
    page.keyboard.press('Escape')
    menuclosed=not page.evaluate("document.querySelector('nav').classList.contains('open')")
    res['interactions'].append({'width':w,'name':'mobile menu escape','pass':menuopen and menuclosed})
   page.locator('#search').fill('円盤')
   count=page.locator('#matches a').count()
   page.locator('#clear-search').click()
   res['interactions'].append({'width':w,'name':'search and clear','pass':count>0 and page.locator('#search').input_value()=='' and page.locator('#results').is_hidden(),'matches':count})
   page.locator('#focus').click()
   focused=page.evaluate("document.body.classList.contains('focus')")
   page.locator('#focus').click()
   unfocused=not page.evaluate("document.body.classList.contains('focus')")
   res['interactions'].append({'width':w,'name':'focus toggle','pass':focused and unfocused})
   page.locator('#wrap').click()
   wrapped=page.evaluate("document.body.classList.contains('wrap')")
   page.locator('#wrap').click()
   res['interactions'].append({'width':w,'name':'wrap toggle','pass':wrapped and not page.evaluate("document.body.classList.contains('wrap')")})
   page.evaluate("location.hash='#p05'")
   page.wait_for_function("document.querySelector('.chapter.active')?.id === 'p05'")
   page.locator('#p05 .codebox .copy').first.click()
   fallback=page.locator('#p05 .codebox .copy-fallback').first
   val=fallback.locator('textarea').input_value() if fallback.is_visible() else 'CLIPBOARD_SUCCEEDED'
   res['interactions'].append({'width':w,'name':'copy or manual fallback','pass':val=='CLIPBOARD_SUCCEEDED' or 'vim practice/05_roster_compare.py' in val,'value_preview':val[:70]})
   # Direct source jump from a step opens the hidden appendix; return should restore original step.
   page.locator('#p05-step1 a[data-source]').click()
   page.wait_for_function("document.querySelector('.chapter.active')?.id === 'appendix-a'")
   link=page.locator('#source-return')
   source_return=link.get_attribute('href')
   link.click()
   page.wait_for_function("document.querySelector('.chapter.active')?.id === 'p05'")
   res['interactions'].append({'width':w,'name':'source and back','pass':source_return=='#p05-step1'})
  page.close()
 b.close()
res['pass']=all(x['doc_width']<=x['viewport'] and not x['outside_visible_blocks'] and not x['undocumented_scroll_tables'] and not x['unlabelled_code_scroll'] for x in res['layout_checks']) and all(t['pass'] for t in res['interactions'])
(ROOT/'verification/v2_browser_audit.json').write_text(json.dumps(res,ensure_ascii=False,indent=2))
print('browser audit completed',res['pass'],'checks',len(res['layout_checks']),'interactions',len(res['interactions']))
for row in res['layout_checks']:
 if row['doc_width']>row['viewport'] or row['outside_visible_blocks'] or row['undocumented_scroll_tables'] or row['unlabelled_code_scroll']:
  print('LAYOUT FAILED',row)
for row in res['interactions']:
 if not row['pass']:print('INTERACTION FAILED',row)
