import sys

CASES = {"split": b"ok\r\nX-Admin: yes", "plain": b"ok", "lf": b"ok\nX-Admin: yes", "empty": b""}


def inspect_value(note):
    wire = b"X-Note: " + note + b"\r\n\r\n"
    lines = wire.split(b"\r\n")[:-2]
    injected = b"X-Admin: yes" in lines
    accepted = b"\r" not in note and b"\n" not in note
    return len(lines), injected, accepted


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script split|plain|lf|empty", file=sys.stderr)
        return 2
    count, injected, accepted = inspect_value(CASES[sys.argv[1]])
    print(f"Header count: {count}")
    print(f"Extra header seen: {injected}")
    print(f"No-newline gate: {accepted}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
