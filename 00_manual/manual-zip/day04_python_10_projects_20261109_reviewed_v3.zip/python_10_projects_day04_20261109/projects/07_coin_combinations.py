import sys


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 07_coin_combinations.py amount")
        return 2
    try:
        if len(sys.argv[1]) > 3:
            raise ValueError
        total = int(sys.argv[1])
        if not 0 <= total <= 30:
            raise ValueError
    except ValueError:
        print("Error: amount must be an integer from 0 to 30.")
        return 2
    combinations = 0
    for tens in range(total // 10 + 1):
        remaining = total - tens * 10
        for fives in range(remaining // 5 + 1):
            ones = remaining - fives * 5
            print(f"10x{tens} 5x{fives} 1x{ones}")
            combinations += 1
    print(f"Combinations: {combinations}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
