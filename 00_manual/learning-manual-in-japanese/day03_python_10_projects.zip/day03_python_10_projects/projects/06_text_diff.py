import difflib
import sys
from pathlib import Path


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 06_text_diff.py before after")
        return 2
    documents = []
    try:
        for name in sys.argv[1:]:
            with Path(name).open("r", encoding="utf-8") as stream:
                text = stream.read(4097)
            if len(text) > 4096:
                raise ValueError
            documents.append(text.splitlines())
    except (OSError, UnicodeError):
        print("Error: cannot read UTF-8 files.")
        return 1
    except ValueError:
        print("Error: each file must have at most 4096 characters.")
        return 2
    before, after = documents
    if before == after:
        print("No differences.")
    else:
        difference = difflib.unified_diff(
            before, after, fromfile="before", tofile="after", lineterm=""
        )
        for line in difference:
            print(line)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
