import string
import sys
from pathlib import Path


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 05_roster_compare.py first.txt second.txt")
        return 2
    groups = []
    try:
        for name in sys.argv[1:]:
            with Path(name).open("r", encoding="utf-8") as stream:
                text = stream.read(141)
            lines = text.split("\n")
            if lines[-1] == "":
                lines.pop()
            if len(text) > 140 or len(lines) > 10:
                raise ValueError
            members = set()
            for line in lines:
                member = line.strip(" \t")
                if not 1 <= len(member) <= 12:
                    raise ValueError
                if any(ch not in string.ascii_letters for ch in member):
                    raise ValueError
                members.add(member.lower())
            groups.append(members)
    except (OSError, UnicodeError):
        print("Error: cannot read UTF-8 rosters.")
        return 1
    except ValueError:
        print("Error: use at most 10 names, 1-12 letters each, within 140 characters.")
        return 2
    first, second = groups
    results = [("Both", first & second), ("First only", first - second), ("Second only", second - first)]
    for label, members in results:
        names = ", ".join(sorted(members))
        print(f"{label}: {names or '(none)'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
