"""Transient visual-only particles and event effects from native engine events."""
import math
import random
from arena_config import C
RNG = random.Random(41073)

class Particle:
    __slots__ = ('x', 'y', 'vx', 'vy', 'life', 'maximum', 'color', 'size', 'kind')
    def __init__(self, x, y, vx, vy, life, color, size, kind='spark'):
        self.x=x;self.y=y;self.vx=vx;self.vy=vy
        self.life=life;self.maximum=life;self.color=color;self.size=size;self.kind=kind

class FloatText:
    __slots__ = ('x','y','text','color','life','maxlife')
    def __init__(self,x,y,text,color,life=.75):
        self.x=x;self.y=y;self.text=text;self.color=color
        self.life=life;self.maxlife=life


class VisualEffects:
    def emit(self,x,y,count,colors,speed=165,size=3.2,life=.55,kind='spark'):
        for _ in range(count):
            theta=RNG.uniform(0,math.tau)
            magnitude=RNG.uniform(speed*.24,speed)
            self.particles.append(Particle(x,y,math.cos(theta)*magnitude,
                                           math.sin(theta)*magnitude,
                                           RNG.uniform(life*.48,life),
                                           RNG.choice(colors),RNG.uniform(size*.5,size*1.5),kind))
        if len(self.particles)>420:self.particles=self.particles[-420:]

    def process_events(self):
        st=self.engine.state
        for i in range(st.event_count):
            e=st.events[i]
            x,y=e.x,e.y
            if e.kind==1:  # muzzle flash
                self.emit(x,y,3,['#ffe6a2','#ffc676','#fda35d'],speed=84,size=2.0,life=.24)
            elif e.kind==2:
                self.emit(x,y,7,['#f6b97c','#d49e72','#78939c'],speed=160,size=2.4,life=.37)
            elif e.kind==3:
                if e.value==-1:
                    self.emit(x,y,18,['#abcaaf','#d4b782','#7d9994'],speed=220,size=4.0,life=.63)
                else:
                    self.emit(x,y,27 if e.value==3 else 18,
                              ['#ffcf8b','#f7a06c','#e56c60','#89999d'],
                              speed=235,size=4.6,life=.72)
                    # Score float is emitted separately with the actual reward;
                    # using the final frame combo mislabels simultaneous kills.
            elif e.kind==12:  # exact per-kill reward (not the final combo)
                self.floats.append(FloatText(x,y-24,'+'+str(round(e.value)),C['gold']))
            elif e.kind==4:
                self.emit(x,y,11,['#fa7580','#ffc18c','#e3a09b'],speed=145,size=3.5)
                self.flash_timer=.13
                self.floats.append(FloatText(x,y-34,'-'+str(round(e.value)),C['red']))
            elif e.kind==5:
                self.emit(x,y,16,['#68e8d4','#a5fbeb','#347b82'],speed=175,size=2.4,life=.37)
            elif e.kind==6:
                self.emit(x,y,60,['#8cddff','#b3e1fa','#94a3fc'],speed=280,size=3.7,life=.74)
            elif e.kind==7:
                self.emit(x,y,12,['#c8ffda','#f5e9ad'],speed=115,size=2.5,life=.53)
                self.floats.append(FloatText(x,y-19,'REPAIRED' if e.value==0 else 'CHARGED',C['green']))
            elif e.kind==8:
                self.emit(x,y,5,['#b49b79','#8b7770','#ccd0b6'],speed=135,size=2.5,life=.35)
            elif e.kind==9:
                self.emit(x,y,5,['#ffcc86','#f28c69','#af6c71'],speed=110,size=2.3,life=.26)
        if len(self.floats)>80:self.floats=self.floats[-80:]

    def update_particles(self,dt):
        for p in self.particles:
            p.x+=p.vx*dt;p.y+=p.vy*dt
            p.vx*=max(0,1-2*dt);p.vy*=max(0,1-2*dt)
            p.life-=dt
        self.particles=[p for p in self.particles if p.life>0]
        for t in self.floats:
            t.y-=36*dt;t.life-=dt
        self.floats=[t for t in self.floats if t.life>0]

