"""Tkinter event-dispatch smoke test; requires an actual GUI/Xvfb."""
import sys
import time
import tkinter as tk
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from game import Game

r = tk.Tk()
g = Game(r, seed=41, auto_loop=False)
g.save_best = lambda: None
try:
    r.update()
    assert g.state == 'menu'
    g.canvas.event_generate('<ButtonPress-1>', x=560, y=535)
    r.update()
    assert g.state == 'playing'
    g.canvas.event_generate('<Motion>', x=750, y=250)
    g.canvas.event_generate('<ButtonPress-1>', x=750, y=250)
    r.update()
    assert (g.mouse_x, g.mouse_y) == (750, 250) and g.mouse_down
    g.canvas.event_generate('<ButtonRelease-1>', x=750, y=250)
    r.update()
    assert not g.mouse_down
    g.canvas.focus_force()
    r.update()
    g.canvas.event_generate('<KeyPress>', keysym='d')
    g.canvas.event_generate('<KeyPress>', keysym='space')
    r.update()
    assert g.player.dash_time > 0
    x_before = g.player.x
    g.tick(1 / 60)
    assert g.player.x > x_before
    g.canvas.event_generate('<KeyRelease>', keysym='space')
    g.canvas.event_generate('<KeyRelease>', keysym='d')
    r.update()
    g.canvas.event_generate('<KeyPress>', keysym='p')
    r.update()
    assert g.state == 'paused'
    g.canvas.event_generate('<KeyRelease>', keysym='p')
    r.update()
    # Wait for debounced release, so the next press is a physical new press.
    time.sleep(.045)
    r.update()
    g.canvas.event_generate('<KeyPress>', keysym='p')
    r.update()
    assert g.state == 'playing'
    g.canvas.event_generate('<KeyRelease>', keysym='p')
    r.update()
    g.enemies.clear()
    g.pending.clear()
    g.finish_wave()
    assert g.state == 'upgrade'
    g.canvas.event_generate('<KeyPress>', keysym='2')
    r.update()
    assert g.state == 'playing' and g.wave == 2
    g.player.hp = 1
    g.player.invulnerable = 0
    g.hurt_player(100)
    assert g.state == 'gameover'
    g.canvas.event_generate('<KeyPress>', keysym='Return')
    r.update()
    assert g.state == 'playing' and g.wave == 1
    other = tk.Toplevel(r)
    other.update()
    other.focus_force()
    r.update()
    other.update()
    r.update()
    assert g.state == 'paused', 'Changing to another window must pause active play'
    other.destroy()
    print('ACTUAL TK EVENT DISPATCH OK: start, aim, fire, release, dash, pause, upgrade, death, restart, focus-out')
finally:
    r.destroy()
