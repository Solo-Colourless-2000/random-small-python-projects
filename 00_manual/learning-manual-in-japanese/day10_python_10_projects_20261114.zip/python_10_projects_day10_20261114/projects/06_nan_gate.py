import math
import sys

CASES = {"nan": "nan", "normal": "50", "lower": "0", "upper": "100", "negative": "-1", "large": "101", "infinity": "inf", "broken": "oops"}


def gates(value):
    weak = not (value < 0 or value > 100)
    strict = math.isfinite(value) and 0 <= value <= 100
    return weak, strict


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script nan|normal|lower|upper|negative|large|infinity|broken", file=sys.stderr)
        return 2
    try:
        value = float(CASES[sys.argv[1]])
    except ValueError:
        print("Invalid lab number.", file=sys.stderr)
        return 2
    weak, strict = gates(value)
    print(f"Finite: {math.isfinite(value)}")
    print(f"Outside-only gate: {weak}")
    print(f"Finite range gate: {strict}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
