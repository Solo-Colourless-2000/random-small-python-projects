"""Create screenshots and inspect canvas text bounding boxes (requires Xvfb)."""
from __future__ import annotations
import sys
import argparse
import tkinter as tk
from pathlib import Path
from PIL import ImageGrab
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from game import Game
from constants import WIDTH, HEIGHT
from entities import Enemy

parser = argparse.ArgumentParser(description='Capture UI screenshots and check text bounds')
parser.add_argument('--output-dir', type=Path,
                    default=Path(__file__).resolve().parents[1] / 'screenshots')
args = parser.parse_args()
args.output_dir.mkdir(parents=True, exist_ok=True)

root = tk.Tk()
game = Game(root, seed=21, auto_loop=False)
game.save_best = lambda: None
root.geometry(f'{WIDTH}x{HEIGHT}+80+35')
root.update()


def save(name):
    game.renderer.draw(game)
    root.update_idletasks()
    root.update()
    x, y = game.canvas.winfo_rootx(), game.canvas.winfo_rooty()
    img = ImageGrab.grab(bbox=(x, y, x + WIDTH, y + HEIGHT))
    path = args.output_dir / f'neon_rift_v4_{name}.png'
    img.save(path)
    print(path, img.getbbox())


def inspect_labels():
    failures = []
    for item in game.canvas.find_all():
        if game.canvas.type(item) != 'text':
            continue
        label = game.canvas.itemcget(item, 'text')
        bound = game.canvas.bbox(item)
        if not bound:
            continue
        x1, y1, x2, y2 = bound
        if x1 < -3 or y1 < -3 or x2 > WIDTH + 3 or y2 > HEIGHT + 3:
            failures.append((label, bound))
    if failures:
        raise AssertionError(f'Text outside Canvas: {failures}')
    print('text overflow: none')


save('menu')
inspect_labels()
game.start()
game.pending.clear()
game.enemies.clear()
game.spawn_enemy('hunter')
game.spawn_enemy('runner')
game.spawn_enemy('gunner')
game.spawn_enemy('bruiser')
game.wave = 5
game.banner = 'WAVE 05  //  BOSS INCOMING'
game.spawn_enemy('warden')
game.player.pellets = 3
game.mouse_x, game.mouse_y = 675, 320
game.fire_player()
for _ in range(38):
    game.tick(1 / 60)
save('game')
inspect_labels()
game.enemies.clear()
game.pending.clear()
game.finish_wave()
game.upgrades_offered = ['medkit', 'thrusters', 'reinforced']
save('upgrades')
inspect_labels()
game.state = 'paused'
save('paused')
inspect_labels()
game.state = 'playing'
game.hurt_player(999)
save('gameover')
inspect_labels()
root.destroy()
