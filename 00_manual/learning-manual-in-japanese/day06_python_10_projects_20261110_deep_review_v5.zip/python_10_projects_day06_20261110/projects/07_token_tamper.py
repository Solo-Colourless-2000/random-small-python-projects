import hmac
import sys

LAB_KEY = b"day06-demo-key"
ORIGINAL = b"role=reader"
ALTERED = b"role=editor"


def tag(body):
    return hmac.digest(LAB_KEY, body, "sha256")


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ("original", "altered"):
        print("Usage: script original|altered", file=sys.stderr)
        return 2
    issued = tag(ORIGINAL)
    body = ALTERED if sys.argv[1] == "altered" else ORIGINAL
    observed = body.decode("ascii")
    authentic = hmac.compare_digest(issued, tag(body))
    print(f"Body only: {observed}")
    print(f"Tag valid: {authentic}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
