def ok(args, *stdout):
    return args, 0, "\n".join(stdout) + "\n", ""


def bad(args, stderr, code=2):
    return args, code, "", stderr + "\n"


CASES = {
    "01_traversal": [
        ok(["/public/%252e%252e/private/notes"], "First decode: /public/%2e%2e/private/notes", "Target: /private/notes", "Early check: True", "Target check: False"),
        ok(["/public/notes"], "First decode: /public/notes", "Target: /public/notes", "Early check: True", "Target check: True"),
        ok(["/public/%2e%2e/private/notes"], "First decode: /public/../private/notes", "Target: /private/notes", "Early check: False", "Target check: False"),
        ok(["/public/" + "a" * 152], "First decode: /public/" + "a" * 152, "Target: /public/" + "a" * 152, "Early check: True", "Target check: True"),
        bad(["/public/" + "a" * 153], "Use a printable ASCII path of up to 160 characters."),
        bad(["/public/%00"], "Invalid decoded path."),
        bad(["/public/%ff"], "Invalid decoded path."),
        bad([], "Usage: script /public/PATH"),
    ],
    "02_sql_probe": [
        ok(["probe"], "Concatenated count: 2", "Bound count: 0"),
        ok(["missing"], "Concatenated count: 0", "Bound count: 0"),
        ok(["known"], "Concatenated count: 1", "Bound count: 1"),
        bad(["'"], "Usage: script known|missing|probe"),
        bad([], "Usage: script known|missing|probe"),
    ],
    "03_object_access": [
        ok(["alice", "102"], "Existence only: 200", "Owner check: 403"),
        ok(["alice", "101"], "Existence only: 200", "Owner check: 200"),
        ok(["alice", "000"], "Existence only: 404", "Owner check: 404"),
        ok(["bob", "102"], "Existence only: 200", "Owner check: 200"),
        ok(["bob", "101"], "Existence only: 200", "Owner check: 403"),
        bad(["alice", "1000"], "Use a known caller and a three-digit ASCII ID."),
        bad(["charlie", "101"], "Use a known caller and a three-digit ASCII ID."),
        bad([], "Usage: script alice|bob ID"),
    ],
    "04_origin_policy": [
        ok(["https://trap-app.example.test"], "Suffix ACAO: https://trap-app.example.test", "Exact ACAO: (omitted)"),
        ok(["https://app.example.test"], "Suffix ACAO: https://app.example.test", "Exact ACAO: https://app.example.test"),
        ok(["https://app.example.test:8443"], "Suffix ACAO: (omitted)", "Exact ACAO: (omitted)"),
        ok(["http://app.example.test"], "Suffix ACAO: http://app.example.test", "Exact ACAO: (omitted)"),
        ok(["x" * 120], "Suffix ACAO: (omitted)", "Exact ACAO: (omitted)"),
        bad(["x" * 121], "Use 1 to 120 printable ASCII characters without spaces."),
        bad([""], "Use 1 to 120 printable ASCII characters without spaces."),
        bad([], "Usage: script ORIGIN"),
    ],
    "05_redirect_scope": [
        ok(["jump"], "Start only: read inside-note", "Every hop: blocked https://inside.example.test/info"),
        ok(["ok"], "Start only: read public-note", "Every hop: read public-note"),
        ok(["loop"], "Start only: hop limit", "Every hop: hop limit"),
        bad(["https://public.example.test/ok"], "Usage: script ok|jump|loop"),
        bad([], "Usage: script ok|jump|loop"),
    ],
    "06_upload_probe": [
        ok(["fake"], "Prefix: b'TEXT!!'", "Suffix check: True", "Signature check: False"),
        ok(["header"], "Prefix: b'GIF89a'", "Suffix check: True", "Signature check: True"),
        ok(["rename"], "Prefix: b'GIF89a'", "Suffix check: False", "Signature check: True"),
        ok(["short"], "Prefix: b'GIF'", "Suffix check: True", "Signature check: False"),
        bad(["../header.gif"], "Usage: script header|fake|rename|short"),
        bad([], "Usage: script header|fake|rename|short"),
    ],
    "07_token_tamper": [
        ok(["altered"], "Body only: role=editor", "Tag valid: False"),
        ok(["original"], "Body only: role=reader", "Tag valid: True"),
        bad(["editor"], "Usage: script original|altered"),
        bad([], "Usage: script original|altered"),
    ],
    "08_limit_buckets": [
        ok(["rotate"], "Header key: allow allow allow", "Account key: allow allow deny"),
        ok(["same"], "Header key: allow allow deny", "Account key: allow allow deny"),
        bad(["single"], "Usage: script same|rotate"),
        bad([], "Usage: script same|rotate"),
    ],
    "09_compare_oracle": [
        ok(["4800"], "Early: match=False, checks=3", "Full: match=False, checks=4"),
        ok(["4827"], "Early: match=True, checks=4", "Full: match=True, checks=4"),
        ok(["0000"], "Early: match=False, checks=1", "Full: match=False, checks=4"),
        ok(["4820"], "Early: match=False, checks=4", "Full: match=False, checks=4"),
        bad(["482"], "Use exactly four ASCII digits."),
        bad(["48270"], "Use exactly four ASCII digits."),
        bad([], "Usage: script FOUR_DIGITS"),
    ],
    "10_banner_probe": [
        ok(["lab"], "Banner: b'LAB/1 ready\\r\\n'", "Known prefix: True"),
        ok(["other"], "Banner: b'NOTICE ready\\r\\n'", "Known prefix: False"),
        bad(["8.8.8.8"], "Usage: script lab|other"),
        bad([], "Usage: script lab|other"),
    ],
}
