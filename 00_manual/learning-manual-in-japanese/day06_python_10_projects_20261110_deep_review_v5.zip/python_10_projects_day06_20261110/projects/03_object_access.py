import sys

OWNERS = {"101": "alice", "102": "bob"}
CALLERS = ("alice", "bob")


def compare(caller, object_id):
    owner = OWNERS.get(object_id)
    if owner is None:
        return "404", "404"
    if owner != caller:
        return "200", "403"
    return "200", "200"


def main():
    if len(sys.argv) != 3:
        print("Usage: script alice|bob ID", file=sys.stderr)
        return 2
    caller, object_id = sys.argv[1:]
    if caller not in CALLERS or len(object_id) != 3 or not object_id.isascii() or not object_id.isdecimal():
        print("Use a known caller and a three-digit ASCII ID.", file=sys.stderr)
        return 2
    weak, checked = compare(caller, object_id)
    print(f"Existence only: {weak}")
    print(f"Owner check: {checked}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
