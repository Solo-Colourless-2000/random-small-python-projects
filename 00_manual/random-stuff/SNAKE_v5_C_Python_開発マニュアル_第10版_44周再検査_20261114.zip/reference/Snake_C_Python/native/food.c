#include "snake_internal.h"

#include <stdint.h>

/* Xorshift32: deterministic, lightweight, not cryptographically secure. */
static uint32_t random_next(SnakeGame *game) {
    uint32_t x = game->rng;
    x ^= x << 13;
    x ^= x >> 17;
    x ^= x << 5;
    game->rng = x;
    return x;
}

/* Unbiased bounded random selection. Precondition: bound > 0. */
static uint32_t random_below(SnakeGame *game, uint32_t bound) {
    const uint32_t threshold = (uint32_t)(-bound) % bound;
    uint32_t value;
    do {
        value = random_next(game);
    } while (value < threshold);
    return value % bound;
}

void snake_place_food(SnakeGame *game) {
    const int free_cells = game->capacity - game->length;
    game->food_x = -1;
    game->food_y = -1;
    if (free_cells <= 0) {
        return;
    }
    /* Scan occupied cells only once, even when the snake is almost full. */
    uint8_t taken[SNAKE_MAX_SIDE * SNAKE_MAX_SIDE] = {0};
    for (int i = 0; i < game->length; ++i) {
        const SnakeCell cell = game->body[i];
        taken[cell.y * game->width + cell.x] = 1;
    }
    int choice = (int)random_below(game, (uint32_t)free_cells);
    for (int y = 0; y < game->height; ++y) {
        for (int x = 0; x < game->width; ++x) {
            if (!taken[y * game->width + x]) {
                if (choice == 0) {
                    game->food_x = x;
                    game->food_y = y;
                    return;
                }
                --choice;
            }
        }
    }
}
