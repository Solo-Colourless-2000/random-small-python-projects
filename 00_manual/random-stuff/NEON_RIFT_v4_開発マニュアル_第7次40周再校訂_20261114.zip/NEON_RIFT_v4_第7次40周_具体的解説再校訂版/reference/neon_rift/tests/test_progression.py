"""Regression tests for upgrade caps, state changes and RNG independence."""
import random
import sys
import types
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from constants import ARENA_BOTTOM, ARENA_LEFT, ARENA_RIGHT, ARENA_TOP, UPGRADES
from entities import Enemy, Player, Pickup
from mechanics import upgrade_choices, wave_roster
from support import create_game
from upgrades import apply_to_player, available_upgrades


class UpgradeTests(unittest.TestCase):
    def test_all_initial_upgrades_are_available(self):
        self.assertEqual(available_upgrades(Player()), set(UPGRADES))

    def test_three_repeatables_survive_all_caps(self):
        p = Player(fire_interval=.075, dash_recharge=.65, pellets=5,
                   speed=500, energy_regen=32)
        self.assertEqual(available_upgrades(p), {'tungsten', 'reinforced', 'medkit'})

    def test_choices_never_include_exhausted_perks(self):
        p = Player(fire_interval=.075, dash_recharge=.65, pellets=5,
                   speed=500, energy_regen=32)
        picks = upgrade_choices(random.Random(55), {'tungsten'}, available_upgrades(p))
        self.assertEqual(set(picks), {'tungsten', 'reinforced', 'medkit'})

    def test_choices_when_only_one_available(self):
        self.assertEqual(upgrade_choices(random.Random(3), eligible={'tungsten'}), ['tungsten'])

    def test_overclock_reaches_cap(self):
        p = Player()
        while 'overclock' in available_upgrades(p):
            apply_to_player(p, 'overclock')
        self.assertAlmostEqual(p.fire_interval, .075)

    def test_phase_reaches_cap(self):
        p = Player()
        while 'phase' in available_upgrades(p):
            apply_to_player(p, 'phase')
        self.assertAlmostEqual(p.dash_recharge, .65)

    def test_scatter_reaches_five_and_stops(self):
        p = Player()
        for _ in range(4):
            apply_to_player(p, 'scatter')
        self.assertEqual(p.pellets, 5)
        self.assertNotIn('scatter', available_upgrades(p))
        with self.assertRaises(ValueError):
            apply_to_player(p, 'scatter')

    def test_speed_reaches_cap(self):
        p = Player()
        while 'thrusters' in available_upgrades(p):
            apply_to_player(p, 'thrusters')
        self.assertAlmostEqual(p.speed, 500)

    def test_regeneration_reaches_cap(self):
        p = Player()
        while 'capacitor' in available_upgrades(p):
            apply_to_player(p, 'capacitor')
        self.assertAlmostEqual(p.energy_regen, 32)

    def test_medkit_repairs_without_exceeding_maximum(self):
        p = Player(hp=80)
        apply_to_player(p, 'medkit')
        self.assertEqual((p.hp, p.max_hp), (100, 100))

    def test_medkit_full_hp_still_improves_ship(self):
        p = Player()
        apply_to_player(p, 'medkit')
        self.assertEqual((p.hp, p.max_hp), (110, 110))

    def test_reinforced_heals_and_grows(self):
        p = Player(hp=65)
        apply_to_player(p, 'reinforced')
        self.assertEqual((p.hp, p.max_hp), (90, 125))

    def test_tungsten_increases_damage(self):
        p = Player()
        apply_to_player(p, 'tungsten')
        self.assertEqual(p.damage, 29)

    def test_unknown_upgrade_fails_explicitly(self):
        with self.assertRaises(ValueError):
            apply_to_player(Player(), 'not-a-real-upgrade')


class GameProgressionTests(unittest.TestCase):
    def setUp(self):
        self.g = create_game()

    def test_wave_one_starts_with_correct_roster(self):
        self.assertEqual(self.g.wave, 1)
        self.assertEqual(len(self.g.pending), 8)

    def test_finish_wave_forbidden_with_pending_enemies(self):
        self.g.finish_wave()
        self.assertEqual(self.g.state, 'playing')

    def test_finish_wave_forbidden_with_live_enemies(self):
        self.g.pending.clear()
        self.g.enemies.append(Enemy('hunter', 400, 400))
        self.g.finish_wave()
        self.assertEqual(self.g.state, 'playing')

    def test_finish_wave_free_recovery_and_choices(self):
        self.g.pending.clear()
        self.g.player.hp = 50
        self.g.player.energy = 20
        self.g.finish_wave()
        self.assertEqual(self.g.state, 'upgrade')
        self.assertEqual(self.g.player.hp, 60)
        self.assertEqual(self.g.player.energy, 40)
        self.assertEqual(len(self.g.upgrades_offered), 3)

    def test_upgrade_starts_next_wave(self):
        self.g.pending.clear()
        self.g.finish_wave()
        self.g.apply_upgrade(0)
        self.assertEqual(self.g.wave, 2)
        self.assertEqual(self.g.state, 'playing')

    def test_upgrade_invalid_index_does_not_start_wave(self):
        self.g.pending.clear()
        self.g.finish_wave()
        self.g.apply_upgrade(7)
        self.assertEqual(self.g.state, 'upgrade')

    def test_pause_freezes_simulation_but_not_background(self):
        self.g.state = 'paused'
        before = self.g.elapsed
        first = self.g.global_time
        self.g.tick(1 / 30)
        self.assertEqual(self.g.elapsed, before)
        self.assertGreater(self.g.global_time, first)

    def test_gameover_disables_dashing(self):
        self.g.state = 'gameover'
        self.g.dash()
        self.assertEqual(self.g.player.dash_cd, 0)

    def test_health_regen_pickup_clamps(self):
        self.g.player.hp = 90
        self.g.pickups.append(Pickup(self.g.player.x, self.g.player.y, 'repair'))
        self.g.update_pickups(1 / 60)
        self.assertEqual(self.g.player.hp, self.g.player.max_hp)
        self.assertEqual(self.g.pickups, [])

    def test_energy_pickup_clamps(self):
        self.g.player.energy = 95
        self.g.pickups.append(Pickup(self.g.player.x, self.g.player.y, 'charge'))
        self.g.update_pickups(1 / 60)
        self.assertEqual(self.g.player.energy, 100)

    def test_combo_expires_after_timeout(self):
        self.g.pending.clear()
        self.g.combo = 7
        self.g.combo_timer = .01
        self.g.tick(1 / 30)
        self.assertEqual(self.g.combo, 0)

    def test_spawn_enemy_has_safe_initial_bounds(self):
        for kind in ('hunter', 'runner', 'gunner', 'bruiser', 'warden'):
            for _ in range(25):
                self.g.spawn_enemy(kind)
        for e in self.g.enemies:
            self.assertGreaterEqual(e.x - e.radius, ARENA_LEFT)
            self.assertLessEqual(e.x + e.radius, ARENA_RIGHT)
            self.assertGreaterEqual(e.y - e.radius, ARENA_TOP)
            self.assertLessEqual(e.y + e.radius, ARENA_BOTTOM)

    def test_enemy_spawn_keeps_away_from_player(self):
        for _ in range(10):
            self.g.spawn_enemy('hunter')
        p = self.g.player
        self.assertTrue(all((e.x - p.x)**2 + (e.y - p.y)**2 > 220**2
                            for e in self.g.enemies))

    def test_boss_has_scaled_hp(self):
        self.g.wave = 10
        self.g.spawn_enemy('warden')
        self.assertEqual(self.g.enemies[-1].hp, 950)

    def test_visual_fx_do_not_change_gameplay_rng(self):
        a, b = create_game(55), create_game(55)
        a.emit(400, 300, '#fff', 400)
        a.start_wave()
        b.start_wave()
        self.assertEqual(a.pending, b.pending)
        a.spawn_enemy('gunner')
        b.spawn_enemy('gunner')
        self.assertEqual((a.enemies[-1].x, a.enemies[-1].y),
                         (b.enemies[-1].x, b.enemies[-1].y))

    def test_idle_player_does_not_move(self):
        p = self.g.player
        x, y = p.x, p.y
        self.g.update_player(1 / 30)
        self.assertEqual((p.x, p.y), (x, y))

    def test_input_auto_repeat_does_not_unpause(self):
        event = types.SimpleNamespace(keysym='p')
        self.g.on_key_down(event)
        self.assertEqual(self.g.state, 'paused')
        self.g.on_key_up(event)
        self.g.on_key_down(event)
        self.assertEqual(self.g.state, 'paused')
        self.g.on_key_up(event)
        self.g.root.flush()
        self.g.on_key_down(event)
        self.assertEqual(self.g.state, 'playing')

    def test_focus_out_clears_keys_and_pauses(self):
        self.g.keys.update(('w', 'd'))
        self.g.mouse_down = True
        self.g.on_focus_out(None)
        self.g.root.flush()
        self.assertEqual(self.g.keys, set())
        self.assertFalse(self.g.mouse_down)
        self.assertEqual(self.g.state, 'paused')

    def test_wave_cycle_long_session_stays_three_choices(self):
        # Simulate progression beyond all five capped upgrade types.
        p = self.g.player
        p.fire_interval, p.dash_recharge, p.pellets = .075, .65, 5
        p.speed, p.energy_regen = 500, 32
        for _ in range(30):
            self.g.pending.clear()
            self.g.enemies.clear()
            self.g.finish_wave()
            self.assertEqual(len(self.g.upgrades_offered), 3)
            self.g.apply_upgrade(0)
        self.assertEqual(self.g.wave, 31)


if __name__ == '__main__':
    unittest.main()
