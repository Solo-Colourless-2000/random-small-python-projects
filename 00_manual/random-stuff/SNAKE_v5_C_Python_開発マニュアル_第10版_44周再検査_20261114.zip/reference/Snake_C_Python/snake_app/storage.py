"""Best scores per difficulty. Bad/readonly files never stop the game."""
from __future__ import annotations

from contextlib import contextmanager
import json
import os
from pathlib import Path
import sys
import tempfile

DIFFICULTIES = ("EASY", "NORMAL", "HARD")


def save_path() -> Path:
    if sys.platform == "win32":
        root = Path(os.environ.get("APPDATA") or Path.home() / "AppData" / "Roaming")
    elif sys.platform == "darwin":
        root = Path.home() / "Library" / "Application Support"
    else:
        root = Path(os.environ.get("XDG_DATA_HOME") or Path.home() / ".local" / "share")
    return root / "SnakeCPython" / "highscores.json"


def load_scores(path: Path | None = None) -> dict[str, int]:
    result = dict.fromkeys(DIFFICULTIES, 0)
    source = path if path is not None else save_path()
    try:
        if source.stat().st_size > 16_384:
            return result
        data = json.loads(source.read_text(encoding="utf-8"))
        if not isinstance(data, dict):
            return result
        for name in DIFFICULTIES:
            value = data.get(name)
            if type(value) is int and 0 <= value <= 4096:
                result[name] = value
    except (OSError, ValueError, UnicodeError, TypeError):
        pass
    return result


@contextmanager
def _score_file_lock(destination: Path):
    """Serialize read/merge/replace across running game processes.

    Lock the *stable sidecar*, never the JSON inode: os.replace() changes the
    JSON inode and would invalidate a lock on the previous file on POSIX.
    The small sidecar remains on disk so other processes can use the same lock.
    """
    lock_path = destination.with_name(destination.name + ".lock")
    with lock_path.open("a+b") as handle:
        if sys.platform == "win32":
            import msvcrt
            # msvcrt.locking locks bytes relative to the current file offset.
            # Give it a real byte to lock even for the first-ever save.
            handle.seek(0, os.SEEK_END)
            if handle.tell() == 0:
                handle.write(b"\0")
                handle.flush()
            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
            try:
                yield
            finally:
                handle.seek(0)
                msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        else:
            import fcntl
            fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
            try:
                yield
            finally:
                fcntl.flock(handle.fileno(), fcntl.LOCK_UN)


def save_scores(scores: dict[str, int], path: Path | None = None) -> bool:
    destination = path if path is not None else save_path()
    try:
        valid = {key: scores.get(key, 0) for key in DIFFICULTIES}
        if any(type(value) is not int or not 0 <= value <= 4096
               for value in valid.values()):
            return False
        destination.parent.mkdir(parents=True, exist_ok=True)
        # Atomic replacement prevents torn JSON; the lock prevents two game
        # instances from losing a higher score between read and replacement.
        with _score_file_lock(destination):
            existing = load_scores(destination)
            merged = {key: max(valid[key], existing[key]) for key in DIFFICULTIES}
            fd, filename = tempfile.mkstemp(prefix="scores_", suffix=".tmp",
                                             dir=destination.parent)
            try:
                with os.fdopen(fd, "w", encoding="utf-8") as stream:
                    json.dump(merged, stream, ensure_ascii=False, indent=2)
                    stream.write("\n")
                    stream.flush()
                    os.fsync(stream.fileno())
                os.replace(filename, destination)
            finally:
                if os.path.exists(filename):
                    os.unlink(filename)
        return True
    except (OSError, ValueError, TypeError, OverflowError):
        return False
