"""Run the standalone, standard-library-only Neon Rift action game."""
import tkinter as tk
from game import Game


def main() -> None:
    root = tk.Tk()
    Game(root)
    root.mainloop()


if __name__ == '__main__':
    main()
