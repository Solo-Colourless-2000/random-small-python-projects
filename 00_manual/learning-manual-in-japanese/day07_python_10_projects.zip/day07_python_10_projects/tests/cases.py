def ok(args, *lines):
    return args, 0, '\n'.join(lines) + '\n', ''


def bad(args, message):
    return args, 2, '', message + '\n'


CASES = {
    '01_query_pollution': [
        ok(['target=public&target=private'], 'First policy allows: True', 'Last target: private', 'Unique policy allows: False'),
        ok(['target=public'], 'First policy allows: True', 'Last target: public', 'Unique policy allows: True'),
        ok(['target=private&target=public'], 'First policy allows: False', 'Last target: public', 'Unique policy allows: False'),
        ok(['target=public&target=public&target=public&target=public'], 'First policy allows: True', 'Last target: public', 'Unique policy allows: False'),
        ok(['target=public&%74arget=private'], 'First policy allows: True', 'Last target: private', 'Unique policy allows: False'),
        bad(['target=public&target=public&target=public&target=public&target=public'], 'Invalid lab query.'),
        bad(['target='], 'Invalid lab query.'),
        bad(['target=public&'], 'Invalid lab query.'),
        bad(['target'], 'Invalid lab query.'),
        bad(['other=public'], 'Invalid lab query.'),
        bad(['x' * 101], 'Usage: script QUERY (1 to 100 ASCII characters)'),
        bad([], 'Usage: script QUERY (1 to 100 ASCII characters)'),
    ],
    '02_mass_assignment': [
        ok(['role'], 'All fields: Alicia / admin', 'Allowed fields: Alicia / reader'),
        ok(['name'], 'All fields: Alicia / reader', 'Allowed fields: Alicia / reader'),
        ok(['empty'], 'All fields: Alice / reader', 'Allowed fields: Alice / reader'),
        bad(['{}'], 'Usage: script name|role|empty'),
        bad([], 'Usage: script name|role|empty'),
    ],
    '03_regex_probe': [
        ok(['wild'], 'Pattern input: alice,admin,a.b,axb', 'Literal input: (none)'),
        ok(['literal'], 'Pattern input: alice', 'Literal input: alice'),
        ok(['dot'], 'Pattern input: a.b,axb', 'Literal input: a.b'),
        bad(['.*'], 'Usage: script literal|wild|dot'),
        bad([], 'Usage: script literal|wild|dot'),
    ],
    '04_token_replay': [
        ok(['valid'], 'Reusable: accept accept', 'Single use: accept reject'),
        ok(['wrong'], 'Reusable: reject reject', 'Single use: reject reject'),
        ok(['blank'], 'Reusable: reject reject', 'Single use: reject reject'),
        bad(['LAB-RESET-01'], 'Usage: script valid|wrong|blank'),
        bad([], 'Usage: script valid|wrong|blank'),
    ],
    '05_quantity_probe': [
        ok(['-1'], 'Upper bounds: accept, balance=23, stock=6', 'Positive quantity: reject, balance=20, stock=5'),
        ok(['1'], 'Upper bounds: accept, balance=17, stock=4', 'Positive quantity: accept, balance=17, stock=4'),
        ok(['0'], 'Upper bounds: accept, balance=20, stock=5', 'Positive quantity: reject, balance=20, stock=5'),
        ok(['5'], 'Upper bounds: accept, balance=5, stock=0', 'Positive quantity: accept, balance=5, stock=0'),
        ok(['6'], 'Upper bounds: reject, balance=20, stock=5', 'Positive quantity: reject, balance=20, stock=5'),
        ok(['-100'], 'Upper bounds: accept, balance=320, stock=105', 'Positive quantity: reject, balance=20, stock=5'),
        ok(['100'], 'Upper bounds: reject, balance=20, stock=5', 'Positive quantity: reject, balance=20, stock=5'),
        bad(['-101'], 'Out of lab range.'),
        bad(['101'], 'Out of lab range.'),
        bad(['1.5'], 'Invalid integer.'),
        bad([''], 'Invalid integer.'),
        bad(['10000'], 'Usage: script INTEGER (-100 to 100)'),
        bad([], 'Usage: script INTEGER (-100 to 100)'),
    ],
    '06_cache_poison': [
        ok(['poison'], 'Path key: variant=red', 'Variant key: variant=blue'),
        ok(['clean'], 'Path key: variant=blue', 'Variant key: variant=blue'),
        bad(['red'], 'Usage: script clean|poison'),
        bad([], 'Usage: script clean|poison'),
    ],
    '07_session_fixation': [
        ok(['login'], 'Keep ID: current=LAB-OLD, old-view=alice', 'Rotate ID: current=LAB-NEW, old-view=invalid'),
        ok(['no-login'], 'Keep ID: current=LAB-OLD, old-view=anonymous', 'Rotate ID: current=LAB-OLD, old-view=anonymous'),
        bad(['alice'], 'Usage: script login|no-login'),
        bad([], 'Usage: script login|no-login'),
    ],
    '08_pickle_inspector': [
        ok(['global'], 'Review opcodes: GLOBAL', 'Trailing bytes: False'),
        ok(['text'], 'Review opcodes: (none)', 'Trailing bytes: False'),
        ok(['trailing'], 'Review opcodes: (none)', 'Trailing bytes: True'),
        bad(['broken'], 'Invalid pickle stream.'),
        bad([], 'Usage: script text|global|trailing|broken'),
    ],
    '09_xml_expansion': [
        ok(['entity'], 'Expanded characters: 48', 'DTD policy: reject'),
        ok(['plain'], 'Expanded characters: 3', 'DTD policy: accept'),
        bad(['broken'], 'Invalid lab XML.'),
        bad([], 'Usage: script plain|entity|broken'),
    ],
    '10_template_probe': [
        ok(['nested'], 'Full context: Value DEMO-ONLY', 'Minimal context: (missing field)'),
        ok(['name'], 'Full context: Hello Alice', 'Minimal context: Hello Alice'),
        ok(['missing'], 'Full context: (missing field)', 'Minimal context: (missing field)'),
        bad(['{user[name]}'], 'Usage: script name|nested|missing'),
        bad([], 'Usage: script name|nested|missing'),
    ],
}
