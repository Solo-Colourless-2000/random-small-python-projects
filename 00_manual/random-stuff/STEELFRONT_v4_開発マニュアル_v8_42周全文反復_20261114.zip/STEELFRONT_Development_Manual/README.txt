STEELFRONT v4 ゼロから作る戦車ゲーム開発マニュアル v7

起動：STEELFRONT_開発マニュアル.html をWebブラウザで開く。
教材：104編集工程、19ファイル、実コードと文脈に即した行別解説。
文脈読解：従来の64例に17例を追加、81例。
原本：reference_sources/ にv4ソース19ファイルを収録（変更なし）。
再現：python3 replay_steps.py --output /path/to/empty_workspace
検証結果：V7_42周の検査と改訂内容.md を必ず読む。
42周とは104工程・2415行・21095要素について複数条件を繰り返した検査であり、全文を人間が42回精読したという意味ではない。
検査再現：python3 verification_tools/audit_42_rounds.py --start 1 --end 21
          python3 verification_tools/audit_42_rounds.py --start 22 --end 42
（検査スクリプトには beautifulsoup4 と lxml が必要です）
ブラウザの実機動作確認は今回実施できていません。Windows/macOS実機も未検証。
