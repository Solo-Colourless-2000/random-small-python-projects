import sys

TOKEN = "LAB-RESET-01"
CASES = {"valid": TOKEN, "wrong": "LAB-WRONG", "blank": ""}


def redeem(store, token, consume):
    if token not in store:
        return "reject"
    if consume:
        del store[token]
    return "accept"


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script valid|wrong|blank", file=sys.stderr)
        return 2
    token = CASES[sys.argv[1]]
    for consume in (False, True):
        store = {TOKEN: "alice"}
        first = redeem(store, token, consume)
        second = redeem(store, token, consume)
        label = "Single use" if consume else "Reusable"
        print(f"{label}: {first} {second}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
