"""Third review checks for manual experiments, input handling and source consistency."""
from html.parser import HTMLParser
from pathlib import Path
import re
import subprocess
import sys
import unittest

ROOT=Path(__file__).resolve().parents[1]
DOC=(ROOT/'python_10_projects_day03_manual.html').read_text(encoding='utf-8')

class Collector(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.blocks={}
        self.active=None
        self.feed(text)
    def handle_starttag(self, tag, attrs):
        key=dict(attrs).get('id')
        if tag=='code' and key:
            self.active=key
            self.blocks[key]=''
    def handle_data(self, data):
        if self.active is not None:
            self.blocks[self.active]+=data
    def handle_endtag(self,tag):
        if tag=='code': self.active=None

class ThirdReview(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.blocks=Collector(DOC).blocks

    def test_all_ten_measured_experiments(self):
        for n in range(1,11):
            with self.subTest(project=n):
                cmd=self.blocks[f'third-p{n:02d}-command'].strip()
                stdout=self.blocks[f'third-p{n:02d}-result']
                m=re.search(rf'id="third-p{n:02d}-status"[^>]*>.*?\u30b9\u30c6\u30fc\u30bf\u30b9\u306f([012])\u3067\u3059',DOC)
                self.assertIsNotNone(m)
                run=subprocess.run(['bash','-c',cmd],cwd=ROOT,capture_output=True,text=True,timeout=20)
                self.assertEqual(run.returncode,int(m.group(1)),cmd)
                self.assertEqual(run.stdout,stdout,cmd)
                self.assertEqual(run.stderr,'',cmd)

    def test_packing_list_trims_space_only(self):
        prog=ROOT/'projects/02_packing_list.py'
        for text in ('Pen',' Pen ','PEN  ','   Pen   '):
            with self.subTest(valid=repr(text)):
                p=subprocess.run([sys.executable,str(prog),text],capture_output=True,text=True,timeout=10)
                self.assertEqual((p.returncode,p.stdout),(0,'Items: 1\n1. pen\n'))
        for char in '\t\r\n\v\f\x1c\x1d\x1e\x1f\x7f':
            for text in ('Pen'+char,char+'Pen'):
                with self.subTest(invalid=repr(text)):
                    p=subprocess.run([sys.executable,str(prog),text],capture_output=True,text=True,timeout=10)
                    self.assertEqual((p.returncode,p.stdout),(2,'Error: use letters, digits or hyphens.\n'))

    def test_additions_present_for_each_project(self):
        for n in range(1,11):
            with self.subTest(project=n):
                for part in ('heading','1','2','exercise','command','result','status'):
                    self.assertIn(f'id="third-p{n:02d}-{part}"',DOC)

    def test_p02_code_matches_space_only_description(self):
        source=(ROOT/'projects/02_packing_list.py').read_text(encoding='ascii')
        self.assertIn('item.strip(" ").lower()',source)
        self.assertNotIn('item.strip().lower()',DOC)
        self.assertIn('ASCII\u30b9\u30da\u30fc\u30b9',DOC)

    def test_p05_sorted_comparison_explained(self):
        source=(ROOT/'projects/05_sorted_merge.py').read_text(encoding='ascii')
        self.assertIn('values != sorted(values)',source)
        self.assertIn('\u5143\u306evalues\u3092\u6bd4\u8f03\u3057\u3001\u5143\u304b\u3089\u6607\u9806\u3060\u3063\u305f\u304b',DOC)

    def test_sample_files_unchanged_by_experiments(self):
        before={p.name:p.read_bytes() for p in (ROOT/'samples').iterdir() if p.is_file()}
        for n in (6,7):
            cmd=self.blocks[f'third-p{n:02d}-command'].strip()
            subprocess.run(['bash','-c',cmd],cwd=ROOT,capture_output=True,text=True,timeout=20)
        after={p.name:p.read_bytes() for p in (ROOT/'samples').iterdir() if p.is_file()}
        self.assertEqual(before,after)

if __name__=='__main__':unittest.main()
