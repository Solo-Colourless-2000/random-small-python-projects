#ifndef SNAKE_CORE_H
#define SNAKE_CORE_H

#include <stdint.h>

#ifdef _WIN32
  #ifdef SNAKE_BUILD
    #define SNAKE_API __declspec(dllexport)
  #else
    #define SNAKE_API __declspec(dllimport)
  #endif
#else
  #define SNAKE_API __attribute__((visibility("default")))
#endif

#ifdef __cplusplus
extern "C" {
#endif

typedef struct SnakeGame SnakeGame;

typedef struct {
    int x;
    int y;
} SnakeCell;

typedef struct {
    int width;
    int height;
    int length;
    int food_x;
    int food_y;
    int score;
    int direction;
    int status;
} SnakeSnapshot;

enum { SNAKE_UP = 0, SNAKE_RIGHT = 1, SNAKE_DOWN = 2, SNAKE_LEFT = 3 };
enum { SNAKE_RUNNING = 0, SNAKE_LOST = 1, SNAKE_WON = 2 };
enum { SNAKE_MOVED = 0, SNAKE_ATE = 1, SNAKE_DIED = 2, SNAKE_VICTORY = 3, SNAKE_NOOP = 4 };

/* Board must be within 8..64 cells along each axis. Returns NULL on failure. */
SNAKE_API SnakeGame *snake_create(int width, int height, uint32_t seed);
SNAKE_API void snake_destroy(SnakeGame *game);
SNAKE_API void snake_reset(SnakeGame *game, uint32_t seed);
/* Queues at most two non-reversing turns. Returns 1 if accepted. */
SNAKE_API int snake_set_direction(SnakeGame *game, int direction);
/* Advances exactly one cell. Game-over states return SNAKE_NOOP. */
SNAKE_API int snake_tick(SnakeGame *game);
/* Caller supplies an array with >= length cells. Returns 1 on success. */
SNAKE_API int snake_snapshot(const SnakeGame *game, SnakeSnapshot *out,
                             SnakeCell *cells, int capacity);

#ifdef __cplusplus
}
#endif
#endif
