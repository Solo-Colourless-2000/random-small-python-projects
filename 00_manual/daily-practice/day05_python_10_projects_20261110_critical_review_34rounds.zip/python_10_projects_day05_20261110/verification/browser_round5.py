"""Author-only optional Chromium checks; learner does not need playwright."""
from pathlib import Path
from playwright.sync_api import sync_playwright
import json
ROOT=Path(__file__).resolve().parents[1]
HTML=(ROOT/'python_10_projects_day05_manual.html').read_text('utf-8')
results=[]
with sync_playwright() as play:
    browser=play.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
    for width in (1440,390,320):
        page=browser.new_page(viewport={'width':width,'height':850})
        page.set_content(HTML,wait_until='load')
        page.wait_for_timeout(150)
        chapter_count=page.locator('.chapter').count()
        assert chapter_count==20
        for n in range(1,11):
            page.evaluate('(n)=>{location.hash="#p"+String(n).padStart(2,"0")}',n)
            page.wait_for_timeout(25)
            section=page.locator(f'#p{n:02d}')
            visible=section.evaluate('(node)=>getComputedStyle(node).display!=="none"')
            assert visible, (width,n)
            box=page.locator(f'#critical-{n:02d}')
            assert box.count()==1
            assert box.locator('details').count()==3
            box.locator('details').first.locator('summary').click()
            assert box.locator('details').first.evaluate('(node)=>node.open')
            horizontal=page.evaluate('document.documentElement.scrollWidth - document.documentElement.clientWidth')
            assert horizontal<=2,(width,n,horizontal)
            results.append({'width':width,'project':n,'chapter_visible':visible,'open_details':True,'horizontal_overflow_px':horizontal})
        # Example answer is selectable without JavaScript as native details.
        page.close()
    js_off=browser.new_page(viewport={'width':320,'height':850},java_script_enabled=False)
    js_off.set_content(HTML,wait_until='load')
    shown=js_off.locator('.chapter').evaluate_all('(nodes)=>nodes.filter(x=>getComputedStyle(x).display!=="none").length')
    assert shown==20,shown
    first=js_off.locator('#critical-case-01 details.critical-answer')
    first.locator('summary').click()
    assert first.evaluate('(node)=>node.open')
    results.append({'width':320,'javascript':False,'visible_chapters':shown,'native_details':True})
    js_off.close()
    browser.close()
(ROOT/'verification/round5_browser_results.json').write_text(json.dumps({'checks':len(results),'passed':len(results),'results':results},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('BROWSER',len(results),'of',len(results),'PASS')
