"""Upgrade eligibility and application, independent of Tk or the controller."""
from __future__ import annotations

from constants import UPGRADES
from entities import Player

# Repeatedly useful options are intentional, even in a very long run.
REPEATABLE = {'tungsten', 'reinforced', 'medkit'}


def available_upgrades(player: Player) -> set[str]:
    eligible = set(REPEATABLE)
    if player.fire_interval > 0.075 + 1e-8:
        eligible.add('overclock')
    if player.dash_recharge > 0.65 + 1e-8:
        eligible.add('phase')
    if player.pellets < 5:
        eligible.add('scatter')
    if player.speed < 500 - 1e-8:
        eligible.add('thrusters')
    if player.energy_regen < 32 - 1e-8:
        eligible.add('capacitor')
    return eligible


def apply_to_player(player: Player, upgrade: str) -> None:
    """Apply precisely one upgrade; fail early for invalid or maxed upgrades."""
    if upgrade not in UPGRADES:
        raise ValueError(f'Unknown upgrade: {upgrade}')
    if upgrade not in available_upgrades(player):
        raise ValueError(f'Upgrade already at maximum: {upgrade}')
    if upgrade == 'overclock':
        player.fire_interval = max(.075, player.fire_interval * .83)
    elif upgrade == 'tungsten':
        player.damage += 7
    elif upgrade == 'reinforced':
        player.max_hp += 25
        player.hp = min(player.max_hp, player.hp + 25)
    elif upgrade == 'thrusters':
        player.speed = min(500, player.speed * 1.12)
    elif upgrade == 'scatter':
        player.pellets += 1
    elif upgrade == 'capacitor':
        player.energy_regen = min(32, player.energy_regen * 1.35)
    elif upgrade == 'medkit':
        if player.hp >= player.max_hp - 1e-8:
            player.max_hp += 10
            player.hp = player.max_hp
        else:
            player.hp = min(player.max_hp, player.hp + 55)
    elif upgrade == 'phase':
        player.dash_recharge = max(.65, player.dash_recharge * .85)
