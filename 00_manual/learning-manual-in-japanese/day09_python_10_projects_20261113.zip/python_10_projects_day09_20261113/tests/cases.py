def ok(args, *lines):
    return args, 0, '\n'.join(lines) + '\n', ''


def bad(args, message):
    return args, 2, '', message + '\n'


CASES = {
    '01_account_oracle': [
        ok(['known'], 'Detailed response: Reset message sent.', 'Uniform response: If registered, a message will be sent.'),
        ok(['absent'], 'Detailed response: Unknown account.', 'Uniform response: If registered, a message will be sent.'),
        ok(['empty'], 'Detailed response: Unknown account.', 'Uniform response: If registered, a message will be sent.'),
        bad(['alice'], 'Usage: script known|absent|empty'),
        bad([], 'Usage: script known|absent|empty'),
    ],
    '02_trace_echo': [
        ok(['token'], 'Status: 200', 'Reflected value: DEMO-ONLY'),
        ok(['bare'], 'Status: 200', 'Reflected value: (none)'),
        bad(['http://example.test'], 'Usage: script token|bare'),
        bad([], 'Usage: script token|bare'),
    ],
    '03_seed_prediction': [
        ok(['known'], 'Issued value in range: True', 'Next prediction matches: True'),
        ok(['different'], 'Issued value in range: True', 'Next prediction matches: False'),
        bad(['7'], 'Usage: script known|different'),
        bad([], 'Usage: script known|different'),
    ],
    '04_reused_xor': [
        ok(['reuse'], 'Recovered bytes: 524f4c453d41444d', 'Matches second plaintext: True'),
        ok(['separate'], 'Recovered bytes: 5f425a453d41444d', 'Matches second plaintext: False'),
        bad(['KEY'], 'Usage: script reuse|separate'),
        bad([], 'Usage: script reuse|separate'),
    ],
    '05_basic_decode': [
        ok(['normal'], 'User: alice', 'Password: DEMO'),
        ok(['colon'], 'User: alice', 'Password: DEMO:1'),
        bad(['broken'], 'Invalid lab Basic header.'),
        bad(['wrong'], 'Invalid lab Basic header.'),
        bad([], 'Usage: script normal|colon|broken|wrong'),
    ],
    '06_compression_oracle': [
        ok(['shared'], 'Equal input lengths: True', 'Matching guess is smaller: True'),
        ok(['separate'], 'Equal input lengths: True', 'Matching guess is smaller: False'),
        bad(['LABDEMO'], 'Usage: script shared|separate'),
        bad([], 'Usage: script shared|separate'),
    ],
    '07_unlinked_handle': [
        ok(['unlink'], 'Path exists: False', 'Opened handle reads: LAB-DATA'),
        ok(['keep'], 'Path exists: True', 'Opened handle reads: LAB-DATA'),
        bad(['/tmp/note.txt'], 'Usage: script unlink|keep'),
        bad([], 'Usage: script unlink|keep'),
    ],
    '08_tls_trust': [
        ok(['unchecked'], 'Certificate accepted: True', 'Payload: LAB'),
        ok(['default'], 'Certificate accepted: False', 'Payload: (none)'),
        bad(['localhost'], 'Usage: script default|unchecked'),
        bad([], 'Usage: script default|unchecked'),
    ],
    '09_range_budget': [
        ok(['repeat'], 'Independent range bytes: 24', 'Unique covered bytes: 8', 'Within one-file budget: False'),
        ok(['single'], 'Independent range bytes: 8', 'Unique covered bytes: 8', 'Within one-file budget: True'),
        ok(['edge'], 'Independent range bytes: 1', 'Unique covered bytes: 1', 'Within one-file budget: True'),
        bad(['invalid'], 'Invalid lab ranges.'),
        bad([], 'Usage: script single|repeat|edge|invalid'),
    ],
    '10_ws_mask': [
        ok(['masked'], 'Payload: LAB', 'Client mask rule: True'),
        ok(['plain'], 'Payload: LAB', 'Client mask rule: False'),
        bad(['short'], 'Invalid lab WebSocket frame.'),
        bad([], 'Usage: script masked|plain|short'),
    ],
}

for rows in CASES.values():
    usage = rows[-1][3].rstrip('\n')
    rows.extend([bad([''], usage), bad(['known', 'extra'], usage)])
