import base64
import importlib.util
import itertools
from pathlib import Path
import subprocess
import sys
import unittest

from cases import CASES

ROOT = Path(__file__).resolve().parents[1]


def load(index):
    path = sorted((ROOT / "projects").glob("*.py"))[index - 1]
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class ProjectTests(unittest.TestCase):
    def test_jwt_decode_is_not_authentication(self):
        m = load(1)
        self.assertEqual(m.decode_claims(m.HEADER + "." + m.CLAIMS["admin"] + "."), {"role": "admin"})
        for text in ("[]", "null", '{"role":true}', '{"other":"admin"}'):
            body = base64.urlsafe_b64encode(text.encode()).decode().rstrip("=")
            with self.subTest(text=text), self.assertRaises(ValueError):
                m.decode_claims(m.HEADER + "." + body + ".")
        for text in ("one", m.HEADER + ".x.signature", "other.x."):
            with self.subTest(text=text), self.assertRaises(ValueError):
                m.decode_claims(text)

    def test_expiry_sets_match_declared_boundary(self):
        m = load(2)
        accepted_weak = {n for n in range(201) if m.check_time(n)[0]}
        accepted_strict = {n for n in range(201) if m.check_time(n)[1]}
        self.assertEqual(accepted_weak, set(range(101)))
        self.assertEqual(accepted_strict, set(range(100)))
        self.assertEqual(accepted_weak - accepted_strict, {100})

    def test_effective_method_is_authorization_target(self):
        m = load(3)
        self.assertEqual(m.route("POST", "DELETE"), ("DELETE", True, False))
        self.assertEqual(m.route("DELETE", "POST"), ("POST", False, True))
        self.assertEqual(m.route("GET", ""), ("GET", False, False))
        self.assertEqual(m.route("POST", ""), ("POST", True, True))

    def test_normalization_collision_and_limits(self):
        m = load(4)
        self.assertEqual(m.inspect_name(chr(0xFF41) + "dmin"), ("admin", True, False))
        self.assertEqual(m.inspect_name("admin"), ("admin", False, False))
        self.assertEqual(m.inspect_name(""), ("", False, False))
        self.assertEqual(m.inspect_name("Admin"), ("Admin", True, True))
        self.assertNotEqual(m.inspect_name(chr(0x0430) + "dmin")[0], "admin")

    def test_json_type_and_integer_boundaries(self):
        m = load(5)
        for value, expected in [(True, (True, False)), (False, (False, False)),
                                (1, (True, True)), (3, (True, True)), (4, (False, False)),
                                (0, (False, False)), (1.0, (False, False)),
                                (None, (False, False)), ("1", (False, False))]:
            with self.subTest(value=value, type=type(value).__name__):
                self.assertEqual(m.gates(value), expected)

    def test_nan_is_not_an_ordinary_outside_value(self):
        m = load(6)
        self.assertEqual(m.gates(float("nan")), (True, False))
        for value in (float("inf"), float("-inf"), -1.0, 101.0):
            self.assertEqual(m.gates(value), (False, False))
        for value in (-0.0, 0.0, 100.0):
            self.assertEqual(m.gates(value), (True, True))

    def test_state_is_bound_to_the_correct_session(self):
        m = load(7)
        before = m.EXPECTED.copy()
        self.assertEqual(m.check_state("session-b", "STATE-A"), (True, False))
        self.assertEqual(m.check_state("session-b", "STATE-B"), (True, True))
        self.assertEqual(m.check_state("missing", "STATE-A"), (True, False))
        self.assertEqual(m.check_state("session-b", ""), (False, False))
        self.assertEqual(m.EXPECTED, before)

    def test_workflow_exhaustive_short_sequences(self):
        m = load(8)
        transitions = {("new", "pay"): "paid", ("paid", "ship"): "shipped"}
        for length in range(5):
            for events in itertools.product(("pay", "ship"), repeat=length):
                state, shipped, rejected = "new", 0, 0
                for event in events:
                    following = transitions.get((state, event))
                    if following is None:
                        rejected += 1
                    else:
                        state = following
                        if state == "shipped":
                            shipped += 1
                self.assertEqual(m.execute(events), (events.count("ship"), shipped, rejected))
                self.assertLessEqual(shipped, 1)
        self.assertEqual(m.execute(("ship", "pay", "ship")), (2, 1, 1))

    def test_control_visibility_preserves_printable_ascii(self):
        m = load(9)
        text = "".join(map(chr, range(128)))
        safe, count = m.visible(text)
        self.assertEqual(count, 33)
        self.assertTrue(all(32 <= ord(c) <= 126 for c in safe))
        printable = "".join(map(chr, range(32, 127)))
        self.assertEqual(m.visible(printable), (printable, 0))
        self.assertEqual(m.visible("A\x1b\n\x7fB"), ("A\\x1b\\x0a\\x7fB", 3))
        self.assertEqual(m.visible(""), ("", 0))

    def test_dns_cycle_offset_root_and_hop_budget(self):
        m = load(10)
        self.assertEqual(m.read_name(b"\x03lab\x00\xc0\x00", 5), "lab")
        self.assertEqual(m.read_name(b"\x00", 0), "")
        bad = [(b"", 0), (b"\xc0", 0), (b"\xc0\x00", 0),
               (b"\xc0\x02\xc0\x00", 0), (b"\xc0\xff", 0),
               (b"\x03la", 0), (b"\x40", 0), (b"\x00", -1)]
        for packet, position in bad:
            with self.subTest(packet=packet), self.assertRaises(ValueError):
                m.read_name(packet, position)
        chain = bytearray(b"\x00")
        for previous in range(0, 16, 2):
            offset = max(0, previous - 1)
            chain.extend((0xC0, offset))
        with self.assertRaisesRegex(ValueError, "Hop budget"):
            m.read_name(bytes(chain), 15)


def cli_test(name, cases):
    def test(self):
        for args, code, stdout, stderr in cases:
            with self.subTest(args=args):
                result = subprocess.run([sys.executable, str(ROOT / "projects" / (name + ".py")), *args],
                                        input="", capture_output=True, text=True, timeout=5)
                self.assertEqual((result.returncode, result.stdout, result.stderr), (code, stdout, stderr))
    return test


for name, cases in CASES.items():
    setattr(ProjectTests, "test_cli_" + name, cli_test(name, cases))
