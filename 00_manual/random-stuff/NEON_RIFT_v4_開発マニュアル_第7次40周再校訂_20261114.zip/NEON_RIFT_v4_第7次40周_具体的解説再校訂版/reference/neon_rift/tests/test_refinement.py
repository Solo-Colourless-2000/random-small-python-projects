"""Regression cases found during the thirty-plus independent v3 review passes."""
from __future__ import annotations

import json
import math
import random
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from constants import ARENA_BOTTOM, ARENA_LEFT, ARENA_RIGHT, ARENA_TOP, CYAN, RED
from entities import Bullet, Enemy, Pickup
from mechanics import moving_circle_hit
from records import load_best_record, save_best_record
from support import create_game
import game as game_module


class PickupSweepTests(unittest.TestCase):
    def setUp(self):
        self.g = create_game()
        self.g.enemies.clear()
        self.g.pending.clear()

    def test_dash_collects_pickup_between_endpoints(self):
        p = self.g.player
        p.hp = 10
        self.g.pickups = [Pickup(p.x + 80, p.y, 'repair')]
        self.g.keys = {'d'}
        self.g.dash()
        self.g.update_player(1 / 10)
        self.g.update_pickups(1 / 10)
        self.assertEqual(p.hp, 36)
        self.assertEqual(self.g.pickups, [])

    def test_distant_pickup_not_collected(self):
        p = self.g.player
        p.prev_x, p.prev_y = p.x - 120, p.y - 100
        self.g.pickups = [Pickup(p.x + 90, p.y + 100, 'charge')]
        p.energy = 20
        self.g.update_pickups(1 / 60)
        self.assertEqual(p.energy, 20)
        self.assertEqual(len(self.g.pickups), 1)

    def test_expired_pickup_removed(self):
        self.g.pickups = [Pickup(ARENA_LEFT + 4, ARENA_TOP + 4, 'repair', ttl=.01)]
        self.g.update_pickups(1 / 60)
        self.assertFalse(self.g.pickups)


class LethalShotTests(unittest.TestCase):
    def test_postmortem_hits_do_not_increase_score(self):
        g = create_game()
        g.pending.clear()
        g.enemies.clear()
        p = g.player
        p.hp = 1
        e = Enemy('hunter', 450, 320, uid=1)
        g.enemies.append(e)
        g.bullets = [
            Bullet(p.x - 20, p.y, 1000, 0, 5.8, 10, 1, False, RED),
            Bullet(430, 320, 1000, 0, 4.4, 200, 1, True, CYAN),
        ]
        g.update_bullets(1 / 30)
        self.assertEqual(g.state, 'gameover')
        self.assertFalse(e.dead)
        self.assertEqual(g.score, 0)

    def test_wave_end_does_not_step_enemy_system(self):
        g = create_game()
        g.pending.clear()
        g.enemies.clear()
        g.wave_time = 3
        g.clear_timer = .999
        calls = []
        g.update_enemies = lambda dt: calls.append(dt)
        g.tick(1 / 30)
        self.assertEqual(g.state, 'upgrade')
        self.assertFalse(calls)


class PersistenceTests(unittest.TestCase):
    def test_invalid_score_types_are_rejected(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'record.json'
            for data in ({'best': True}, {'best': 52.3}, {'best': '999'},
                         {'best': float('inf')}, {'best': None}, [], {}):
                path.write_text(json.dumps(data), encoding='utf8')
                self.assertEqual(load_best_record(path), 0, data)

    def test_negative_score_becomes_zero(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'record.json'
            path.write_text('{"best": -99}', encoding='utf8')
            self.assertEqual(load_best_record(path), 0)

    def test_save_has_no_leftover_temp_files(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'record.json'
            self.assertTrue(save_best_record(path, 1234))
            self.assertEqual(load_best_record(path), 1234)
            self.assertEqual([p.name for p in Path(folder).iterdir()], ['record.json'])

    def test_atomic_replace_failure_keeps_old_record(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'record.json'
            path.write_text('{"best": 123}', encoding='utf8')
            with patch('records.os.replace', side_effect=OSError('simulated failure')):
                self.assertFalse(save_best_record(path, 987))
            self.assertEqual(load_best_record(path), 123)
            self.assertEqual([p.name for p in Path(folder).iterdir()], ['record.json'])

    def test_save_directory_unwritable_or_missing(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'missing' / 'record.json'
            self.assertFalse(save_best_record(path, 1))


class TimingTests(unittest.TestCase):
    def test_simulation_catches_up_after_slow_render(self):
        g = create_game()
        g.renderer = types.SimpleNamespace(draw=lambda _: None)
        g._frame_debt = 0
        g.last_clock = 5
        with patch.object(game_module.time, 'perf_counter', side_effect=[5.10, 5.10]):
            g.loop()
        self.assertAlmostEqual(g.elapsed, 0.1, places=6)
        self.assertAlmostEqual(g._frame_debt, 0, delta=.00001)

    def test_large_clock_gap_is_bounded(self):
        g = create_game()
        g.renderer = types.SimpleNamespace(draw=lambda _: None)
        g.last_clock = 5
        with patch.object(game_module.time, 'perf_counter', side_effect=[125, 125]):
            g.loop()
        self.assertLessEqual(g.elapsed, .117)
        self.assertGreater(g.elapsed, 0)

    def test_negative_clock_gap_never_advances_world(self):
        g = create_game()
        g.renderer = types.SimpleNamespace(draw=lambda _: None)
        g.last_clock = 10
        with patch.object(game_module.time, 'perf_counter', side_effect=[9, 9]):
            g.loop()
        self.assertEqual(g.elapsed, 0)


class InputTests(unittest.TestCase):
    def test_leaving_canvas_releases_fire(self):
        g = create_game()
        g.mouse_down = True
        g.on_mouse_leave(None)
        self.assertFalse(g.mouse_down)

    def test_pending_focus_callback_after_close_noops(self):
        g = create_game()
        g.running = False
        g.keys = {'w'}
        g.on_focus_out(None)
        g.root.flush()
        self.assertEqual(g.keys, {'w'})

    def test_resume_discards_stale_frame_debt(self):
        g = create_game()
        g.state = 'paused'
        g._frame_debt = .11
        g.on_key_down(types.SimpleNamespace(keysym='p'))
        self.assertEqual(g.state, 'playing')
        self.assertEqual(g._frame_debt, 0)

    def test_completed_wave_persists_record(self):
        g = create_game()
        calls = []
        g.save_best = lambda: calls.append(g.score)
        g.score = 1234
        g.pending.clear()
        g.enemies.clear()
        g.finish_wave()
        self.assertEqual(calls, [1234])

    def test_numpad_selects_upgrade(self):
        g = create_game()
        g.pending.clear()
        g.finish_wave()
        self.assertEqual(g.state, 'upgrade')
        g.on_key_down(types.SimpleNamespace(keysym='KP_2'))
        self.assertEqual(g.state, 'playing')
        self.assertEqual(g.wave, 2)

    def test_corner_move_is_normalized(self):
        g = create_game()
        p = g.player
        g.keys = {'w', 'd'}
        old = p.x, p.y
        g.update_player(1 / 60)
        self.assertAlmostEqual(math.hypot(p.x - old[0], p.y - old[1]),
                               p.speed / 60, places=6)


if __name__ == '__main__':
    unittest.main()
