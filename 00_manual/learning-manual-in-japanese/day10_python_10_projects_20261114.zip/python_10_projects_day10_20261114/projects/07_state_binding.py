import sys

EXPECTED = {"session-a": "STATE-A", "session-b": "STATE-B"}
CASES = {"cross": ("session-b", "STATE-A"), "own": ("session-b", "STATE-B"), "unknown": ("session-b", "OTHER"), "empty": ("session-b", "")}


def check_state(session, supplied):
    weak = supplied in EXPECTED.values()
    strict = session in EXPECTED and supplied == EXPECTED[session]
    return weak, strict


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script cross|own|unknown|empty", file=sys.stderr)
        return 2
    session, supplied = CASES[sys.argv[1]]
    weak, strict = check_state(session, supplied)
    print(f"Any-session gate: {weak}")
    print(f"Bound-session gate: {strict}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
