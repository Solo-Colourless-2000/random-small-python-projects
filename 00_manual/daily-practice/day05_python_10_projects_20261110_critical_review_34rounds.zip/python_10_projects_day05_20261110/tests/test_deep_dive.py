"""Verify new learning sections against actual source and observed outputs."""
import json
from html import escape
import re
import subprocess
import sys
import unittest
from html.parser import HTMLParser
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
TEXT = (ROOT / 'python_10_projects_day05_manual.html').read_text(encoding='utf-8')
EXAMPLES = json.loads((ROOT / 'verification/round3_error_examples.json').read_text(encoding='utf-8'))


class DivParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.divs = []
        self.ids = set()
        self.feed(TEXT)

    def handle_starttag(self, tag, attrs):
        attr = dict(attrs)
        ident = attr.get('id', '')
        if ident:
            self.ids.add(ident)
        if tag == 'div' and 'deep-dive' in attr.get('class', '').split():
            self.divs.append(ident)


class ExpandedLessons(unittest.TestCase):
    def test_each_project_has_full_learning_sequence(self):
        parser = DivParser()
        self.assertEqual(parser.divs, ['workflow-mini'] + ['walkthrough-%02d' % n for n in range(1, 11)])
        for n in range(1, 11):
            start = TEXT.index('id="walkthrough-%02d"' % n)
            end = TEXT.index('<h3>\u521d\u51fa\u306e\u8a00\u8449', start)
            block = TEXT[start:end]
            with self.subTest(n=n):
                for phrase in ['\u5165\u529b\u304b\u3089\u51fa\u529b\u307e\u3067\u3092\u8ffd\u8de1', '\u306a\u305c\u3053\u306e\u66f8\u304d\u65b9', '\u610f\u56f3\u7684\u306a\u30a8\u30e9\u30fc',
                               '\u30a8\u30e9\u30fc\u306e\u539f\u56e0', '\u76f4\u3057\u65b9', '\u8aa4\u89e3\u3057\u3084\u3059\u3044', '\u89e3\u7b54\u30fb\u7406\u7531', '\u6b21\u306e\u7df4\u7fd2']:
                    self.assertIn(phrase, block)
                self.assertEqual(block.count('<tr>'), 6)
                self.assertIn('class="guide-quiz"', block)
                self.assertIn('\u7d42\u4e86\u30b9\u30c6\u30fc\u30bf\u30b9\uff1a2', block)

    def test_errors_are_measured_and_match_html(self):
        self.assertEqual(len(EXAMPLES), 10)
        for n, item in enumerate(EXAMPLES, 1):
            with self.subTest(n=n):
                self.assertEqual(item['number'], n)
                self.assertEqual(item['returncode'], 2)
                self.assertEqual(item['stderr'], '')
                self.assertIn(escape(item['stdout']), TEXT)
                path = ROOT / 'projects' / item['filename']
                result = subprocess.run([sys.executable, str(path), *item['args']],
                                        input=item['stdin'], text=True, capture_output=True,
                                        timeout=10, cwd=ROOT)
                self.assertEqual((result.returncode, result.stdout, result.stderr),
                                 (item['returncode'], item['stdout'], item['stderr']))

    def test_error_samples_are_intentionally_invalid(self):
        request = (ROOT / 'samples/request_no_host.txt').read_text(encoding='ascii')
        self.assertNotIn('Host:', request)
        self.assertIn('HTTP/1.1', request)
        ini = (ROOT / 'samples/filter_invalid.ini').read_text(encoding='ascii')
        self.assertIn('minimum=30', ini)
        self.assertIn('maximum=10', ini)

    def test_newton_zero_explanation_is_accurate(self):
        self.assertNotIn('0\u3092\u53cd\u5fa9\u3078\u5165\u308c\u308b\u30680\u9664\u7b97\u306b\u81f3\u308a\u5f97\u308b', TEXT)
        self.assertEqual(TEXT.count('0\u306e\u5e73\u65b9\u6839\u306f\u53b3\u5bc6\u306b0\u306a\u306e\u3067'), 2)
        self.assertIn('number=0\u306e\u5834\u5408\u306f\u5e73\u65b9\u6839\u304c\u53b3\u5bc6\u306b0', TEXT)

    def test_source_code_remains_unchanged_in_html(self):
        from test_materials import Material
        Material.setUpClass()
        obj = Material(methodName='test_sources_three_way')
        obj.test_sources_three_way()


if __name__ == '__main__':
    unittest.main()
