import io
import sys
import zipfile

CASES = {"small": b"LAB", "repeat": b"A" * 256}
LIMIT = 64


def inspect(data):
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, "w", compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr("note.txt", data)
    with zipfile.ZipFile(io.BytesIO(buffer.getvalue())) as archive:
        info = archive.getinfo("note.txt")
        allowed = info.file_size <= LIMIT
        actual = len(archive.read("note.txt")) if allowed else 0
        return info.file_size, actual, info.compress_size < info.file_size, allowed


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script small|repeat", file=sys.stderr)
        return 2
    try:
        declared, actual, smaller, allowed = inspect(CASES[sys.argv[1]])
    except (OSError, RuntimeError, zipfile.BadZipFile):
        print("ZIP experiment failed.", file=sys.stderr)
        return 1
    print(f"Declared bytes: {declared}")
    print(f"Read bytes: {actual}")
    print(f"Smaller when compressed: {smaller}")
    print(f"Metadata budget allows: {allowed}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
