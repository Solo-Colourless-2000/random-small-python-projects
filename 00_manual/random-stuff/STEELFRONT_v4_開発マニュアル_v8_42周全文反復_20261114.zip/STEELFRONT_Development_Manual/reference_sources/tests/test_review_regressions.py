"""New adversarial reviews of the refactored STEELFRONT game.

Each test is a distinct regression scenario discovered during the second review.
The original 91 tests remain untouched in their individual test files.
"""
from __future__ import annotations
import ctypes as ct
import math
from pathlib import Path
import subprocess
import sys

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from arena_config import UPGRADES, SCREEN_W, SCREEN_H
from arena_scores import MAX_RECORD, read_best, write_best
from build_engine import SOURCES, HEADERS, build, library_path
from c_bridge import Control, Snapshot, Engine
from test_engine import dll, engine, snap, step
from test_ui import app, key, mouse


def test_review_01_native_files_have_distinct_responsibilities():
    assert [src.name for src in SOURCES] == [
        'tank_engine.c', 'tank_geometry.c', 'tank_combat.c', 'tank_enemies.c']
    assert all(src.is_file() for src in (*SOURCES, *HEADERS))


def test_review_02_frontend_is_not_a_single_giant_source():
    limits = {'main.py': 320, 'arena_visual.py': 460, 'arena_effects.py': 110,
              'arena_config.py': 65, 'arena_scores.py': 75, 'c_bridge.py': 125}
    for name, limit in limits.items():
        count = len((ROOT / name).read_text().splitlines())
        assert count < limit, (name, count, limit)


def test_review_03_api_matches_native_structure(dll):
    assert dll.engine_api_version() == 4
    assert dll.engine_snapshot_size() == ct.sizeof(Snapshot)


def test_review_04_c_sources_compile_under_strict_warnings(tmp_path):
    out = tmp_path / 'review.so'
    proc = subprocess.run(['gcc', '-std=c11', '-O2', '-Wall', '-Wextra', '-Wpedantic',
            '-Werror', '-shared', '-fPIC', *map(str, SOURCES), '-lm', '-o', str(out)],
            capture_output=True, text=True)
    assert proc.returncode == 0, proc.stderr
    assert out.is_file() and out.stat().st_size > 10000


def test_review_05_nonfinite_timesteps_cannot_corrupt_world(engine):
    before = snap(engine)
    for dt in (math.nan, math.inf, -math.inf, 0.0, -1000.0):
        after = step(engine, dt=dt, fire=1)
        assert after.time == before.time
        assert after.bullet_count == before.bullet_count


def test_review_06_nonfinite_pointer_is_ignored(engine):
    for x, y in ((math.nan, 200), (600, math.inf), (-math.inf, 20)):
        before = snap(engine)
        after = step(engine, aim_x=x, aim_y=y, fire=1)
        assert after.time == before.time
        assert after.bullet_count == before.bullet_count


def test_review_07_nonfinite_movement_is_ignored(engine):
    before = snap(engine)
    after = step(engine, move_x=math.nan)
    assert (after.time, after.player.x, after.player.y) == (
        before.time, before.player.x, before.player.y)


def test_review_08_focus_has_visible_duration(engine):
    engine.engine_upgrade(10)
    assert snap(engine).focus_timer == pytest.approx(9.0)
    after = step(engine, 60)
    assert 7.9 < after.focus_timer < 8.1


def test_review_09_focus_increases_bullet_damage(engine):
    engine.engine_upgrade(10)
    after = step(engine, 1, fire=1, aim_x=800, aim_y=310)
    shots = [b for b in after.bullets if b.active and b.owner == 0]
    assert shots and shots[0].damage == pytest.approx(29 * 1.5)


def test_review_10_focus_expires_without_unsafe_underflow(engine):
    engine.engine_upgrade(10)
    after = step(engine, 610)
    assert after.focus_timer == 0
    assert after.time > 10


def test_review_11_shield_is_temporary(engine):
    engine.engine_upgrade(8)
    assert snap(engine).invulnerability == pytest.approx(6)
    after = step(engine, 370)
    assert after.invulnerability == 0


def test_review_12_score_bonus_is_exact(engine):
    for i in range(20):
        engine.engine_upgrade(9)
    assert snap(engine).score == 60000


def test_review_13_score_bonus_saturates_without_overflow(engine):
    for _ in range(34000):
        engine.engine_upgrade(9)
    after = snap(engine)
    assert after.score == 99_999_999
    engine.engine_upgrade(9)
    assert snap(engine).score == 99_999_999


def test_review_14_combat_kill_near_score_cap_is_safe(engine):
    for _ in range(33333):
        engine.engine_upgrade(9)
    engine.debug_enemy(3, 700, 310, 1)
    engine.debug_bullet(660, 310, 1500, 0, 0, 5, 0)
    after = step(engine, 3)
    assert 0 <= after.score <= 99_999_999


def test_review_15_permanent_upgrades_never_give_redundant_cards(app):
    app.new_game()
    for idx in (1,2,3,4,5,6,7):
        for _ in range(120):
            app.engine.lib.engine_upgrade(idx)
    app.engine.refresh()
    app.start_upgrade_screen()
    assert len(app.upgrade_choices) == 3
    assert len(set(app.upgrade_choices)) == 3
    assert all(i in (8,9,10) for i in app.upgrade_choices)


def test_review_16_new_module_cards_match_native_enum(app):
    assert len(UPGRADES) == 11
    app.new_game()
    app.engine.upgrade(8)
    assert app.engine.state.invulnerability > 5
    app.engine.upgrade(9)
    assert app.engine.state.score == 3000
    app.engine.upgrade(10)
    assert app.engine.state.focus_timer == 9


def test_review_17_high_score_roundtrips_atomically(tmp_path):
    path = tmp_path / '試験記録.json'
    assert write_best(path, 12345, 14)
    assert read_best(path) == (12345, 14)
    assert sorted(p.name for p in tmp_path.iterdir()) == ['試験記録.json']


def test_review_18_score_file_is_bounded_and_nonnegative(tmp_path):
    path = tmp_path / 'data.json'
    assert write_best(path, 10**25, -60)
    assert read_best(path) == (MAX_RECORD, 0)


def test_review_19_wrong_json_types_do_not_crash(tmp_path):
    path = tmp_path / 'data.json'
    for content in ('[]', 'null', '"hi"', '{"best_wave":{},"high_score":0}',
                    '{"best_wave":3,"high_score":"NaN"}'):
        path.write_text(content, encoding='utf-8')
        assert read_best(path) == (0, 0)


def test_review_20_save_failure_preserves_previous_file(monkeypatch, tmp_path):
    import arena_scores
    path = tmp_path / 'record.json'
    assert write_best(path, 77, 3)
    def fail_replace(*args):
        raise PermissionError('simulated read-only save file')
    monkeypatch.setattr(arena_scores.os, 'replace', fail_replace)
    assert not write_best(path, 990, 6)
    assert read_best(path) == (77, 3)
    assert sorted(p.name for p in tmp_path.iterdir()) == ['record.json']


def test_review_21_menu_keys_do_not_queue_combat_moves(app):
    app.key_press(key('Shift_L'))
    app.key_press(key('e'))
    assert (app.dash_queue, app.pulse_queue) == (False, False)


def test_review_22_intro_keys_do_not_queue_combat_moves(app):
    app.new_game()
    app.key_press(key('Shift_L'))
    app.key_press(key('e'))
    assert (app.dash_queue, app.pulse_queue) == (False, False)


def test_review_23_pause_discards_queued_abilities(app):
    app.new_game()
    app.screen = 'PLAYING'
    app.key_press(key('Shift_L'))
    app.key_press(key('e'))
    app.focus_lost()
    assert (app.dash_queue, app.pulse_queue) == (False, False)
    app.resume()
    assert app._input().dash == app._input().pulse == 0


def test_review_24_upgrade_discards_queued_abilities(app):
    app.new_game()
    app.screen = 'PLAYING'
    app.key_press(key('Shift_L'))
    app.key_press(key('e'))
    app.start_upgrade_screen()
    assert (app.dash_queue, app.pulse_queue) == (False, False)


def test_review_25_cover_cache_refreshes_only_when_damage_changes(app):
    app.new_game()
    app.render()
    ids_before = app.canvas.find_withtag('cover')
    app.render()
    assert app.canvas.find_withtag('cover') == ids_before
    box = next(o for o in app.engine.state.obstacles if o.active and o.kind == 1)
    box.hp -= 20  # Controlled visual snapshot, native world is unaffected.
    app.render()
    assert app.canvas.find_withtag('cover') != ids_before


def test_review_26_hud_shows_focus_active_status(app):
    app.new_game()
    app.engine.upgrade(10)
    app.render()
    hud_text = [app.canvas.itemcget(i, 'text') for i in app.canvas.find_withtag('hud')
                if app.canvas.type(i) == 'text']
    assert any('FOCUS' in t for t in hud_text)


def test_review_27_upgrade_copy_wraps_within_cards(app):
    app.new_game()
    app.screen = 'UPGRADE'
    app.upgrade_choices = [2, 4, 8]
    app.render()
    # Longest tooltips must contain line breaks by the renderer's word wrapper.
    texts = [app.canvas.itemcget(i, 'text') for i in app.canvas.find_withtag('dynamic')
             if app.canvas.type(i) == 'text']
    assert 'each second.' in texts
    assert '+7 dash energy regenerated each' not in texts


def test_review_28_all_screens_redraw_without_stale_shared_tags(app):
    app.new_game()
    for screen in ('PLAYING','PAUSED','UPGRADE','INTRO','GAMEOVER','TITLE','PLAYING'):
        if screen == 'UPGRADE':
            app.start_upgrade_screen()
        app.screen = screen
        app.render()
        all_ids = app.canvas.find_all()
        assert all_ids and len(all_ids) == len(set(all_ids))
    assert app.canvas.find_withtag('hud')


def test_review_29_fixed_timestep_caps_catchup_burst(app):
    app.new_game()
    app.screen = 'PLAYING'
    app.last_clock -= 20
    app.tick()
    assert 0 < app.engine.state.time <= 6/60 + 0.0001
    assert app.accumulator <= 0.12


def test_review_30_build_dependencies_include_every_native_unit():
    native = {x.name for x in (ROOT / 'engine').iterdir() if x.suffix in ('.c', '.h')}
    declared = {x.name for x in (*SOURCES, *HEADERS)}
    assert native == declared


def test_review_31_save_retry_after_temporary_io_failure(app, monkeypatch):
    import main
    app.new_game()
    old = main.write_best
    calls = []
    def intermittent(path, score, wave):
        calls.append((score, wave))
        if len(calls) == 1:
            return False
        return old(path, score, wave)
    monkeypatch.setattr(main, 'write_best', intermittent)
    app._store_best()
    assert app._pending_save and not app._save_path().exists()
    app._store_best()
    assert not app._pending_save
    assert read_best(app._save_path())[1] == 1
    assert len(calls) == 2


def test_review_32_extreme_wave_number_does_not_overflow(engine):
    engine.debug_wave(2_147_483_647)
    engine.engine_next_wave()
    after = snap(engine)
    # Wave counter cannot grow unbounded; it remains representable as int32.
    assert 0 <= after.wave <= 2_147_483_647
    assert 0 <= after.enemy_count <= 80


def test_review_33_canvas_has_no_unused_camera_shake_state(app):
    assert not hasattr(app, 'shake')
    app.new_game()
    app.render()
    assert app.canvas.find_withtag('static')


def test_review_34_clear_timer_transitions_into_reward_choices(app):
    import time
    app.new_game()
    app.screen = 'PLAYING'
    def simulate_empty_wave(ctrl, dt):
        app.engine.state.enemy_count = 0
    app.engine.step = simulate_empty_wave
    app.engine.state.enemy_count = 0
    for i in range(15):
        app.last_clock = time.perf_counter() - 0.099
        app.tick()
        if app.screen == 'UPGRADE':
            break
    assert app.screen == 'UPGRADE'
    assert len(app.upgrade_choices) == 3


def test_review_35_reward_to_next_combat_roundtrip(app):
    app.new_game()
    app.start_upgrade_screen()
    app.choose_upgrade(0)
    assert app.engine.state.wave == 2
    assert app.screen == 'INTRO'
    app.wave_banner = 0.01
    app.last_clock -= 0.1
    app.tick()
    assert app.screen == 'PLAYING'
