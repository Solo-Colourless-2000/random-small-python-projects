"""Guard the deliberately small dependency graph against regression."""
from __future__ import annotations

import ast
from pathlib import Path
import unittest

PROJECT = Path(__file__).resolve().parents[1]


def imported_modules(source: Path) -> set[str]:
    tree = ast.parse(source.read_text(encoding="utf-8"))
    modules = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            modules.update(alias.name for alias in node.names)
        if isinstance(node, ast.ImportFrom) and node.module:
            modules.add(node.module)
    return modules


class ArchitectureTests(unittest.TestCase):
    def test_config_remains_free_of_gui_and_native_dependencies(self) -> None:
        imports = imported_modules(PROJECT / "snake_app/config.py")
        self.assertFalse(any(x.startswith(("tkinter", "snake_app.engine", "ctypes"))
                             for x in imports))

    def test_renderer_does_not_import_controller_or_storage_write_api(self) -> None:
        imports = imported_modules(PROJECT / "snake_app/renderer.py")
        self.assertNotIn("snake_app.ui", imports)
        text = (PROJECT / "snake_app/renderer.py").read_text(encoding="utf-8")
        for dangerous in (".tick(", ".reset(", "save_scores(", "root.after("):
            self.assertNotIn(dangerous, text)

    def test_controller_has_no_canvas_drawing_implementation(self) -> None:
        controller = (PROJECT / "snake_app/ui.py").read_text(encoding="utf-8")
        for draw_call in ("create_oval(", "create_polygon(", "create_rectangle(",
                          "create_text(", "create_line("):
            self.assertNotIn(draw_call, controller)

    def test_c_public_header_does_not_expose_private_struct(self) -> None:
        public = (PROJECT / "native/snake.h").read_text(encoding="utf-8")
        private = (PROJECT / "native/snake_internal.h").read_text(encoding="utf-8")
        self.assertIn("typedef struct SnakeGame SnakeGame;", public)
        self.assertNotIn("struct SnakeGame {", public)
        self.assertIn("struct SnakeGame {", private)

    def test_build_and_tests_know_both_c_compilation_units(self) -> None:
        import build
        self.assertTrue(build.SOURCE.is_file())
        self.assertTrue(build.FOOD_SOURCE.is_file())
        self.assertTrue(build.PRIVATE_HEADER.is_file())
        self.assertTrue(build.HEADER.is_file())
        text = (PROJECT / "tests/native_checks.c").read_text(encoding="utf-8")
        self.assertIn('"../native/snake.c"', text)
        self.assertIn('"../native/food.c"', text)

    def test_no_oversized_controller_or_engine_source_file(self) -> None:
        # A review guardrail, not a universal design law.
        for source in ("native/snake.c", "native/food.c", "snake_app/ui.py",
                       "snake_app/renderer.py", "snake_app/config.py"):
            lines = (PROJECT / source).read_text(encoding="utf-8").splitlines()
            self.assertLess(len(lines), 300, source)


if __name__ == "__main__":
    unittest.main()
