import sys
from urllib.parse import urljoin, urlsplit

PUBLIC = "public.example.test"
STARTS = {"ok": "/ok", "jump": "/jump", "loop": "/loop"}
PAGES = {
    "https://public.example.test/ok": (200, "public-note"),
    "https://public.example.test/jump": (302, "//inside.example.test/info"),
    "https://inside.example.test/info": (200, "inside-note"),
    "https://public.example.test/loop": (302, "/loop"),
}


def follow(start, recheck):
    current = start
    for hop in range(4):
        if hop == 0 or recheck:
            parts = urlsplit(current)
            if (parts.scheme, parts.netloc) != ("https", PUBLIC):
                return "blocked " + current
        reply = PAGES.get(current)
        if reply is None:
            return "no fixture"
        status, data = reply
        if status == 200:
            return "read " + data
        current = urljoin(current, data)
    return "hop limit"


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in STARTS:
        print("Usage: script ok|jump|loop", file=sys.stderr)
        return 2
    start = "https://" + PUBLIC + STARTS[sys.argv[1]]
    print(f"Start only: {follow(start, False)}")
    print(f"Every hop: {follow(start, True)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
