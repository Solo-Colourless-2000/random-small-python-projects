"""Executable checks for the ten additional teaching cases (stdlib only)."""
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from html.parser import HTMLParser

ROOT = Path(__file__).resolve().parents[1]
CASES = json.loads((ROOT / 'verification/round4_lab_cases.json').read_text(encoding='utf-8'))

class TransferLab(unittest.TestCase):
    def verify(self, number):
        example = CASES[number - 1]
        self.assertEqual(example['number'], number)
        with tempfile.TemporaryDirectory() as temporary:
            base = Path(temporary)
            (base / 'practice').mkdir()
            if number == 7:
                (base / 'practice/head_request.txt').write_text(example['prepare_file'], encoding='ascii', newline='')
            cwd = base if number in (2, 7) else ROOT
            result = subprocess.run([sys.executable, str(ROOT / 'projects' / example['filename']), *example['args']],
                                    input=example['stdin'], text=True, capture_output=True, cwd=cwd, timeout=10)
            self.assertEqual((result.returncode, result.stdout, result.stderr),
                             (example['status'], example['stdout'], example['stderr']))
            if number == 2:
                self.assertEqual((base / 'practice/card_further.html').read_text(encoding='utf-8'), example['saved_html'])

    def test_01_leading_zero(self): self.verify(1)
    def test_02_escape_and_file(self): self.verify(2)
    def test_03_width_one(self): self.verify(3)
    def test_04_ongoing_board(self): self.verify(4)
    def test_05_duplicate_sort(self): self.verify(5)
    def test_06_undo_previous(self): self.verify(6)
    def test_07_head_request(self): self.verify(7)
    def test_08_empty_filter(self): self.verify(8)
    def test_09_zero_root(self): self.verify(9)
    def test_10_probability_rounding(self): self.verify(10)

    def test_12_new_labs_are_searchable(self):
        html = (ROOT / 'python_10_projects_day05_manual.html').read_text(encoding='utf-8')
        for n in range(1, 11):
            with self.subTest(project=n):
                self.assertIn(f'class="transfer-lab" data-search="" id="transfer-{n:02d}"', html)

    def test_11_manual_has_matching_outputs_and_answers(self):
        html = (ROOT / 'python_10_projects_day05_manual.html').read_text(encoding='utf-8')
        class Codes(HTMLParser):
            def __init__(self):
                super().__init__(convert_charrefs=True)
                self.current = None
                self.outputs = {}
                self.in_lab = None
                self.in_code = False
                self.code = ''
            def handle_starttag(self, tag, attrs):
                d = dict(attrs)
                if tag == 'div' and 'transfer-lab' in d.get('class', '').split():
                    self.in_lab = d.get('id')
                    self.outputs[self.in_lab] = []
                if tag == 'code' and self.in_lab:
                    self.in_code = True
                    self.code = ''
            def handle_data(self, data):
                if self.in_code: self.code += data
            def handle_endtag(self, tag):
                if tag == 'code' and self.in_code:
                    self.outputs[self.in_lab].append(self.code)
                    self.in_code = False
                if tag == 'div' and self.in_lab:
                    # There are no nested div elements inside transfer-lab.
                    self.in_lab = None
        parser = Codes()
        parser.feed(html)
        self.assertEqual(len(parser.outputs), 10)
        for n, example in enumerate(CASES, 1):
            with self.subTest(project=n):
                data = parser.outputs[f'transfer-{n:02d}']
                self.assertIn(example['stdout'], data)
                if example['saved_html']: self.assertIn(example['saved_html'], data)
                self.assertTrue(any(example['filename'] in line for line in data))
                self.assertEqual(example['status'], 0)

if __name__ == '__main__':
    unittest.main()
