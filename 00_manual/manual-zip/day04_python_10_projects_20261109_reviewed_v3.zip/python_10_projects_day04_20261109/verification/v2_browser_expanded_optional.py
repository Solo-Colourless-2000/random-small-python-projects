from pathlib import Path
from playwright.sync_api import sync_playwright
import json
root=Path(__file__).resolve().parents[1]
html=(root/'python_10_projects_day04_manual.html').read_text()
records=[]
with sync_playwright() as p:
 b=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 for w in (320,390,1440):
  page=b.new_page(viewport={'width':w,'height':650});page.set_content(html)
  for n in range(1,11):
   target=f'p{n:02d}'
   page.evaluate('(id) => {location.hash="#"+id}',target)
   page.wait_for_function('(id) => document.querySelector(".chapter.active")?.id === id',arg=target)
   page.locator(f'#{target} details').evaluate_all('(els) => els.forEach(e=>e.open=true)')
   page.wait_for_timeout(60)
   data=page.evaluate('''() => {let c=document.querySelector('.chapter.active');return {width:innerWidth,doc:document.documentElement.scrollWidth,chapter:c.id,outside:[...c.querySelectorAll('pre,.codebox,.table-wrap,table,.step,.precision-notes,.deep-dive')].filter(e=>e.getClientRects().length).filter(e=>{let r=e.getBoundingClientRect();return r.right >innerWidth+1 || r.left< -1}).length,hidden_scroll_codes:[...c.querySelectorAll('.codebox')].filter(e=>{let pre=e.querySelector('pre');return pre&&pre.scrollWidth>pre.clientWidth+3&&!e.querySelector('.scroll-hint:not([hidden])')}).length}}''')
   data['pass']=data['doc']<=data['width'] and not data['outside'] and not data['hidden_scroll_codes']
   records.append(data)
  if w==320:
   page.evaluate("location.hash='#p08'")
   page.wait_for_function("document.querySelector('.chapter.active')?.id === 'p08'")
   for _ in range(5):page.locator('#larger').click()
   page.locator('#wrap').click()
   page.wait_for_timeout(150)
   res=page.evaluate('''() => ({width:innerWidth,doc:document.documentElement.scrollWidth,size:document.documentElement.style.getPropertyValue('--scale'),wrap:document.body.classList.contains('wrap')})''')
   res['pass']=res['width']==res['doc'] and res['wrap'] and float(res['size'])>=1.24
   records.append({'case':'maximum font size and wrap',**res})
  page.close()
 # JS disabled on 320: all 20 chapters visible and scrollable
 ctx=b.new_context(viewport={'width':320,'height':650},java_script_enabled=False)
 page=ctx.new_page();page.set_content(html)
 nojs=page.evaluate('''() => ({chapters:document.querySelectorAll('.chapter').length, visible:[...document.querySelectorAll('.chapter')].filter(x=>getComputedStyle(x).display!=='none').length,doc:document.documentElement.scrollWidth,width:innerWidth})''')
 nojs['pass']=nojs['chapters']==nojs['visible']==20 and nojs['doc']==nojs['width']
 records.append({'case':'JS disabled 320px',**nojs})
 page.close();ctx.close();b.close()
(root/'verification/v2_browser_expanded.json').write_text(json.dumps({'checks':records,'success':all(r['pass'] for r in records),'count':len(records)},indent=2,ensure_ascii=False))
print('expanded browser checks',len(records),'pass',sum(r['pass'] for r in records),'failures:')
for r in records:
 if not r['pass']:print(r)
if not all(r['pass'] for r in records):raise SystemExit(1)
