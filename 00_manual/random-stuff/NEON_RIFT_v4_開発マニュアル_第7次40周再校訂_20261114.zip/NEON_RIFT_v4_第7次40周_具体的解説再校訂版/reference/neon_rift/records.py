"""Crash-resistant, dependency-free high score storage.

Keep persistence separate from the frame loop.  An interrupted save should not
truncate the previous record; storage failures must not interrupt gameplay.
"""
from __future__ import annotations

import json
import os
from pathlib import Path
import tempfile


def load_best_record(path: Path) -> int:
    """Return a non-negative integer score, ignoring malformed records."""
    try:
        value = json.loads(path.read_text(encoding='utf-8'))['best']
        # Reject bool, floats (including Infinity), strings and nested data.
        if type(value) is not int:
            return 0
        return max(0, value)
    except (FileNotFoundError, OSError, ValueError, TypeError, KeyError, OverflowError):
        return 0


def save_best_record(path: Path, score: int) -> bool:
    """Write atomically via a sibling temporary file. Return False on I/O error."""
    if type(score) is not int or score < 0:
        return False
    temporary: Path | None = None
    try:
        with tempfile.NamedTemporaryFile(
            mode='w', encoding='utf-8', dir=path.parent,
            prefix=f'.{path.name}.', suffix='.tmp', delete=False,
        ) as stream:
            temporary = Path(stream.name)
            json.dump({'best': int(score)}, stream)
            stream.write('\n')
            stream.flush()
            os.fsync(stream.fileno())
        os.replace(temporary, path)
        return True
    except (OSError, ValueError, TypeError):
        return False
    finally:
        if temporary is not None:
            try:
                temporary.unlink(missing_ok=True)
            except OSError:
                pass
