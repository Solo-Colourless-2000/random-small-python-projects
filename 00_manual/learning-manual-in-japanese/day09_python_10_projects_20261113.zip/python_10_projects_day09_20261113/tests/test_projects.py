import base64
import contextlib
import importlib.util
import io
from pathlib import Path
import random
import subprocess
import sys
import tempfile
import threading
import unittest
from unittest.mock import patch

from cases import CASES

ROOT = Path(__file__).resolve().parents[1]


def load(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / 'projects' / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class ProjectTests(unittest.TestCase):
    def check_cases(self, name):
        for args, code, stdout, stderr in CASES[name]:
            with self.subTest(args=args):
                r = subprocess.run([sys.executable, str(ROOT / 'projects' / (name + '.py')), *args],
                                   cwd=ROOT, stdin=subprocess.DEVNULL, capture_output=True,
                                   text=True, encoding='ascii', timeout=10)
                self.assertEqual((r.returncode, r.stdout, r.stderr), (code, stdout, stderr))

    def test_01_account(self):
        self.check_cases('01_account_oracle')

    def test_02_trace(self):
        self.check_cases('02_trace_echo')

    def test_03_random(self):
        self.check_cases('03_seed_prediction')

    def test_04_xor(self):
        self.check_cases('04_reused_xor')

    def test_05_basic(self):
        self.check_cases('05_basic_decode')

    def test_06_compression(self):
        self.check_cases('06_compression_oracle')

    def test_07_handle(self):
        self.check_cases('07_unlinked_handle')

    def test_08_tls(self):
        self.check_cases('08_tls_trust')

    def test_09_ranges(self):
        self.check_cases('09_range_budget')

    def test_10_ws(self):
        self.check_cases('10_ws_mask')

    def test_account_response_has_one_uniform_result(self):
        lab = load('01_account_oracle')
        values = {lab.respond(value, True) for value in ('alice', 'bob', 'carol', '')}
        self.assertEqual(values, {'If registered, a message will be sent.'})
        self.assertNotEqual(lab.respond('alice', False), lab.respond('carol', False))

    def test_seed_prediction_after_several_steps(self):
        for seed in (0, 7, 99):
            issuer = random.Random(seed)
            observer = random.Random(seed)
            self.assertEqual([issuer.randrange(1000000) for _ in range(8)],
                             [observer.randrange(1000000) for _ in range(8)])

    def test_xor_cancellation_and_length_mismatch(self):
        lab = load('04_reused_xor')
        for value in (b'', b'LAB', bytes(range(256))):
            zeros = bytes(len(value))
            self.assertEqual(lab.xor(value, value), zeros)
            self.assertEqual(lab.xor(value, zeros), value)
        with self.assertRaises(ValueError):
            lab.xor(b'LAB', b'L')

    def test_basic_colon_and_invalid_inputs(self):
        lab = load('05_basic_decode')
        value = base64.b64encode(b'alice:a:b:c').decode('ascii')
        self.assertEqual(lab.decode('Basic ' + value), ('alice', 'a:b:c'))
        for value in ('Basic YWxpY2U=', 'Basic ???', 'Basic', 'Bearer LAB'):
            with self.assertRaises(ValueError):
                lab.decode(value)

    def test_compression_input_lengths_and_directions(self):
        lab = load('06_compression_oracle')
        self.assertEqual(len(lab.GUESSES[0]), len(lab.GUESSES[1]))
        shared = lab.sizes(True)
        self.assertLess(shared[0], shared[1])
        separate = lab.sizes(False)
        self.assertGreaterEqual(separate[0], separate[1])

    def test_unlinked_temporary_directory_is_removed(self):
        lab = load('07_unlinked_handle')
        locations = []

        @contextlib.contextmanager
        def track_directory():
            with tempfile.TemporaryDirectory() as folder:
                locations.append(Path(folder))
                yield folder

        with patch.object(lab, 'TemporaryDirectory', track_directory):
            self.assertEqual(lab.observe(True), (False, 'LAB-DATA'))
        self.assertTrue(all(not path.exists() for path in locations))

    def test_tls_and_http_threads_finish(self):
        before = set(threading.enumerate())
        trace = load('02_trace_echo')
        tls = load('08_tls_trust')
        self.assertEqual(trace.probe(True), (200, 'DEMO-ONLY'))
        self.assertEqual(tls.probe(False), (False, '(none)'))
        self.assertEqual(tls.probe(True), (True, 'LAB'))
        self.assertEqual(set(threading.enumerate()), before)

    def test_io_failures_are_not_observation_success(self):
        for name, argument, function in [
            ('02_trace_echo', 'bare', 'probe'),
            ('07_unlinked_handle', 'keep', 'observe'),
            ('08_tls_trust', 'default', 'probe'),
        ]:
            lab = load(name)
            with patch.object(sys, 'argv', ['script', argument]):
                with patch.object(lab, function, side_effect=OSError):
                    with contextlib.redirect_stderr(io.StringIO()):
                        self.assertEqual(lab.main(), 1)

    def test_range_overlaps_and_invalid_boundaries(self):
        lab = load('09_range_budget')
        self.assertEqual(lab.measure('bytes=0-3,2-5'), (8, 6))
        self.assertEqual(lab.measure('bytes=0-0'), (1, 1))
        for header in ('bytes=0-8', 'bytes=7-6', 'bytes=-1-2', 'items=0-1'):
            with self.assertRaises(ValueError):
                lab.measure(header)

    def test_ws_mask_reverses_all_four_key_positions(self):
        lab = load('10_ws_mask')
        payload = b'ABCDEFGH'
        key = b'\x01\x02\x03\x04'
        encoded = bytes([64, 64, 64, 64, 68, 68, 68, 76])
        frame = bytes([0x81, 0x88]) + key + encoded
        self.assertEqual(lab.inspect(frame), ('ABCDEFGH', True))
        for frame in (b'', b'\x81', b'\x82\x00', b'\x81\x15' + b'A' * 21):
            with self.assertRaises(ValueError):
                lab.inspect(frame)
