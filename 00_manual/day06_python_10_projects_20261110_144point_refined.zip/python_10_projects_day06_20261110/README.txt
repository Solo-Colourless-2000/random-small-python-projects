Python ペネトレーションテスト実習 day06 | 第4次改訂版
作成日：2026-11-10 JST
配布ZIP: day06_python_10_projects_20261110_144point_refined.zip

【最初の手順】
1. ZIPを展開して python_10_projects_day06_20261110/ に移動する。
2. python_10_projects_day06_manual.html をブラウザーで開き、02「本書の使い方」へ進む。
3. Python 3.10以上、vimまたはnvimがあれば標準ライブラリだけで全10作品を実行可能。
4. すでに存在する完成版は projects/、自分で入力するファイルは practice/ に分ける。
5. 同じファイルへSTEP 01〜04を順番に入力し、保存後に実行する。

【端末での例】
unzip day06_python_10_projects_20261110_144point_refined.zip
cd python_10_projects_day06_20261110
python3 --version
pwd
ls
mkdir -p practice
vim practice/01_traversal.py
python3 practice/01_traversal.py /public/notes

Vimでは i で入力開始、Esc → :wq → Enter で保存・終了。
字下げは半角スペース4つを基準にする。Neovimなら vim を nvim に変更する。
途中のSTEP 01〜03は未完成でも異常ではない。STEP 04まで追記して確認する。

【完成版を動かす10例】
python3 projects/01_traversal.py /public/%252e%252e/private/notes
python3 projects/02_sql_probe.py probe
python3 projects/03_object_access.py alice 102
python3 projects/04_origin_policy.py https://trap-app.example.test
python3 projects/05_redirect_scope.py jump
python3 projects/06_upload_probe.py fake
python3 projects/07_token_tamper.py altered
python3 projects/08_limit_buckets.py rotate
python3 projects/09_compare_oracle.py 4800
python3 projects/10_banner_probe.py lab

Project 06は __file__ から samples/ を探す。projects/またはpractice/にソースが
ある限り、実行時の現在地（pwd）が別の場所でも同梱データを読める。
Project 10だけは127.0.0.1のIPv4 TCP接続を作る。リモート宛の指定はできない。
残りは固定データか同梱サンプルを使う。実ファイルを改変する作品はない。

【終了値と確認】
0：実験を実行し結果を観測できた（False、403、拒否も含む）。
2：引数が不足・過剰、または許可されない値。
1：Project 06のI/O失敗、Project 10のTCP試験失敗・不完全なバナー。
実行の直後に echo $? で確認できる（bash/zsh）。

python3 -m unittest discover -s tests -v
python3 verification/audit_36_rounds.py
python3 verification/audit_additional_36.py
python3 verification/audit_third_36.py
python3 verification/audit_fourth_36.py

テストは主にprojects/の完成版を対象とする。practice/へ入力した内容が
正しいかは、同じ引数で自分で実行してから diff -u で比較する。
検証環境、実測値、検証不能な範囲はREVIEW_REPORT.txtとverification/を参照。
ブラウザーの保存機能はブラウザーの設定・開き方に依存する。

【学習時間】
基本10作品の目安250分。準備と休憩の時間、追加の3例×10作品は別。
実際の時間は学習経験で変わる。次回はday07。
