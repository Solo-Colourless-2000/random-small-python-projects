#!/usr/bin/env python3
"""Repeated full-manual multi-axis audit. Automated coverage != human close reading.
Requires lxml in the audit environment. Each round inspects ALL 104 steps, 2415 source lines,
21095 element descriptions, 19 source files and 25 newly curated examples.
"""
import argparse,ast,hashlib,json,re,sys
from pathlib import Path
from lxml import html
ap=argparse.ArgumentParser();ap.add_argument('--start',type=int,required=True);ap.add_argument('--end',type=int,required=True)
a=ap.parse_args();assert 1<=a.start<=a.end<=42
root=Path(__file__).resolve().parent.parent;blob=(root/'STEELFRONT_開発マニュアル.html').read_bytes();dom=html.fromstring(blob)
manifest=json.loads((root/'STEP_MANIFEST.json').read_text());ref={k:(root/'reference_sources'/k).read_text().splitlines() for k in manifest['files']}
sha={k:hashlib.sha256((root/'reference_sources'/k).read_bytes()).hexdigest() for k in ref}
by_class=lambda node,tag,klass:node.xpath(f'.//{tag}[contains(concat(" ",normalize-space(@class)," ")," {klass} ")]')
get_text=lambda node:'' if node is None else node.text_content().strip()
steps=[]
for i,art in enumerate(by_class(dom,'article','lesson-step')):
 info=manifest['steps'][i];frag=(root/info['fragment']).read_bytes();code=by_class(art,'code','source-lines')
 rows=[]
 for li in by_class(art,'ol','line-by-line')[0].xpath('./li'):
  anchor=by_class(li,'div','line-anchor')[0];meaning=by_class(li,'p','line-meaning')[0];meancode=meaning.xpath('./code')
  tokens=[]
  for el in by_class(li,'span','element'):
   c=el.xpath('./code');d=by_class(el,'span','element-description')
   tokens.append((get_text(c[0]) if c else '',get_text(d[0]) if d else ''))
  rows.append((get_text(anchor.xpath('./code')[0]),get_text(meancode[0]) if meancode else '',get_text(meaning),tokens))
 steps.append((info,art.get('id'),frag,code[0].text_content().encode('utf-8') if code else b'',rows,
    bool(by_class(art,'label','step-check')),bool(by_class(art,'div','contextual-note')),bool(by_class(art,'div','lesson-field'))))
guides=[]
for art in by_class(dom,'article','v8-guided-case'):
 pt=art.xpath('./p')[0].text_content(); m=re.search(r'原本：(.+?) L(\d+)',pt)
 c=art.xpath('./pre/code');dl=by_class(art,'dl','v8-terms')
 guides.append((art.get('id'),m.group(1) if m else None,int(m.group(2)) if m else -1,c[0].text_content() if c else '',
                len(dl[0].xpath('./dt')) if dl else 0,bool(by_class(art,'p','v8-worked')),bool(by_class(art,'p','v8-checkpoint'))))
ids={x.get('id') for x in dom.xpath('//*[@id]')};links=[x.get('href')[1:] for x in dom.xpath('//a[starts-with(@href,"#")]')]
focus=['言語差','変数名と関数スコープ','ABI','数値','入力の順番','時間更新','幾何','テスト','描画座標','作業手順','実名の意味','出典','UI導線','例外','追記工程','定型文','学習者の操作','原本一致','全要素','誤解対策']
log=[];any_errors=[]
for nr in range(a.start,a.end+1):
 errors=[];linecount=0;tokencount=0
 for off in range(len(steps)):
  info,id_,frag,shown,rows,checkbox,note,lesson=steps[(off+nr*17)%len(steps)]
  if id_!=f'step-{info["id"]:03d}':errors.append(f'wrong step id {info["id"]}')
  if frag!=shown:errors.append(f'HTML fragment differs step {info["id"]}')
  if frag.decode()!='\n'.join(ref[info['path']][info['start']-1:info['end']])+'\n':errors.append(f'fragment/source differs step {info["id"]}')
  if hashlib.sha256(frag).hexdigest()!=info['sha256']:errors.append(f'fragment hash step {info["id"]}')
  if not (checkbox and note and lesson):errors.append(f'editing guidance step {info["id"]}')
  if len(rows)!=sum(bool(x.strip()) for x in ref[info['path']][info['start']-1:info['end']]):errors.append(f'line count step {info["id"]}')
  ordered=rows if nr%2 else reversed(rows)
  for literal,locator,meaning,parts in ordered:
   linecount+=1;file,sep,n=locator.rpartition(':')
   if not sep or not n.isdigit() or file!=info['path'] or not info['start']<=int(n)<=info['end']:
    errors.append(f'invalid line ref {locator}');continue
   no=int(n);real=ref[file][no-1].strip()
   if literal!=real:errors.append(f'annotation has wrong source {locator}')
   if len(meaning)<45 or 'この行の命令・値を、下の' in meaning or 'このスコープの変数' in meaning:errors.append(f'weak line meaning {locator}')
   if file.endswith('.py') and not meaning.startswith('Python・'):errors.append(f'wrong language {locator}')
   if file.endswith(('.h','.c')) and not meaning.startswith('C・'):errors.append(f'wrong C label {locator}')
   if file.endswith('.bat') and not meaning.startswith('Windowsバッチ・'):errors.append(f'wrong batch label {locator}')
   if not parts:errors.append(f'no element breakdown {locator}')
   for word,expl in parts:
    tokencount+=1
    if not word or len(expl)<13:errors.append(f'vague element {locator} {word}')
    if word=='#' and file.endswith(('.c','.h')) and 'プリプロセッサ' not in expl:errors.append(f'wrong C # {locator}')
    if word=='annotations' and real.startswith('from __future__') and '文字列' not in expl:errors.append(f'wrong annotations {locator}')
    if word=='__future__' and '標準モジュール' not in expl:errors.append(f'wrong future module {locator}')
    if word=='->' and file.endswith('.py') and not ('型アノテーション' in expl or '戻り値' in expl):errors.append(f'Python type arrow {locator}')
    if word=='as' and real.startswith('except') and '例外' not in expl:errors.append(f'except as mistaken {locator}')
    if word in ('print','file') and 'file=sys.stderr' in real and '標準エラー' not in expl:errors.append(f'stderr mistaken {locator}')
    if word==':' and file.endswith(('.c','.h')) and '?' in real and '条件演算子' not in expl:errors.append(f'C ternary mistaken {locator}')
    if word in 'ltrb' and len(word)==1 and ('self.card_bounds' in real or 'l<=mx<=r' in real or 'l<=x<=r' in real):
     if {'l':'左','t':'上','r':'右','b':'下'}[word] not in expl:errors.append(f'rectangle role mistaken {locator} {word}')
    if word=='b' and file=='engine/tank_combat.c' and 'b->' in real and not ('Bullet' in expl or '弾' in expl):errors.append(f'bullet role mistaken {locator}')
   # Editorial regression canaries added after manual source-based review.
   if file=='engine/tank_geometry.c' and real.lstrip().startswith(('*x=', '*y=', '*x+=', '*y+=', '*hit_t=')) and '実行されないコメント' in meaning:errors.append(f'pointer dereference called a comment {locator}')
   if file=='engine/engine_internal.h' and real.startswith('extern ') and '初期化している' in meaning:errors.append(f'extern mistaken for initialization {locator}')
   if file=='engine/tank_engine.h' and real.strip().startswith(('float ', 'int ')) and no in (30,34,35,39,40,44,45,49,50,54,55,59,60,61,62,69) and '宣言・初期化' in meaning:errors.append(f'struct field mistaken for initialization {locator}')
   if file=='engine/tank_engine.c' and no==12 and ('累乗' not in meaning or 'XOR' not in meaning):errors.append(f'xorshift unexplained {locator}')
   if file=='main.py' and no==294 and '標準エラー' not in meaning:errors.append('main.py stderr line wrong')
   if file=='main.py' and no==279 and 'マウス' not in meaning:errors.append('main.py hover mouse wrong')
   if file=='engine/tank_combat.c' and no==38 and 'フラグ' not in meaning:errors.append('remaining_enemies flag wrong')
 if linecount!=2415:errors.append(f'expected 2415 lines got {linecount}')
 if tokencount!=21095:errors.append(f'expected 21095 tokens got {tokencount}')
 for file,digest in sha.items():
  if manifest['files'][file]['sha256']!=digest:errors.append(f'file hash changed {file}')
  if file.endswith('.py'):
   try:ast.parse('\n'.join(ref[file]),filename=file)
   except SyntaxError:errors.append(f'bad Python source {file}')
 if any(link not in ids for link in links if link):errors.append('broken chapter links')
 if len(by_class(dom,'section','manual-section'))!=len(by_class(dom,'button','toc-item')):errors.append('navigation count mismatch')
 if len(guides)!=25:errors.append('v8 manual example count')
 for id_,f,n,excerpt,count,has_work,has_check in guides:
  if f not in ref or not 1<=n<=len(ref[f]) or excerpt.strip()!=ref[f][n-1].strip():errors.append(f'guide source mismatch {id_}')
  if count<3 or not has_work or not has_check:errors.append(f'guide detail missing {id_}')
 if not dom.xpath('//meta[@name="viewport"]') or not dom.xpath('//script') or not dom.xpath('//style'):errors.append('HTML main structure')
 samples=[]
 for k in range(8):
  st=steps[(nr*13+k*29)%104];row=st[4][(nr*5+k*7)%len(st[4])]
  samples.append({'source':row[1],'code':row[0],'explanation':row[2][:320]})
 log.append({'round':nr,'steps_checked':104,'lines_checked':linecount,'components_checked':tokencount,
    'source_files_checked':19,'guides_checked':25,'links_checked':len(links),
    'axes_checked_each_round':['code byte comparison','source references','explanation presence','C/Python syntax differences','contextual variable roles','imports and function types','time and math canaries','full element descriptions','editing instructions','tutorial code examples','chapter navigation','original digests'],
    'extra_focus_for_spot_review':focus[(nr-1)%len(focus)],'sample_rows_for_human_review':samples,'issues':errors,'pass':not errors})
 any_errors.extend(errors)
out=root/f'V8_REVIEW_ROUNDS_{a.start:02d}_{a.end:02d}.json';out.write_text(json.dumps({'html_sha256':hashlib.sha256(blob).hexdigest(),
 'scope_note':'Automated repeated complete checks, NOT 42 human full-text rereads','rounds':log},ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'rounds':len(log),'lines_in_each':linecount,'components_in_each':tokencount,'errors':len(any_errors),'examples':any_errors[:15]},ensure_ascii=False))
if any_errors:sys.exit(2)
