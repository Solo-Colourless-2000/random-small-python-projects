"""Full gameplay campaign with real food, growth, and victory (not mocked)."""
from __future__ import annotations

import unittest

from snake_app.engine import Direction, Event, SnakeEngine, Status


class VictoryCampaignTests(unittest.TestCase):
    def test_sixty_complete_victories_on_eight_by_eight(self) -> None:
        width = height = 8
        # One Hamiltonian cycle through every cell, safely visiting food until
        # all 64 squares have been filled by an organically grown snake.
        route = [(x, 0) for x in range(width)]
        for y in range(1, height):
            columns = range(width - 1, 0, -1) if y % 2 else range(1, width)
            route.extend((x, y) for x in columns)
        route.extend((0, y) for y in range(height - 1, 0, -1))
        order = {cell: n for n, cell in enumerate(route)}
        turns = {(0, -1): Direction.UP, (1, 0): Direction.RIGHT,
                 (0, 1): Direction.DOWN, (-1, 0): Direction.LEFT}
        victories = 0
        total_steps = 0
        with SnakeEngine(width, height, seed=1) as engine:
            for seed in range(1001, 1061):
                engine.reset(seed=seed)
                for _ in range(18000):
                    head = engine.snapshot().body[0]
                    target = route[(order[head] + 1) % 64]
                    direction = turns[(target[0] - head[0], target[1] - head[1])]
                    engine.turn(direction)
                    event = engine.tick()
                    total_steps += 1
                    self.assertNotEqual(event, Event.DIED, f"seed={seed}")
                    if event == Event.VICTORY:
                        result = engine.snapshot()
                        self.assertEqual(result.score, 60)
                        self.assertEqual(len(result.body), 64)
                        self.assertEqual(result.status, Status.WON)
                        self.assertIsNone(result.food)
                        victories += 1
                        break
                else:
                    self.fail(f"seed {seed}: no victory within 18000 moves")
        self.assertEqual(victories, 60)
        self.assertGreater(total_steps, 30000)


if __name__ == "__main__":
    unittest.main()
