import sys
from pathlib import Path
from tempfile import TemporaryDirectory


def probe(name):
    with TemporaryDirectory() as folder:
        root = Path(folder)
        public = root / "public"
        public.mkdir()
        (public / "note").write_text("PUBLIC", encoding="ascii")
        (root / "private").write_text("PRIVATE", encoding="ascii")
        (public / "alias").symlink_to(root / "private")
        target = public / ("alias" if name == "linked" else "note")
        weak = target.read_text(encoding="ascii")
        resolved = target.resolve(strict=True)
        inside = resolved.is_relative_to(public.resolve())
        checked = resolved.read_text(encoding="ascii") if inside else "BLOCKED"
        return weak, checked


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ("normal", "linked"):
        print("Usage: script normal|linked", file=sys.stderr)
        return 2
    try:
        weak, checked = probe(sys.argv[1])
    except OSError:
        print("Temporary filesystem experiment failed.", file=sys.stderr)
        return 1
    print(f"Path location only: {weak}")
    print(f"Resolved scope: {checked}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
