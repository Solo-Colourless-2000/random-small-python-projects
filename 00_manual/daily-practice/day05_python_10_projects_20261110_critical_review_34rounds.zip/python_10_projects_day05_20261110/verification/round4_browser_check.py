from pathlib import Path
import json
from playwright.sync_api import sync_playwright

ROOT = Path(__file__).resolve().parents[1]
CONTENT=(ROOT/'python_10_projects_day05_manual.html').read_text(encoding='utf-8')
ids=['cover','usage','setup','basics','schedule']+[f'p{i:02d}' for i in range(1,11)]+['trouble','glossary','references','appendix-a','appendix-b']
rows=[]
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True, executable_path='/usr/bin/chromium', args=['--no-sandbox'])
    for width in (1440,390,320):
        context=browser.new_context(viewport={'width':width,'height':920},device_scale_factor=1)
        page=context.new_page()
        errors=[]
        page.on('pageerror',lambda error:errors.append(str(error)))
        page.set_content(CONTENT, wait_until='load')
        for chapter in ids:
            page.evaluate('(id) => location.hash = "#" + id',chapter)
            page.wait_for_function('(id) => document.querySelector(".chapter.active")?.id === id',arg=chapter,timeout=5000)
            dim=page.evaluate('''() => ({
              document: document.documentElement.scrollWidth,
              body: document.body.scrollWidth,
              viewport: window.innerWidth,
              active: document.querySelector('.chapter.active')?.id,
              totalLabs: document.querySelectorAll('.transfer-lab').length
            })''')
            ok=(dim['document']<=width and dim['body']<=width and dim['active']==chapter and dim['totalLabs']==10 and not errors)
            rows.append({'width':width,'chapter':chapter,'success':ok,'dimensions':dim,'js_errors':list(errors)})
            if chapter=='p07' and width==1440:
                page.locator('#transfer-07 summary').click()
                page.locator('#transfer-07').screenshot(path=str(ROOT/'verification/round4_desktop_lab07.png'))
            if chapter=='p10' and width==390:
                page.locator('#transfer-10 summary').click()
                page.locator('#transfer-10').screenshot(path=str(ROOT/'verification/round4_mobile_lab10.png'))
        # No JS: all chapters are stacked and each lab must stay readable.
        nojs=browser.new_context(viewport={'width':width,'height':920},java_script_enabled=False)
        np=nojs.new_page();np.set_content(CONTENT)
        visible=np.evaluate('''() => ({
          chapters: Array.from(document.querySelectorAll('.chapter')).filter(el => getComputedStyle(el).display !== 'none').length,
          labs: document.querySelectorAll('.transfer-lab').length,
          whole: document.documentElement.scrollWidth
        })''')
        rows.append({'width':width,'chapter':'nojavascript','success':visible['chapters']==20 and visible['labs']==10 and visible['whole']<=width,'dimensions':visible})
        nojs.close();context.close()
    browser.close()
(ROOT/'verification/round4_browser_results.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('checks',len(rows),'pass',sum(x['success'] for x in rows),'fail',sum(not x['success'] for x in rows))
for row in rows:
    if not row['success']: print('FAILED:',row)
if not all(x['success'] for x in rows):raise SystemExit(1)
