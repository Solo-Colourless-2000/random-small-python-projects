"""Reproducible 36 focused review passes. Not a claim of 36 manual cover-to-cover readings."""
from pathlib import Path
from bs4 import BeautifulSoup
from collections import Counter
import ast
import json
import re
import subprocess
import sys
import tempfile
import time

ROOT=Path(__file__).resolve().parents[1]
MANUAL=ROOT/'python_10_projects_day03_manual.html'
PROJECTS=sorted((ROOT/'projects').glob('*.py'))
soup=BeautifulSoup(MANUAL.read_text(encoding='utf-8'),'html.parser')
examples=json.loads((ROOT/'verification/examples.json').read_text(encoding='ascii'))
passes=[]

def record(name,scope,fn,notes):
    begin=time.monotonic()
    try:
        result=fn()
        if result is False:raise AssertionError('Condition was False')
        passes.append({'round':len(passes)+1,'name':name,'scope':scope,'status':'PASS','notes':notes,'elapsed_seconds':round(time.monotonic()-begin,3)})
    except Exception as err:
        passes.append({'round':len(passes)+1,'name':name,'scope':scope,'status':'FAIL','notes':notes,'error':repr(err),'elapsed_seconds':round(time.monotonic()-begin,3)})

def check(ok,msg='condition failed'):
    if not ok:raise AssertionError(msg)

def run(n, args, stdin=''):
    return subprocess.run([sys.executable,str(PROJECTS[n-1]),*args],input=stdin,text=True,capture_output=True,timeout=7,cwd=ROOT)

# Review 1-10: the actual implementation and its sample contracts, separately for every project.
for n,source in enumerate(PROJECTS,1):
    def f(n=n,source=source):
        data=source.read_text(encoding='ascii')
        tree=ast.parse(data,feature_version=(3,10))
        check(any(isinstance(node,ast.FunctionDef) and node.name=='main' for node in tree.body),'main absent')
        check(data.endswith('\n') and '\t' not in data,'source format')
        case=examples[n-1]
        if n!=7:
            args=case['normal']['args'];p=run(n,args,case['normal']['input'])
            check((p.returncode,p.stdout,p.stderr)==(case['normal']['status'],case['normal']['stdout'],case['normal']['stderr']),'normal example')
        else:
            with tempfile.TemporaryDirectory() as tmp:
                out=Path(tmp)/'check.md'
                p=run(n,['samples/tasks.json',str(out)])
                check(p.returncode==0 and out.read_bytes()==(ROOT/'samples/checklist_expected.md').read_bytes(),'JSON normal sample')
    record(f'作品{n:02d}: ソースの構文・正常系','implementation',f,'AST 3.10 / ASCII / 正常サンプルの出力を個別照合')

# Review 11-20: test a negative or boundary case per project, not just a filename check.
cases={
 1:([['abc'],['256'],['-1']],2),
 2:([['a,,b'],['a!'],['a'*301]],2),
 3:([[''],['A'*81],['Ab']],2),
 4:([['{}'],['() '],['(' *81]],2),
 5:([['2,1','1'],['100','1'],['1,,2','1']],2),
 6:([['samples/nonexistent_file.txt','samples/after.txt']],1),
 7:([],2),
 8:([],2),
 9:([['1','/','0'],['1/0','+','2'],['10001','+','1']],2),
 10:([['00100','9'],['00102','1'],['00100','\uff11']],2)
}
for n in range(1,11):
    def f(n=n):
        if n==7:
            with tempfile.TemporaryDirectory() as tmp:
                inp=Path(tmp)/'in.json';out=Path(tmp)/'out.md'
                inp.write_text('[{"name":"A","done":false,"done":true}]',encoding='ascii')
                p=run(n,[str(inp),str(out)])
                check(p.returncode==2 and not out.exists() and p.stderr=='','duplicate JSON keys should be refused')
                return
        if n==8:
            p=run(n,[], 'show\n'*50)
            check(p.returncode==2 and 'command limit reached' in p.stdout,'50 commands')
            return
        inputs,expected=cases[n]
        for a in inputs:
            p=run(n,a)
            check(p.returncode==expected and not p.stderr,(n,a,p.returncode,p.stdout))
    record(f'作品{n:02d}: 境界・異常系','behavior',f,'不正文字、上下限、JSON重複、EOF/上限などを実行確認')

# Review 21-30: independently reconcile each chapter with its code and new pedagogy.
for n in range(1,11):
    def f(n=n):
        src=PROJECTS[n-1].read_text(encoding='ascii')
        combined=''.join(soup.select_one(f'#p{n:02d}-chunk{k}').get_text() for k in range(1,5))
        full=soup.select_one(f'#src{n:02d}').get_text()
        check(src==combined==full,'source chunks do not match')
        xlines=[line for line in src.splitlines() if line.strip()]
        for locator in (f'#p{n:02d} table.line-explanation-table tbody tr',f'#full-{n:02d} table.line-explanation-table tbody tr'):
            rr=soup.select(locator)
            check(len(rr)==len(xlines),'line count mismatch')
            check([r.find_all('td',recursive=False)[1].get_text() for r in rr]==xlines,'line text mismatch')
            check(all(r.select_one('details.syntax-breakdown') for r in rr),'missing token explanation')
        worked=soup.select_one(f'#fifth-deep-dive-{n:02d}')
        check(worked is not None and len(worked.select('.fifth-worked-trace tbody tr'))>=3,'worked trace absent')
        check(all('工程のつながりと字下げ' in soup.select_one(f'#p{n:02d}-step{i}').get_text() for i in range(1,5)),'missing bespoke step descriptions')
        check('間違えやすい点' in worked.get_text(),'pedagogy missing')
    record(f'作品{n:02d}: 全行照合・構文説明・手計算の追跡','manual',f,'4工程＝完成コード＝付録A、全非空行説明、4工程の固有解説・追跡表')

# Reviews 31-36: cross-cutting quality concerns that apply to the whole artifact.
def audit_navigation():
    ids=[tag['id'] for tag in soup.select('[id]')]
    check(len(ids)==len(set(ids)),'duplicate ids')
    check(len(soup.select('section.chapter'))==20,'chapter count')
    check(len(soup.select('article.step'))==40,'step count')
    for a in soup.select('a[href^="#"]'):
        check(a['href'][1:] in ids,'broken anchor '+a['href'])
record('全体: 目次・章数・内部リンク','navigation',audit_navigation,'20章40工程、ID一意性、ページ内リンク')

def audit_html_tables():
    for t in soup.select('table.line-explanation-table'):
        check(t.tbody is not None,'missing tbody')
        for r in t.find_all('tr',recursive=False):
            check(r.parent.name in ('thead','tbody'),'row misplaced')
    check(len(soup.select('.fifth-deep-dive'))==10,'new sections')
record('全体: HTML表構造','html',audit_html_tables,'tbody・trの親子構造と追跡表')

def audit_assets():
    check(not soup.select('script[src],iframe[src],img[src]'),'unexpected online assets')
    check(not soup.select('link[rel="stylesheet"]'),'unexpected stylesheet')
    check(len(soup.select('style'))==1 and len(soup.select('script'))==1,'standalone HTML')
    check('localStorage' in soup.script.text,'checkbox persistence')
    check('navigator.clipboard' in soup.script.text,'copy feature')
record('全体: オフライン閲覧と操作','assets',audit_assets,'CSS/JS内蔵、進捗保存、コピー')

def audit_source_cleanliness():
    for src in PROJECTS:
        t=src.read_bytes().decode('ascii')
        check('requests' not in t and 'urllib' not in t and 'socket' not in t,'external networking')
        check('eval(' not in t and 'exec(' not in t,'dynamic execution')
    check(sum(len(p.read_text(encoding='ascii').splitlines()) for p in PROJECTS)>300,'source size unexpectedly low')
record('全体: 安全な学習範囲・ASCII','safety',audit_source_cleanliness,'ネットワーク処理・動的コード実行がないことを照合')

def audit_samples():
    for f in (ROOT/'samples').iterdir():
        f.read_bytes().decode('ascii')
    task=json.loads((ROOT/'samples/tasks.json').read_text(encoding='ascii'))
    check(len(task)==2 and all(set(t)=={'name','done'} for t in task),'sample schema')
    check((ROOT/'samples/checklist_expected.md').read_bytes()==b'- [x] Read\n- [ ] Practice\n','expected markdown')
record('全体: 入力例・期待する成果物','samples',audit_samples,'UTF-8/ASCIIサンプル、JSON項目、Markdown期待値')

def audit_fifth_semantics():
    text=soup.select_one('#p07').get_text(' ',strip=True)
    check('出力を作らず終了2で拒否' in text,'old JSON text')
    check('改行を正規化した後の文字数' in soup.select_one('#p06').get_text(' ',strip=True),'newlines note')
    check(len(soup.select('details.syntax-breakdown'))==746,'syntax count')
    check(len(soup.select('.fifth-legend tbody tr'))==12,'punctuation legend')
record('全体: 誤解を招く説明の修正','explanations',audit_fifth_semantics,'旧JSON記述、改行正規化、括弧・=等の文脈、746行の説明')

file=ROOT/'verification/fifth_36_review_rounds.json'
report={'date':'2026-11-11','scope':'36 focused rounds: 10 source-and-normal, 10 boundary, 10 manual consistency, 6 global. Not 36 human cover-to-cover readings.','total_rounds':len(passes),'passed':sum(x['status']=='PASS' for x in passes),'failed':sum(x['status']=='FAIL' for x in passes),'rounds':passes}
file.write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
for r in passes:
    print(f"{r['round']:02d}: {r['status']} {r['name']}" + (f" -> {r['error']}" if r['status']=='FAIL' else ''))
print('TOTAL',report['passed'],'PASS,',report['failed'],'FAIL')
sys.exit(1 if report['failed'] else 0)
