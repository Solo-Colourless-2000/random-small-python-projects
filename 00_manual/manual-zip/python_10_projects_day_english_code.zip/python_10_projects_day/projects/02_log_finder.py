"""Print matching lines from a UTF-8 log with their line numbers."""
import sys
from pathlib import Path


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 02_log_finder.py <log_file> <keyword>")
        return 2

    keyword = sys.argv[2]
    if not keyword:
        print("Error: Keyword must not be empty.")
        return 2
    matches = 0
    try:
        path = Path(sys.argv[1]).expanduser()
        if not path.is_file():
            print(f"Error: File not found: {path}")
            return 1
        with path.open("r", encoding="utf-8") as handle:
            for line_number, line in enumerate(handle, start=1):
                if keyword in line:
                    clean_line = line.rstrip("\n")
                    print(f"{line_number}: {clean_line}")
                    matches += 1
    except (OSError, UnicodeError, RuntimeError) as error:
        print(f"Error: Cannot read log: {error}")
        return 1

    print(f"Matches: {matches}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
