import sys


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 01_bit_inspector.py number")
        return 2
    try:
        if len(sys.argv[1]) > 10:
            raise ValueError
        value = int(sys.argv[1])
    except ValueError:
        print("Error: enter an integer from 0 to 255.")
        return 2
    if not 0 <= value <= 255:
        print("Error: enter an integer from 0 to 255.")
        return 2
    print(f"Binary: {value:08b}")
    ones = 0
    for position in range(8):
        mask = 1 << position
        bit = 0
        if value & mask:
            bit = 1
            ones += 1
        print(f"Bit {position}: {bit}")
    print(f"On bits: {ones}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
