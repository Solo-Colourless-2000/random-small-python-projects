"""Differential tests: independently predict every snake movement and collision.

The model below deliberately does not call the native C rule functions. It
compares the resulting cells, movement events, score, food and end states.
"""
from __future__ import annotations

import random
import unittest

from snake_app.engine import Direction, Event, SnakeEngine, Status

MOVES = {Direction.UP: (0, -1), Direction.RIGHT: (1, 0),
         Direction.DOWN: (0, 1), Direction.LEFT: (-1, 0)}


class ModelTests(unittest.TestCase):
    def test_independent_model_across_many_input_streams(self) -> None:
        rng = random.Random(20261113)
        with SnakeEngine(8, 8, seed=1) as game:
            checked = 0
            eaten = 0
            hit_wall = 0
            hit_self = 0
            for seed in range(1, 401):
                game.reset(seed=seed)
                frame = game.snapshot()
                pending: list[Direction] = []
                for _ in range(100):
                    # Feed adversarial rapid inputs; verify the queue's policy.
                    for _ in range(rng.randrange(4)):
                        wanted = Direction(rng.randrange(4))
                        last = pending[-1] if pending else frame.direction
                        should_accept = (len(pending) < 2 and wanted != last
                                         and (int(wanted) + 2) % 4 != int(last))
                        self.assertEqual(game.turn(wanted), should_accept)
                        if should_accept:
                            pending.append(wanted)
                    direction = pending.pop(0) if pending else frame.direction
                    dx, dy = MOVES[direction]
                    hx, hy = frame.body[0]
                    next_cell = (hx + dx, hy + dy)
                    ate = next_cell == frame.food
                    wall = not (0 <= next_cell[0] < 8 and 0 <= next_cell[1] < 8)
                    self_hit = next_cell in (frame.body if ate else frame.body[:-1])
                    if wall or self_hit:
                        expected_event = Event.DIED
                        expected_body = frame.body
                        expected_status = Status.LOST
                        hit_wall += wall
                        hit_self += self_hit and not wall
                    else:
                        expected_event = Event.ATE if ate else Event.MOVED
                        expected_body = (next_cell,) + frame.body[:len(frame.body) - (0 if ate else 1)]
                        expected_status = Status.RUNNING
                    actual_event = game.tick()
                    actual = game.snapshot()
                    self.assertEqual(actual_event, expected_event)
                    self.assertEqual(actual.body, expected_body)
                    self.assertEqual(actual.direction, direction)
                    self.assertEqual(actual.score, frame.score + int(ate and not (wall or self_hit)))
                    self.assertEqual(actual.status, expected_status)
                    if expected_event == Event.ATE:
                        self.assertNotIn(actual.food, actual.body)
                        eaten += 1
                    if expected_status == Status.RUNNING:
                        self.assertIsNotNone(actual.food)
                    checked += 1
                    frame = actual
                    if actual_event == Event.DIED:
                        self.assertEqual(game.tick(), Event.NOOP)
                        self.assertEqual(game.snapshot(), actual)
                        break
            self.assertGreater(checked, 1200)
            self.assertGreater(eaten, 0)
            self.assertGreater(hit_wall, 0)
            self.assertGreater(hit_self, 0)


if __name__ == "__main__":
    unittest.main()
