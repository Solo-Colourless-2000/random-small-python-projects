"""Extra executable checks for the detailed day07 revision (stdlib only)."""
import ast
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
HTML = (ROOT / 'python_10_projects_day07_manual.html').read_text(encoding='utf-8')
PROJECTS = sorted((ROOT / 'projects').glob('*.py'))


def load(path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    obj = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


class RevisionTests(unittest.TestCase):
    def test_all_245_nonempty_lines_explained(self):
        count = sum(bool(line.strip()) for path in PROJECTS for line in path.read_text().splitlines())
        self.assertEqual(count, 245)
        self.assertEqual(HTML.count('class="line-breakdown"'), count)
        self.assertEqual(HTML.count('\u69cb\u6587\u30fb\u8a18\u53f7\u306e\u5185\u8a33\uff1a'), count)
        self.assertEqual(HTML.count('\u5168\u975e\u7a7a\u884c\u306e\u9010\u884c\u89e3\u8aac'), 11)

    def test_each_project_has_guide_with_trace_and_pitfalls(self):
        self.assertEqual(HTML.count('class="reader-guide"'), 10)
        self.assertEqual(HTML.count('\u521d\u5b66\u8005\u5411\u3051\u30fb\u5b9f\u884c\u524d\u306e\u8aad\u307f\u89e3\u304d\u30ac\u30a4\u30c9'), 10)
        self.assertEqual(HTML.count('\u624b\u3092\u52d5\u304b\u3057\u3066\u78ba\u8a8d\uff1a'), 10)
        self.assertEqual(HTML.count('\u9593\u9055\u3048\u3084\u3059\u3044\u70b9\uff1a'), 10)

    def test_source_bytes_match_original_archive_manifest(self):
        original = json.loads((ROOT / 'verification' / 'original_sha256.json').read_text())
        self.assertEqual(set(original), {path.name for path in PROJECTS})
        for path in PROJECTS:
            with self.subTest(file=path.name):
                self.assertEqual(hashlib.sha256(path.read_bytes()).hexdigest(), original[path.name])

    def test_source_is_stdlib_and_disallows_network_or_eval(self):
        disallowed = {'eval', 'exec', 'compile', 'open', '__import__'}
        imports = set()
        for path in PROJECTS:
            tree = ast.parse(path.read_text(encoding='ascii'), feature_version=(3, 10))
            for node in ast.walk(tree):
                if isinstance(node, ast.Import):
                    imports.update(alias.name.split('.')[0] for alias in node.names)
                elif isinstance(node, ast.ImportFrom):
                    imports.add(node.module.split('.')[0])
                elif isinstance(node, ast.Call) and isinstance(node.func, ast.Name):
                    self.assertNotIn(node.func.id, disallowed)
                elif isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute):
                    self.assertNotIn(node.func.attr, {'loads'} if path.name.startswith('08_') else set())
        self.assertFalse(imports.intersection({'socket', 'http', 'requests', 'subprocess', 'os', 'pathlib'}))

    def test_01_decoding_and_duplicate_policy(self):
        app = load(PROJECTS[0])
        self.assertEqual(app.compare('target=public&%74arget=private'), (True, 'private', False))
        self.assertEqual(app.compare('target=public'), (True, 'public', True))
        for raw in ('target=public&', 'target=', 'target=public&target=public&target=public&target=public&target=public'):
            with self.subTest(raw=raw):
                with self.assertRaises(ValueError):
                    app.compare(raw)

    def test_02_field_whitelist_does_not_mutate_baseline(self):
        app = load(PROJECTS[1])
        before = app.BASE.copy()
        self.assertEqual(app.apply_update(app.CASES['role'], False)['role'], 'admin')
        self.assertEqual(app.apply_update(app.CASES['role'], True)['role'], 'reader')
        self.assertEqual(app.BASE, before)

    def test_03_regex_literal_vs_pattern(self):
        app = load(PROJECTS[2])
        self.assertEqual(app.matches('a.b', False), 'a.b,axb')
        self.assertEqual(app.matches('a.b', True), 'a.b')
        self.assertEqual(app.matches('.*', True), '(none)')

    def test_04_one_time_token_replay(self):
        app = load(PROJECTS[3])
        store = {app.TOKEN: 'alice'}
        self.assertEqual(app.redeem(store, app.TOKEN, True), 'accept')
        self.assertEqual(store, {})
        self.assertEqual(app.redeem(store, app.TOKEN, True), 'reject')

    def test_05_negative_qty_and_python_unicode_int(self):
        app = load(PROJECTS[4])
        self.assertEqual(app.purchase(-1, False), ('accept', 23, 6))
        self.assertEqual(app.purchase(-1, True), ('reject', 20, 5))
        for quantity in range(-100, 101):
            status, balance, stock = app.purchase(quantity, True)
            if status == 'accept':
                self.assertTrue(1 <= quantity <= 5)
                self.assertEqual((balance, stock), (20 - 3*quantity, 5 - quantity))
            else:
                self.assertEqual((balance, stock), (20, 5))
        self.assertEqual(int('\uff11'), 1)  # Important parsing distinction in the revised guide.

    def test_06_cache_key_partitioning(self):
        app = load(PROJECTS[5])
        weak = {}
        app.fetch(weak, 'red', False)
        self.assertEqual(app.fetch(weak, 'blue', False), 'variant=red')
        safe = {}
        app.fetch(safe, 'red', True)
        self.assertEqual(app.fetch(safe, 'blue', True), 'variant=blue')

    def test_07_old_session_id_removed_on_rotation(self):
        app = load(PROJECTS[6])
        sessions = {app.OLD_ID: 'anonymous'}
        self.assertEqual(app.login(sessions, True), app.NEW_ID)
        self.assertEqual(sessions, {app.NEW_ID: 'alice'})

    def test_08_never_deserializes_and_detects_suffix(self):
        app = load(PROJECTS[7])
        with patch('pickle.loads', side_effect=AssertionError('Deserialization not permitted')):
            self.assertEqual(app.inspect(app.CASES['global']), ('GLOBAL', False))
            self.assertEqual(app.inspect(app.CASES['trailing']), ('(none)', True))
        self.assertIn('\u4efb\u610f\u306e\u58ca\u308c\u305fpickle', HTML)

    def test_09_xml_expansion_is_not_dtd_policy_enforcement(self):
        app = load(PROJECTS[8])
        self.assertEqual(app.expanded_length(app.CASES['entity']), 48)
        self.assertIn('\u89e3\u6790\u5f8c\u306e\u8868\u793a\u3060\u3051', HTML)
        self.assertIn('\u975e\u4fe1\u983cXML', HTML)
        lines = PROJECTS[8].read_text().splitlines()
        parse_line = next(i for i, line in enumerate(lines, 1) if 'expanded_length(raw)' in line and 'def ' not in line)
        policy_line = next(i for i, line in enumerate(lines, 1) if 'DTD policy' in line)
        self.assertLess(parse_line, policy_line)

    def test_10_minimal_context_restricts_known_demo_secret(self):
        app = load(PROJECTS[9])
        self.assertEqual(app.render(app.CASES['nested'], app.FULL), 'Value DEMO-ONLY')
        self.assertEqual(app.render(app.CASES['nested'], app.MINIMAL), '(missing field)')
        self.assertIn('\u5b89\u5168\u6027\u4fdd\u8a3c\u3067\u306f\u306a\u3044', HTML)

    def test_no_external_assets_and_mobile_style(self):
        self.assertNotRegex(HTML, r'<(?:img|iframe|script)\b[^>]+src=')
        self.assertNotRegex(HTML, r'<link\b[^>]+stylesheet')
        self.assertIn('@media (max-width: 720px)', HTML)
        self.assertIn('@media print', HTML)
        self.assertIn('overflow: auto', HTML)

    def test_revision_does_not_remove_safety_cautions(self):
        for term in ('DTD policy: reject', 'pickletools', 'MINIMAL', '\u6700\u59274\u9805\u76ee', '\u5358\u56de\u4f7f\u7528'):
            with self.subTest(term=term):
                self.assertIn(term, HTML)


if __name__ == '__main__':
    unittest.main()
