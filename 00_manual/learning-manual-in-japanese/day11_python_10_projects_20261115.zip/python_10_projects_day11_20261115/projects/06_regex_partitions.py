import re
import sys

CASES = {"short": 4, "long": 8, "edge": 1}


def partitions(length):
    if length == 0:
        return 1
    total = 0
    for size in range(1, length + 1):
        total += partitions(length - size)
    return total


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script short|long|edge", file=sys.stderr)
        return 2
    length = CASES[sys.argv[1]]
    text = "a" * length + "!"
    print(f"Ambiguous partitions: {partitions(length)}")
    print(f"Linear positions: {length}")
    print(f"Nested pattern rejects: {re.fullmatch('(a+)+', text) is None}")
    print(f"Flat pattern rejects: {re.fullmatch('a+', text) is None}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
