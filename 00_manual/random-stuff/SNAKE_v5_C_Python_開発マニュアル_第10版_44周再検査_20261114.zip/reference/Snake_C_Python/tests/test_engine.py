"""Public API tests: run with `python -m unittest discover -s tests -v`."""
from __future__ import annotations

import ctypes as ct
import random
import unittest

from snake_app.engine import Direction, Event, SnakeEngine, Status, _CCell, _CSnapshot, load_library


class EngineTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.lib = load_library()

    def engine(self, width: int = 12, height: int = 9, seed: int = 100) -> SnakeEngine:
        obj = SnakeEngine(width, height, library=self.lib, seed=seed)
        self.addCleanup(obj.close)
        return obj

    def test_default_start_is_centered_and_right(self) -> None:
        frame = self.engine().snapshot()
        self.assertEqual(frame.body, ((6, 4), (5, 4), (4, 4), (3, 4)))
        self.assertEqual(frame.direction, Direction.RIGHT)
        self.assertEqual(frame.score, 0)
        self.assertEqual(frame.status, Status.RUNNING)

    def test_minimum_board_is_allowed(self) -> None:
        frame = self.engine(8, 8).snapshot()
        self.assertEqual((frame.width, frame.height), (8, 8))

    def test_maximum_board_is_allowed(self) -> None:
        frame = self.engine(64, 64).snapshot()
        self.assertEqual((frame.width, frame.height), (64, 64))
        self.assertEqual(len(frame.body), 4)

    def test_unsupported_dimensions_are_rejected(self) -> None:
        for dims in ((0, 8), (8, 0), (7, 9), (9, 7), (65, 8), (8, 65), (-1, 8)):
            with self.subTest(dims=dims), self.assertRaises(ValueError):
                self.engine(*dims)

    def test_ctypes_integer_overflow_is_rejected_before_native_call(self) -> None:
        for size in (2**32 + 8, -(2**32) + 8, 2**64 + 12, True, 8.0, "12"):
            with self.subTest(size=size), self.assertRaises(ValueError):
                self.engine(size, 8)

    def test_seed_overflow_and_wrong_type_rejected(self) -> None:
        for seed in (-1, 2**32, 2**40 + 1, True, 4.5, "42"):
            with self.subTest(seed=seed), self.assertRaises(ValueError):
                self.engine(seed=seed)
        game = self.engine()
        with self.assertRaises(ValueError):
            game.reset(seed=-1)
        with self.assertRaises(ValueError):
            game.reset(seed=2**32)

    def test_turn_requires_a_direction_enum(self) -> None:
        game = self.engine()
        for value in (1, -1, 9, "UP", 1.9, True):
            with self.subTest(value=value), self.assertRaises(ValueError):
                game.turn(value)

    def test_random_seed_reproduces_same_food(self) -> None:
        a = self.engine(seed=776).snapshot()
        b = self.engine(seed=776).snapshot()
        self.assertEqual(a, b)

    def test_zero_random_seed_is_safe(self) -> None:
        a = self.engine(seed=0).snapshot()
        b = self.engine(seed=0).snapshot()
        self.assertEqual(a.food, b.food)
        self.assertNotIn(a.food, a.body)

    def test_initial_food_does_not_overlap_body(self) -> None:
        e = self.engine()
        for seed in range(1, 1001):
            e.reset(seed=seed)
            frame = e.snapshot()
            self.assertNotIn(frame.food, frame.body)
            self.assertTrue(0 <= frame.food[0] < frame.width)
            self.assertTrue(0 <= frame.food[1] < frame.height)

    def test_tick_moves_one_cell_without_growth(self) -> None:
        e = self.engine()
        before = e.snapshot()
        if before.food == (7, 4):
            e.reset(seed=101)
            before = e.snapshot()
        self.assertEqual(e.tick(), Event.MOVED)
        after = e.snapshot()
        self.assertEqual(after.body, ((7, 4), (6, 4), (5, 4), (4, 4)))
        self.assertEqual(after.score, 0)

    def test_reverse_turn_is_ignored(self) -> None:
        e = self.engine()
        self.assertFalse(e.turn(Direction.LEFT))
        self.assertEqual(e.tick(), Event.MOVED)
        self.assertEqual(e.snapshot().body[0], (7, 4))

    def test_duplicate_turn_is_ignored(self) -> None:
        e = self.engine()
        self.assertFalse(e.turn(Direction.RIGHT))
        self.assertTrue(e.turn(Direction.UP))
        self.assertFalse(e.turn(Direction.UP))

    def test_invalid_direction_is_ignored(self) -> None:
        e = self.engine()
        self.assertEqual(self.lib.snake_set_direction(e._handle(), -1), 0)
        self.assertEqual(self.lib.snake_set_direction(e._handle(), 4), 0)
        self.assertEqual(self.lib.snake_set_direction(e._handle(), 999), 0)

    def test_two_turns_buffered_one_per_tick(self) -> None:
        e = self.engine()
        self.assertTrue(e.turn(Direction.UP))
        self.assertTrue(e.turn(Direction.LEFT))
        self.assertFalse(e.turn(Direction.DOWN))
        self.assertEqual(e.tick(), Event.MOVED)
        self.assertEqual(e.snapshot().body[0], (6, 3))
        self.assertEqual(e.tick(), Event.MOVED)
        self.assertEqual(e.snapshot().body[0], (5, 3))

    def test_queue_does_not_allow_reverse_of_pending_turn(self) -> None:
        e = self.engine()
        self.assertTrue(e.turn(Direction.UP))
        self.assertFalse(e.turn(Direction.DOWN))
        self.assertTrue(e.turn(Direction.LEFT))

    def test_wall_collision_stops_game(self) -> None:
        e = self.engine(8, 8)
        for _ in range(3):
            self.assertIn(e.tick(), (Event.MOVED, Event.ATE))
        position = e.snapshot().body[0]
        self.assertEqual(position, (7, 4))
        self.assertEqual(e.tick(), Event.DIED)
        self.assertEqual(e.snapshot().body[0], position)
        self.assertEqual(e.snapshot().status, Status.LOST)
        self.assertEqual(e.tick(), Event.NOOP)

    def test_reset_returns_to_initial_state(self) -> None:
        e = self.engine()
        e.turn(Direction.UP)
        e.turn(Direction.LEFT)
        e.tick()
        e.reset(seed=100)
        self.assertEqual(e.snapshot(), self.engine().snapshot())
        self.assertTrue(e.turn(Direction.UP))

    def test_food_consumption_and_replacement(self) -> None:
        e = self.engine(8, 8)
        for seed in range(1, 100000):
            e.reset(seed=seed)
            food = e.snapshot().food
            if food == (5, 4):
                break
        else:
            self.fail("Could not find food immediately ahead")
        self.assertEqual(e.tick(), Event.ATE)
        frame = e.snapshot()
        self.assertEqual(frame.score, 1)
        self.assertEqual(len(frame.body), 5)
        self.assertEqual(frame.body[0], (5, 4))
        self.assertNotIn(frame.food, frame.body)
        self.assertIsNotNone(frame.food)

    def test_snapshot_rejects_insufficient_buffer_without_writes(self) -> None:
        e = self.engine()
        out = _CSnapshot()
        out.score = 12345
        cells = (_CCell * 3)()
        result = self.lib.snake_snapshot(e._handle(), ct.byref(out), cells, 3)
        self.assertEqual(result, 0)
        self.assertEqual(out.score, 12345)

    def test_null_api_handling(self) -> None:
        self.assertEqual(self.lib.snake_tick(None), Event.NOOP)
        self.assertEqual(self.lib.snake_set_direction(None, 1), 0)
        self.assertEqual(self.lib.snake_snapshot(None, None, None, 0), 0)
        self.lib.snake_reset(None, 0)
        self.lib.snake_destroy(None)

    def test_close_is_idempotent(self) -> None:
        e = self.engine()
        e.close()
        e.close()
        with self.assertRaises(RuntimeError):
            e.snapshot()

    def test_context_manager_closes_engine(self) -> None:
        e = SnakeEngine(8, 8, library=self.lib, seed=33)
        with e as game:
            self.assertEqual(game.snapshot().status, Status.RUNNING)
        with self.assertRaises(RuntimeError):
            e.tick()

    def test_real_game_can_win_by_filling_all_64_cells(self) -> None:
        # Follow a Hamiltonian cycle, eating normally spawned food. This tests
        # actual growth, collision handling and eventual victory end-to-end.
        width = height = 8
        path = [(x, 0) for x in range(width)]
        for y in range(1, height):
            xs = range(width - 1, 0, -1) if y % 2 else range(1, width)
            path.extend((x, y) for x in xs)
        path.extend((0, y) for y in range(height - 1, 0, -1))
        positions = {cell: index for index, cell in enumerate(path)}
        directions = {(0, -1): Direction.UP, (1, 0): Direction.RIGHT,
                      (0, 1): Direction.DOWN, (-1, 0): Direction.LEFT}
        e = self.engine(width, height, seed=32)
        for _ in range(15000):
            x, y = e.snapshot().body[0]
            nx, ny = path[(positions[(x, y)] + 1) % len(path)]
            e.turn(directions[(nx - x, ny - y)])
            event = e.tick()
            self.assertNotEqual(event, Event.DIED)
            if event == Event.VICTORY:
                frame = e.snapshot()
                self.assertEqual(frame.status, Status.WON)
                self.assertEqual(frame.score, 60)
                self.assertEqual(len(frame.body), 64)
                self.assertIsNone(frame.food)
                return
        self.fail("Snake did not reach victory within the cycle bound")

    def test_large_board_random_stress_invariants(self) -> None:
        rng = random.Random(20261113)
        e = self.engine(26, 18)
        for i in range(18000):
            if i % 101 == 0 or e.snapshot().status != Status.RUNNING:
                e.reset(seed=i + 1)
            e.turn(Direction(rng.randrange(4)))
            event = e.tick()
            frame = e.snapshot()
            self.assertEqual(len(set(frame.body)), len(frame.body))
            self.assertTrue(all(0 <= x < frame.width and 0 <= y < frame.height
                                for x, y in frame.body))
            self.assertEqual(len(frame.body), frame.score + 4)
            if frame.status == Status.RUNNING:
                self.assertIsNotNone(frame.food)
                self.assertNotIn(frame.food, frame.body)
            if event == Event.DIED:
                self.assertEqual(frame.status, Status.LOST)
            elif event == Event.VICTORY:
                self.assertEqual(frame.status, Status.WON)


if __name__ == "__main__":
    unittest.main()
