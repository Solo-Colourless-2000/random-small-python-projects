"""Shared gameplay timing and window layout (no GUI or engine dependencies)."""

WINDOW_WIDTH = 850
WINDOW_HEIGHT = 700
COLUMNS = 26
ROWS = 18
CELL = 26
BOARD_X = (WINDOW_WIDTH - COLUMNS * CELL) // 2
BOARD_Y = 140
BOARD_WIDTH = COLUMNS * CELL
BOARD_HEIGHT = ROWS * CELL
FRAME_DELAY_MS = 33
IDLE_FRAME_DELAY_MS = 110

BASE_INTERVAL = {"EASY": 0.170, "NORMAL": 0.125, "HARD": 0.090}
MIN_INTERVAL = 0.060
SCORE_SAVE_INTERVAL = 5.0
# Limited catch-up makes movement independent of screen refresh cadence while
# avoiding a cascade of instant deaths after the desktop has been suspended.
MAX_CATCHUP_TICKS = 3
MAX_UPDATE_GAP = 0.45

BG = "#0a111b"
BOARD_BG = "#101d2b"
GRID = "#1b2b3a"
WHITE = "#eaf3f6"
MUTED = "#91a6b6"
GREEN = "#78e3a3"
BODY_A = "#38b986"
BODY_B = "#31a97b"
FOOD = "#ff876d"
PANEL = "#142334"
OUTLINE = "#334c5c"


def game_interval(difficulty: str, score: int) -> float:
    """Seconds per cell. The minimum prevents an impossible speed."""
    return max(MIN_INTERVAL, BASE_INTERVAL[difficulty] * (0.987 ** score))


def animation_progress(mode: str, now: float, last_step: float, interval: float) -> float:
    """Clamp snake interpolation; menus and paused screens show exact cells."""
    if mode != "playing" or interval <= 0:
        # A broken timing configuration must not crash the drawing loop.
        return 1.0
    return min(1.0, max(0.0, (now - last_step) / interval))
