import sys
import wave


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 tests/inspect_wav.py file.wav")
        return 2
    try:
        with wave.open(sys.argv[1], "rb") as stream:
            print(f"Channels: {stream.getnchannels()}")
            print(f"Width: {stream.getsampwidth()} bytes")
            print(f"Rate: {stream.getframerate()} Hz")
            print(f"Frames: {stream.getnframes()}")
    except (OSError, EOFError, wave.Error):
        print("Error: cannot inspect WAV.")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
