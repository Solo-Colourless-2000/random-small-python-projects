"""Scene render benchmark; results depend on the machine and display server."""
import random
import sys
import time
import tkinter as tk
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from game import Game
from entities import Bullet
from constants import ARENA_LEFT, ARENA_TOP, ARENA_RIGHT, ARENA_BOTTOM, CYAN

root = tk.Tk()
try:
    g = Game(root, seed=123, auto_loop=False)
    g.start()
    g.pending.clear()
    r = random.Random(81)
    for label, enemies, bullets, particles in [('typical', 8, 30, 80),
                                               ('midgame', 18, 100, 180),
                                               ('stress', 28, 220, 300)]:
        g.enemies.clear()
        g.bullets.clear()
        g.particles.clear()
        for i in range(enemies):
            g.spawn_enemy(['hunter', 'gunner', 'runner', 'bruiser'][i % 4])
        for i in range(bullets):
            g.bullets.append(Bullet(r.uniform(ARENA_LEFT, ARENA_RIGHT),
                                    r.uniform(ARENA_TOP, ARENA_BOTTOM),
                                    r.uniform(-350, 350), r.uniform(-350, 350),
                                    4, 10, 2, i%2==0, CYAN))
        g.emit(580, 320, CYAN, particles)
        before = time.perf_counter()
        for i in range(40):
            g.renderer.draw(g)
            root.update_idletasks()
        duration = time.perf_counter() - before
        print(f'{label.upper():8}: {40 / duration:.1f} renders/sec, '
              f'{duration / 40 * 1000:.1f} ms/frame, '
              f'{len(g.canvas.find_all())} Tk items')
finally:
    root.destroy()
