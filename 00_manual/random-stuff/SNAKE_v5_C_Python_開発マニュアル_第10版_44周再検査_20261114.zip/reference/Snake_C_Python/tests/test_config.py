"""Pure gameplay timing should not need Tk or the C shared library."""
from __future__ import annotations

import unittest

from snake_app.config import BASE_INTERVAL, MIN_INTERVAL, animation_progress, game_interval


class ConfigTests(unittest.TestCase):
    def test_difficulty_order_and_start_speed(self) -> None:
        self.assertGreater(game_interval("EASY", 0), game_interval("NORMAL", 0))
        self.assertGreater(game_interval("NORMAL", 0), game_interval("HARD", 0))
        for name, initial in BASE_INTERVAL.items():
            self.assertAlmostEqual(game_interval(name, 0), initial)

    def test_progressively_faster_but_never_below_minimum(self) -> None:
        for name in BASE_INTERVAL:
            samples = [game_interval(name, score) for score in (0, 10, 30, 60, 200, 500)]
            self.assertEqual(samples, sorted(samples, reverse=True))
            self.assertGreaterEqual(min(samples), MIN_INTERVAL)
            self.assertEqual(samples[-1], MIN_INTERVAL)

    def test_no_animation_on_pause_or_menu(self) -> None:
        for mode in ("menu", "paused", "over"):
            self.assertEqual(animation_progress(mode, 0.0, 99.0, 0.1), 1.0)

    def test_invalid_interpolation_interval_does_not_crash_renderer(self) -> None:
        for bad_interval in (0, -0.1):
            self.assertEqual(animation_progress("playing", 1, 0, bad_interval), 1.0)

    def test_interpolation_bounds_for_clock_anomalies(self) -> None:
        self.assertEqual(animation_progress("playing", -100, 0, 0.1), 0.0)
        self.assertEqual(animation_progress("playing", 100, 0, 0.1), 1.0)
        self.assertAlmostEqual(animation_progress("playing", .05, 0, .1), .5)


if __name__ == "__main__":
    unittest.main()
