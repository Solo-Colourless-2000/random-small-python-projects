import sys


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 10_cell_generations.py state generations")
        return 2
    state = sys.argv[1]
    if not 3 <= len(state) <= 21 or any(ch not in "01" for ch in state):
        print("Error: state needs 3-21 binary digits.")
        return 2
    try:
        if len(sys.argv[2]) != 1 or sys.argv[2] not in "012345678":
            raise ValueError
        generations = int(sys.argv[2])
    except ValueError:
        print("Error: generations must be 0-8.")
        return 2
    print(f"0: {state}")
    for generation in range(1, generations + 1):
        next_state = ""
        for index in range(len(state)):
            left = "0"
            right = "0"
            if index > 0:
                left = state[index - 1]
            if index + 1 < len(state):
                right = state[index + 1]
            if left != right:
                next_state += "1"
            else:
                next_state += "0"
        state = next_state
        print(f"{generation}: {state}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
