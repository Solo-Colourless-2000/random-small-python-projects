"""Compile the C game core as a shared library (GCC/Clang, Python 3.9+)."""
from __future__ import annotations
import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import tempfile

HERE = Path(__file__).resolve().parent
ENGINE_DIR = HERE / 'engine'
SOURCES = tuple(ENGINE_DIR / file for file in (
    'tank_engine.c', 'tank_geometry.c', 'tank_combat.c', 'tank_enemies.c'))
HEADERS = (ENGINE_DIR / 'tank_engine.h', ENGINE_DIR / 'engine_internal.h')

def library_path() -> Path:
    if sys.platform == 'win32':
        return ENGINE_DIR / 'tank_engine.dll'
    if sys.platform == 'darwin':
        return ENGINE_DIR / 'libtank_engine.dylib'
    return ENGINE_DIR / 'libtank_engine.so'

def _candidates():
    requested = os.environ.get('CC', '').strip()
    if requested:
        yield shlex.split(requested)
    for compiler in (('gcc', 'clang') if sys.platform == 'win32' else ('gcc', 'clang', 'cc')):
        yield [compiler]

def build(force: bool = False) -> Path:
    output = library_path()
    deps = (*SOURCES, *HEADERS)
    if (not force and output.is_file() and
            output.stat().st_mtime_ns >= max(dep.stat().st_mtime_ns for dep in deps)):
        return output
    problems = []
    for candidate in _candidates():
        if not candidate or not shutil.which(candidate[0]):
            continue
        # A unique temp library avoids leaving a corrupt, apparently-current
        # shared object behind after an interrupted/failed compiler run.
        fd, temporary = tempfile.mkstemp(prefix='steelfront-build-',
               suffix=output.suffix, dir=output.parent)
        os.close(fd)
        try:
            command = list(candidate) + ['-std=c11', '-O2', '-Wall', '-Wextra',
                     '-Wpedantic']
            if sys.platform == 'darwin':
                command += ['-dynamiclib', '-fPIC']
            elif sys.platform == 'win32':
                command += ['-shared']
            else:
                command += ['-shared', '-fPIC']
            command += [str(source) for source in SOURCES]
            command += ['-o', temporary, '-lm']
            try:
                result = subprocess.run(command, text=True, capture_output=True)
            except OSError as exc:
                problems.append(f"{' '.join(candidate)}: {exc}")
                continue
            if result.returncode == 0:
                # mkstemp starts with mode 0600; some linkers turn this into
                # 0711. A shared library must be readable by every user who
                # should be able to run the installed game.
                if os.name != 'nt':
                    os.chmod(temporary, 0o755)
                os.replace(temporary, output)
                return output
            problems.append(f"{' '.join(candidate)}: {result.stderr.strip()}")
        finally:
            try:
                os.unlink(temporary)
            except FileNotFoundError:
                pass
    detail = '\n'.join(problems) if problems else 'C compiler not found (GCC or Clang).'
    raise RuntimeError('Could not build the C gameplay engine.\n' + detail)

if __name__ == '__main__':
    try:
        print('Built:', build(force=True))
    except (RuntimeError, OSError, ValueError) as exc:
        print(exc, file=sys.stderr)
        raise SystemExit(1) from exc
