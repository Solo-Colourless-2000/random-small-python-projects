import sys
from pathlib import Path
from tempfile import TemporaryDirectory


def observe(remove):
    with TemporaryDirectory() as folder:
        path = Path(folder) / "note.txt"
        path.write_text("LAB-DATA", encoding="ascii")
        with path.open("r", encoding="ascii") as stream:
            if remove:
                path.unlink()
            exists = path.exists()
            value = stream.read()
        return exists, value


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ("unlink", "keep"):
        print("Usage: script unlink|keep", file=sys.stderr)
        return 2
    try:
        exists, value = observe(sys.argv[1] == "unlink")
    except OSError:
        print("Temporary handle experiment failed.", file=sys.stderr)
        return 1
    print(f"Path exists: {exists}")
    print(f"Opened handle reads: {value}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
