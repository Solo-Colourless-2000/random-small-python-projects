import ast
from collections import Counter
from html.parser import HTMLParser
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
MANUAL = ROOT / "python_10_projects_day04_manual.html"


class Manual(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.ids = []
        self.links = []
        self.external_assets = []
        self.chapters = []
        self.steps = []
        self.code = {}
        self.kind = {}
        self.current = None
        self.context = []
        self.rows = []
        self.row = None
        self.cell = None
        self.feed(text)

    def handle_starttag(self, tag, attrs):
        attrs = dict(attrs)
        identifier = attrs.get("id")
        if tag == "article":
            self.context.append(identifier)
        if tag == "tr":
            self.row = []
        if tag == "td":
            self.cell = ""
        if identifier:
            self.ids.append(identifier)
        if tag == "a" and "href" in attrs:
            self.links.append(attrs["href"])
        if tag == "section" and "chapter" in attrs.get("class", "").split():
            self.chapters.append(identifier)
        if tag == "article" and "step" in attrs.get("class", "").split():
            self.steps.append(identifier)
        if tag in ("script", "img", "iframe") and "src" in attrs:
            self.external_assets.append(attrs["src"])
        if tag == "link" and attrs.get("rel") == "stylesheet":
            self.external_assets.append(attrs.get("href"))
        if tag == "code" and identifier:
            self.current = identifier
            self.code[identifier] = ""
            self.kind[identifier] = attrs.get("data-kind")

    def handle_data(self, data):
        if self.current:
            self.code[self.current] += data
        if self.cell is not None:
            self.cell += data

    def handle_endtag(self, tag):
        if tag == "code":
            self.current = None
        if tag == "td":
            self.row.append(self.cell)
            self.cell = None
        if tag == "tr" and self.row:
            self.rows.append((self.context[-1] if self.context else None, self.row))
            self.row = None
        if tag == "article":
            self.context.pop()


class Material(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.text = MANUAL.read_text(encoding="utf-8")
        cls.manual = Manual(cls.text)

    def test_sources_three_way(self):
        files = sorted((ROOT / "projects").glob("*.py"))
        self.assertEqual(len(files), 10)
        for number, file in enumerate(files, 1):
            with self.subTest(file=file.name):
                chunks = "".join(self.manual.code[f"p{number:02d}-chunk{s}"] for s in range(1, 5))
                source = self.manual.code[f"src{number:02d}"]
                self.assertEqual(chunks.encode("ascii"), file.read_bytes())
                self.assertEqual(source.encode("ascii"), file.read_bytes())
                self.assertTrue(source.endswith("\n"))
                self.assertNotIn("\t", source)

    def test_ascii_code_commands_outputs(self):
        for identifier, text in self.manual.code.items():
            with self.subTest(identifier=identifier):
                text.encode("ascii")
                self.assertNotIn(" #| ", text)
        for directory in ["projects", "samples", "tests"]:
            for file in (ROOT / directory).rglob("*"):
                if file.is_file() and file.suffix not in (".pyc",):
                    with self.subTest(file=file.name):
                        file.read_bytes().decode("ascii")
        for file in ROOT.rglob("*"):
            str(file.relative_to(ROOT)).encode("ascii")

    def test_explanations_cover_every_nonempty_line(self):
        for number, file in enumerate(sorted((ROOT / "projects").glob("*.py")), 1):
            source = file.read_text(encoding="ascii").splitlines()
            expected = {str(i): line for i, line in enumerate(source, 1) if line.strip()}
            for scope in ["full", "steps"]:
                with self.subTest(file=file.name, scope=scope):
                    rows = [row for context, row in self.manual.rows if context and ((scope == "full" and context == f"full-{number:02d}") or (scope == "steps" and context.startswith(f"p{number:02d}-step")))]
                    self.assertEqual(len(rows), len(expected))
                    actual = {row[0]: row[1] for row in rows}
                    self.assertEqual(actual, expected)
                    self.assertTrue(all(row[2].strip() for row in rows))

    def test_practice_built_from_steps_runs_all_examples(self):
        examples = json.loads((ROOT / "verification/examples.json").read_text())
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            (base / "practice").mkdir()
            (base / "samples").mkdir()
            for sample in (ROOT / "samples").iterdir():
                (base / "samples" / sample.name).write_bytes(sample.read_bytes())
            for number, file in enumerate(sorted((ROOT / "projects").glob("*.py")), 1):
                with self.subTest(file=file.name):
                    chunks = "".join(self.manual.code[f"p{number:02d}-chunk{s}"] for s in range(1, 5))
                    target = base / "practice" / file.name
                    target.write_text(chunks, encoding="ascii")
                    example = examples[number - 1]["normal"]
                    result = subprocess.run([sys.executable, str(target), *example["args"]], input=example["input"], text=True, capture_output=True, cwd=base, timeout=5)
                    self.assertEqual(result.returncode, example["status"])
                    self.assertEqual(result.stdout, example["stdout"])
                    self.assertEqual(result.stderr, example["stderr"])
            result = subprocess.run([sys.executable, str(ROOT / "tests/inspect_wav.py"), "practice/tone.wav"], cwd=base, text=True, capture_output=True, timeout=5)
            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, examples[7]["inspection"])

    def test_python310_syntax_and_compile(self):
        for file in sorted((ROOT / "projects").glob("*.py")):
            with self.subTest(file=file.name):
                text = file.read_text(encoding="ascii")
                ast.parse(text, filename=str(file), feature_version=(3, 10))
                compile(text, str(file), "exec")

    def test_html_links_ids_and_assets(self):
        duplicates = [x for x, n in Counter(self.manual.ids).items() if n > 1]
        self.assertEqual(duplicates, [])
        known = set(self.manual.ids)
        for href in self.manual.links:
            if href.startswith("#"):
                with self.subTest(href=href):
                    self.assertIn(href[1:], known)
        self.assertEqual(len(self.manual.chapters), 20)
        self.assertEqual(len(self.manual.steps), 40)
        self.assertEqual(self.manual.external_assets, [])
        self.assertNotIn("@import", self.text)
        self.assertNotIn("https://fonts", self.text)

    def test_measured_examples(self):
        examples = json.loads((ROOT / "verification/examples.json").read_text())
        self.assertEqual(len(examples), 10)
        code_values = list(self.manual.code.values())
        for example in examples:
            with self.subTest(number=example["number"]):
                self.assertIn(example["normal"]["stdout"], code_values)
                self.assertIn(example["error"]["stdout"], code_values)
                self.assertEqual(example["normal"]["status"], 0)
                self.assertEqual(example["normal"]["stderr"], "")

    def test_history_and_day_names(self):
        history = json.loads((ROOT / "PROJECT_HISTORY.json").read_text(encoding="utf-8"))
        identifiers = [p["id"] for p in history["projects"]]
        self.assertEqual(len(identifiers), 40)
        self.assertEqual(len(set(identifiers)), 40)
        self.assertEqual(sum(p["day"] == "day04" for p in history["projects"]), 10)
        self.assertIn("day04", MANUAL.name)
        self.assertIn("2026-11-09", self.text)
        self.assertIn(MANUAL.name, (ROOT / "README.txt").read_text(encoding="utf-8"))
        self.assertIn("python-day04-20261109-reader-v1", self.text)

    def test_wav_inspection_utility_errors(self):
        helper = ROOT / "tests/inspect_wav.py"
        result = subprocess.run([sys.executable, str(helper)], text=True, capture_output=True, timeout=5)
        self.assertEqual(result.returncode, 2)
        self.assertTrue(result.stdout.startswith("Usage:"))
        self.assertEqual(result.stderr, "")
        with tempfile.TemporaryDirectory() as directory:
            file = Path(directory) / "sample.wav"
            for data in [None, b"", b"TEXT"]:
                with self.subTest(data=data):
                    if data is not None:
                        file.write_bytes(data)
                    result = subprocess.run([sys.executable, str(helper), str(file)], text=True, capture_output=True, timeout=5)
                    self.assertEqual(result.returncode, 1)
                    self.assertEqual(result.stdout, "Error: cannot inspect WAV.\n")
                    self.assertEqual(result.stderr, "")


if __name__ == "__main__":
    unittest.main()
