import sys
from urllib.parse import parse_qsl


def compare(raw):
    pairs = parse_qsl(raw, keep_blank_values=True, strict_parsing=True, max_num_fields=4)
    values = []
    for key, value in pairs:
        if key != "target" or value not in ("public", "private"):
            raise ValueError("Invalid field.")
        values.append(value)
    if not values:
        raise ValueError("Missing target.")
    first = values[0]
    last = values[-1]
    guarded = len(values) == 1 and first == "public"
    return first == "public", last, guarded


def main():
    if len(sys.argv) != 2 or not 1 <= len(sys.argv[1]) <= 100 or not sys.argv[1].isascii():
        print("Usage: script QUERY (1 to 100 ASCII characters)", file=sys.stderr)
        return 2
    try:
        allowed, selected, guarded = compare(sys.argv[1])
    except ValueError:
        print("Invalid lab query.", file=sys.stderr)
        return 2
    print(f"First policy allows: {allowed}")
    print(f"Last target: {selected}")
    print(f"Unique policy allows: {guarded}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
