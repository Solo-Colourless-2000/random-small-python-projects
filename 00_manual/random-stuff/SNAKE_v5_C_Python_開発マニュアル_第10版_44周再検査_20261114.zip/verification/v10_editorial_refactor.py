#!/usr/bin/env python3
"""Source-guided manual editorial corrections. Source of truth: supplied v9 ZIP only."""
from __future__ import annotations
import ast, collections, json, re
from pathlib import Path
from bs4 import BeautifulSoup

ROOT=Path(__file__).resolve().parent.parent
DOC=next(ROOT.glob('*.html'))
REF=ROOT/'reference/Snake_C_Python'
soup=BeautifulSoup(DOC.read_text(encoding='utf-8'),'html.parser')
changes=[]

# Exact interpretations of calls that occur in the supplied game, grouped by effect.
CALLEE={
 'tk.Tk':'Tkのメインウィンドウを作る。戻り値をrootに持ち、タイトル・入力イベント・描画領域を管理する',
 'root.title':'ゲームまたは試作のウィンドウタイトルを設定する。Snakeの位置は変化しない',
 'tk.Canvas':'マス目や蛇を描くためのCanvasウィジェットを作る。幅・高さの単位はピクセル',
 'canvas.pack':'Canvasを親ウィンドウ内に配置する。ゲームの盤面データは変更しない',
 'root.bind':'指定したイベントとハンドラ関数を関連づける。コールバックはキー入力が起きた時に呼ばれる',
 'root.mainloop':'Tkのイベントループを開始し、キー入力や再描画イベントを受け付ける',
 'canvas.delete':'指定タグのCanvas描画要素を消す。C側のゲーム状態は消さない',
 'canvas.create_rectangle':'Canvasに長方形を描く。先頭4引数は左上x・y／右下x・yの画面ピクセル座標',
 'time.monotonic':'単調時計を秒単位で読み取る。移動間隔を計算するために使用し、壁時計の時刻ではない',
 'time.sleep':'指定した秒数だけテスト／処理を停止する。画面を移動させる関数ではない',
 'shutil.which':'PATHから実行可能なコンパイラ名を探し、見つからなければNoneを返す',
 'shutil.copyfile':'元のファイルから指定先へ内容をコピーする。ビルド検査では元ファイルを保護した別ディレクトリを使用する',
 'patch.multiple':'unittest.mockで、指定したモジュールの複数属性を一時的に置き換えるパッチャーを作る。プロセスの複数起動とは無関係',
 'tempfile.TemporaryDirectory':'処理終了時に削除される一時ディレクトリを作成する。テストが配布ソースを変更しないための隔離先',
 'tempfile.mkstemp':'保存先と同じディレクトリに仮ファイルを生成し、(fd, パス)を返す。書込み完了後に本ファイルと置換する',
 'os.replace':'ファイル名の置換を行う。同じファイルシステム内では原子的な名前の切替えが期待できるが、電源断後の永続性とは別',
 'os.fsync':'OSのファイル記述子に対して書込み内容の同期を要求する。親ディレクトリの永続性まで保証するものではない',
 'os.fdopen':'ファイル記述子fdをPythonのファイルオブジェクトに包む。with終了時に閉じる',
 'json.dump':'辞書などのデータをJSON形式に変換し、指定のファイルへ書き込む',
 'json.loads':'JSON文字列をPythonのオブジェクトへ復元する。不正な文字列では例外が発生する',
 'ct.CDLL':'ビルドしたC共有ライブラリを読み込む。以後、C関数の引数型と戻り値型を正しく宣言する必要がある',
 'ct.POINTER':'Cのポインタ型に対応するctypes型を作る。アドレスそのものをこの時点で読み取るわけではない',
 'ct.byref':'ctypesオブジェクトのアドレス参照を作り、C関数へ書込み先として渡す',
 'ct.create_string_buffer':'Cへ渡すために書込み可能なバイト配列を確保する',
 'dict.fromkeys':'列挙したすべての難易度名をキーにし、初期スコア0の辞書を作る',
 'max':'候補のうち大きい値を選ぶ。ここでは保存済みの最高得点を新しい低得点で上書きしない',
 'len':'配列・文字列・リストなどの要素数を求める。インデックスは0から始まる',
 'range':'繰返し用の整数列を作る。終端は含まない',
 'enumerate':'要素と0始まりの位置を対にして繰り返す',
 'zip':'複数の列から対応する要素を順に取り出す。短い列が終わると通常は終了する',
 'Path':'文字列や既存パスからPathオブジェクトを作る。/演算子でパスを組み立てられる',
 'Path.home':'利用者のホームディレクトリをPathで取得する',
 'self.engine':'テスト用ヘルパーメソッド。新しいSnakeEngineを作って検査し、後片付けできるよう管理する',
 'self.key':'GUIテストの補助メソッド。指定キーの押下を模擬してアプリの入力処理を検査する',
 'self.assertEqual':'2つの評価結果が等しいことを検査し、違えばテストを失敗にする',
 'self.assertNotEqual':'2つの評価結果が異なることを検査し、同じならテストを失敗にする',
 'self.assertTrue':'引数が真として評価されることを検査する',
 'self.assertFalse':'引数が偽として評価されることを検査する',
 'self.assertIsNone':'引数がNoneであることを検査する',
 'self.assertIsNotNone':'引数がNoneでないことを検査する',
 'self.assertIn':'第1引数が第2引数に含まれることを検査する',
 'self.assertNotIn':'第1引数が第2引数に含まれないことを検査する',
 'self.assertRaises':'指定した例外が起きることを検査する。例外が起きなければ失敗となる',
 'self.assertRaisesRegex':'指定した例外が起こり、メッセージが指定パターンに一致することを検査する',
 'self.assertGreater':'第1引数が第2引数より大きいことを検査する',
 'self.assertLess':'第1引数が第2引数より小さいことを検査する',
 'self.assertGreaterEqual':'第1引数が第2引数以上であることを検査する',
 'self.assertLessEqual':'第1引数が第2引数以下であることを検査する',
 'self.assertIsInstance':'オブジェクトが指定の型のインスタンスかを検査する',
 'self.assertCountEqual':'順序にかかわらず要素とその出現回数が一致することを検査する',
 'self.assertAlmostEqual':'小数の丸め誤差を許容する指定精度で値を比較する',
 'self.assertRegex':'文字列が正規表現に一致するか検査する',
 'self.app._draw':'Tk Canvasを現在のFrameに基づいて描き直す。Cエンジンのtickとは別',
 'self.app._on_key':'入力イベントをGameAppへ渡し、画面モードに応じて開始・一時停止・方向変更を処理する',
 'self._pause_toggle':'現在のplaying/paused状態を切り替える。一時停止中は論理的なtickを進めない',
 'self._draw':'GameAppの画面描画を行う。蛇の移動は別のtick処理が担当する',
 'self.engine.reset':'Cエンジンを初期状態へ戻す。体、得点、方向予約、餌を初期化する',
 'self.engine.tick':'C側で1マス分のゲーム処理を行う。衝突、成長、勝利の結果をEventで返す',
 'self.engine.turn':'入力された方向をCの方向予約処理へ渡す。逆走や満杯の予約は受理されない',
 'self.engine.snapshot':'Cから盤面状態を読み出してPythonのFrameに変換する',
 'self._lib.snake_snapshot':'Cのsnake_snapshotへ書込み先と体配列を渡し、現在のゲーム状態をまとめて受け取る',
}

# Source-anchored corrections: explicit observable behavior, no invented results.
SPECIAL={
 ('experiments/grid_probe.py',8):'tk.Tk()でウィンドウを生成してrootへ保持する。Canvasはこのrootに配置するため、最初にウィンドウを作る必要がある。',
 ('experiments/grid_probe.py',9):'root.title()で試作ウィンドウのタイトルバー表示を設定する。引数はウィンドウ名の文字列であり、蛇の座標には影響しない。',
 ('native/snake.c',69):'方向キューに予約があれば最後の予約方向を、空なら現在の進行方向を基準に選ぶ三項演算子の開始行。次行の ? と : まで一つの式として読む。',
 ('native/snake.c',70):'前行の三項演算子の続き。pending_countが0でなければpending[pending_count-1]、0ならgame->directionをlastにする。',
 ('native/snake.c',74):'pending_countを添字として予約方向を書込み、後置++で件数を1増やす。件数が0ならpending[0]へ格納後に1、件数が1ならpending[1]へ格納後に2になる。',
 ('native/snake.c',96):'進行方向がUPならyを1減らし、breakでswitchを抜ける。ここでは複数の文（--y と break）が同じ1行にある。',
 ('native/snake.c',97):'進行方向がRIGHTならxを1増やし、breakでswitchを抜ける。++xは更新後の値を使う前置インクリメント。',
 ('native/snake.c',98):'進行方向がDOWNならyを1増やし、breakでswitchを抜ける。Tkの画面座標は下が正方向。',
 ('native/snake.c',99):'進行方向がLEFTならxを1減らし、breakでswitchを抜ける。',
 ('native/snake.c',100):'方向値がUP/RIGHT/DOWN/LEFTのどれでもなければSNAKE_NOOPを返す。defaultとreturnが同じ行にある。',
 ('native/snake.c',110):'食べない移動では、次の瞬間に空く尻尾を衝突判定から除く（length-1）。食べる移動は伸びて尻尾が残るので全length個を検査する。',
 ('native/snake.c',117):'memmoveで体配列の先頭から(new_length-1)個を1要素後方へ移す。コピー元と先が重なるのでmemcpyでなくmemmoveが必要。引数は次行へ続く。',
 ('native/snake.c',118):'前行のmemmoveに渡すコピーサイズは (new_length - 1) × sizeof(SnakeCell)。キャスト(size_t)でバイト長の計算型を合わせる。',
 ('native/food.c',7):'game->rngに保持した32ビット符号なし乱数状態を、局所変数xへ読み込む。xはこの関数内では横座標ではない。',
 ('native/food.c',8):'乱数状態xを13ビット左シフトした値とのXORで更新する。x ^= y は x = x ^ y の略であり座標変更ではない。',
 ('native/food.c',9):'次に乱数状態xを17ビット右シフトした値とのXORで更新する。uint32_tなので空いた上位ビットは0で埋まる。',
 ('native/food.c',10):'最後に乱数状態xを5ビット左シフトした値とのXORで更新する。xorshift32の3段階目であり暗号用途には使わない。',
 ('native/food.c',17):'UINT32の2^32個の候補をboundで均等に割れない余りの領域を、thresholdとして計算する。(-bound)はunsigned 32ビット演算へ変換してから%を取るため、単なる負の整数の剰余ではない。',
 ('native/food.c',22):'threshold未満を棄却した乱数valueからvalue % boundで0〜bound-1を返す。剰余だけで選ぶ方法に比べ、範囲内候補の出現数の偏りを除く。ただし元の疑似乱数の品質は改善しない。',
 ('native/food.c',33):'最大64×64マスを記録できるuint8_t taken配列を用意して0で初期化する。0は空、1は蛇の体で占有と解釈する。',
 ('native/food.c',47):'餌の配置先に選ばれなかった空きマス1つを通過したので、choiceを1減らす。占有マスでは減らさない。',
 ('snake_app/engine.py',32):'CのSnakeCell構造体に一致するct.Structureを定義する。次行の_fields_の順序がCのint x, int yと一致しないと、座標を誤読する。',
 ('snake_app/engine.py',43):'@dataclass(frozen=True)によりFrameの初期化メソッド等を自動生成し、生成後の属性再代入を禁止する。体リストは次行以降でtupleとして保持する。',
 ('snake_app/engine.py',54):'Cライブラリの読み込み口。引数pathは指定ライブラリのPathまたはNoneで、Noneならビルド手順を呼ぶ。戻り値ct.CDLLはCのハンドルではなくライブラリを表す。',
 ('snake_app/engine.py',68):'C関数snake_createの引数型を(int, int, uint32_t)に設定する。ct.c_uint32によりseedをCの32ビット符号なし整数として渡す。',
 ('snake_app/engine.py',69):'snake_createの戻り値はゲーム状態へのポインタなのでct.c_void_pに設定する。省略するとctypesが通常intを想定し、64ビット環境でアドレスを壊す危険がある。',
 ('snake_app/engine.py',137):'Cのsnake_snapshotを呼ぶ。self._handle()はゲーム状態、ct.byref(native)は出力用C構造体のアドレス。次行で体配列と容量を渡す。',
 ('snake_app/engine.py',138):'前行のC関数へself._cells（書込み先の座標配列）とlen(self._cells)（確保した要素数）を渡す。C側はcapacityが不足していないか検査する。',
 ('snake_app/storage.py',30):'sourceからUTF-8のJSON文字列を読み込み、json.loadsで辞書などのPython値に復元する。直後に辞書型かを確認し、不正なら初期値を返す。',
 ('snake_app/storage.py',51):'保存先JSONと別の固定名.lockファイルをバイナリ追記モードで開く。handleはファイルハンドルで、Cエンジンのポインタではない。',
 ('snake_app/storage.py',60):'Windowsのmsvcrt.lockingが現在位置から1バイトをロックするため、seek(0)でファイル先頭へ位置を戻す。',
 ('snake_app/storage.py',88):'難易度ごとに、今回のスコアvalid[key]とディスクの既存スコアexisting[key]の大きい方をmergedに採用する。ロック内で再読込するので同時起動で高得点を消しにくい。',
 ('snake_app/storage.py',96):'stream.fileno()で書込み中の一時ファイルの記述子を得てos.fsyncで同期要求する。ディレクトリのfsyncはしていないため、電源断後のファイル名の永続性までは保証しない。',
 ('snake_app/storage.py',97):'一時ファイルをdestinationへos.replaceで置換する。通常、同一ファイルシステムで名前の切替えは原子的だが、電源断後の永続性とは別問題。',
 ('tests/test_engine.py',None):'テスト用ヘルパーself.engine()からSnakeEngineを作る。テスト変数eは例外オブジェクトではなくゲームエンジンを指す。',
}

try:
 import tokenize
except Exception:
 pass

# AST classification: use source lines, never infer from word spelling alone.
PY_NODES={}
for path in sorted((REF).rglob('*.py')):
 rel=path.relative_to(REF).as_posix()
 try:tree=ast.parse(path.read_text(encoding='utf8'))
 except SyntaxError:continue
 d=collections.defaultdict(list)
 for n in ast.walk(tree):
  if isinstance(n,(ast.stmt,)) and hasattr(n,'lineno'):
   d[n.lineno].append(n)
 PY_NODES[rel]=dict(d)
path=ROOT/'experiments/grid_probe.py'
PY_NODES['experiments/grid_probe.py']={}
for n in ast.walk(ast.parse(path.read_text(encoding='utf8'))):
 if isinstance(n,ast.stmt) and hasattr(n,'lineno'): PY_NODES['experiments/grid_probe.py'].setdefault(n.lineno,[]).append(n)


def short(x,limit=115):
 x=re.sub(r'\s+',' ',x).strip()
 return (x if len(x)<=limit else x[:limit-1]+'…')

def expression(expr):
 if isinstance(expr,ast.Constant):
  if expr.value is None:return '値がないことを示すNone'
  if expr.value is True:return '真を表すTrue'
  if expr.value is False:return '偽を表すFalse'
  if isinstance(expr.value,str):return f'文字列 {short(repr(expr.value),72)}'
  return f'数値 {expr.value}'
 if isinstance(expr,ast.Call):
  callee=ast.unparse(expr.func)
  effect=CALLEE.get(callee)
  if effect:return effect
  if callee.startswith('self.assert'):
   return 'unittestの検証メソッド '+callee+' を実行する'
  if callee.startswith('self.engine('):return 'テスト用SnakeEngineを作る'
  if callee.endswith('.snapshot'):return '現在のゲーム状態をFrameなどのスナップショットとして取得する'
  if callee.endswith('.tick'):return 'Cのゲーム状態を1ステップ進め、イベントを返す'
  if callee.endswith('.stat'):return 'ファイルのサイズ・更新時刻などのメタ情報を取得する'
  if callee.endswith('.read_text'):return 'ファイルから文字列を読み込む'
  if callee.endswith('.write_text'):return '文字列をファイルへ書き込む'
  if callee.endswith('.mkdir'):return '指定したディレクトリを作る'
  if callee.endswith('.resolve'):return '絶対パスへ正規化したPathを返す'
  return f'{short(callee)}({short(", ".join(ast.unparse(a) for a in expr.args),85)}) を評価する'
 if isinstance(expr,ast.ListComp):return 'for節で要素を順に作成し、リストへ集める内包表記'
 if isinstance(expr,ast.DictComp):return 'for節でキーと値を作成し、辞書を組み立てる内包表記'
 if isinstance(expr,ast.GeneratorExp):return 'for節の値を遅延評価するジェネレーター式'
 if isinstance(expr,ast.Tuple):return '複数の値を持つタプル'
 if isinstance(expr,ast.Dict):return 'キーと値を対応付ける辞書'
 if isinstance(expr,ast.List):return '複数の要素を順序付きで保持するリスト'
 if isinstance(expr,ast.BinOp) and isinstance(expr.op,ast.Div) and ('storage' in source_file or 'build' in source_file):return 'Pathに子ファイル・ディレクトリを結合したパス'
 if isinstance(expr,ast.BinOp):return f'演算式 {short(ast.unparse(expr),85)} の計算結果'
 if isinstance(expr,ast.Compare):return f'比較式 {short(ast.unparse(expr),85)} の真偽'
 if isinstance(expr,ast.IfExp):return f'条件 {short(ast.unparse(expr.test),65)} に応じて2つの候補から選んだ値'
 return short(ast.unparse(expr),100)


def improve_line(source_file, line_number, code, orig):
 special=SPECIAL.get((source_file,line_number))
 if special:return special
 if not source_file.endswith('.py') or not code.strip():return None
 items=PY_NODES.get(source_file,{}).get(line_number,[])
 if not items:return None
 # Prefer the direct statement over nested nodes on this line.
 items=sorted(items,key=lambda n: (not isinstance(n,(ast.Assign,ast.AnnAssign,ast.Expr,ast.Return,ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef,ast.Import,ast.ImportFrom,ast.If,ast.For,ast.While,ast.Try,ast.With,ast.Assert,ast.Raise)), getattr(n,'end_lineno',n.lineno)-n.lineno))
 node=items[0]
 generics=('名前だけで型を決めつけず','呼び出し先の処理を実行し','このプロジェクトの別モジュール','このファイルで必要な名前・処理','というメソッド／関数を定義する','次の字下げ範囲を実行する','で要素を取り出しながら')
 if not any(x in orig for x in generics):return None
 if isinstance(node,(ast.Assign,ast.AnnAssign)):
  val=node.value
  if val is None:return None
  dest=', '.join(ast.unparse(t) for t in node.targets) if isinstance(node,ast.Assign) else ast.unparse(node.target)
  if isinstance(val,ast.Call) and ast.unparse(val.func).startswith('self.assert'):
   return f'{expression(val)}。評価結果は {dest} に保存される。'
  desc=expression(val)
  if isinstance(val,ast.Call):
   args=', '.join(ast.unparse(a) for a in val.args)
   if val.keywords:args+= (', ' if args else '')+', '.join(f'{k.arg}={ast.unparse(k.value)}' for k in val.keywords)
   return f'右辺の {short(ast.unparse(val.func))}({short(args,130)}) を評価して {short(dest)} へ格納する。{desc}。' if len(desc)<180 else f'{short(dest)} に {short(desc,180)} の結果を保存する。'
  return f'{short(dest)} に {desc} を格納する。' if desc else None
 if isinstance(node,ast.Expr) and isinstance(node.value,ast.Call):
  c=node.value; callee=ast.unparse(c.func)
  args=', '.join(ast.unparse(a) for a in c.args)
  if c.keywords:args+= (', ' if args else '')+', '.join(f'{k.arg}={ast.unparse(k.value)}' for k in c.keywords)
  eff=CALLEE.get(callee)
  if not eff:
   if callee.endswith('.close'):eff='使い終えたゲームハンドルやファイルなどを閉じる。close後に同じハンドルを利用しない'
   elif callee.endswith('.turn'):eff='Cエンジンに方向入力を予約する。拒否された場合はFalseを返す'
   elif callee.endswith('.tick'):eff='ゲームの論理状態を1ステップ進め、イベントを返す'
   elif callee.endswith('.snapshot'):eff='現在のゲーム状態を読み取り、テストや描画で参照する'
   elif callee.endswith('.append'):eff='対象のリストの末尾に引数の要素を1件追加する'
   elif callee.endswith('.join'):eff='文字列の列を区切り文字で連結して新しい文字列を作る'
   else:eff=f'{callee}へ指定値を渡して実行する。この呼出しの定義元を前の工程と照らし、状態変更または戻り値を確認する'
  return f'呼出し {callee}({short(args,130)})。{eff}。'
 if isinstance(node,ast.Import):
  names=', '.join(a.name+(f' as {a.asname}' if a.asname else '') for a in node.names)
  effects={'sys':'OS・Python実行環境の情報や終了コード','shutil':'PATH検索（which）やファイルコピー（copyfile）','time':'経過時間を測るmonotonic','ctypes':'Cの構造体・関数・ポインタを扱う','json':'辞書とJSON文字列を相互変換する','tkinter':'Tkウィンドウ、Canvas、キーイベントを扱う','tempfile':'テスト・保存用の一時ファイルやディレクトリを作る','subprocess':'外部のCコンパイラを新しいプロセスで起動する','os':'環境変数、ファイル名置換、ファイル同期などOS操作を行う','unittest':'テストケース定義と期待値の検証を行う','pathlib':'OSごとの差を吸収したPathを使う'}
  module=node.names[0].name
  return f'{names}を読み込み、{effects.get(module,"そのモジュールが公開する関数・型")}ための名前を使えるようにする。import自体はSnakeを1マス進めない。'
 if isinstance(node,ast.ImportFrom):
  imported=', '.join(a.name for a in node.names)
  x={'unittest.mock':'patchで依存先を一時差替えしてテストする','contextlib':'contextmanagerでロック取得・解放をwith構文にまとめる','dataclasses':'dataclassで値を格納するクラスの初期化を生成する','enum':'IntEnumでCの状態番号と対応する列挙値を定義する','pathlib':'Pathで保存先やビルド対象のファイルパスを操作する','__future__':'型注釈を遅延評価する形式に切り替える'}
  src=node.module or '.'
  return f'{src}から {short(imported)} を直接取り込む。{x.get(src,"取り込んだ各名を、このファイルでモジュール名の接頭辞なしに参照する")}。'
 if isinstance(node,ast.ClassDef):
  bases=', '.join(ast.unparse(b) for b in node.bases)
  extra=f'基底クラスは {bases}。' if bases else '独自の新しいクラスを定義する。'
  if 'TestCase' in bases:extra+=' unittestの自動発見対象になるtest_メソッドをこの中に置く。'
  elif 'IntEnum' in bases:extra+=' Cに渡す整数の方向・状態を名前付き定数として扱う。'
  elif 'ct.Structure' in bases:extra+=' C構造体とのフィールド順序とABIを一致させる。'
  return f'{node.name}クラスを定義する。{extra}末尾のコロンからインデントした本体が始まる。'
 if isinstance(node,(ast.FunctionDef,ast.AsyncFunctionDef)):
  name=node.name
  args=[a.arg for a in node.args.args]
  roles={'test_':'後続のassertで期待したゲーム動作を確かめる',
   'setUp':'各テスト前に検査用のファイルやアプリ状態を準備する',
   'tearDown':'テスト後にCハンドルや一時ファイルを後片付けする',
   'setUpClass':'テストクラス全体の前処理としてCライブラリを準備する',
   'tearDownClass':'テストクラス全体で使ったリソースを片付ける',
   '_on_key':'キー入力を受け取り、画面状態に応じて方向変更や開始操作を振り分ける',
   'snapshot':'Cから盤面を取得しFrameとして返す',
   'tick':'Cのsnake_tickを呼び1ステップ進める',
   'save_scores':'難易度別のスコアを検証・統合・安全に保存する',
   'load_scores':'JSON保存データを検証して難易度別の最高点を返す',
   'ensure_library':'Cソースが更新された場合に共有ライブラリをビルドする',
   '_score_file_lock':'複数ゲームで同時にハイスコアを保存しないよう、固定ロックファイルで排他する',
   'load_library':'C共有ライブラリをロードしABIの引数・戻り値の型を登録する'}
  role=roles.get(name) or (roles['test_'] if name.startswith('test_') else f'{name}の機能を提供する')
  ann=ast.unparse(node.returns) if node.returns else '明示なし'
  return f'{name}を定義する（ここではまだ本体を実行しない）。仮引数は {", ".join(args) or "なし"}、戻り値の型注釈は {ann}。{role}。コロン以降のインデントした行が呼出し時に実行される。'
 if isinstance(node,ast.If):
  return f'条件 {short(ast.unparse(node.test),135)} が真なら、次のインデントした処理を実行する。偽ならそのブロックを飛ばす。'
 if isinstance(node,(ast.For,ast.AsyncFor)):
  return f'{short(ast.unparse(node.iter),115)} から要素を順に取り出して {ast.unparse(node.target)} へ代入し、インデントした処理を繰り返す。'
 if isinstance(node,ast.Return):
  return f'{expression(node.value)} を呼出し元に返し、この関数の処理を終了する。' if node.value else 'ここで関数を終了して、戻り値はNoneとなる。'
 if isinstance(node,ast.With):
  items=[ast.unparse(w.context_expr) for w in node.items]
  return f'withで {", ".join(items)} の管理対象を開く。インデントした範囲を抜けると、例外が起きた場合も終了処理が呼ばれる。'
 return None


# Parser-aware token rectification, independent of the line's prose summary.
TOKEN_FIXES=collections.Counter()
for article in soup.select('article.lesson-step'):
 head=article.find('h2')
 if not head:continue
 fname=head.get_text(' ',strip=True).split(' L')[0]
 for row in article.select('table.line-analysis tr:has(code.one-line)'):
  td=row.find('td');m=re.search(r'L(\d+)',td.get_text(' ',strip=True)) if td else None
  if not m:continue
  n=int(m.group(1));code_node=row.select_one('code.one-line');code=code_node.get_text(strip=False) if code_node else ''
  syn=row.select_one('p.syntactic')
  if not syn:continue
  old=syn.get_text(' ',strip=True)
  source_file=fname
  new=improve_line(fname,n,code,old)
  if new and old!=new:
   syn.string=new
   syn['class']=sorted(set(syn.get('class',[])+['source-guided-v10']))
   changes.append({'kind':'line_prose','file':fname,'line':n,'before':short(old,170),'after':short(new,235)})
  tokens=row.select('ul.token-notes li')
  for li in tokens:
   token=li.find('code')
   if token is None:continue
   val=token.get_text(' ',strip=True)
   before=li.get_text(' ',strip=True)
   desc=before.split('：',1)[1].strip() if '：' in before else ''
   replacement=None
   if fname.endswith('.py'):
    if val=='(' and re.match(r'\s*class\s+\w+\s*\(',code):replacement='基底クラス（継承元）を指定する括弧の開始。これはクラス定義であり関数呼出しではない'
    elif val==')' and re.match(r'\s*class\s+\w+\s*\(',code):replacement='継承する基底クラス一覧の終了。末尾のコロンからクラス本体が始まる'
    elif val=='(' and re.match(r'\s*from\s+.+\s+import\s*\(',code):replacement='複数行に分けて名前をimportするためのグループ開始。関数呼出しではない'
    elif val==')' and re.match(r'\s*\)\s*$',code) and 'import' in (Path(REF/fname).read_text(encoding='utf8') if fname!='experiments/grid_probe.py' else '')[:2000]:
     # safe not to override ambiguous final closing parentheses here
     replacement=None
    elif val=='e' and fname in {'tests/test_engine.py','tests/test_model.py'} and 'except' not in code:
     replacement='テストで作成したSnakeEngineの短い変数名。turn()・tick()・snapshot()でゲームを操作し、終了後はcloseする（例外eではない）'
    elif val=='handle' and fname=='snake_app/storage.py':replacement='ロック用の.lockファイルをopenしたファイルオブジェクト。seek/filenoはそのファイルに対する操作でありCのゲームハンドルではない'
    elif val=='multiple' and fname=='tests/test_build.py':replacement='unittest.mock.patch.multiple。対象モジュールの複数属性を一度に差し替える関数。複数プロセスの意味ではない'
    elif val=='engine' and fname=='tests/test_engine.py' and 'self.engine(' in code:
     replacement='テストクラスのヘルパーメソッド。SnakeEngineを生成して後片付けの対象へ登録する。既存インスタンスの属性参照ではない'
    elif val=='shutil' and fname=='tests/test_build.py':replacement='テスト隔離ディレクトリへCソースやヘッダーをコピーするためのPython標準モジュール（ここではcopyfileを使用）'
    elif val=='stat' and '.stat(' in code:replacement='path.stat()でファイルの属性情報を得る。st_mtime_nsなどの更新時刻やst_sizeを参照するために使う'
    elif val==':' and re.match(r'\s*def\s+.+\(',code) and code.rstrip().endswith(':'):
     if desc.startswith('この行の条件・関数'):
      # colons in type annotations on same line are corrected separately below
      replacement=None
    elif val=='root' and fname=='snake_app/storage.py':replacement='OSごとに取得したユーザーデータ用ディレクトリのPathオブジェクト。Tkinterのrootウィンドウではない'
    elif val=='x' and fname=='native/food.c':replacement=None
    elif val=='path' and fname=='tests/test_build.py' and 'path.stat()' in code:replacement='変更時刻を調べる対象ファイルのPath。stat()で最新更新時刻を調べ、ビルドの更新判定に用いる'
   if fname=='native/food.c' and val=='x' and 6<=n<=13:
    replacement='uint32_t型の疑似乱数状態。xorshift32でビット演算する値であり、蛇や餌の横座標ではない'
   if fname=='tests/native_checks.c' and val=='7' and '; game->food_y' in code:replacement='テストで餌のx座標とy座標の両方に指定した整数7。1行に2つの代入文がある'
   if replacement and replacement!=desc:
    token.extract()
    li.clear();li.append(token);li.append('：'+replacement)
    TOKEN_FIXES['token_semantic_repair']+=1
    changes.append({'kind':'lexeme','file':fname,'line':n,'token':val,'before':short(desc,140),'after':replacement})

  # Correction: Python type annotations with colons in function signatures, not block entry.
  if fname.endswith('.py') and code.lstrip().startswith('def ') and ':' in code:
   cols=[li for li in tokens if li.select_one('code') and li.select_one('code').get_text(' ',strip=True)==':']
   # The last ':' ends a def suite if code contains the closing colon, earlier colon introduce parameter type.
   if len(cols)>1:
    for li in cols[:-1]:
     token=li.select_one('code')
     li.clear();li.append(token);li.append('：この引数名の後ろに型注釈を記述する区切り。関数本体を開始する末尾のコロンとは別')
     TOKEN_FIXES['def_type_annotation']+=1
     changes.append({'kind':'type_annotation','file':fname,'line':n,'token':':'})
  # C: multiple statements with semicolons get source-specific explanation.
  if fname.endswith('.c') and ';' in code and code.count(';')>=2 and not code.lstrip().startswith(('for (','/*','*','//')):
   p=row.select_one('p.syntactic')
   if p and '前半' not in p.get_text(' ',strip=True):
    if 'game->food_x = ' in code and 'game->food_y = ' in code:
     value=re.search(r'game->food_x\s*=\s*([^;]+);\s*game->food_y\s*=\s*([^;]+)',code)
     if value:
      new=f'セミコロンで区切られた2つの代入を左から順に実行する。前半で餌のx座標を{value.group(1).strip()}、後半でy座標を{value.group(2).strip()}にする。1個の代入文ではない。'
      prev=p.get_text(' ',strip=True);p.string=new
      changes.append({'kind':'c_two_statements','file':fname,'line':n,'before':short(prev,170),'after':new})

# Specific failure descriptions previously mistaken: check if correction still needed.
for a in soup.select('h1,h2'):
 t=a.get_text(' ',strip=True)
 if '第9版' in t and '42周' in t and ('再検査' not in t):
  a.string=t.replace('第9版','第10版').replace('42周全体監査','前版42周の再点検を継承・新規40周再検査')
if soup.title:
 soup.title.string='SNAKE v5 C + Python 開発マニュアル【第10版・意味精査と40周以上の再検証】'
# New edition explanation without claiming verification before it is performed.
first=soup.select_one('.manual-section')
if first:
 notice=soup.new_tag('aside',attrs={'class':'source-architecture-note','id':'v10-editorial-notice'})
 h=soup.new_tag('h3');h.string='第10版：コードの意味を優先した再点検';notice.append(h)
 p=soup.new_tag('p');p.string='この版は、第9版に残っていた関数呼出し・基底クラス宣言・テスト用変数・Cの複数代入文などの文脈依存の誤説明を訂正しています。以下の「構成要素」では、記号の一般的な意味と、いま読んでいるコードでの実際の役割を区別してください。';notice.append(p)
 first.insert(0,notice)

DOC.write_text(str(soup),encoding='utf8')
report=ROOT/'verification/v10_editorial_changes.json'
report.write_text(json.dumps({'total_changes':len(changes),'by_type':dict(collections.Counter(c['kind'] for c in changes)),'changes':changes},ensure_ascii=False,indent=2),encoding='utf8')
print('source-guided changes',len(changes),collections.Counter(c['kind'] for c in changes));print('new doc bytes',DOC.stat().st_size)
