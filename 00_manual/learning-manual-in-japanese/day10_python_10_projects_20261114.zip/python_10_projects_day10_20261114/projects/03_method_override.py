import sys

CASES = {"override": ("POST", "DELETE"), "plain": ("POST", ""), "direct": ("DELETE", ""), "read": ("GET", "")}


def route(method, override):
    effective = override or method
    weak = method == "POST"
    strict = effective == "POST"
    return effective, weak, strict


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script override|plain|direct|read", file=sys.stderr)
        return 2
    method, override = CASES[sys.argv[1]]
    effective, weak, strict = route(method, override)
    print(f"Effective method: {effective}")
    print(f"Outer gate: {weak}")
    print(f"Effective gate: {strict}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
