"""24 documented third-review full-collection sweeps. Standard library only.

Each sweep checks all ten sources and their corresponding manual chapter.
Project-specific behavioral tests are independently in tests/test_extended_review.py and tests/test_third_review.py.
"""
import ast
from collections import Counter
from datetime import datetime, timezone
import html
from html.parser import HTMLParser
import json
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
TEXT=(ROOT/'python_10_projects_day03_manual.html').read_text(encoding='utf-8')
FILES=sorted((ROOT/'projects').glob('[0-9][0-9]_*.py'))
assert len(FILES)==10
EXAMPLES=json.loads((ROOT/'verification/examples.json').read_text(encoding='utf-8'))

class Manual(HTMLParser):
    def __init__(self,text):
        super().__init__(convert_charrefs=True)
        self.ids=[];self.links=[];self.assets=[];self.code={};self.lines={};self.rows=[]
        self.current_code=None;self.row=None;self.cell=None;self.article=[];self.context=[]
        self.feed(text)
    def handle_starttag(self,tag,attrs):
        a=dict(attrs); key=a.get('id')
        if key:self.ids.append(key)
        if tag=='article':self.article.append(key)
        if tag=='tr':self.row=[]
        if tag=='td':self.cell=''
        if tag=='a' and a.get('href'):self.links.append(a['href'])
        if tag in ('img','script','iframe') and a.get('src'):self.assets.append(a['src'])
        if tag=='link' and a.get('rel')=='stylesheet':self.assets.append(a.get('href'))
        if tag=='code' and key:self.current_code=key;self.code[key]=''
        if tag=='span' and 'line' in a.get('class','').split() and self.current_code:
            self.lines.setdefault(self.current_code,[]).append((int(a['data-line']),key))
    def handle_data(self,data):
        if self.current_code is not None:self.code[self.current_code]+=data
        if self.cell is not None:self.cell+=data
    def handle_endtag(self,tag):
        if tag=='code':self.current_code=None
        if tag=='td':self.row.append(self.cell);self.cell=None
        if tag=='tr' and self.row:
            self.rows.append((self.article[-1] if self.article else None,self.row))
            self.row=None
        if tag=='article':self.article.pop()

M=Manual(TEXT)
SECTIONS={}
for i in range(1,11):
    k=f'p{i:02d}'
    match=re.search(r'<section\b[^>]*\bid="'+k+r'"[^>]*>',TEXT)
    assert match,k
    end=TEXT.find('</section>',match.end())
    assert end!=-1
    SECTIONS[i]=TEXT[match.start():end+10]

rounds=[]
for turn in range(1,25):
    cases=0; evidence=[]
    for i,file in enumerate(FILES,1):
        key=f'{i:02d}';src=file.read_text(encoding='ascii');lines=src.splitlines(keepends=True)
        section=SECTIONS[i];src_id=f'src{key}'
        def check(condition,reason):
            global cases
            if not condition:raise AssertionError(f'round={turn}, project={i:02d}: {reason}')
            cases+=1
        if turn==1:
            check(src.isascii() and '\x00' not in src and '\t' not in src and '\r' not in src,'ASCII source without tabs/CR/NUL')
        elif turn==2:
            check(isinstance(ast.parse(src,feature_version=(3,10)),ast.Module),'Python 3.10 AST parse')
        elif turn==3:
            check(compile(src,str(file),'exec') is not None,'source compiles')
        elif turn==4:
            tree=ast.parse(src)
            mods={n.names[0].name.split('.')[0] for n in ast.walk(tree) if isinstance(n,ast.Import)}
            mods|={n.module.split('.')[0] for n in ast.walk(tree) if isinstance(n,ast.ImportFrom)}
            check(mods <= {'sys','string','pathlib','fractions','collections','json','difflib'},'only selected Python standard-library imports')
        elif turn==5:
            check('if __name__ == "__main__":' in src and 'raise SystemExit(main())' in src,'safe main guard')
        elif turn==6:
            check('def main():' in src and 'return 0' in src and 'return 2' in src,'success and invalid-input statuses')
        elif turn==7:
            check(src.endswith('\n') and '\r\n' not in src and file.name.startswith(key+'_'),'line endings and filename')
        elif turn==8:
            tree=ast.parse(src)
            banned={'eval','exec','compile','__import__','input' if i!=8 else '!not_banned!'}
            called={n.func.id for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Name)}
            check(not (banned & called),'no dynamic code evaluation')
        elif turn==9:
            tree=ast.parse(src)
            check(sum(isinstance(n,ast.If) for n in ast.walk(tree))>=3,'multiple explicit conditional checks')
        elif turn==10:
            check(20<=len(lines)<=65 and len(src)<3500,'small teachable program within bounded length')
        elif turn==11:
            check(M.code[src_id]==src,'appendix code exactly equals source')
        elif turn==12:
            check(''.join(M.code[f'p{key}-chunk{step}'] for step in range(1,5))==src,'four cumulative lesson steps match source')
        elif turn==13:
            spans=M.lines[src_id]
            check(spans==[(n,f'src{key}-L{n}') for n in range(1,len(lines)+1)],'appendix line numbers and anchors are consecutive')
        elif turn==14:
            refs=[x for step in range(1,5) for x in M.lines[f'p{key}-chunk{step}']]
            check([n for n,_ in refs]==list(range(1,len(lines)+1)),'four steps cover source exactly once in order')
        elif turn in (15,16):
            scope=f'full-{key}' if turn==15 else f'p{key}-step'
            rows=[row for context,row in M.rows if context and (context==scope if turn==15 else context.startswith(scope))]
            expected={n:line.rstrip('\n') for n,line in enumerate(lines,1) if line.strip()}
            found={int(row[0]):(row[1],row[2]) for row in rows}
            check(set(found)==set(expected) and all(found[n][0]==expected[n] and len(found[n][1].strip())>=9 for n in expected),'one meaningful explanation per nonblank line')
        elif turn==17:
            check('できること・入力と出力の仕様' in section and '難易度：' in section and '学習テーマ' in section,'objective, audience, and I/O specification')
        elif turn==18:
            check(f'practice/{file.name}' in section and f'projects/{file.name}' in section and f'python3 practice/{file.name}' in section,'training and completed paths plus an executable example')
        elif turn==19:
            check('ここで初めて使う言葉' in section and 'ここまでの確認' in section and '任意の復習' in section,'term definition and gradual-stage structure')
        elif turn==20:
            pids=[f'extended-p{key}-{part}' for part in range(1,4)]
            tags=[re.search(r'<p\b[^>]*\bid="'+p+r'"[^>]*>(.*?)</p>',section,re.S) for p in pids]
            texts=[html.unescape(re.sub(r'<[^>]*>','',m.group(1))) if m else '' for m in tags]
            check(all(len(t)>=65 and any('\u3040'<=ch<='\u9fff' for ch in t) for t in texts),'three substantial Japanese deep-dive explanations')
        elif turn==21:
            normal,err=EXAMPLES[i-1]['normal'],EXAMPLES[i-1]['error']
            check(normal['stdout'] in M.code.values() and err['stdout'] in M.code.values() and normal['status']==0,'measured positive/negative outputs appear in the manual')
        elif turn==22:
            check(f'id="p{key}"' in section and f'id="refine-p{key}-heading"' in section and f'id="extended-p{key}-heading"' in section and f'id="third-p{key}-heading"' in section and '完成条件' in section and '実装した範囲と制限' in section,'all three refinements and final limitations')
        elif turn==23:
            command=M.code.get(f'third-p{key}-command','')
            stdout=M.code.get(f'third-p{key}-result')
            check(command.startswith(('python3 ', 'printf ')) and isinstance(stdout,str) and len(stdout)>5 and command.endswith('\n'),'third-review executable command and measured stdout')
        elif turn==24:
            tags=[re.search(r'<p\b[^>]*\bid="third-p'+key+r'-'+part+r'"[^>]*>(.*?)</p>',section,re.S) for part in ['1','2']]
            explanations=[html.unescape(re.sub(r'<[^>]*>','',m.group(1))) if m else '' for m in tags]
            check(all(len(e)>=55 and any('ぁ'<=char<='龥' for char in e) for e in explanations) and f'id="third-p{key}-status"' in section,'two substantial concrete additions and expected exit status')
        else:raise AssertionError('unknown audit sweep')
        evidence.append(file.name)
    rounds.append({'round':turn,'focus':[
      'ASCII and control-character safety','Python 3.10 grammar','bytecode compilation',
      'standard-library-only dependencies','direct-run main guard','defined exit-status branches',
      'consistent filenames and LF endings','no dynamic code execution','explicit validations',
      'compact beginner scope','complete source appendix match','four-step source match',
      'appendix anchor sequence','four-step line coverage','appendix line-specific explanations',
      'step-level line-specific explanations','stated goals, scope and I/O','reproducible paths and CLI',
      'terminology and stage checks','substantial project-specific deep dives',
      'measured normal and error examples','all refinements and limitations',
      'third-review command and expected stdout','new explanations and expected status'
      ][turn-1],
      'checked_projects':10,'checks':cases,'status':'PASS','files':evidence})
# Global audit: also applied to every chapter through the cross-references.
assert len(M.ids)==len(set(M.ids)), 'duplicate HTML ID'
assert all(x[1:] in set(M.ids) for x in M.links if x.startswith('#')), 'broken internal anchor'
assert not M.assets, 'external JS/CSS/image dependency'
assert TEXT.count('<section class="chapter"')==20, '20 chapter count'
assert '.chapter' in TEXT and 'background:' in TEXT and 'const key =' in TEXT, 'CSS and reader JS'
record={
 'title':'third review: 24 distinct full-collection passes',
 'method':'Each of 24 distinct checks traversed all ten Python sources and their manual chapters. This is a structural/semantic code-and-doc audit, not a claim of 24 independent full human proofreading passes. Dynamic model tests are separate.',
 'total_passes':len(rounds),'projects_per_pass':10,
 'project_checks':sum(round_['checks'] for round_ in rounds),
 'global_checks':['unique HTML ids','internal anchors','no external assets','20 chapters','embedded CSS and JS'],
 'passes':rounds, 'all_pass':all(round_['status']=='PASS' for round_ in rounds)
}
path=ROOT/'verification/audit_third_24_rounds.json'
path.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('PASS:',len(rounds),'rounds,',record['project_checks'],'project-specific checks plus 5 global checks')
