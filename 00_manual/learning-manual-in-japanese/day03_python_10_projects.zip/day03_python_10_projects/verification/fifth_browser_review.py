from playwright.sync_api import sync_playwright
from pathlib import Path
import json

ROOT=Path(__file__).resolve().parents[1]
entries=[]
with sync_playwright() as p:
    browser=p.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
    for width in [320,390,1440]:
        page=browser.new_page(viewport={'width':width,'height':850},device_scale_factor=1)
        errors=[]
        page.on('pageerror',lambda e:errors.append(str(e)))
        page.set_content((ROOT/'python_10_projects_day03_manual.html').read_text(encoding='utf-8'),wait_until='load',timeout=30000)
        page.evaluate('location.hash = "#fifth-deep-dive-07"')
        page.wait_for_timeout(750)
        active=page.locator('#p07').get_attribute('class') or ''
        overflow=page.evaluate('document.documentElement.scrollWidth - window.innerWidth')
        is_visible=page.locator('#fifth-deep-dive-07 .fifth-worked-trace').is_visible()
        assert 'active' in active and is_visible,(width,active,is_visible)
        assert overflow<=1,(width,overflow)
        page.locator('#fifth-deep-dive-07').screenshot(path=str(ROOT/'verification'/f'fifth_browser_trace_{width}px.png'))
        page.locator('#search').fill('object_pairs_hook')
        page.wait_for_timeout(80)
        matches=page.locator('#search-count').inner_text()
        assert '件' in matches,(width,matches)
        page.locator('#clear-search').click()
        details=page.locator('#p07 details.syntax-breakdown').first
        details.evaluate('(e)=>{let p=e.parentElement.closest("details");while(p){p.open=true;p=p.parentElement.closest("details")}}')
        details.locator('summary').click(timeout=8000)
        assert details.evaluate('(e)=>e.open')
        entries.append({'width_px':width,'page_errors':errors,'overflow_px':overflow,'p07_trace_visible':is_visible,'search_result':matches,'expand_details':True})
        assert not errors,errors
        page.close()
    # Switch to no-JS mode to make sure the entire manual remains readable.
    page=browser.new_page(java_script_enabled=False,viewport={'width':390,'height':900})
    page.set_content((ROOT/'python_10_projects_day03_manual.html').read_text(encoding='utf-8'),wait_until='load',timeout=30000)
    assert page.locator('section.chapter').count()==20
    hidden=page.locator('.chapter').evaluate_all('(els)=>els.filter(e=>getComputedStyle(e).display==="none").length')
    assert hidden==0,hidden
    entries.append({'javascript_disabled':True,'chapters_visible':20})
    page.close()
    browser.close()
report={'chromium':'system Chromium; local HTML injected via set_content because file:// and 127.0.0.1 navigation are blocked by the test environment','results':entries,'passed':True,'limitations':'LocalStorage persistence and clipboard permissions are not validated in this navigation-restricted browser; DOM interactions and responsive overflow were checked.'}
(ROOT/'verification/fifth_browser_review.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(report,ensure_ascii=False,indent=2))
