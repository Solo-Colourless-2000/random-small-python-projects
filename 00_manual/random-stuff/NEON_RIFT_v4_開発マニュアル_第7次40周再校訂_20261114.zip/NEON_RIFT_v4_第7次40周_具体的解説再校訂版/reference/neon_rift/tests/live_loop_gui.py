"""Runs the actual event loop for a short timed interval (requires display)."""
import sys
import time
import tkinter as tk
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from game import Game

root = tk.Tk()
game = Game(root, seed=6)
game.save_best = lambda: None
game.start()
start = time.perf_counter()
root.after(1500, game.close)
root.mainloop()
wall = time.perf_counter() - start
ratio = game.elapsed / wall
print(f'LIVE LOOP: real {wall:.2f}s / simulated {game.elapsed:.2f}s / ratio {ratio:.2f}')
assert 0.78 < ratio <= 1.06, 'Simulation clock is substantially slower than real time'
