import ast
import importlib.util
import json
import os
from pathlib import Path
import signal
import subprocess
import sys
import tempfile
import time
import unittest

ROOT = Path(__file__).resolve().parents[1]
FILES = sorted((ROOT / "projects").glob("*.py"))
RUNS = []


def run(number, args=(), data="", cwd=None):
    result = subprocess.run(
        [sys.executable, str(FILES[number - 1]), *args],
        input=data, text=True, capture_output=True, cwd=cwd or ROOT, timeout=5
    )
    RUNS.append({"project": number, "args": list(args), "input": data,
                 "status": result.returncode, "stdout": result.stdout,
                 "stderr": result.stderr})
    return result


class Programs(unittest.TestCase):
    def check(self, number, args, status, output, data="", cwd=None):
        result = run(number, args, data, cwd)
        self.assertEqual(result.returncode, status, result.stderr)
        self.assertEqual(result.stdout, output)
        self.assertEqual(result.stderr, "")
        return result

    def errors(self, number, cases, prefix="Error:"):
        for args in cases:
            with self.subTest(args=args):
                result = run(number, args)
                self.assertEqual(result.returncode, 2)
                self.assertTrue(result.stdout.startswith(prefix), result.stdout)
                self.assertEqual(result.stderr, "")

    def test_01_bits_known(self):
        self.check(1, ["13"], 0, "Binary: 00001101\nBit 0: 1\nBit 1: 0\nBit 2: 1\nBit 3: 1\nBit 4: 0\nBit 5: 0\nBit 6: 0\nBit 7: 0\nOn bits: 3\n")

    def test_01_bits_boundaries(self):
        for value, bits, count in [(0, "00000000", 0), (255, "11111111", 8), (128, "10000000", 1)]:
            with self.subTest(value=value):
                result = run(1, [str(value)])
                self.assertEqual(result.returncode, 0)
                lines = result.stdout.splitlines()
                self.assertEqual(lines[0], "Binary: " + bits)
                actual_bits = [int(line.split(": ")[1]) for line in lines[1:9]]
                self.assertEqual(sum(actual_bits), count)
                self.assertEqual(sum(bit * 2 ** pos for pos, bit in enumerate(actual_bits)), value)
                self.assertEqual(lines[-1], f"On bits: {count}")
                self.assertEqual(result.stderr, "")

    def test_01_bits_invalid(self):
        self.errors(1, [["-1"], ["256"], [""], ["abc"], ["1.0"], ["1" * 11]])

    def test_02_packing_known(self):
        self.check(2, ["Pen, book, pen, CUP"], 0, "Items: 3\n1. pen\n2. book\n3. cup\n")
        self.check(2, ["rope,rope,bottle"], 0, "Items: 2\n1. rope\n2. bottle\n")

    def test_02_ascii_is_checked_before_lowercase(self):
        # Unicode Kelvin sign lowercases to ASCII k unless rejected first.
        for raw in ["\u212a", "a,\u00a0b", "pen,\u212a", "\u3000A"]:
            with self.subTest(value=raw):
                self.check(2, [raw], 2, "Error: use at most 300 ASCII characters.\n")
        self.check(2, ["Pen, book, pen, CUP"], 0,
                   "Items: 3\n1. pen\n2. book\n3. cup\n")

    def test_02_packing_boundaries(self):
        self.check(2, ["a" * 20], 0, "Items: 1\n1. " + "a" * 20 + "\n")
        labels = [str(n) for n in range(12)]
        expected = "Items: 12\n" + "".join(f"{i}. {label}\n" for i, label in enumerate(labels, 1))
        self.check(2, [",".join(labels)], 0, expected)

    def test_02_packing_invalid(self):
        self.errors(2, [[""], [" "], ["a,,b"], ["a,"], ["a" * 21], ["a!"] , [",".join(["a"] * 13)], ["a" * 301]])

    def test_03_runs_known(self):
        self.check(3, ["AAABBA"], 0, "Runs: A:3 B:2 A:1\nLength: 6\n")
        self.check(3, ["ABAB"], 0, "Runs: A:1 B:1 A:1 B:1\nLength: 4\n")

    def test_03_runs_roundtrip(self):
        for text in ["A", "Z" * 80, "AB" * 40, "AAABBCCCCDDDA"]:
            with self.subTest(text=text):
                result = run(3, [text])
                self.assertEqual(result.returncode, 0)
                tokens = result.stdout.splitlines()[0].removeprefix("Runs: ").split()
                recovered = ""
                previous = None
                for token in tokens:
                    character, count = token.split(":")
                    self.assertNotEqual(character, previous)
                    self.assertGreater(int(count), 0)
                    recovered += character * int(count)
                    previous = character
                self.assertEqual(recovered, text)
                self.assertEqual(result.stdout.splitlines()[1], f"Length: {len(text)}")
                self.assertEqual(result.stderr, "")

    def test_03_runs_invalid(self):
        self.errors(3, [[""], ["A" * 81], ["abc"], ["A B"], ["A1"]])

    def test_04_brackets_known(self):
        for text, expected in [("([])", "Balanced"), ("([)]", "Mismatch at 3"), ("(()", "Unclosed"), ("())", "Mismatch at 3"), ("]", "Mismatch at 1"), ("(", "Unclosed"), ("[]" * 40, "Balanced")]:
            with self.subTest(text=text):
                self.check(4, [text], 0, expected + "\n")

    def test_04_brackets_invalid(self):
        self.errors(4, [[""], ["() "], ["{}"], ["(" * 81]])

    def test_05_merge_known(self):
        self.check(5, ["1,4,4", "2,3,8"], 0, "Merged: 1 2 3 4 4 8\n")
        self.check(5, ["1,1", "1"], 0, "Merged: 1 1 1\n")

    def test_05_merge_invariants(self):
        from collections import Counter
        examples = [([-99], [99]), ([99], [-99]), ([0] * 8, [0] * 8), ([-9, 0, 2], [-9, -1, 2, 4]), ([1, 2, 3], [7])]
        for left, right in examples:
            with self.subTest(left=left, right=right):
                result = run(5, [",".join(map(str, left)), ",".join(map(str, right))])
                self.assertEqual(result.returncode, 0)
                output = list(map(int, result.stdout.removeprefix("Merged: ").split()))
                self.assertEqual(len(output), len(left) + len(right))
                self.assertEqual(Counter(output), Counter(left + right))
                self.assertTrue(all(a <= b for a, b in zip(output, output[1:])))
                self.assertEqual(result.stderr, "")

    def test_05_merge_invalid(self):
        self.errors(5, [["", "1"], ["2,1", "1"], ["100", "1"], ["-100", "1"], ["1,,2", "1"], ["1.5", "1"], [",".join(["1"] * 9), "1"], ["1" * 41, "1"]])

    def test_06_diff_known(self):
        self.check(6, ["samples/before.txt", "samples/after.txt"], 0, "--- before\n+++ after\n@@ -1,3 +1,3 @@\n red\n-green\n+gold\n blue\n")
        self.check(6, ["samples/before.txt", "samples/before.txt"], 0, "No differences.\n")

    def test_06_diff_edges_and_no_mutation(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            a, b = base / "a.txt", base / "b.txt"
            for first, second, expected in [(b"", b"", "No differences.\n"), (b"a\r\n", b"a", "No differences.\n"), (b"x" * 4096, b"x" * 4096, "No differences.\n")]:
                with self.subTest(size=len(first)):
                    a.write_bytes(first)
                    b.write_bytes(second)
                    self.check(6, [str(a), str(b)], 0, expected)
                    self.assertEqual(a.read_bytes(), first)
                    self.assertEqual(b.read_bytes(), second)

    def test_06_diff_read_errors(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            a = base / "a.txt"
            self.check(6, [str(a), str(a)], 1, "Error: cannot read UTF-8 files.\n")
            self.check(6, [str(base), str(base)], 1, "Error: cannot read UTF-8 files.\n")
            a.write_bytes(bytes([255]))
            self.check(6, [str(a), str(a)], 1, "Error: cannot read UTF-8 files.\n")
            a.write_text("x" * 4097, encoding="ascii")
            self.check(6, [str(a), str(a)], 2, "Error: each file must have at most 4096 characters.\n")

    def test_07_checklist_known_and_exclusive(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "check.md"
            result = run(7, [str(ROOT / "samples/tasks.json"), str(output)])
            self.assertEqual(result.returncode, 0)
            self.assertEqual(result.stdout, f"Saved: {output}\n")
            self.assertEqual(result.stderr, "")
            expected = b"- [x] Read\n- [ ] Practice\n"
            self.assertEqual(output.read_bytes(), expected)
            self.check(7, [str(ROOT / "samples/tasks.json"), str(output)], 1, "Error: cannot create output; choose a new path.\n")
            self.assertEqual(output.read_bytes(), expected)

    def test_07_checklist_valid_limits(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            source, output = base / "tasks.json", base / "out.md"
            for count, name in [(1, "a"), (8, "A" * 30), (2, " Read ")]:
                with self.subTest(count=count, name=name):
                    source.write_text(json.dumps([{"name": name, "done": False}] * count), encoding="ascii")
                    result = run(7, [str(source), str(output)])
                    self.assertEqual(result.returncode, 0)
                    self.assertEqual(output.read_text(), (f"- [ ] {name}\n") * count)
                    self.assertEqual(result.stderr, "")
                    output.unlink()

    def test_07_checklist_invalid_structure_no_output(self):
        examples = [[], {}, None, 1, [1], [{"name": "a"}], [{"name": "a", "done": False, "extra": 1}], [{"name": 3, "done": True}], [{"name": "", "done": True}], [{"name": " " , "done": True}], [{"name": "a" * 31, "done": True}], [{"name": "a*", "done": True}], [{"name": "a", "done": "false"}], [{"name": "a", "done": 1}], [{"name": "a", "done": False}] * 9, [{"name": "ok", "done": True}, {"name": "bad*", "done": False}]]
        with tempfile.TemporaryDirectory() as directory:
            source, output = Path(directory) / "a.json", Path(directory) / "out.md"
            for example in examples:
                with self.subTest(example=example):
                    source.write_text(json.dumps(example), encoding="ascii")
                    result = run(7, [str(source), str(output)])
                    self.assertEqual(result.returncode, 2)
                    self.assertTrue(result.stdout.startswith("Error:"))
                    self.assertEqual(result.stderr, "")
                    self.assertFalse(output.exists())

    def test_07_checklist_bad_files(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            source, output = base / "a.json", base / "out.md"
            self.check(7, [str(source), str(output)], 1, "Error: cannot read the UTF-8 input.\n")
            for text in ["", "{", " " * 4097]:
                with self.subTest(text_length=len(text)):
                    source.write_text(text, encoding="ascii")
                    self.check(7, [str(source), str(output)], 2, "Error: use valid JSON within 4096 characters.\n")
                    self.assertFalse(output.exists())
            self.check(7, [str(base), str(output)], 1, "Error: cannot read the UTF-8 input.\n")
            source.write_bytes(bytes([255]))
            self.check(7, [str(source), str(output)], 1, "Error: cannot read the UTF-8 input.\n")
            self.check(7, [str(ROOT / "samples/tasks.json"), str(base / "missing/out.md")], 1, "Error: cannot create output; choose a new path.\n")
            self.check(7, [str(ROOT / "samples/tasks.json"), str(base)], 1, "Error: cannot create output; choose a new path.\n")

    @unittest.skipIf(os.name != "posix" or os.geteuid() == 0, "needs non-root POSIX permissions")
    def test_file_permission_errors(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            source = base / "locked.txt"
            source.write_text("[]", encoding="ascii")
            source.chmod(0)
            try:
                self.check(6, [str(source), str(source)], 1, "Error: cannot read UTF-8 files.\n")
                self.check(7, [str(source), str(base / "out.md")], 1, "Error: cannot read the UTF-8 input.\n")
            finally:
                source.chmod(0o600)
            folder = base / "locked"
            folder.mkdir()
            folder.chmod(0o500)
            try:
                self.check(7, [str(ROOT / "samples/tasks.json"), str(folder / "out.md")], 1, "Error: cannot create output; choose a new path.\n")
                self.assertFalse((folder / "out.md").exists())
            finally:
                folder.chmod(0o700)

    def test_08_queue_known(self):
        data = "add Ada\nadd Bob\nnext\nshow\nquit\n"
        self.check(8, [], 0, "Commands: add NAME, next, show, quit\nQueue> Added: Ada\nQueue> Added: Bob\nQueue> Serving: Ada\nQueue> Waiting: Bob\nQueue> Bye\n", data)

    def test_08_queue_edges(self):
        intro = "Commands: add NAME, next, show, quit\n"
        self.check(8, [], 0, intro + "Queue> Empty\nQueue> Waiting: \nQueue> Bye\n", "next\nshow\nquit\n")
        self.check(8, [], 0, intro + "Queue> Added: " + "a" * 12 + "\nQueue> Bye\n", "add " + "a" * 12 + "\nquit\n")
        data = "add Ada\n" * 5 + "show\nquit\n"
        self.check(8, [], 0, intro + "Queue> Added: Ada\n" * 5 + "Queue> Waiting: Ada, Ada, Ada, Ada, Ada\nQueue> Bye\n", data)
        self.check(8, [], 2, intro + "Queue> Added: Ada\n" * 5 + "Queue> Error: queue is full.\n", "add Ada\n" * 6)
        self.check(8, [], 0, intro + "Queue> Waiting: \n" * 49 + "Queue> Bye\n", "show\n" * 49 + "quit\n")
        self.check(8, [], 2, intro + "Queue> Waiting: \n" * 50 + "Error: command limit reached.\n", "show\n" * 50)

    def test_08_queue_invalid(self):
        for data in ["\n", " \n", "add\n", "add A B\n", "other\n", "add A1\n", "add " + "a" * 13 + "\n", "a" * 41 + "\n"]:
            with self.subTest(data=data):
                result = run(8, [], data)
                self.assertEqual(result.returncode, 2)
                self.assertIn("Error:", result.stdout)
                self.assertEqual(result.stderr, "")

    def test_08_queue_eof(self):
        self.check(8, [], 1, "Commands: add NAME, next, show, quit\nQueue> \nStopped.\n", "")
        self.check(8, [], 1, "Commands: add NAME, next, show, quit\nQueue> Added: Ada\nQueue> \nStopped.\n", "add Ada\n")

    @unittest.skipUnless(os.name == "posix", "POSIX signal test")
    def test_08_queue_interrupt(self):
        import select
        process = subprocess.Popen([sys.executable, "-u", str(FILES[7])], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        output = b""
        deadline = time.monotonic() + 5
        try:
            while not output.endswith(b"Queue> "):
                self.assertLess(time.monotonic(), deadline, "input prompt timeout")
                ready, _, _ = select.select([process.stdout], [], [], 0.1)
                if ready:
                    chunk = os.read(process.stdout.fileno(), 4096)
                    self.assertTrue(chunk, "process exited before prompt")
                    output += chunk
            process.send_signal(signal.SIGINT)
            rest, error = process.communicate(timeout=5)
            output += rest
            self.assertEqual(process.returncode, 1)
            self.assertTrue(output.endswith(b"Queue> \nStopped.\n"))
            self.assertEqual(error, b"")
            RUNS.append({"project": 8, "args": [], "signal": "SIGINT", "status": process.returncode, "stdout": output.decode(), "stderr": error.decode()})
        finally:
            if process.poll() is None:
                process.kill()
                process.communicate()

    def test_09_fractions_known(self):
        for args, value, numerator, denominator in [(["1/3", "+", "1/6"], "1/2", 1, 2), (["1/2", "/", "1/3"], "3/2", 3, 2), (["-1/2", "*", "2/3"], "-1/3", -1, 3), (["1/3", "-", "1/2"], "-1/6", -1, 6), (["2/4", "+", "0"], "1/2", 1, 2), (["10000", "+", "10000"], "20000", 20000, 1), (["1/10000", "+", "0"], "1/10000", 1, 10000), (["0", "*", "10000"], "0", 0, 1)]:
            with self.subTest(args=args):
                self.check(9, args, 0, f"Result: {value}\nNumerator: {numerator}\nDenominator: {denominator}\n")

    def test_09_fractions_invalid(self):
        self.errors(9, [["1", "/", "0"], ["1/0", "+", "1"], ["10001", "+", "0"], ["1/10001", "+", "0"], ["", "+", "0"], ["1.2", "+", "0"], ["nan", "+", "0"], ["1/-2", "+", "0"], ["1//2", "+", "0"], ["1", "**", "2"], ["1" * 13, "+", "0"]])

    def test_10_cells_known(self):
        self.check(10, ["00100", "2"], 0, "0: 00100\n1: 01010\n2: 10001\n")
        self.check(10, ["010", "0"], 0, "0: 010\n")
        self.check(10, ["010", "1"], 0, "0: 010\n1: 101\n")

    def test_10_cells_invariants(self):
        for state, generations in [("0" * 21, 8), ("00100", 8), ("111", 2), ("1" + "0" * 20, 1)]:
            with self.subTest(state=state, generations=generations):
                result = run(10, [state, str(generations)])
                self.assertEqual(result.returncode, 0)
                actual = [line.split(": ")[1] for line in result.stdout.splitlines()]
                self.assertEqual(len(actual), generations + 1)
                model = [int(c) for c in state]
                self.assertEqual(actual[0], state)
                for output in actual[1:]:
                    padded = [0] + model + [0]
                    model = [int((padded[i] + padded[i + 2]) % 2) for i in range(len(model))]
                    self.assertEqual(output, "".join(map(str, model)))
                    self.assertEqual(len(output), len(state))
                self.assertEqual(result.stderr, "")

    def test_10_cells_invalid(self):
        self.errors(10, [["", "1"], ["01", "1"], ["0" * 22, "1"], ["01a", "1"], ["010", "-1"], ["010", "9"], ["010", ""], ["010", "abc"], ["010", "1.5"], ["010", "000"]])

    def test_argument_counts(self):
        required = {1: ["1"], 2: ["a"], 3: ["A"], 4: ["()"], 5: ["1", "2"], 6: ["a", "b"], 7: ["a", "b"], 9: ["1", "+", "2"], 10: ["010", "1"]}
        for number, valid in required.items():
            for args in [[], valid + ["extra"]]:
                with self.subTest(number=number, args=args):
                    self.errors(number, [args], "Usage:")

    def test_import_has_no_side_effects(self):
        for file in FILES:
            with self.subTest(file=file.name):
                code = "import importlib.util; s=importlib.util.spec_from_file_location('lesson', " + repr(str(file)) + "); m=importlib.util.module_from_spec(s); s.loader.exec_module(m)"
                result = subprocess.run([sys.executable, "-c", code], text=True, capture_output=True, timeout=5, cwd=ROOT)
                self.assertEqual((result.returncode, result.stdout, result.stderr), (0, "", ""))


if __name__ == "__main__":
    unittest.main()
