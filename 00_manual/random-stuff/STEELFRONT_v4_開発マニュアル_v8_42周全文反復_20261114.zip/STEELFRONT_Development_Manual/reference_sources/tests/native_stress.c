/* Native gameplay simulation stress under ASan/UBSan, not a post-death no-op loop.
 * Build with -DENGINE_TESTING to allow controlled wave progression. */
#include "../engine/tank_engine.h"
#include <math.h>
#include <stdio.h>
#include <stdint.h>
#include <stdlib.h>

#ifdef ENGINE_TESTING
extern void debug_clear_enemies(void);
extern void debug_invulnerability(float seconds);
#else
#error Native stress requires the test-only C hooks
#endif

static uint32_t seed=0x7f328a91u;
static uint32_t next(void) {seed^=seed<<13;seed^=seed>>17;seed^=seed<<5;return seed;}
static float sample(float lo,float hi) {return lo+(hi-lo)*(next()/(float)UINT32_MAX);}

int main(void) {
    Snapshot *s=(Snapshot*)malloc(sizeof(Snapshot));
    if(!s) return 9;
    unsigned long active_frames=0, resets=0, transitions=0, boss_waves=0;
    for(int run=0;run<24;run++) {
        engine_reset(1234u+(unsigned)run*38491u);
        engine_next_wave();
        for(int k=0;k<2400;k++) {
            engine_snapshot(s);
            if(!s->player_alive) {
                engine_reset(4000u+(unsigned)run*773u+(unsigned)k);
                engine_next_wave();
                engine_snapshot(s);
                resets++;
            }
            /* Half the runs force survivability so later waves and bosses are
             * stress-tested. The other half also exercise deaths/restarts. */
            if(run%2==0 && k%130==0) debug_invulnerability(8.0f);
            if(k>0 && k%210==0) {
                debug_clear_enemies();
                engine_upgrade((int)(next()%11u));
                engine_next_wave();
                transitions++;
                engine_snapshot(s);
                if(s->wave%5==0) {
                    int found=0;
                    for(int i=0;i<MAX_ENEMIES;i++)
                        if(s->enemies[i].active && s->enemies[i].type==ENEMY_BOSS)
                            found++;
                    if(found!=1) {
                        fprintf(stderr,"expected one boss at wave %d, got %d\n",s->wave,found);
                        free(s);return 3;
                    }
                    boss_waves++;
                }
            }
            Control c={0};
            c.move_x=sample(-1,1);c.move_y=sample(-1,1);
            c.aim_x=sample(-80,WORLD_W+80);c.aim_y=sample(-80,WORLD_H+80);
            c.fire=(next()%3)!=0;c.dash=(next()%80)==0;c.pulse=(next()%160)==0;
            engine_step(&c,1.0f/60.0f);
            active_frames++;
            if(k%90==0) {
                engine_snapshot(s);
                if(!isfinite(s->player.x) || !isfinite(s->player.y) ||
                   !isfinite(s->player.hp) || !isfinite(s->time) ||
                   !isfinite(s->focus_timer) ||
                   s->enemy_count<0 || s->enemy_count>MAX_ENEMIES ||
                   s->bullet_count<0 || s->bullet_count>MAX_BULLETS ||
                   s->event_count<0 || s->event_count>MAX_EVENTS ||
                   s->score<0 || s->score>99999999) {
                    fprintf(stderr,"invalid state run %d frame %d\n",run,k);
                    free(s);return 1;
                }
            }
        }
    }
    free(s);
    if(active_frames!=57600 || transitions<100 || boss_waves==0) {
        fprintf(stderr,"insufficient coverage frames=%lu waves=%lu bosses=%lu\n",
                active_frames,transitions,boss_waves);
        return 2;
    }
    printf("PASS: %lu active engine_step frames, %lu controlled wave changes, %lu boss-wave checks, %lu death resets\n",
           active_frames,transitions,boss_waves,resets);
    return 0;
}
