"""Score file corruption, strict types, directory handling and safe replacement."""
from __future__ import annotations

import json
import subprocess
import sys
from pathlib import Path
import tempfile
import unittest
from unittest.mock import patch

from snake_app.storage import DIFFICULTIES, load_scores, save_scores


class StorageTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name) / "nested" / "highscores.json"

    def test_missing_file_returns_zeroes(self) -> None:
        self.assertEqual(load_scores(self.path), dict.fromkeys(DIFFICULTIES, 0))

    def test_roundtrip_creates_parent_directory(self) -> None:
        data = {"EASY": 12, "NORMAL": 36, "HARD": 7}
        self.assertTrue(save_scores(data, self.path))
        self.assertEqual(load_scores(self.path), data)

    def test_atomic_save_leaves_no_temporary_file(self) -> None:
        self.assertTrue(save_scores({"EASY": 1}, self.path))
        self.assertEqual(sorted(p.name for p in self.path.parent.iterdir()),
                         ["highscores.json", "highscores.json.lock"])

    def test_corrupted_json_is_ignored(self) -> None:
        self.path.parent.mkdir()
        self.path.write_text('{"EASY": 44', encoding="utf-8")
        self.assertEqual(load_scores(self.path)["EASY"], 0)

    def test_wrong_root_type_is_ignored(self) -> None:
        self.path.parent.mkdir()
        self.path.write_text("[1, 2, 3]", encoding="utf-8")
        self.assertEqual(load_scores(self.path)["NORMAL"], 0)

    def test_bad_field_values_do_not_corrupt_valid_ones(self) -> None:
        self.path.parent.mkdir()
        self.path.write_text(json.dumps({"EASY": True, "NORMAL": 20, "HARD": -3}))
        self.assertEqual(load_scores(self.path), {"EASY": 0, "NORMAL": 20, "HARD": 0})

    def test_oversized_input_is_ignored(self) -> None:
        self.path.parent.mkdir()
        self.path.write_bytes(b" " * 16385)
        self.assertEqual(load_scores(self.path)["EASY"], 0)

    def test_out_of_bounds_value_is_ignored(self) -> None:
        self.path.parent.mkdir()
        self.path.write_text('{"EASY": 999999, "NORMAL": 4}')
        self.assertEqual(load_scores(self.path)["EASY"], 0)
        self.assertEqual(load_scores(self.path)["NORMAL"], 4)

    def test_invalid_utf8_is_ignored(self) -> None:
        self.path.parent.mkdir()
        self.path.write_bytes(b"\xff\xfe")
        self.assertEqual(load_scores(self.path)["EASY"], 0)

    def test_save_failure_does_not_raise(self) -> None:
        self.path.parent.mkdir()
        self.path.mkdir()
        self.assertFalse(save_scores({"EASY": 12}, self.path))

    def test_invalid_save_does_not_erase_valid_file(self) -> None:
        self.assertTrue(save_scores({"EASY": 12}, self.path))
        before = self.path.read_bytes()
        for bad in (True, -1, 4097, float("nan"), "20", None):
            with self.subTest(bad=bad):
                self.assertFalse(save_scores({"EASY": bad}, self.path))
                self.assertEqual(self.path.read_bytes(), before)

    def test_save_can_overwrite_previous_file(self) -> None:
        self.assertTrue(save_scores({"EASY": 1}, self.path))
        self.assertTrue(save_scores({"EASY": 9}, self.path))
        self.assertEqual(load_scores(self.path)["EASY"], 9)

    def test_stale_game_instance_cannot_lower_stored_record_sequentially(self) -> None:
        self.assertTrue(save_scores({"EASY": 35, "NORMAL": 2}, self.path))
        self.assertTrue(save_scores({"EASY": 8, "NORMAL": 7}, self.path))
        self.assertEqual(load_scores(self.path), {"EASY": 35, "NORMAL": 7, "HARD": 0})

    def test_merge_does_not_accept_corrupt_disk_value(self) -> None:
        self.path.parent.mkdir(parents=True)
        self.path.write_text('{"EASY": 1000000, "NORMAL": 3}', encoding="utf-8")
        self.assertTrue(save_scores({"EASY": 4}, self.path))
        self.assertEqual(load_scores(self.path), {"EASY": 4, "NORMAL": 3, "HARD": 0})

    def test_lock_is_released_after_failed_replacement(self) -> None:
        self.assertTrue(save_scores({"EASY": 8}, self.path))
        with patch("snake_app.storage.os.replace", side_effect=OSError("disk full")):
            self.assertFalse(save_scores({"EASY": 15}, self.path))
        self.assertTrue(save_scores({"NORMAL": 11}, self.path))
        self.assertEqual(load_scores(self.path),
                         {"EASY": 8, "NORMAL": 11, "HARD": 0})
        self.assertFalse(any(p.suffix == ".tmp" for p in self.path.parent.iterdir()))

    def test_concurrent_processes_do_not_erase_each_others_high_scores(self) -> None:
        # Deliberately stretch the read/merge phase. This detects a real race:
        # atomic os.replace alone protects JSON integrity, not lost updates.
        project = Path(__file__).resolve().parents[1]
        script = """
import sys, time
from pathlib import Path
import snake_app.storage as storage
path = Path(sys.argv[1]); start = Path(sys.argv[2])
field = sys.argv[3]; value = int(sys.argv[4])
while not start.exists(): time.sleep(0.005)
original = storage.load_scores
def slow_load(file):
    result = original(file)
    time.sleep(0.06)
    return result
storage.load_scores = slow_load
assert storage.save_scores({field: value}, path)
"""
        start = self.path.parent.parent / "start.flag"
        workers = []
        try:
            for field, value in (("EASY", 41), ("NORMAL", 52),
                                 ("HARD", 63), ("EASY", 72)):
                workers.append(subprocess.Popen(
                    [sys.executable, "-c", script, str(self.path), str(start),
                     field, str(value)], cwd=project,
                    stdout=subprocess.PIPE, stderr=subprocess.PIPE, text=True))
            start.touch()
            for worker in workers:
                out, err = worker.communicate(timeout=20)
                self.assertEqual(worker.returncode, 0, err + out)
            self.assertEqual(load_scores(self.path),
                             {"EASY": 72, "NORMAL": 52, "HARD": 63})
        finally:
            for worker in workers:
                if worker.poll() is None:
                    worker.kill()
                    worker.communicate()

    def test_saved_document_contains_only_expected_keys(self) -> None:
        save_scores({"EASY": 1, "UNKNOWN": 100}, self.path)
        data = json.loads(self.path.read_text(encoding="utf-8"))
        self.assertEqual(set(data), set(DIFFICULTIES))


if __name__ == "__main__":
    unittest.main()
