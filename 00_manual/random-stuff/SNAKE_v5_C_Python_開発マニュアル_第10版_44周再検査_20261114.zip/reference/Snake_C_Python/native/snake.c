#include "snake_internal.h"

#include <stddef.h>
#include <stdlib.h>
#include <string.h>

static int occupied(const SnakeGame *game, int x, int y, int count) {
    for (int i = 0; i < count; ++i) {
        if (game->body[i].x == x && game->body[i].y == y) {
            return 1;
        }
    }
    return 0;
}

SnakeGame *snake_create(int width, int height, uint32_t seed) {
    if (width < SNAKE_MIN_SIDE || width > SNAKE_MAX_SIDE ||
        height < SNAKE_MIN_SIDE || height > SNAKE_MAX_SIDE) {
        return NULL;
    }
    SnakeGame *game = (SnakeGame *)calloc(1, sizeof(*game));
    if (game == NULL) {
        return NULL;
    }
    game->width = width;
    game->height = height;
    game->capacity = width * height;
    game->body = (SnakeCell *)calloc((size_t)game->capacity, sizeof(*game->body));
    if (game->body == NULL) {
        free(game);
        return NULL;
    }
    snake_reset(game, seed);
    return game;
}

void snake_destroy(SnakeGame *game) {
    if (game != NULL) {
        free(game->body);
        free(game);
    }
}

void snake_reset(SnakeGame *game, uint32_t seed) {
    if (game == NULL) {
        return;
    }
    game->rng = seed != 0 ? seed : UINT32_C(0x9e3779b9);
    game->length = SNAKE_START_LENGTH;
    game->score = 0;
    game->direction = SNAKE_RIGHT;
    game->pending_count = 0;
    game->status = SNAKE_RUNNING;
    const int head_x = game->width / 2;
    const int head_y = game->height / 2;
    for (int i = 0; i < SNAKE_START_LENGTH; ++i) {
        game->body[i].x = head_x - i;
        game->body[i].y = head_y;
    }
    snake_place_food(game);
}

int snake_set_direction(SnakeGame *game, int direction) {
    if (game == NULL || game->status != SNAKE_RUNNING ||
        direction < SNAKE_UP || direction > SNAKE_LEFT ||
        game->pending_count >= SNAKE_TURN_BUFFER_SIZE) {
        return 0;
    }
    const int last = game->pending_count != 0
        ? game->pending[game->pending_count - 1] : game->direction;
    if (direction == last || (direction + 2) % 4 == last) {
        return 0;
    }
    game->pending[game->pending_count++] = direction;
    return 1;
}

int snake_tick(SnakeGame *game) {
    if (game == NULL) {
        return SNAKE_NOOP;
    }
    if (game->status != SNAKE_RUNNING) {
        return SNAKE_NOOP;
    }
    if (game->pending_count != 0) {
        game->direction = game->pending[0];
        --game->pending_count;
        if (game->pending_count != 0) {
            game->pending[0] = game->pending[1];
        }
    }

    int x = game->body[0].x;
    int y = game->body[0].y;
    switch (game->direction) {
        case SNAKE_UP:    --y; break;
        case SNAKE_RIGHT: ++x; break;
        case SNAKE_DOWN:  ++y; break;
        case SNAKE_LEFT:  --x; break;
        default: return SNAKE_NOOP;
    }

    if (x < 0 || x >= game->width || y < 0 || y >= game->height) {
        game->status = SNAKE_LOST;
        return SNAKE_DIED;
    }

    const int ate = x == game->food_x && y == game->food_y;
    /* Moving onto the tail is legal unless this tick also grows the snake. */
    const int collision_count = game->length - (ate ? 0 : 1);
    if (occupied(game, x, y, collision_count)) {
        game->status = SNAKE_LOST;
        return SNAKE_DIED;
    }

    const int new_length = game->length + ate;
    memmove(&game->body[1], &game->body[0],
            (size_t)(new_length - 1) * sizeof(*game->body));
    game->body[0].x = x;
    game->body[0].y = y;
    game->length = new_length;

    if (ate) {
        ++game->score;
        if (game->length == game->capacity) {
            game->food_x = -1;
            game->food_y = -1;
            game->status = SNAKE_WON;
            return SNAKE_VICTORY;
        }
        snake_place_food(game);
        return SNAKE_ATE;
    }
    return SNAKE_MOVED;
}

int snake_snapshot(const SnakeGame *game, SnakeSnapshot *out,
                   SnakeCell *cells, int capacity) {
    if (game == NULL || out == NULL || cells == NULL || capacity < game->length) {
        return 0;
    }
    out->width = game->width;
    out->height = game->height;
    out->length = game->length;
    out->food_x = game->food_x;
    out->food_y = game->food_y;
    out->score = game->score;
    out->direction = game->direction;
    out->status = game->status;
    memcpy(cells, game->body, (size_t)game->length * sizeof(*cells));
    return 1;
}
