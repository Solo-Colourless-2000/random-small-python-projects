"""Data for actors, bullets and transient effects."""
from __future__ import annotations
from dataclasses import dataclass, field
from constants import ENEMY_SPECS

@dataclass(slots=True)
class Player:
    x: float = 560
    y: float = 350
    vx: float = 0
    vy: float = 0
    hp: float = 100
    max_hp: float = 100
    speed: float = 278
    radius: float = 15
    damage: float = 22
    fire_interval: float = 0.17
    fire_timer: float = 0
    bullet_speed: float = 690
    pellets: int = 1
    dash_cd: float = 0
    dash_recharge: float = 1.65
    dash_time: float = 0
    invulnerable: float = 0
    energy: float = 100
    energy_regen: float = 10
    shot_flash: float = 0
    last_dx: float = 0
    last_dy: float = -1
    dash_hits: set[int] = field(default_factory=set)
    prev_x: float = field(init=False)
    prev_y: float = field(init=False)

    def __post_init__(self) -> None:
        self.prev_x, self.prev_y = self.x, self.y

@dataclass(slots=True)
class Enemy:
    kind: str
    x: float
    y: float
    hp: float = 0
    max_hp: float = 0
    speed: float = 0
    radius: float = 0
    damage: float = 0
    points: int = 0
    color: str = ''
    vx: float = 0
    vy: float = 0
    age: float = 0
    shot_timer: float = 1
    charge_timer: float = 1.5
    rush_time: float = 0
    hit_flash: float = 0
    stun: float = 0
    orbit: int = 1
    uid: int = 0
    dead: bool = False
    prev_x: float = field(init=False)
    prev_y: float = field(init=False)

    def __post_init__(self) -> None:
        self.prev_x, self.prev_y = self.x, self.y
        spec = ENEMY_SPECS[self.kind]
        self.hp = self.max_hp = float(spec['hp'])
        self.speed = float(spec['speed'])
        self.radius = float(spec['radius'])
        self.damage = float(spec['damage'])
        self.points = int(spec['points'])
        self.color = str(spec['color'])

@dataclass(slots=True)
class Bullet:
    x: float
    y: float
    vx: float
    vy: float
    radius: float
    damage: float
    ttl: float
    friendly: bool
    color: str
    # A projectile spawned during this simulation tick must not collide with
    # an actor's *earlier* movement in that same tick.
    fresh: bool = False

@dataclass(slots=True)
class Particle:
    x: float
    y: float
    vx: float
    vy: float
    ttl: float
    max_ttl: float
    color: str
    size: float

@dataclass(slots=True)
class Ring:
    x: float
    y: float
    radius: float
    max_radius: float
    life: float
    max_life: float
    color: str
    width: int = 2

@dataclass(slots=True)
class Pickup:
    x: float
    y: float
    kind: str  # 'repair' or 'charge'
    age: float = 0
    ttl: float = 12
