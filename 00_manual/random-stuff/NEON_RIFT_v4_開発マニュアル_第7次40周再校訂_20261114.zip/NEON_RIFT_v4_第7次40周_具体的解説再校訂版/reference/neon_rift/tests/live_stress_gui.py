"""Frame pacing when Canvas is crowded (requires a GUI/Xvfb)."""
import sys
import time
import tkinter as tk
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from game import Game
from entities import Bullet
from constants import ARENA_LEFT, ARENA_TOP, CYAN

root = tk.Tk()
g = Game(root, seed=80, auto_loop=True)
g.save_best = lambda: None
g.start()
g.pending.clear()
for i in range(28):
    g.spawn_enemy(('hunter', 'gunner', 'bruiser', 'runner')[i % 4])
for i in range(200):
    g.bullets.append(Bullet(ARENA_LEFT + 30 + i % 50 * 18,
                            ARENA_TOP + 35 + i // 50 * 60,
                            0, 0, 4, 3, 2.5, True, CYAN))
g.emit(490, 330, CYAN, 300)
g.player.invulnerable = 1000
start = time.perf_counter()
root.after(1800, g.close)
root.mainloop()
wall = time.perf_counter() - start
ratio = g.elapsed / wall
print(f'HEAVY SCENE: real {wall:.2f}s, simulation {g.elapsed:.2f}s, ratio {ratio:.2f}')
assert .83 <= ratio <= 1.05, 'Game clock drift under heavy rendering is too large'
