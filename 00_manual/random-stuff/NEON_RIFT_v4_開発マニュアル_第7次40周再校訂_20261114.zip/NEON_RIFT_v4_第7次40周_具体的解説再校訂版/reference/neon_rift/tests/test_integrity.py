"""Persistence, timing and numerical integrity regression checks."""
import json
import random
import sys
import tempfile
import unittest
from pathlib import Path
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

import game as game_module
from entities import Player
from mechanics import sweep_circle
from support import create_game


class IntegrityTests(unittest.TestCase):
    def test_corrupted_save_is_ignored(self):
        with tempfile.TemporaryDirectory() as home:
            path = Path(home) / 'best.json'
            path.write_text('{ invalid JSON', encoding='utf8')
            with patch.object(game_module, 'SAVE_PATH', path):
                self.assertEqual(game_module.Game.load_best(), 0)

    def test_best_save_round_trip(self):
        with tempfile.TemporaryDirectory() as home:
            path = Path(home) / 'best.json'
            g = create_game()
            # fixture's mock is intentionally replaced for this test
            del g.save_best
            g.score = 1570
            with patch.object(game_module, 'SAVE_PATH', path):
                g.save_best()
                self.assertEqual(game_module.Game.load_best(), 1570)
                self.assertEqual(json.loads(path.read_text())['best'], 1570)

    def test_best_does_not_decrease(self):
        with tempfile.TemporaryDirectory() as home:
            path = Path(home) / 'best.json'
            path.write_text('{"best":2000}', encoding='utf8')
            g = create_game()
            del g.save_best
            g.best, g.score = 2000, 120
            with patch.object(game_module, 'SAVE_PATH', path):
                g.save_best()
                self.assertEqual(game_module.Game.load_best(), 2000)

    def test_close_saves_score_and_destroys_root(self):
        with tempfile.TemporaryDirectory() as home:
            path = Path(home) / 'best.json'
            g = create_game()
            del g.save_best
            g.score = 25
            with patch.object(game_module, 'SAVE_PATH', path):
                g.close()
                self.assertEqual(game_module.Game.load_best(), 25)
                self.assertFalse(g.running)
                self.assertTrue(g.root.destroyed)

    def test_firing_rate_stays_close_to_nominal(self):
        g = create_game()
        g.pending.clear()
        g.mouse_down = True
        count = 0
        original = g.fire_player
        def count_shot():
            nonlocal count
            count += 1
            original()
        g.fire_player = count_shot
        for _ in range(600):
            g.update_player(1 / 60)
        self.assertTrue(58 <= count <= 61, count)

    def test_geometry_fuzz_hit_is_on_circle_surface(self):
        rng = random.Random(1337)
        for _ in range(5000):
            ax, ay, bx, by, cx, cy = (rng.uniform(-300, 300) for _ in range(6))
            r = rng.uniform(.2, 50)
            t = sweep_circle(ax, ay, bx, by, cx, cy, r)
            if t is None:
                continue
            self.assertTrue(0 <= t <= 1)
            x, y = ax + (bx - ax) * t, ay + (by - ay) * t
            self.assertLessEqual((x - cx)**2 + (y - cy)**2, r*r + .00001)

    def test_idle_tick_does_not_consume_ammo_or_effects(self):
        g = create_game()
        initial_time = g.global_time
        g.tick(0)
        self.assertEqual(g.global_time, initial_time)


if __name__ == '__main__':
    unittest.main()
