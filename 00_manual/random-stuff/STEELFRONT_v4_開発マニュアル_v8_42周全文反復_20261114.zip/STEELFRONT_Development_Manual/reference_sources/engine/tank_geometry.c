#include "engine_internal.h"

static void resolve_circle_rect(float *x,float *y,float r,const Obstacle *o) {
    if(!o->active) return;
    float closest_x=clampf(*x,o->x,o->x+o->w);
    float closest_y=clampf(*y,o->y,o->y+o->h);
    float dx=*x-closest_x,dy=*y-closest_y;
    float dist2=length2(dx,dy);
    if(dist2>=r*r) return;
    if(dist2>0.00001f) {
        float dist=sqrtf(dist2);
        *x+=dx*(r-dist)/dist;
        *y+=dy*(r-dist)/dist;
    } else {
        /* Center inside a rectangle: take the nearest safe exit. */
        float left=fabsf(*x-o->x),right=fabsf(o->x+o->w-*x);
        float top=fabsf(*y-o->y),bottom=fabsf(o->y+o->h-*y);
        float best=minf(minf(left,right),minf(top,bottom));
        if(best==left) *x=o->x-r;
        else if(best==right) *x=o->x+o->w+r;
        else if(best==top) *y=o->y-r;
        else *y=o->y+o->h+r;
    }
}
void constrain(float *x,float *y,float r) {
    *x=clampf(*x,r+12.0f,WORLD_W-r-12.0f);
    *y=clampf(*y,r+12.0f,WORLD_H-r-12.0f);
    for(int pass=0;pass<2;pass++)
        for(int i=0;i<s.obstacle_count;i++)
            resolve_circle_rect(x,y,r,&s.obstacles[i]);
    *x=clampf(*x,r+12.0f,WORLD_W-r-12.0f);
    *y=clampf(*y,r+12.0f,WORLD_H-r-12.0f);
}
void move_tank(Tank *t,float dx,float dy) {
    t->x+=dx;
    constrain(&t->x,&t->y,t->radius);
    t->y+=dy;
    constrain(&t->x,&t->y,t->radius);
}
/* Segment versus rectangle expanded by the projectile's radius. */
int ray_box(float x,float y,float dx,float dy,const Obstacle *o,float radius,
                   float *hit_t,float *nx,float *ny) {
    float lo=0,hi=1,norm_x=0,norm_y=0;
    float a[2]={x,y},d[2]={dx,dy};
    float mins[2]={o->x-radius,o->y-radius};
    float maxs[2]={o->x+o->w+radius,o->y+o->h+radius};
    for(int k=0;k<2;k++) {
        if(fabsf(d[k])<0.000001f) {
            if(a[k]<mins[k] || a[k]>maxs[k]) return 0;
        } else {
            float inv=1.0f/d[k];
            float t1=(mins[k]-a[k])*inv,t2=(maxs[k]-a[k])*inv;
            float n=(inv>0)?-1.0f:1.0f;
            if(t1>t2) {float temp=t1;t1=t2;t2=temp;}
            if(t1>lo) {lo=t1;norm_x=k==0?n:0;norm_y=k==1?n:0;}
            hi=minf(hi,t2);
            if(lo>hi) return 0;
        }
    }
    if(lo<0 || lo>1) return 0;
    /* An expanded AABB has square corners, but a moving circular projectile
     * has ROUND corners in configuration space. Refine corner contacts against
     * an actual corner-circle so shots do not strike empty space. */
    float px=x+dx*lo,py=y+dy*lo;
    float near_x=clampf(px,o->x,o->x+o->w);
    float near_y=clampf(py,o->y,o->y+o->h);
    if(radius>0 && length2(px-near_x,py-near_y)>radius*radius+0.00001f) {
        float rounded_t;
        if(!ray_circle(x,y,dx,dy,near_x,near_y,radius,&rounded_t)) return 0;
        px=x+dx*rounded_t;py=y+dy*rounded_t;
        float len=sqrtf(length2(px-near_x,py-near_y));
        if(len<0.00001f) return 0;
        norm_x=(px-near_x)/len;
        norm_y=(py-near_y)/len;
        lo=rounded_t;
    }
    *hit_t=lo;*nx=norm_x;*ny=norm_y;
    return 1;
}
int ray_circle(float x,float y,float dx,float dy,float cx,float cy,float r,float *hit_t) {
    float fx=x-cx,fy=y-cy;
    float a=length2(dx,dy);
    if(a<0.000001f) return 0;
    float b=2*(fx*dx+fy*dy),c=length2(fx,fy)-r*r;
    float disc=b*b-4*a*c;
    if(disc<0) return 0;
    float t=(-b-sqrtf(disc))/(2*a);
    if(t<0 && c<=0) t=0;
    if(t<0 || t>1) return 0;
    *hit_t=t;return 1;
}
int has_los(float x,float y,float tx,float ty) {
    for(int i=0;i<s.obstacle_count;i++) {
        Obstacle *o=&s.obstacles[i];float t,nx,ny;
        if(o->active && ray_box(x,y,tx-x,ty-y,o,1.0f,&t,&nx,&ny) && t>0.0001f)
            return 0;
    }
    return 1;
}
