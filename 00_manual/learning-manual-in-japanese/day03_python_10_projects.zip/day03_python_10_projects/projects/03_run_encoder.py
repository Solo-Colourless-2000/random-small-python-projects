import string
import sys


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 03_run_encoder.py text")
        return 2
    text = sys.argv[1]
    if not 1 <= len(text) <= 80:
        print("Error: use 1-80 uppercase letters.")
        return 2
    for character in text:
        if character not in string.ascii_uppercase:
            print("Error: use A-Z only.")
            return 2
    runs = []
    current = text[0]
    count = 1
    for character in text[1:]:
        if character == current:
            count += 1
        else:
            runs.append(f"{current}:{count}")
            current = character
            count = 1
    runs.append(f"{current}:{count}")
    print("Runs: " + " ".join(runs))
    print(f"Length: {len(text)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
