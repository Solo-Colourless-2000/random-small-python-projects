"""Tkinter controller: input, navigation, clock and score persistence.

All drawing belongs to renderer.py and all game rules belong to the C engine.
"""
from __future__ import annotations

import time
import tkinter as tk

from snake_app.config import (BG, WINDOW_WIDTH, WINDOW_HEIGHT, COLUMNS, ROWS,
                              FRAME_DELAY_MS, IDLE_FRAME_DELAY_MS, SCORE_SAVE_INTERVAL,
                              MAX_CATCHUP_TICKS, MAX_UPDATE_GAP,
                              game_interval, animation_progress)
from snake_app.engine import Direction, Event, SnakeEngine, Status
from snake_app.renderer import SnakeRenderer, RenderState, Hitbox
from snake_app.storage import DIFFICULTIES, load_scores, save_scores


class GameApp:
    def __init__(self, *, root: tk.Tk | None = None,
                 engine: SnakeEngine | None = None) -> None:
        self.root = root if root is not None else tk.Tk()
        self.root.title("Snake | C + Python")
        self.root.geometry(f"{WINDOW_WIDTH}x{WINDOW_HEIGHT}")
        self.root.resizable(False, False)
        self.root.configure(bg=BG)
        self.canvas = tk.Canvas(self.root, width=WINDOW_WIDTH, height=WINDOW_HEIGHT,
                                bg=BG, highlightthickness=0, bd=0)
        self.canvas.pack(fill="both", expand=True)
        self.renderer = SnakeRenderer(self.canvas)
        own_engine = engine is None
        acquired_engine = None
        try:
            acquired_engine = engine if engine is not None else SnakeEngine(COLUMNS, ROWS)
            # A snapshot or storage failure is also a startup failure. Do not
            # leak the already created native state or our own Tk window.
            first_frame = acquired_engine.snapshot()
            initial_scores = load_scores()
        except Exception:
            if own_engine and acquired_engine is not None:
                acquired_engine.close()
            # Never destroy a caller-supplied Tk root or engine.
            if root is None:
                self.root.destroy()
            raise
        self.engine = acquired_engine
        self.scores = initial_scores
        self.difficulty = "NORMAL"
        self.mode = "menu"  # menu, playing, paused, over
        self.frame = first_frame
        self.previous = self.frame
        self.last_step = time.monotonic()
        self.flash_end = 0.0
        self._after_id: str | None = None
        self._closed = False
        self._hitboxes: list[Hitbox] = []
        self._cursor = ""
        self.pause_reason = "PAUSED"
        self.save_warning = False
        self._scores_dirty = False
        self._last_save_attempt = time.monotonic()
        self.canvas.bind("<Button-1>", self._on_canvas_click)
        self.canvas.bind("<Motion>", self._on_canvas_motion)
        self.canvas.bind("<Leave>", self._on_canvas_leave)
        self.root.bind("<KeyPress>", self._on_key)
        self.root.bind("<FocusOut>", self._on_focus_out)
        self.root.protocol("WM_DELETE_WINDOW", self.close)
        # focus_set respects the window manager; focus_force would steal focus.
        self._focus_after_id: str | None = self.root.after_idle(self.root.focus_set)

    def run(self) -> None:
        self._loop()
        self.root.mainloop()

    def _save_if_dirty(self) -> None:
        if not self._scores_dirty:
            return
        self._last_save_attempt = time.monotonic()
        if save_scores(self.scores):
            # Another game instance might have recorded a higher score.
            # Keep our in-memory display consistent with the file on disk.
            disk = load_scores()
            for level in DIFFICULTIES:
                self.scores[level] = max(self.scores[level], disk[level])
            self._scores_dirty = False
            self.save_warning = False
        else:
            self.save_warning = True

    def close(self) -> None:
        if self._closed:
            return
        self._closed = True
        if self._after_id is not None:
            self.root.after_cancel(self._after_id)
            self._after_id = None
        if self._focus_after_id is not None:
            self.root.after_cancel(self._focus_after_id)
            self._focus_after_id = None
        try:
            self._save_if_dirty()
        finally:
            self.engine.close()
            self.root.destroy()

    def _start(self) -> None:
        self._save_if_dirty()
        self.engine.reset()
        self.frame = self.engine.snapshot()
        self.previous = self.frame
        self.mode = "playing"
        self.last_step = time.monotonic()
        self.flash_end = 0.0
        self._hitboxes.clear()
        self.root.focus_set()
        self._set_cursor("")

    def _menu(self) -> None:
        self._save_if_dirty()
        self.mode = "menu"
        self.engine.reset()
        self.frame = self.engine.snapshot()
        self.previous = self.frame
        self._hitboxes.clear()
        self._set_cursor("")

    def _pause_toggle(self) -> None:
        if self.mode == "playing":
            self.mode = "paused"
            self.pause_reason = "PAUSED"
            self._save_if_dirty()
        elif self.mode == "paused":
            self.mode = "playing"
            self.last_step = time.monotonic()
            self.previous = self.frame
            self._hitboxes.clear()
            self._set_cursor("")

    def _on_focus_out(self, event: tk.Event) -> None:
        if event.widget is self.root and self.mode == "playing":
            self._pause_toggle()
            self.pause_reason = "AUTO-PAUSED"

    def _set_cursor(self, cursor: str) -> None:
        if cursor != self._cursor:
            self.canvas.configure(cursor=cursor)
            self._cursor = cursor

    def _on_canvas_click(self, event: tk.Event) -> None:
        for x0, y0, x1, y1, action in self._hitboxes:
            if x0 <= event.x <= x1 and y0 <= event.y <= y1:
                if action == "start" and self.mode in ("menu", "over"):
                    self._start()
                elif action == "resume" and self.mode == "paused":
                    self._pause_toggle()
                elif action.startswith("difficulty:") and self.mode == "menu":
                    self._choose(action.partition(":")[2])
                else:
                    return
                self.root.focus_set()
                self._set_cursor("")
                return

    def _on_canvas_motion(self, event: tk.Event) -> None:
        inside = any(x0 <= event.x <= x1 and y0 <= event.y <= y1
                     for x0, y0, x1, y1, _ in self._hitboxes)
        self._set_cursor("hand2" if inside else "")

    def _on_canvas_leave(self, _: tk.Event) -> None:
        self._set_cursor("")

    def _on_key(self, event: tk.Event) -> None:
        key = event.keysym.lower()
        if key == "escape":
            if self.mode != "menu":
                self._menu()
            return
        menu_number = key.removeprefix("kp_")
        if menu_number in ("1", "2", "3") and self.mode == "menu":
            self.difficulty = DIFFICULTIES[int(menu_number) - 1]
            return
        if key == "r":
            self._start()
            return
        if key in ("return", "kp_enter"):
            if self.mode in ("menu", "over"):
                self._start()
            return
        if key in ("space", "p"):
            if self.mode in ("menu", "over"):
                self._start()
            else:
                self._pause_toggle()
            return
        if self.mode != "playing":
            return
        directions = {
            "up": Direction.UP, "w": Direction.UP, "kp_up": Direction.UP,
            "kp_8": Direction.UP,
            "right": Direction.RIGHT, "d": Direction.RIGHT, "kp_right": Direction.RIGHT,
            "kp_6": Direction.RIGHT,
            "down": Direction.DOWN, "s": Direction.DOWN, "kp_down": Direction.DOWN,
            "kp_2": Direction.DOWN,
            "left": Direction.LEFT, "a": Direction.LEFT, "kp_left": Direction.LEFT,
            "kp_4": Direction.LEFT,
        }
        direction = directions.get(key)
        if direction is not None:
            self.engine.turn(direction)

    def _interval(self) -> float:
        return game_interval(self.difficulty, self.frame.score)

    def _animation_progress(self, now: float) -> float:
        return animation_progress(self.mode, now, self.last_step, self._interval())

    def _loop(self) -> None:
        if self._closed:
            return
        if self._after_id is not None:
            self.root.after_cancel(self._after_id)
            self._after_id = None
        now = time.monotonic()
        if self.mode == "playing":
            # Preserve fractional elapsed time instead of resetting to "now"
            # after each move (which otherwise slows play at ~30 FPS).
            gap = now - self.last_step
            if gap < 0:
                self.last_step = now
            elif gap > MAX_UPDATE_GAP:
                # An OS suspend/debugger stall is not player time. Restart
                # the clock without a surprise move (even at the wall).
                self.last_step = now
                self.previous = self.frame
            steps = 0
            while steps < MAX_CATCHUP_TICKS and self.mode == "playing":
                interval = self._interval()  # Speed can change after eating.
                if now - self.last_step + 1e-9 < interval:
                    break
                self.previous = self.frame
                event = self.engine.tick()
                self.frame = self.engine.snapshot()
                self.last_step += interval
                steps += 1
                if event in (Event.ATE, Event.VICTORY):
                    self.flash_end = now + 0.14
                    if self.frame.score > self.scores[self.difficulty]:
                        self.scores[self.difficulty] = self.frame.score
                        self._scores_dirty = True
                if self.frame.status != Status.RUNNING:
                    self.mode = "over"
                    self._save_if_dirty()
            # Drop excess backlog, rather than letting a slow GUI spiral into
            # repeated multi-move frames.
            if (self.mode == "playing" and steps == MAX_CATCHUP_TICKS and
                    now - self.last_step >= self._interval()):
                self.last_step = now
        if self._scores_dirty and now - self._last_save_attempt >= SCORE_SAVE_INTERVAL:
            self._save_if_dirty()
        self._draw(now)
        delay = FRAME_DELAY_MS if self.mode == "playing" else IDLE_FRAME_DELAY_MS
        self._after_id = self.root.after(delay, self._loop)

    def _draw(self, now: float) -> None:
        self._hitboxes = self.renderer.draw(RenderState(
            frame=self.frame, previous=self.previous, mode=self.mode,
            difficulty=self.difficulty, scores=self.scores,
            pause_reason=self.pause_reason, save_warning=self.save_warning,
            flash_end=self.flash_end, last_step=self.last_step,
        ), now)

    def _choose(self, difficulty: str) -> None:
        if self.mode == "menu" and difficulty in DIFFICULTIES:
            self.difficulty = difficulty
