import sys


def simulate(interleaved):
    stock = 1
    accepted = 0
    if interleaved:
        snapshots = (stock, stock)
        for seen in snapshots:
            if seen > 0:
                stock = seen - 1
                accepted += 1
    else:
        for request in range(2):
            if stock > 0:
                stock -= 1
                accepted += 1
    return stock, accepted


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ("serial", "interleave"):
        print("Usage: script serial|interleave", file=sys.stderr)
        return 2
    stock, accepted = simulate(sys.argv[1] == "interleave")
    print(f"Stock: {stock}")
    print(f"Accepted: {accepted}")
    print(f"Conservation holds: {stock + accepted == 1}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
