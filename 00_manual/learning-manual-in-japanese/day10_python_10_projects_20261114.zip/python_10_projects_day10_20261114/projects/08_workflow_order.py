import sys

CASES = {"skip": ("ship",), "normal": ("pay", "ship"), "repeat": ("pay", "ship", "ship"), "empty": ()}


def execute(events):
    state = "new"
    weak_count = strict_count = rejected = 0
    for event in events:
        if event == "ship":
            weak_count += 1
        if state == "new" and event == "pay":
            state = "paid"
        elif state == "paid" and event == "ship":
            state = "shipped"
            strict_count += 1
        else:
            rejected += 1
    return weak_count, strict_count, rejected


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script skip|normal|repeat|empty", file=sys.stderr)
        return 2
    weak, strict, rejected = execute(CASES[sys.argv[1]])
    print(f"Ungated shipments: {weak}")
    print(f"State-gated shipments: {strict}")
    print(f"Rejected steps: {rejected}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
