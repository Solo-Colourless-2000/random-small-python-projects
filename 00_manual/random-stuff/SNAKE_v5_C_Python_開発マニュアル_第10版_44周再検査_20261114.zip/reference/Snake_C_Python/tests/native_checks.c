/* White-box tests to cover difficult branches (including a full-board win).
   Compile as its own executable, never as part of the shipped shared library. */
#include <assert.h>
#include <stdint.h>
#include <stdio.h>
#include <string.h>

#include "../native/snake.c"
#include "../native/food.c"

static SnakeGame *fresh(void) {
    SnakeGame *game = snake_create(8, 8, UINT32_C(12345));
    assert(game != NULL);
    return game;
}

static void test_tail_square_allowed(void) {
    SnakeGame *game = fresh();
    game->body[0] = (SnakeCell){2,2};
    game->body[1] = (SnakeCell){2,3};
    game->body[2] = (SnakeCell){3,3};
    game->body[3] = (SnakeCell){3,2};
    game->food_x = 6; game->food_y = 6;
    game->direction = SNAKE_RIGHT;
    assert(snake_tick(game) == SNAKE_MOVED);
    assert(game->body[0].x == 3 && game->body[0].y == 2);
    assert(game->status == SNAKE_RUNNING);
    snake_destroy(game);
}

static void test_body_square_kills(void) {
    SnakeGame *game = fresh();
    game->body[0] = (SnakeCell){2,2};
    game->body[1] = (SnakeCell){3,2};
    game->body[2] = (SnakeCell){3,3};
    game->body[3] = (SnakeCell){2,3};
    game->food_x = 7; game->food_y = 7;
    game->direction = SNAKE_RIGHT;
    assert(snake_tick(game) == SNAKE_DIED);
    assert(game->status == SNAKE_LOST && game->length == 4);
    assert(snake_tick(game) == SNAKE_NOOP);
    snake_destroy(game);
}

static void test_growth_preserves_tail(void) {
    SnakeGame *game = fresh();
    SnakeCell tail = game->body[3];
    game->food_x = 5; game->food_y = 4;
    assert(snake_tick(game) == SNAKE_ATE);
    assert(game->score == 1 && game->length == 5);
    assert(game->body[4].x == tail.x && game->body[4].y == tail.y);
    assert(game->food_x != 5 || game->food_y != 4);
    snake_destroy(game);
}

static void test_full_board_win(void) {
    SnakeGame *game = fresh();
    game->length = 63;
    game->body[0] = (SnakeCell){0,0};
    int at = 1;
    for (int y = 0; y < 8; ++y) {
        for (int x = 0; x < 8; ++x) {
            if ((x == 0 && y == 0) || (x == 1 && y == 0)) continue;
            game->body[at++] = (SnakeCell){x,y};
        }
    }
    assert(at == 63);
    game->food_x = 1; game->food_y = 0;
    game->direction = SNAKE_RIGHT;
    assert(snake_tick(game) == SNAKE_VICTORY);
    assert(game->length == 64 && game->status == SNAKE_WON);
    assert(game->food_x == -1 && game->food_y == -1);
    assert(game->score == 1);
    assert(snake_tick(game) == SNAKE_NOOP);
    snake_destroy(game);
}

static void test_queue_reset_and_death(void) {
    SnakeGame *game = fresh();
    assert(snake_set_direction(game, SNAKE_UP) == 1);
    assert(snake_set_direction(game, SNAKE_LEFT) == 1);
    assert(snake_set_direction(game, SNAKE_DOWN) == 0);
    snake_reset(game, 42);
    assert(game->pending_count == 0 && game->direction == SNAKE_RIGHT);
    game->body[0] = (SnakeCell){7,4};
    game->food_x = 3; game->food_y = 3;
    assert(snake_tick(game) == SNAKE_DIED);
    assert(snake_set_direction(game, SNAKE_UP) == 0);
    snake_destroy(game);
}

static void test_empty_space_food_generation(void) {
    SnakeGame *game = fresh();
    game->length = 63;
    int at = 0;
    for (int y = 0; y < 8; ++y) {
        for (int x = 0; x < 8; ++x) {
            if (x == 6 && y == 7) continue;
            game->body[at++] = (SnakeCell){x,y};
        }
    }
    snake_place_food(game);
    assert(game->food_x == 6 && game->food_y == 7);
    game->length = 64;
    snake_place_food(game);
    assert(game->food_x == -1 && game->food_y == -1);
    snake_destroy(game);
}

static void test_large_nearly_full_food_placement(void) {
    SnakeGame *game = snake_create(64, 64, UINT32_C(4321));
    assert(game != NULL);
    int index = 0;
    for (int y = 0; y < 64; ++y) {
        for (int x = 0; x < 64; ++x) {
            if (x == 63 && y == 63) continue;
            game->body[index++] = (SnakeCell){x, y};
        }
    }
    assert(index == 4095);
    game->length = index;
    for (int i = 0; i < 300; ++i) {
        snake_place_food(game);
        assert(game->food_x == 63 && game->food_y == 63);
    }
    game->length = 4096;
    game->body[4095] = (SnakeCell){63, 63};
    snake_place_food(game);
    assert(game->food_x == -1 && game->food_y == -1);
    snake_destroy(game);
}

static void test_growth_into_tail_is_rejected(void) {
    /* Impossible via normal spawning, but proves the collision branch
       distinguishes growth from a vacated tail cell. */
    SnakeGame *game = fresh();
    game->body[0] = (SnakeCell){2,2};
    game->body[1] = (SnakeCell){2,3};
    game->body[2] = (SnakeCell){3,3};
    game->body[3] = (SnakeCell){3,2};
    game->food_x = 3; game->food_y = 2;
    game->direction = SNAKE_RIGHT;
    assert(snake_tick(game) == SNAKE_DIED);
    assert(game->score == 0 && game->length == 4);
    snake_destroy(game);
}

static void test_snapshot_fails_safely(void) {
    SnakeGame *game = fresh();
    SnakeSnapshot snapshot = {0};
    snapshot.score = 987;
    SnakeCell cells[4];
    memset(cells, 0, sizeof cells);
    assert(snake_snapshot(game, &snapshot, cells, 3) == 0);
    assert(snapshot.score == 987);
    assert(snake_snapshot(game, &snapshot, cells, 4) == 1);
    assert(snapshot.length == 4 && cells[0].x == 4);
    assert(snake_snapshot(game, NULL, cells, 4) == 0);
    assert(snake_snapshot(game, &snapshot, NULL, 4) == 0);
    snake_destroy(game);
}

static void test_null_pointer_and_bad_sizes(void) {
    assert(snake_create(7, 8, 2) == NULL);
    assert(snake_create(8, 65, 2) == NULL);
    assert(snake_create(-1, 12, 2) == NULL);
    snake_reset(NULL, 2);
    snake_destroy(NULL);
    assert(snake_set_direction(NULL, 1) == 0);
    assert(snake_tick(NULL) == SNAKE_NOOP);
    assert(snake_snapshot(NULL, NULL, NULL, 0) == 0);
}

int main(void) {
    test_tail_square_allowed();
    test_body_square_kills();
    test_growth_preserves_tail();
    test_full_board_win();
    test_queue_reset_and_death();
    test_empty_space_food_generation();
    test_large_nearly_full_food_placement();
    test_growth_into_tail_is_rejected();
    test_snapshot_fails_safely();
    test_null_pointer_and_bad_sizes();
    puts("native checks: 10 groups passed");
    return 0;
}
