"""Reproducible content-and-runtime audit for the day05 lesson.

Each recorded check is an independent acceptance criterion, not a claim that
human eyes read the entire document again on each pass. Run from lesson root:
    python3 verification/verify_round2.py
"""
import ast
from collections import Counter
from datetime import datetime
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
MANUAL = ROOT / 'python_10_projects_day05_manual.html'
HTML = MANUAL.read_text(encoding='utf-8')
FILES = sorted((ROOT / 'projects').glob('*.py'))
EXAMPLES = json.loads((ROOT / 'verification/examples.json').read_text())
BROWSER = json.loads((ROOT / 'verification/round2_browser_results.json').read_text())
TEST_LOG = (ROOT / 'verification/round2_all_tests.log').read_text()
RESULTS = []


def check(name, okay, details):
    RESULTS.append({'number':len(RESULTS)+1,'criterion':name,'result':'PASS' if okay else 'FAIL','evidence':details})


class Inspector(HTMLParser):
    def __init__(self, source):
        super().__init__(convert_charrefs=True)
        self.ids=[]; self.anchors=[]; self.chapters=[]; self.steps=[]; self.codes={}; self.rows=[]
        self.current_code=None; self.ctx=[]; self.row=None; self.cell=None
        self.feed(source)

    def handle_starttag(self, tag, attrs):
        a=dict(attrs)
        if a.get('id'): self.ids.append(a['id'])
        if tag=='a' and 'href' in a: self.anchors.append(a['href'])
        if tag=='section' and 'chapter' in a.get('class','').split(): self.chapters.append(a.get('id'))
        if tag=='article': self.ctx.append(a.get('id'))
        if tag=='article' and 'step' in a.get('class','').split(): self.steps.append(a.get('id'))
        if tag=='code' and a.get('id'):
            self.current_code=a['id'];self.codes[self.current_code]=''
        if tag=='tr': self.row=[]
        if tag=='td': self.cell=''

    def handle_data(self,data):
        if self.current_code is not None: self.codes[self.current_code]+=data
        if self.cell is not None:self.cell+=data

    def handle_endtag(self,tag):
        if tag=='code':self.current_code=None
        if tag=='td' and self.row is not None and self.cell is not None:self.row.append(self.cell);self.cell=None
        if tag=='tr' and self.row: self.rows.append((self.ctx[-1] if self.ctx else '',self.row));self.row=None
        if tag=='article' and self.ctx:self.ctx.pop()

M=Inspector(HTML)
SOURCES=[f.read_text(encoding='ascii') for f in FILES]
LINES=[[ (str(j),s) for j,s in enumerate(src.splitlines(),1) if s.strip() ] for src in SOURCES]

check('01 \u4f5c\u54c1\u6570',len(FILES)==10,'projects/*.py has 10 files')
check('02 \u9023\u756a\u3068\u56fa\u6709\u30d5\u30a1\u30a4\u30eb\u540d',len(set(f.name for f in FILES))==10 and all(f.name.startswith(f'{i:02d}_') for i,f in enumerate(FILES,1)),[f.name for f in FILES])
check('03 \u30bd\u30fc\u30b9\u306eASCII\u9650\u5b9a',all(f.read_bytes().isascii() for f in FILES),'all project source bytes are ASCII')
check('04 \u30bf\u30d6\u6587\u5b57\u3092\u4f7f\u7528\u3057\u306a\u3044',all('\t' not in src for src in SOURCES),'tab-free indentation in ten projects')
check('05 \u30bd\u30fc\u30b9\u306e\u6700\u7d42\u6539\u884c',all(src.endswith('\n') for src in SOURCES),'ten project files end with LF')
check('06 Python 3.10\u69cb\u6587\u3068\u3057\u3066\u89e3\u6790',all(ast.parse(src,feature_version=(3,10)) is not None for src in SOURCES),'ast.parse 3.10 mode on 10 scripts')
check('07 \u5b9f\u884c\u74b0\u5883\u3067\u69cb\u6587\u30b3\u30f3\u30d1\u30a4\u30eb',all(compile(src,f.name,'exec') is not None for src,f in zip(SOURCES,FILES)),'compile() succeeded 10/10')
imports=set()
for src in SOURCES:
    for n in ast.walk(ast.parse(src)):
        if isinstance(n,ast.Import): imports.update(a.name for a in n.names)
        if isinstance(n,ast.ImportFrom): imports.add(n.module or '')
check('08 \u30bd\u30fc\u30b9\u306e\u4f9d\u5b58\u30e9\u30a4\u30d6\u30e9\u30ea',imports <= {'html','sys','pathlib','string','configparser','math'},sorted(imports))
check('09 \u5404\u4f5c\u54c1\u304c4\u5de5\u7a0b',all(len([v for v in M.steps if v.startswith(f'p{i:02d}-step')])==4 for i in range(1,11)),'10 projects x 4 steps')
check('10 4\u5de5\u7a0b\u306e\u9023\u7d50\u3068\u5b9f\u30d5\u30a1\u30a4\u30eb\u304c\u4e00\u81f4',all(''.join(M.codes[f'p{i:02d}-chunk{k}'] for k in range(1,5))==src for i,src in enumerate(SOURCES,1)),'40 code chunks checked')
check('11 \u4ed8\u9332A\u306e\u5b8c\u6210\u30b3\u30fc\u30c9\u4e00\u81f4',all(M.codes[f'src{i:02d}']==src for i,src in enumerate(SOURCES,1)),'10 embedded full sources checked')
check('12 \u5de5\u7a0b\u3054\u3068\u306e\u9010\u884c\u8868\u304c\u6f0f\u308c\u306a\u304f\u5b58\u5728',all(len([r for ctx,r in M.rows if ctx.startswith(f'p{i:02d}-step')])==len(lines) for i,lines in enumerate(LINES,1)),'all nonempty source lines have step explanations')
check('13 \u4ed8\u9332A\u306e\u9010\u884c\u8868\u304c\u6f0f\u308c\u306a\u304f\u5b58\u5728',all(len([r for ctx,r in M.rows if ctx==f'full-{i:02d}'])==len(lines) for i,lines in enumerate(LINES,1)),'all nonempty source lines have full appendix explanations')
check('14 \u5de5\u7a0b\u306e\u884c\u756a\u53f7\u3068\u5f15\u7528\u30b3\u30fc\u30c9',all([(r[0],r[1]) for ctx,r in M.rows if ctx.startswith(f'p{i:02d}-step')]==lines for i,lines in enumerate(LINES,1)),'line numbers and source fragments match 10 projects')
check('15 \u4ed8\u9332A\u306e\u884c\u756a\u53f7\u3068\u5f15\u7528\u30b3\u30fc\u30c9',all([(r[0],r[1]) for ctx,r in M.rows if ctx==f'full-{i:02d}']==lines for i,lines in enumerate(LINES,1)),'line numbers and source fragments match 10 appendices')
check('16 \u975e\u7a7a\u884c\u3059\u3079\u3066\u306b\u8aac\u660e\u6587',all(len(r)>2 and bool(r[2].strip()) for ctx,r in M.rows if ctx and (ctx.startswith('p') or ctx.startswith('full-'))),'no blank descriptions in 10 projects and appendices')
check('17 \u516820\u7ae0\u306e\u5b58\u5728',len(M.chapters)==20,'found '+str(len(M.chapters))+' sections')
check('18 \u516840\u5de5\u7a0b\u306e\u5b58\u5728',len(M.steps)==40,'found '+str(len(M.steps))+' step articles')
nav=re.search(r'<nav\b.+?</nav>',HTML,re.S)
check('19 \u76ee\u6b2120\u9805\u76ee\u3068\u7ae0\u306e\u5bfe\u5fdc',bool(nav) and all(f'href="#{id}"' in nav.group(0) for id in M.chapters), 'every chapter has a TOC link')
check('20 HTML\u8b58\u5225\u5b50\u306e\u885d\u7a81\u306a\u3057',len(M.ids)==len(set(M.ids)),'unique ids across document')
check('21 \u5185\u90e8\u30ea\u30f3\u30af\u306e\u884c\u304d\u5148',all(link[1:] in set(M.ids) for link in M.anchors if link.startswith('#')),'all local anchor targets exist')
check('22 \u5358\u4f53HTML\u306b\u5916\u90e8\u4f9d\u5b58\u306a\u3057',not re.search(r'<(?:script|img|iframe)\b[^>]*\bsrc=',HTML) and not re.search(r'<link\b[^>]*\bhref=',HTML),'no linked scripts, fonts, images, css')
check('23 \u65e5\u672c\u8a9e\u6587\u66f8\u30fb\u30c0\u30fc\u30af\u30c6\u30fc\u30de', '<html lang="ja"' in HTML and 'color-scheme:dark' in HTML,'lang ja / dark color scheme')
check('24 \u691c\u7d22\u30fb\u30b3\u30d4\u30fc\u30fb\u9032\u6357\u7ba1\u7406',all(phrase in HTML for phrase in ('id="search"','class="copy js-only"','data-check=','python-day05-20261110-reader-v1')),'basic reader functions present')
check('25 \u4f5c\u54c1\u306e\u5b8c\u6210\u7528\u9014\u8aac\u660e10\u4ef6',HTML.count('class="tool-purpose"')==10,'10 purpose-first explanation blocks')
for suffix,title in [('what','26 \u5b8c\u6210\u3059\u308b\u9053\u5177\u306e\u5b9a\u7fa9'),('when','27 \u4f7f\u3046\u5177\u4f53\u7684\u5834\u9762'),('how','28 \u5185\u90e8\u306e\u51e6\u7406\u306e\u6d41\u308c'),('result','29 \u7d50\u679c\u306e\u8aad\u307f\u65b9'),('limits','30 \u672a\u5b9f\u88c5\u306e\u7bc4\u56f2'),('terms','31 \u7528\u8a9e\u88dc\u8db3'),('try','32 \u4efb\u610f\u306e\u5b9f\u7fd2\u8ab2\u984c')]:
    names=[f'purpose-{i:02d}-{suffix}' for i in range(1,11)]
    check(title,all(f'id="{k}"' in HTML for k in names),'10/10 dedicated, searchable explanations')
check('33 \u516810\u4f5c\u54c1\u306e\u30b5\u30f3\u30d7\u30eb\u5b9f\u884c\u30b3\u30de\u30f3\u30c9',all('projects/'+f.name in HTML for f in FILES) and HTML.count('class="tool-example"')==10,'10 separately labeled invocations')
import html as htmlmod
output_blocks=re.findall(r'<pre class="tool-output"><code>(.*?)</code></pre>',HTML,re.S)
check('34 \u8868\u793a\u4f8b\u306e\u6b63\u78ba\u6027',len(output_blocks)==10 and all(htmlmod.unescape(out)==ex['normal']['stdout'] for out,ex in zip(output_blocks,EXAMPLES)), 'output blocks byte-exact vs ten measured fixture outputs')
check('35 \u4f5c\u54c1\u7528\u9014\u65e9\u898b\u8868\u3068\u30ea\u30f3\u30af',HTML.count('class="quick-tools"')==1 and all(f'href="#p{i:02d}"' in HTML for i in range(1,11)),'all ten chapters accessible from overview')
check('36 \u521d\u5b66\u8005\u5411\u30514\u3064\u306e\u8cea\u554f',HTML.count('class="reader-guide"')==1 and '\u30bc\u30ed\u304b\u3089\u8aad\u3080\u305f\u3081\u306e4\u3064\u306e\u8cea\u554f' in HTML,'four prompts and command line explanation present')
current='day05_python_10_projects_20261110_40point_refined.zip'
readme=(ROOT/'README.txt').read_text()
check('37 ZIP\u624b\u9806\u306e\u6700\u65b0\u30d5\u30a1\u30a4\u30eb\u540d\u4e00\u81f4','unzip '+current in HTML and 'ZIP\u540d\uff1a'+current in readme,'setup example and README use exact delivered ZIP name')
check('38 \u73fe\u884c\u691c\u8a3c\u74b0\u5883\u3068\u53c2\u7167\u7bc4\u56f2', 'Python 3.13.5' in HTML and '\u4eca\u56de\u306e\u518d\u76e3\u67fb\u3067\u53c2\u7167\u30fb\u4fee\u6b63\u3057\u305f\u4e00\u6b21\u8cc7\u6599' in HTML,'in-document environment and scope corrected')

with tempfile.TemporaryDirectory() as tmp:
    td=Path(tmp);(td/'practice').mkdir();(td/'samples').mkdir()
    for sf in (ROOT/'samples').iterdir():
        (td/'samples'/sf.name).write_bytes(sf.read_bytes())
    outcomes=[]
    for file,ex in zip(FILES,EXAMPLES):
        norm=ex['normal']
        result=subprocess.run([sys.executable,str(file),*norm['args']],cwd=td,input=norm['input'],text=True,capture_output=True,timeout=8)
        outcomes.append((result.returncode,result.stdout,result.stderr)==(norm['status'],norm['stdout'],norm['stderr']))
    check('39 10\u4f5c\u54c1\u306e\u5b9f\u6e2c\u51fa\u529b\u3068\u4fdd\u5b58\u78ba\u8a8d',len(outcomes)==10 and all(outcomes) and (td/'practice/card.html').read_text()==EXAMPLES[1]['saved_content'], 'all ten subprocess examples matched exit/stdout/stderr and saved HTML')

report_views=BROWSER['views'];inter=BROWSER['interactions']
check('40 \u30c6\u30b9\u30c848\u4ef6\u30fb\u30d6\u30e9\u30a6\u30b6\u30fc3\u5e45\u30fb\u64cd\u4f5c',
      'Ran 48 tests' in TEST_LOG and '\nOK\n' in TEST_LOG and 'skipped=' not in TEST_LOG and all(report_views[str(w)]['overflow']==0 and report_views[str(w)]['wrong_active']==0 and report_views[str(w)]['chapters']==20 for w in (1440,390,320))
      and inter['mobile_menu'] and inter['mobile_menu_escape'] and inter['copy_fallback'] and inter['wrap'] and inter['focus'] and inter['nojs_visible_chapters']==20 and inter['search_links']>0 and inter['navigation_p03']=='p03',
      {'unittest':'48 passed / zero skipped','viewports':'1440,390,320 no document overflow over 20 chapters','interactions':inter})

assert len(RESULTS)==40
result={
    'title':'day05 round2 40 independent acceptance checks',
    'audit_date':datetime.now(ZoneInfo('Asia/Tokyo')).isoformat(timespec='seconds'),
    'source_scope':'only the user-supplied day05 29point refined ZIP and its own contents',
    'meaning_of_rounds':'40 distinct acceptance criteria; not 40 literal human rereads of all text',
    'python':sys.version.split()[0],
    'criteria_count':len(RESULTS),
    'passed':sum(x['result']=='PASS' for x in RESULTS),
    'failed':sum(x['result']=='FAIL' for x in RESULTS),
    'checks':RESULTS,
}
target=ROOT/'verification/round2_audit_report.json'
target.write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
print(f"{result['passed']}/{result['criteria_count']} PASS", target)
for x in RESULTS:
    if x['result']=='FAIL':print('FAIL',x['number'],x['criterion'],x['evidence'])
if result['failed']:raise SystemExit(1)
