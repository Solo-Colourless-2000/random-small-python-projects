"""Combat and movement systems used by Game.

CombatMixin expects its host to provide player, enemies, bullets, the two random
streams, state, emit(), notify(), game_over(), and the input cursor/key fields.
Keeping combat separate from the Tk event loop makes collision logic testable.
"""
from __future__ import annotations

import math

from constants import (ARENA_BOTTOM, ARENA_LEFT, ARENA_RIGHT, ARENA_TOP,
                       BLUE, CYAN, RED, YELLOW)
from entities import Bullet, Pickup, Ring
from mechanics import (boundary_travel_fraction, clamp,
                       distance_sq, in_arena, moving_circle_hit, unit)


class CombatMixin:
    def update_player(self, dt: float) -> None:
        p = self.player
        p.prev_x, p.prev_y = p.x, p.y
        self._dash_active_this_tick = p.dash_time > 0
        if self.mouse_down and p.dash_time <= 0:
            p.fire_timer -= dt
        else:
            # Dashing or releasing fire must not accumulate a burst of shots.
            p.fire_timer = max(0.0, p.fire_timer - dt)
        p.dash_cd = max(0.0, p.dash_cd - dt)
        p.invulnerable = max(0.0, p.invulnerable - dt)
        p.shot_flash = max(0.0, p.shot_flash - dt)
        p.energy = min(100.0, p.energy + p.energy_regen * dt)

        dx = int('d' in self.keys or 'right' in self.keys) - int('a' in self.keys or 'left' in self.keys)
        dy = int('s' in self.keys or 'down' in self.keys) - int('w' in self.keys or 'up' in self.keys)
        mx, my = unit(dx, dy)
        if mx or my:
            p.last_dx, p.last_dy = mx, my
        if p.dash_time > 0:
            travel_time = min(dt, p.dash_time)
            p.dash_time = max(0.0, p.dash_time - dt)
            p.x += p.vx * travel_time
            p.y += p.vy * travel_time
            if self.fx_rng.random() < .9:
                self.emit(p.x, p.y, CYAN, 1, speed=55, ttl=.26, size=3.8)
        else:
            p.vx, p.vy = mx * p.speed, my * p.speed
            p.x += p.vx * dt
            p.y += p.vy * dt
        p.x, p.y = in_arena(p.x, p.y, p.radius + 3)
        if self.mouse_down and p.fire_timer <= 0 and not self._dash_active_this_tick:
            self.fire_player()

    def fire_player(self) -> None:
        p = self.player
        dx, dy = unit(self.mouse_x - p.x, self.mouse_y - p.y)
        if not (dx or dy):
            dx, dy = 0, -1
        direction = math.atan2(dy, dx)
        count = p.pellets
        spacing = .13 if count < 4 else .10
        for j in range(count):
            angle = direction + (j - (count - 1) / 2) * spacing
            ux, uy = math.cos(angle), math.sin(angle)
            self.bullets.append(Bullet(p.x + ux * 21, p.y + uy * 21,
                                       ux * p.bullet_speed, uy * p.bullet_speed,
                                       4.4, p.damage, 1.5, True, CYAN, fresh=True))
        p.fire_timer = max(0.0, p.fire_timer + p.fire_interval)
        p.shot_flash = .07
        self.emit(p.x + dx * 22, p.y + dy * 22, YELLOW, 2,
                  speed=115, ttl=.13, size=2.6)

    def dash(self) -> None:
        p = self.player
        if self.state != 'playing' or p.dash_cd > 0 or p.dash_time > 0:
            return
        dx = int('d' in self.keys or 'right' in self.keys) - int('a' in self.keys or 'left' in self.keys)
        dy = int('s' in self.keys or 'down' in self.keys) - int('w' in self.keys or 'up' in self.keys)
        dx, dy = unit(dx, dy)
        if not (dx or dy):
            dx, dy = unit(p.vx, p.vy)
        if not (dx or dy):
            dx, dy = unit(self.mouse_x - p.x, self.mouse_y - p.y)
        if not (dx or dy):
            dx, dy = p.last_dx, p.last_dy
        p.dash_time = .17
        p.vx, p.vy = dx * 1050, dy * 1050
        p.dash_cd = p.dash_recharge
        p.invulnerable = max(p.invulnerable, .29)
        p.dash_hits.clear()
        self.emit(p.x, p.y, CYAN, 12, speed=130, ttl=.33)
        self.rings.append(Ring(p.x, p.y, 15, 75, .27, .27, CYAN))

    def resolve_dash_hits(self) -> None:
        """Dash contact is swept across the whole frame, not just its endpoint."""
        if not self._dash_active_this_tick:
            return
        p = self.player
        for e in self.enemies:
            if e.dead or e.uid in p.dash_hits:
                continue
            t = moving_circle_hit(p.prev_x, p.prev_y, p.x, p.y,
                                  e.prev_x, e.prev_y, e.x, e.y,
                                  p.radius + e.radius + 5)
            if t is not None:
                p.dash_hits.add(e.uid)
                self.hit_enemy(e, 38, p.vx, p.vy)
        self.enemies = [e for e in self.enemies if not e.dead]

    def pulse(self) -> None:
        p = self.player
        if self.state != 'playing':
            return
        if p.energy < 65:
            self.notify('NOT ENOUGH ENERGY')
            return
        p.energy -= 65
        self.rings.append(Ring(p.x, p.y, 10, 220, .43, .43, BLUE, 4))
        self.emit(p.x, p.y, BLUE, 30, speed=230, ttl=.42, size=3)
        self.shake = min(9, self.shake + 4)
        for enemy in self.enemies:
            if not enemy.dead and distance_sq(p.x, p.y, enemy.x, enemy.y) <= (202 + enemy.radius) ** 2:
                dx, dy = unit(enemy.x - p.x, enemy.y - p.y)
                self.hit_enemy(enemy, 45, dx * 140, dy * 140)
        self.enemies = [e for e in self.enemies if not e.dead]
        self.bullets = [b for b in self.bullets
                        if b.friendly or distance_sq(p.x, p.y, b.x, b.y) > 205 ** 2]

    def update_bullets(self, dt: float) -> None:
        """Resolve earliest continuous hit, including targets moving during dt."""
        remaining: list[Bullet] = []
        p = self.player
        for b in self.bullets:
            if b.fresh:
                # The player and enemies have already moved this tick. A new
                # shot originates at its creation-time position, not at the
                # beginning of everyone else's motion. Start flight next tick.
                b.fresh = False
                if b.ttl > 0:
                    remaining.append(b)
                continue
            travel = min(dt, max(0.0, b.ttl))
            b.ttl -= dt
            if travel <= 0:
                continue
            dx, dy = b.vx * travel, b.vy * travel
            wall_fraction = boundary_travel_fraction(b.x, b.y, dx, dy)
            step = travel * wall_fraction / dt if dt > 0 else 0.0
            x1, y1 = b.x + dx * wall_fraction, b.y + dy * wall_fraction
            first_t = 2.0
            target = None
            if b.friendly:
                for e in self.enemies:
                    if e.dead:
                        continue
                    tx = e.prev_x + (e.x - e.prev_x) * step
                    ty = e.prev_y + (e.y - e.prev_y) * step
                    t = moving_circle_hit(b.x, b.y, x1, y1,
                                          e.prev_x, e.prev_y, tx, ty,
                                          b.radius + e.radius)
                    if t is not None and t < first_t:
                        first_t, target = t, e
            else:
                tx = p.prev_x + (p.x - p.prev_x) * step
                ty = p.prev_y + (p.y - p.prev_y) * step
                t = moving_circle_hit(b.x, b.y, x1, y1,
                                      p.prev_x, p.prev_y, tx, ty,
                                      b.radius + p.radius)
                if t is not None:
                    first_t, target = t, p
            if target is not None:
                b.x += (x1 - b.x) * first_t
                b.y += (y1 - b.y) * first_t
                if b.friendly:
                    self.hit_enemy(target, b.damage, b.vx * .055, b.vy * .055)
                else:
                    self.hurt_player(b.damage)
                self.emit(b.x, b.y, b.color, 4, speed=95, ttl=.26, size=2.3)
                if self.state != 'playing':
                    # Do not keep awarding hits after the lethal hostile shot.
                    break
            else:
                b.x, b.y = x1, y1
                if (b.ttl > 0 and wall_fraction >= 1 and
                        ARENA_LEFT <= b.x <= ARENA_RIGHT and
                        ARENA_TOP <= b.y <= ARENA_BOTTOM):
                    remaining.append(b)
        self.bullets = remaining
        self.enemies = [e for e in self.enemies if not e.dead]

    def resolve_enemy_contact(self) -> None:
        if self.state != 'playing':
            return
        p = self.player
        for e in self.enemies:
            if e.dead:
                continue
            touched = moving_circle_hit(p.prev_x, p.prev_y, p.x, p.y,
                                        e.prev_x, e.prev_y, e.x, e.y,
                                        p.radius + e.radius) is not None
            if not touched:
                continue
            if self._dash_active_this_tick:
                continue  # Already handled by resolve_dash_hits().
            self.hurt_player(e.damage)
            dx, dy = unit(p.x - e.x, p.y - e.y)
            if not (dx or dy):
                dx, dy = unit(p.x - e.prev_x, p.y - e.prev_y)
            if not (dx or dy):
                dx, dy = 0, -1
            p.x, p.y = in_arena(p.x + dx * 6, p.y + dy * 6, p.radius + 3)
            if self.state != 'playing':
                break

    def hurt_player(self, damage: float) -> None:
        p = self.player
        if p.invulnerable > 0 or self.state != 'playing':
            return
        p.hp = max(0.0, p.hp - damage)
        p.invulnerable = .7
        self.shake = min(13, self.shake + 7)
        self.emit(p.x, p.y, RED, 16, speed=170, ttl=.45)
        self.rings.append(Ring(p.x, p.y, 12, 48, .3, .3, RED))
        self.combo = 0
        self.combo_timer = 0
        if p.hp <= 0:
            self.game_over()

    def hit_enemy(self, e, damage: float, knock_x: float, knock_y: float) -> None:
        if e.dead:
            return
        e.hp -= damage
        e.hit_flash = .11
        if e.kind != 'warden':
            e.x, e.y = in_arena(e.x + clamp(knock_x, -18, 18),
                                e.y + clamp(knock_y, -18, 18), e.radius + 2)
            # A hit teleports the target a little: future hit tests in the same
            # frame must use the NEW location, not an obsolete movement trail.
            e.prev_x, e.prev_y = e.x, e.y
            e.stun = max(e.stun, .055)
        self.emit(e.x, e.y, e.color, 3, speed=70, ttl=.20, size=2.5)
        if e.hp <= 0:
            self.kill_enemy(e)

    def kill_enemy(self, e) -> None:
        if e.dead:
            return
        e.dead = True
        self.total_kills += 1
        self.combo = min(20, self.combo + 1)
        self.combo_timer = 3.6
        self.score += int(e.points * (1 + min(self.combo - 1, 15) * .12))
        self.shake = min(10, self.shake + (6 if e.kind == 'warden' else 1.5))
        self.emit(e.x, e.y, e.color, 46 if e.kind == 'warden' else 15,
                  speed=220 if e.kind == 'warden' else 130, ttl=.5, size=3.5)
        self.rings.append(Ring(e.x, e.y, e.radius, e.radius + 55, .42, .42, e.color, 3))
        chance = .95 if e.kind == 'warden' else .07
        if self.rng.random() < chance:
            kind = ('repair' if self.player.hp < self.player.max_hp * .72
                    and self.rng.random() < .65 else 'charge')
            self.pickups.append(Pickup(e.x, e.y, kind))
