"""Menu and overlay rendering. World rendering stays in arena_visual.py."""
from arena_config import C, UPGRADES, UPGRADE_COMPACT, SCREEN_W, SCREEN_H

class ArenaMenus:
    def overlay(self,opacity='dark'):
        # Tk stipple gives an intentionally grainy translucent overlay, no alpha support needed.
        pattern='gray75' if opacity=='dark' else 'gray50'
        self.cr(0,0,SCREEN_W,SCREEN_H,fill='#030b11',stipple=pattern,outline='')

    def button(self,x,y,w,h,label,secondary=None):
        self.panel(x,y,w,h,fill='#183c42',outline=C['cyan'])
        self.text(x+w/2,y+23,label,19,C['text'],'bold')
        if secondary:self.text(x+w/2,y+48,secondary,10,C['muted'])

    def title_screen(self):
        self.overlay()
        self.panel(271,112,738,584,fill='#0d2029',outline='#416c72')
        self.text(640,160,'//  ARMORED DIVISION  //',15,C['cyan'],'bold')
        self.text(640,228,'STEELFRONT',57,C['text'],'bold')
        self.cl(382,287,898,287,fill='#477b78',width=2)
        self.text(640,320,'T A N K   A R E N A',21,C['gold'],'bold')
        self.text(640,372,'Survive the onslaught.  Rebuild.  Strike back.',14,C['text'])
        self.text(640,412,'Every fifth wave unleashes a COMMANDER-class tank.',12,C['muted'])
        self.text(640,450,'WASD / ARROWS     MOVE            MOUSE     AIM',13,C['text'],'bold')
        self.text(640,482,'LMB / SPACE    FIRE        SHIFT    DASH        E    EMP',12,C['muted'])
        self.button(478,528,324,67,'DEPLOY TANK', 'ENTER  /  CLICK TO START')
        self.text(640,625,f'PERSONAL BEST   {self.high_score:08}       BEST WAVE   {self.best_wave:02}',
                  12,C['gold'],'bold')
        self.text(640,665,'NATIVE C COMBAT ENGINE    +    PYTHON DISPLAY SYSTEM',10,C['muted'])

    def intro_overlay(self,s):
        self.cr(260,320,1020,444,fill='#071820',outline=C['cyan'],width=2)
        self.text(640,342,'TACTICAL COMMAND / INCOMING TRANSMISSION',13,C['muted'],'bold')
        self.text(640,377,f'WAVE {s.wave:02}  //  ENGAGE',33,C['gold'],'bold')
        self.text(640,423,'ELIMINATE ALL HOSTILES',12,C['cyan'],'bold')

    def pause_screen(self):
        self.overlay()
        self.panel(375,213,530,377,fill='#10232d',outline='#65a3a2')
        self.text(640,281,'PAUSED',42,C['text'],'bold')
        self.text(640,341,'The battlefield can hold for a moment.',13,C['muted'])
        self.text(640,392,'WASD  MOVE     MOUSE  AIM     LMB  FIRE',13,C['text'])
        self.text(640,419,'SHIFT  DASH          E  EMP',13,C['text'])
        self.button(466,481,348,63,'RESUME BATTLE','P / ESC / ENTER')

    def upgrade_screen(self,s):
        self.overlay()
        self.text(640,152,'FIELD MAINTENANCE',19,C['cyan'],'bold')
        self.text(640,202,'WAVE CLEARED',43,C['text'],'bold')
        self.text(640,250,f'{s.wave:02} WAVES SURVIVED    |    {s.score:08} POINTS',14,C['gold'])
        self.text(640,308,'SELECT ONE MODULE  /  PRESS 1, 2 OR 3',14,C['text'],'bold')
        self.card_bounds=[]
        for idx,upgrade in enumerate(self.upgrade_choices):
            x=151+idx*338;y=365;w=302;h=228
            self.card_bounds.append((x,y,x+w,y+h))
            info=UPGRADES[upgrade]
            mx,my=self.pointer
            hover=x<=mx<=x+w and y<=my<=y+h
            self.panel(x,y,w,h,fill='#1b3940' if hover else '#152932',
                       outline=info[3] if hover else '#47636a')
            self.text(x+24,y+29,f'0{idx+1}   /   {info[2]}',12,info[3],'bold',anchor='nw')
            self.cl(x+21,y+63,x+w-21,y+63,fill='#3a565f',width=1)
            self.text(x+23,y+93,info[0],15,C['text'],'bold',anchor='nw')
            # On small desktops use semantic short copy. Width scaling does
            # not shrink Canvas fonts below 7pt, so normal text would overflow.
            description=UPGRADE_COMPACT[upgrade] if self.scale<.70 else info[1]
            words=description.split();lines=[];line=''
            for word in words:
                test=(line+' '+word).strip()
                limit=23 if self.scale<.70 else 27
                if len(test)>limit and line:lines.append(line);line=word
                else:line=test
            if line:lines.append(line)
            for li,txt in enumerate(lines):self.text(x+23,y+137+li*23,txt,11,C['muted'],anchor='nw')
            self.text(x+w/2,y+h-27,'EQUIP  [ '+str(idx+1)+' ]',13,
                      info[3] if hover else C['cyan'],'bold')
        self.text(640,651,'THE NEXT WAVE STARTS AFTER YOUR SELECTION',12,C['text'])

    def gameover_screen(self,s):
        self.overlay()
        self.panel(319,163,642,508,fill='#1c222c',outline='#a95862')
        self.text(640,219,'CONNECTION LOST',15,C['red'],'bold')
        self.text(640,293,'TANK DESTROYED',38,C['text'],'bold')
        self.cl(404,333,876,333,fill='#794d57',width=2)
        self.text(510,372,'FINAL SCORE',12,C['muted'])
        self.text(773,372,'WAVES HELD',12,C['muted'])
        self.text(510,411,f'{s.score:08}',29,C['gold'],'bold')
        self.text(773,411,f'{s.wave:02}',30,C['text'],'bold')
        self.text(640,463,f'KILLS {s.kills:03}     PERSONAL BEST {self.high_score:08}',
                  12,C['muted'])
        self.button(478,528,324,67,'REDEPLOY','ENTER  /  R  /  CLICK')
        self.text(640,636,'A good commander knows when to try again.',11,C['muted'])

