import sys

ACCOUNTS = {"alice", "bob"}
CASES = {"known": "alice", "absent": "carol", "empty": ""}


def respond(name, uniform):
    exists = name in ACCOUNTS
    if uniform:
        return "If registered, a message will be sent."
    if exists:
        return "Reset message sent."
    return "Unknown account."


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script known|absent|empty", file=sys.stderr)
        return 2
    name = CASES[sys.argv[1]]
    print(f"Detailed response: {respond(name, False)}")
    print(f"Uniform response: {respond(name, True)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
