"""Run 36 additional, different check focuses; repeat code/manual byte comparison.

Run from the extracted package root with:
    python3 verification/audit_additional_36.py
The original 36-focus log is retained separately for provenance.
"""
import ast
from collections import Counter
from contextlib import closing
import hashlib
import importlib.util
import json
from pathlib import Path
import re
import sqlite3
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'tests'))
from cases import CASES
from test_materials import Manual

PROJECTS=sorted((ROOT/'projects').glob('*.py'))
HTML=ROOT/'python_10_projects_day06_manual.html'
REPORT=ROOT/'verification'/'audit_additional_36.json'
TEXT=HTML.read_text(encoding='utf-8')
README=(ROOT/'README.txt').read_text(encoding='utf-8')
HISTORY=json.loads((ROOT/'PROJECT_HISTORY.json').read_text(encoding='utf-8'))


def ensure(value, message):
    if not value: raise AssertionError(message)


def module(index):
    path=PROJECTS[index-1]
    spec=importlib.util.spec_from_file_location('lab_'+str(index),path)
    obj=importlib.util.module_from_spec(spec)
    spec.loader.exec_module(obj)
    return obj


def baseline(round_number):
    page=Manual(TEXT)
    ensure(len(PROJECTS)==10 and len(page.chapters)==20,'project/chapter count')
    for index,path in enumerate(PROJECTS,1):
        name=f'{index:02}'
        data=path.read_bytes()
        steps=''.join(page.sources[f'step-{name}-{i}'] for i in range(1,5)).encode('ascii')
        ensure(data==steps==page.sources[f'src-{name}'].encode('ascii'),f'round {round_number} source mismatch {name}')
        line_ids=[x for i in range(1,5) for x in page.line_numbers[f'step-{name}-{i}']]
        ensure(line_ids==list(range(1,data.count(b'\n')+1)),f'round {round_number} line numbers {name}')
    return page


def check01(page): ensure(len(set(p.name for p in PROJECTS))==10,'unique project names')
def check02(page): ensure(all(p.read_bytes().isascii() for p in PROJECTS),'all code ascii')
def check03(page):
    for p in PROJECTS:ast.parse(p.read_text('ascii'),feature_version=(3,10))
def check04(page): ensure(all('raise SystemExit(main())' in p.read_text('ascii') for p in PROJECTS),'main entrypoint')
def check05(page):
    allowed={'posixpath','sys','sqlite3','contextlib','urllib.parse','pathlib','hmac','socket'}
    for p in PROJECTS:
        tree=ast.parse(p.read_text('ascii'))
        imports=[n.module for n in ast.walk(tree) if isinstance(n,ast.ImportFrom)]
        imports += [a.name for n in ast.walk(tree) if isinstance(n,ast.Import) for a in n.names]
        ensure(set(imports)<=allowed,f'import {p.name}')
def check06(page):
    for name, cases in CASES.items():
        for args,code,stdout,stderr in cases:
            run=subprocess.run([sys.executable,'-S',str(ROOT/'projects'/f'{name}.py'),*args],cwd=ROOT,capture_output=True,text=True,timeout=6)
            ensure((run.returncode,run.stdout,run.stderr)==(code,stdout,stderr),f'CLI discrepancy: {name} {args}')
def check07(page):
    results=json.loads((ROOT/'verification'/'cli_observations.json').read_text())
    for name,cases in CASES.items():
        ensure([(r['args'],r['code'],r['stdout'],r['stderr']) for r in results[name]]==cases, f'observation {name}')
def check08(page):ensure(all(f'step-{i:02}-{n}' in page.sources for i in range(1,11) for n in range(1,5)),'40 chunks')
def check09(page):ensure(not [id_ for id_,count in page.ids.items() if count!=1],'duplicate html id')
def check10(page):ensure(not(set(page.anchors)-set(page.ids)),'broken in-page anchors')
def check11(page):ensure(len(page.chapters)==20,'chapter count')
def check12(page):ensure(len(page.checks)==20 and len(set(page.checks))==20,'20 checks')
def check13(page):ensure(len([k for k in page.sources if re.fullmatch(r'step-\d\d-[1-4]',k)])==40,'40 steps')
def check14(page):ensure(len([k for k in page.sources if re.fullmatch(r'src-\d\d',k)])==10,'10 appendices')
def check15(page):ensure(page.internal_assets==[],'no network assets')
def check16(page):ensure('python-daily-day06-20261110-v1' in TEXT,'storage key')
def check17(page):ensure("match[1]" in TEXT and 'step.slice(1, 3)' not in TEXT,'fixed source link')
def check18(page):ensure(all(f'reasoning-{i:02}' in page.ids for i in range(1,11)),'deep dives')
def check19(page):ensure(all(f'reasoning-{i:02}-{n}' in page.ids for i in range(1,11) for n in range(1,4)),'30 notes')
def check20(page):ensure(all(f'glossary-second-{n}' in page.ids for n in range(1,16)),'15 glossary')
def check21(page):ensure('debugging-walkthrough' in page.ids and 'diff -u' in TEXT and 'echo $?' in TEXT,'debug guide')
def check22(page):ensure('unzip day06_python_10_projects_20261110_144point_refined.zip' in TEXT,'correct unzip command')
def check23(page):
    m=module(1)
    ensure(m.resolve('/public/%252e%252e/private/notes')[2:]==(True,False),'double decode')
    ensure(m.resolve('/public/%2e%2e/private/notes')[2:]==(False,False),'single decode')
    for bad in ('/public/%00','/public/%ff'):
        try:m.resolve(bad)
        except ValueError:pass
        else:raise AssertionError('bad decoded input accepted')
def check24(page):
    m=module(2)
    with closing(sqlite3.connect(':memory:')) as db:
        db.execute('CREATE TABLE notes(label TEXT)')
        db.executemany('INSERT INTO notes VALUES (?)',[('blue',),('red',)])
        ensure(m.count_rows(db,'blue')==(1,1),'known sql')
        ensure(m.count_rows(db,"none' OR '1'='1")== (2,0),'probe sql')
def check25(page):
    m=module(3)
    ensure(m.compare('alice','102')==('200','403'),'object authorization')
    ensure(m.compare('bob','101')==('200','403'),'reverse object authorization')
    ensure(m.compare('bob','404')==('404','404'),'missing object')
def check26(page):
    m=module(4)
    ensure(m.headers('http://app.example.test')==('http://app.example.test','(omitted)'),'scheme not exact')
    ensure(m.headers('https://trap-app.example.test')[1]=='(omitted)','evil suffix not trusted')
def check27(page):
    m=module(5)
    ensure(m.follow('https://public.example.test/jump',True)=='blocked https://inside.example.test/info','every-hop blocked')
    ensure(m.follow('https://public.example.test/jump',False)=='read inside-note','weak follows')
    ensure(m.follow('https://public.example.test/loop',True)=='hop limit','loop finite')
def check28(page):
    m=module(6)
    ensure(m.compare(ROOT/'samples'/'header.gif')[1:]==(True,True),'header fixture')
    ensure(m.compare(ROOT/'samples'/'fake.gif')[1:]==(True,False),'fake fixture')
    ensure(m.compare(ROOT/'samples'/'header.txt')[1:]==(False,True),'rename fixture')
def check29(page):
    m=module(7)
    ensure(m.tag(m.ORIGINAL)!=m.tag(m.ALTERED),'altered tag must differ')
    ensure(len(m.tag(m.ORIGINAL))==32,'SHA256 length')
def check30(page):
    m=module(8)
    ensure(m.decisions(m.CASES['rotate'])=='allow allow allow','rotation effect')
    ensure(m.decisions(m.ACCOUNT)=='allow allow deny','account effect')
def check31(page):
    m=module(9)
    for i in range(10000):
        val=f'{i:04}'
        early,n=m.early_count(val)
        ensure(early==(val==m.SECRET) and m.full_count(val)==(early,4) and 1<=n<=4,'compare exhaustive')
def check32(page):
    m=module(10)
    ensure(m.capture(b'LAB/1 ready\r\n')==b'LAB/1 ready\r\n','loopback banner')
    ensure(m.capture(b'X'*70+b'\n')==b'X'*64,'read limit')
def check33(page):
    m=module(3)
    ensure(m.compare('alice','\uff10\uff11\uff12')==('404','404'),'dict Unicode not coerced')
    ensure('isascii()' in PROJECTS[2].read_text('ascii'),'CLI ascii safeguard')
def check34(page):
    for p in PROJECTS:
        tree=ast.parse(p.read_text('ascii'))
        calls=[n.func.attr for n in ast.walk(tree) if isinstance(n,ast.Call) and isinstance(n.func,ast.Attribute)]
        ensure(not(set(calls)&{'unlink','remove','write_text','write_bytes','rmtree'}),f'filesystem mutation {p.name}')
def check35(page):
    ensure(all(f'beginner-{i:02}' in page.ids for i in range(1,11)),'previous beginner cards')
    ensure(all(f'reasoning-{i:02}-3' in page.ids for i in range(1,11)),'extended case walkthroughs')
    ensure(len(re.findall(r'https://docs.python.org',TEXT))>=3,'official reference links')
def check36(page):
    ensure(HISTORY['last_completed_volume']==6 and HISTORY['next_volume']==7,'progress ledger')
    ensure(len(HISTORY['projects'])==60,'ledger count')
    ensure('144point_refined.zip' in README,'README filename')

LABELS=[
 'Ten unique filenames','ASCII-only project source','Python 3.10-compatible grammar','Direct script entrypoints','Stdlib-only imports',
 'All 59 CLI cases executed','Observed outputs match baseline','All forty code chunks','Unique HTML element IDs','Resolvable internal anchors',
 'Twenty ordered chapters','Twenty distinct completion boxes','Exactly forty program steps','Exactly ten full-source appendices','Offline-only page assets',
 'Persistent settings key','Appendix return-link fix','Ten additional code walkthroughs','Thirty additional detailed notes','Fifteen extra glossary entries',
 'Practical debugging guide','Current ZIP filename in unzip instructions','Double-decode error-path variants','SQL bound/unsafe contrast',
 'Existing vs unauthorized object','Origin scheme and attacker suffix','Redirect checks at all hops','GIF fixture semantic contrasts',
 'HMAC changed-message detection','Rate-limit identity scope','Exhaustive 10k comparison candidates','Loopback socket and bounded reader',
 'Unicode object-ID non-equivalence','No mutating filesystem calls','All previous beginner notes retained','Handoff and packaging references'
]
FOCUSES=[globals()[f'check{i:02}'] for i in range(1,37)]
assert len(FOCUSES)==len(LABELS)==36

def main():
    output=[]
    for index,(func,label) in enumerate(zip(FOCUSES,LABELS),1):
        page=baseline(index)
        func(page)
        entry={'round':index,'focus':label,'status':'PASS','full_program_sources':10,'html_step_chunks':40,'appendices':10}
        output.append(entry)
        print(f'ADDITIONAL ROUND {index:02}: PASS | {label} | code/steps/appendix 10/40/10')
    REPORT.write_text(json.dumps({'scope':'36 additional differing foci, one per round; complete code-to-manual comparison repeated in each','results':output},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
    print('ALL 36 ADDITIONAL ROUNDS PASS')

if __name__=='__main__':main()
