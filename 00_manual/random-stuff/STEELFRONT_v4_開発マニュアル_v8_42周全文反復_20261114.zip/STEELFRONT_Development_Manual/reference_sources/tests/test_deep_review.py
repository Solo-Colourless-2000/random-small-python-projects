"""Version-3 independent regression cases based on source and real-play reviews."""
from __future__ import annotations
import ctypes as ct
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import time
from types import SimpleNamespace
import tkinter as tk
import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from arena_scores import read_best, write_best
from c_bridge import Control, Snapshot
from test_engine import dll, engine, snap, step
from test_ui import app, key, mouse


def test_deep_01_menus_do_not_share_large_world_renderer_source():
    visual = (ROOT/'arena_visual.py').read_text()
    menus = (ROOT/'arena_menus.py').read_text()
    assert 'class ArenaRenderer(ArenaMenus)' in visual
    assert 'def draw_bullets(' in visual
    assert 'def upgrade_screen(' in menus
    assert 'def draw_bullets(' not in menus
    assert 'def upgrade_screen(' not in visual


def test_deep_02_mouse_leaving_canvas_releases_trigger(app):
    app.new_game(); app.screen='PLAYING'
    app.mouse_press(mouse(300, 220))
    assert app.mouse_down
    app.mouse_leave(SimpleNamespace())
    assert not app.mouse_down and app._input().fire==0


def test_deep_03_global_mouse_release_ends_sustained_fire(app):
    app.new_game(); app.screen='PLAYING'
    app.mouse_down=True
    assert app.root.bind('<ButtonRelease-1>')
    app.mouse_release(mouse(-1, -1))
    assert not app.mouse_down


def test_deep_04_intro_escape_keeps_remaining_countdown(app):
    app.new_game()
    app.wave_banner=.83
    app.key_press(key('Escape'))
    assert app.screen=='PAUSED' and app.paused_from=='INTRO'
    app.key_press(key('Return'))
    assert app.screen=='INTRO' and app.wave_banner==pytest.approx(.83)


def test_deep_05_focus_out_during_intro_stops_unattended_start(app):
    app.new_game(); app.focus_lost()
    assert app.screen=='PAUSED'
    app.last_clock=time.perf_counter()-5
    app.tick()
    assert app.screen=='PAUSED'


def test_deep_06_pausing_during_combat_drops_both_ability_queues(app):
    app.new_game(); app.screen='PLAYING'
    app.key_press(key('e')); app.key_press(key('Shift_L'))
    app.key_press(key('Escape'))
    assert app.screen=='PAUSED' and not app.keys
    assert not app.pulse_queue and not app.dash_queue
    app.resume()
    assert app._input().pulse==app._input().dash==0


def test_deep_07_upgrade_selection_clears_pressed_keys(app):
    app.new_game(); app.start_upgrade_screen()
    app.key_press(key('space'));app.key_press(key('w'))
    assert 'space' in app.keys and 'w' in app.keys
    app.choose_upgrade(0)
    assert app.screen=='INTRO' and not app.keys
    assert app._input().fire==0 and app._input().move_y==0


def test_deep_08_mouse_press_in_pause_does_not_leak_to_combat(app):
    app.new_game(); app.screen='PAUSED'
    app.mouse_press(mouse(640*app.scale,513*app.scale))
    assert app.screen=='PLAYING' and not app.mouse_down


def test_deep_09_menu_render_does_not_leave_duplicate_cover(app):
    app.new_game();app.screen='PLAYING';app.render()
    base=tuple(app.canvas.find_withtag('cover'))
    for mode in ('PAUSED','INTRO','UPGRADE','GAMEOVER','TITLE','PLAYING'):
        if mode=='UPGRADE':app.start_upgrade_screen()
        app.screen=mode;app.render()
        assert tuple(app.canvas.find_withtag('cover'))==base


def test_deep_10_repeated_frames_do_not_accumulate_canvas_shapes(app):
    app.new_game();app.screen='PLAYING'
    counts=[]
    for _ in range(45):
        app.render()
        counts.append(len(app.canvas.find_all()))
    assert max(counts)-min(counts)<12


def test_deep_11_score_event_is_exact_for_single_kill(engine):
    engine.debug_enemy(0,660,310,10)
    engine.debug_bullet(640,310,1500,0,0,40,0)
    state=step(engine,1,dt=.0333)
    rewards=[int(e.value) for e in state.events[:state.event_count] if e.kind==12]
    assert rewards==[100]
    assert state.score==100


def test_deep_12_simultaneous_kills_keep_distinct_combo_rewards(engine):
    engine.debug_enemy(0,660,310,10);engine.debug_enemy(0,720,310,10)
    engine.debug_bullet(640,310,1500,0,0,40,0)
    engine.debug_bullet(700,310,1500,0,0,40,0)
    state=step(engine,1,dt=.0333)
    rewards=[int(e.value) for e in state.events[:state.event_count] if e.kind==12]
    assert rewards==[100,200],rewards
    assert state.score==300 and state.combo==2


def test_deep_13_visual_kill_text_uses_event_reward_not_final_combo(app):
    app.new_game()
    state=app.engine.state
    state.combo=8
    state.event_count=2
    for i,reward in enumerate((100,200)):
        e=state.events[i];e.kind=12;e.x=500+i*20;e.y=310;e.value=reward
    app.floats.clear();app.process_events()
    assert [t.text for t in app.floats]==['+100','+200']


def test_deep_14_crate_destroy_does_not_create_score_reward(engine):
    # Crate x297..346, y279..323, away from all neighboring tanks.
    engine.debug_bullet(275,305,1100,0,0,100,0)
    state=step(engine,1,dt=.0333)
    assert state.score==0
    assert not any(e.kind==12 for e in state.events[:state.event_count])


def test_deep_15_player_shell_uses_post_ricochet_frame_time(engine):
    engine.debug_bullet(339,150,500,0,0,29,1)
    state=step(engine,1,dt=.0333)
    shots=[b for b in state.bullets if b.active]
    assert len(shots)==1
    assert shots[0].vx<0 and shots[0].bounces==0
    # Hit at x=347, offset 1.5, followed by remaining backward travel.
    assert shots[0].x<342,shots[0].x


def test_deep_16_ricochet_reflects_once_not_forever(engine):
    engine.debug_bullet(339,150,500,0,0,29,1)
    s=step(engine,1,dt=.0333)
    assert len([b for b in s.bullets if b.active and b.bounces>0])==0
    s=step(engine,10)
    assert all(b.bounces>=0 for b in s.bullets if b.active)


def test_deep_17_no_ricochet_on_destructible_crate(engine):
    engine.debug_bullet(275,305,1100,0,0,20,1)
    s=step(engine,1,dt=.0333)
    assert s.bullet_count==0
    assert any(e.kind==8 for e in s.events[:s.event_count])


def test_deep_18_bruiser_detours_around_vertical_barrier(engine):
    engine.debug_player(560,180,140)
    engine.debug_enemy(2,300,180,100)
    before=snap(engine);assert before.enemies[0].x==300
    after=step(engine,135,aim_x=560,aim_y=180)
    e=after.enemies[0]
    assert e.active and e.x>380 and e.y>210,(e.x,e.y)


def test_deep_19_obstacle_detour_is_deterministic_from_same_seed(engine):
    positions=[]
    for _ in range(2):
        engine.engine_reset(1369)
        engine.debug_player(560,180,140)
        engine.debug_enemy(2,300,180,100)
        s=step(engine,140)
        positions.append((s.enemies[0].x,s.enemies[0].y))
    assert positions[0]==positions[1]


def test_deep_20_bruteforce_enemy_walk_never_leaves_arena(engine):
    engine.debug_player(560,180,140)
    engine.debug_enemy(2,300,180,100)
    for _ in range(240):
        s=step(engine,1)
        for e in s.enemies:
            if e.active:
                assert e.radius+11<=e.x<=1120-e.radius-11
                assert e.radius+11<=e.y<=620-e.radius-11


def test_deep_21_tiny_positive_input_does_not_overflow(engine):
    state=step(engine,1,move_x=1.e-38,move_y=1.e-38,aim_x=0,aim_y=0)
    assert math.isfinite(state.player.x) and math.isfinite(state.player.y)
    assert 0<=state.player.x<=1120


def test_deep_22_shield_survives_display_pause_without_decay(app):
    app.new_game();app.engine.upgrade(8)
    app.screen='PLAYING';app.pause()
    before=app.engine.state.invulnerability
    app.last_clock=time.perf_counter()-15
    app.tick()
    assert app.engine.state.invulnerability==before


def test_deep_23_best_score_save_clamps_invalid_ranges(tmp_path):
    p=tmp_path/'score.json'
    assert write_best(p,-300,10**20)
    assert read_best(p)==(0,9999)


def test_deep_24_save_corruption_is_nonfatal_and_recoverable(tmp_path):
    p=tmp_path/'score.json';p.write_text('{broken',encoding='utf8')
    assert read_best(p)==(0,0)
    assert write_best(p,2700,3)
    assert read_best(p)==(2700,3)


def test_deep_25_failed_save_has_no_temporary_file_leaks(tmp_path):
    p=tmp_path/'nonexistent_dir'/'save.json'
    assert write_best(p,100,1) is False
    assert not list(tmp_path.glob('**/.steelfront-*.tmp'))


def test_deep_26_boss_and_obstacle_appear_on_wave_five_for_many_seeds(engine):
    for seed in range(1,16):
        engine.engine_reset(seed)
        engine.debug_wave(4);engine.engine_next_wave()
        s=snap(engine)
        assert s.wave==5
        assert sum(e.active and e.type==3 for e in s.enemies)==1
        assert s.obstacle_count>=18


def test_deep_27_no_empty_initial_wave_for_many_seeds(engine):
    for seed in range(1,71):
        engine.engine_reset(seed);engine.engine_next_wave()
        assert snap(engine).enemy_count>=1


def test_deep_28_python_does_not_use_external_runtime_dependencies():
    import ast
    stdlib={'__future__','tkinter','random','math','sys','time','pathlib','ctypes',
            'os','tempfile','subprocess','shlex','shutil','json'}
    local={'arena_config','arena_effects','arena_visual','arena_menus',
           'arena_scores','c_bridge','build_engine'}
    for path in ROOT.glob('*.py'):
        tree=ast.parse(path.read_text())
        for node in ast.walk(tree):
            if isinstance(node,ast.Import):
                names=[alias.name.partition('.')[0] for alias in node.names]
            elif isinstance(node,ast.ImportFrom) and node.module:
                names=[node.module.partition('.')[0]]
            else:continue
            assert set(names)<=stdlib|local,(path.name,names)


def test_deep_29_window_restricts_its_geometry_to_desktop(app):
    assert app.w<=max(320,app.root.winfo_screenwidth()-60)
    assert app.h<=max(240,app.root.winfo_screenheight()-90)
    assert app.scale>0


def test_deep_30_display_modes_have_expected_overlay_labels(app):
    app.new_game();app.start_upgrade_screen()
    for mode,phrase in [('TITLE','STEELFRONT'),('PAUSED','PAUSED'),
                        ('GAMEOVER','TANK DESTROYED'),('UPGRADE','WAVE CLEARED'),
                        ('INTRO','ENGAGE')]:
        app.screen=mode;app.render()
        labels=[app.canvas.itemcget(i,'text') for i in app.canvas.find_withtag('dynamic')
                if app.canvas.type(i)=='text']
        assert any(phrase in t for t in labels),(mode,phrase)


def test_deep_31_dynamic_elements_do_not_leave_frame_on_state_transition(app):
    app.new_game();app.render()
    n1=len(app.canvas.find_all())
    app.screen='PAUSED';app.render()
    n2=len(app.canvas.find_all())
    app.screen='PLAYING';app.render()
    n3=len(app.canvas.find_all())
    assert n2-n1<120 and abs(n3-n1)<10


def test_deep_32_full_combat_simulation_from_random_inputs(engine):
    import random
    rng=random.Random(83591)
    engine.engine_next_wave()
    for _ in range(1000):
        s=step(engine,1,move_x=rng.choice((-1,0,1)),
               move_y=rng.choice((-1,0,1)),aim_x=rng.randrange(0,1120),
               aim_y=rng.randrange(0,620),fire=rng.randrange(2),
               dash=rng.randrange(30)==0,pulse=rng.randrange(50)==0)
        assert math.isfinite(s.player.x) and math.isfinite(s.player.hp)
        assert 0<=s.bullet_count<=420 and 0<=s.event_count<=220
        if not s.player_alive: break


def test_deep_33_weapon_never_fires_when_dead(engine):
    engine.debug_player(560,310,0)
    before=snap(engine)
    after=step(engine,1,fire=1,pulse=1,dash=1)
    assert after.player_alive==0 and after.bullet_count==before.bullet_count


def test_deep_34_invalid_upgrade_cannot_change_combat_stats(engine):
    before=snap(engine)
    for kind in (-1,2222,2**31-1):engine.engine_upgrade(kind)
    after=snap(engine)
    assert (after.player_damage,after.armor,after.player.hp)==(before.player_damage,before.armor,before.player.hp)


def test_deep_35_near_zero_mouse_vector_is_finite(engine):
    s=step(engine,120,aim_x=560,aim_y=310,fire=1)
    assert math.isfinite(s.player.turret)
    assert all(math.isfinite(b.x) and math.isfinite(b.y) for b in s.bullets if b.active)


def test_deep_36_engine_snapshots_are_finite_after_long_input_sequence(engine):
    engine.engine_next_wave()
    for j in range(1800):
        if not snap(engine).player_alive:
            engine.engine_reset(j+123);engine.engine_next_wave()
        s=step(engine,1,fire=j%3==0,move_x=math.sin(j*.1),move_y=math.cos(j*.1),
               aim_x=(j*17)%1120,aim_y=(j*23)%620)
        assert math.isfinite(s.time) and math.isfinite(s.dash_energy)
        assert 0<=s.enemy_count<=80 and 0<=s.bullet_count<=420


def test_deep_37_python_packages_parse_and_compile():
    import py_compile
    for name in ('main','arena_config','arena_effects','arena_visual',
                 'arena_menus','arena_scores','build_engine','c_bridge'):
        py_compile.compile(str(ROOT/(name+'.py')),doraise=True)


def test_deep_38_shipped_run_scripts_point_to_actual_entrypoint():
    sh=(ROOT/'run_steelfront.sh').read_text()
    bat=(ROOT/'Run_Steelfront.bat').read_text()
    assert 'main.py' in sh and 'main.py' in bat
    assert (ROOT/'main.py').is_file()


def test_deep_39_canvas_hover_highlights_correct_upgrade_card(app):
    app.new_game();app.start_upgrade_screen();app.render()
    l,t,r,b=app.card_bounds[1]
    app.pointer=((l+r)/2,(t+b)/2)
    app.render()
    assert app.last_rendered_hover==1


def test_deep_40_score_ignores_zero_gain_at_cap(engine):
    for _ in range(33334):
        engine.engine_upgrade(9)
    assert snap(engine).score==99999999
    engine.debug_enemy(0,660,310,5)
    engine.debug_bullet(640,310,1000,0,0,100,0)
    state=step(engine,1,dt=.0333)
    assert state.score==99999999
    assert not any(e.kind==12 for e in state.events[:state.event_count])


def test_deep_41_grazing_metal_corner_does_not_hit_empty_space(engine):
    # A swept circle must use rounded rectangle corners, not an expanded box.
    # Steel starts x=350,y=80 and the shell radius is 3. The closest distance
    # at end x=348,y=77.2 is sqrt(2²+2.8²), greater than the shell radius.
    engine.debug_bullet(345,77.2,180,0,0,10,1)
    state=step(engine,1,dt=1/60)
    shot=next(b for b in state.bullets if b.active)
    assert shot.x==pytest.approx(348,abs=.02)
    assert shot.bounces==1
    assert not any(e.kind==2 for e in state.events[:state.event_count])


def test_deep_42_actual_metal_corner_hit_has_oblique_reflection(engine):
    engine.debug_bullet(345,78,300,0,0,10,1)
    state=step(engine,1,dt=1/60)
    shot=next(b for b in state.bullets if b.active)
    assert shot.bounces==0
    assert shot.vy < -50  # a rounded corner has an oblique surface normal
    assert any(e.kind==2 for e in state.events[:state.event_count])


def test_deep_43_compact_upgrade_copy_stays_inside_small_cards(app):
    from arena_config import UPGRADE_COMPACT
    app.new_game();app.scale=580/1280;app.w=580;app.h=362
    app.canvas.configure(width=580,height=362)
    app.screen='UPGRADE';app.upgrade_choices=[1,4,6]
    app.render();app.root.update_idletasks()
    expected=[UPGRADE_COMPACT[i] for i in app.upgrade_choices]
    for idx,caption in enumerate(expected):
        items=[ident for ident in app.canvas.find_withtag('dynamic')
               if app.canvas.type(ident)=='text' and
               app.canvas.itemcget(ident,'text')==caption]
        assert len(items)==1,(idx,caption)
        bounds=app.canvas.bbox(items[0]);l,t,r,b=app.card_bounds[idx]
        assert bounds is not None
        assert bounds[0]>=l*app.scale and bounds[2] <= r*app.scale
        assert bounds[3] <= (b-40)*app.scale


def test_deep_44_small_hud_single_line_is_not_clipped(app):
    app.new_game();app.scale=580/1280;app.w=580;app.h=362
    app.canvas.configure(width=580,height=362)
    app.screen='PLAYING';app.render();app.root.update_idletasks()
    captions={i:app.canvas.itemcget(i,'text') for i in app.canvas.find_withtag('hud')
              if app.canvas.type(i)=='text'}
    assert any('SHIFT DASH' in t for t in captions.values())
    assert all('CORE 04' not in t for t in captions.values())
    for ident,caption in captions.items():
        if 'SHIFT DASH' in caption or 'C / PYTHON' in caption:
            assert app.canvas.bbox(ident)[3] <= app.h+2
