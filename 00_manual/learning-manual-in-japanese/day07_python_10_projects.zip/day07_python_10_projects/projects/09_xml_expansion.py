import sys
from xml.etree import ElementTree

CASES = {
    "plain": '<note>LAB</note>',
    "entity": '<!DOCTYPE note [<!ENTITY a "LAB"><!ENTITY b "&a;&a;&a;&a;">]><note>&b;&b;&b;&b;</note>',
    "broken": '<note>',
}


def expanded_length(raw):
    root = ElementTree.fromstring(raw)
    return len(root.text or "")


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script plain|entity|broken", file=sys.stderr)
        return 2
    raw = CASES[sys.argv[1]]
    try:
        length = expanded_length(raw)
    except ElementTree.ParseError:
        print("Invalid lab XML.", file=sys.stderr)
        return 2
    print(f"Expanded characters: {length}")
    print(f"DTD policy: {'reject' if '<!DOCTYPE' in raw else 'accept'}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
