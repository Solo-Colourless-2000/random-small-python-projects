"""Deterministic geometry, wave generation and selection helpers (no GUI)."""
from __future__ import annotations

import math
import random

from constants import ARENA_BOTTOM, ARENA_LEFT, ARENA_RIGHT, ARENA_TOP, UPGRADES


def clamp(value: float, low: float, high: float) -> float:
    return max(low, min(high, value))


def unit(x: float, y: float) -> tuple[float, float]:
    length = math.hypot(x, y)
    return (x / length, y / length) if length > 1e-8 else (0.0, 0.0)


def distance_sq(x1: float, y1: float, x2: float, y2: float) -> float:
    return (x1 - x2) ** 2 + (y1 - y2) ** 2


def circles_touch(ax: float, ay: float, ar: float, bx: float, by: float, br: float) -> bool:
    return distance_sq(ax, ay, bx, by) <= (ar + br) ** 2


def sweep_circle(
    ax: float, ay: float, bx: float, by: float,
    cx: float, cy: float, radius: float,
) -> float | None:
    """First hit time (0..1) of a moving point AB against a circle; None if missed.

    The radius should be the sum of the two colliders' radii.
    Handles zero-length travel, initial overlap and tangent hits.
    """
    ox, oy = ax - cx, ay - cy
    dx, dy = bx - ax, by - ay
    r2 = radius * radius
    if ox * ox + oy * oy <= r2:
        return 0.0
    aa = dx * dx + dy * dy
    if aa <= 1e-12:
        return None
    bb = 2 * (ox * dx + oy * dy)
    cc = ox * ox + oy * oy - r2
    disc = bb * bb - 4 * aa * cc
    if disc < 0:
        return None
    t = (-bb - math.sqrt(disc)) / (2 * aa)
    return t if 0 <= t <= 1 else None


def moving_circle_hit(
    ax: float, ay: float, bx: float, by: float,
    cx: float, cy: float, dx: float, dy: float,
    combined_radius: float,
) -> float | None:
    """First contact fraction for two discs moving linearly during one frame."""
    return sweep_circle(ax - cx, ay - cy, bx - dx, by - dy, 0, 0, combined_radius)


def boundary_travel_fraction(x: float, y: float, dx: float, dy: float) -> float:
    """Fraction of a movement vector that remains within the visible arena.

    Projectiles can start slightly outside when enemies fire near a wall. In
    that case they get one frame to enter, but cannot hit across the whole arena.
    """
    fraction = 1.0
    if dx > 0 and x <= ARENA_RIGHT:
        fraction = min(fraction, max(0.0, (ARENA_RIGHT - x) / dx))
    elif dx < 0 and x >= ARENA_LEFT:
        fraction = min(fraction, max(0.0, (ARENA_LEFT - x) / dx))
    if dy > 0 and y <= ARENA_BOTTOM:
        fraction = min(fraction, max(0.0, (ARENA_BOTTOM - y) / dy))
    elif dy < 0 and y >= ARENA_TOP:
        fraction = min(fraction, max(0.0, (ARENA_TOP - y) / dy))
    return clamp(fraction, 0.0, 1.0)


def in_arena(x: float, y: float, radius: float = 0) -> tuple[float, float]:
    return (clamp(x, ARENA_LEFT + radius, ARENA_RIGHT - radius),
            clamp(y, ARENA_TOP + radius, ARENA_BOTTOM - radius))


def boundary_spawn(rng: random.Random, margin: float = 8) -> tuple[float, float]:
    """Spawn just inside the arena boundary, away from its center."""
    edge = rng.randrange(4)
    inset = max(10, margin)
    if edge == 0:
        return rng.uniform(ARENA_LEFT + inset, ARENA_RIGHT - inset), ARENA_TOP + margin
    if edge == 1:
        return rng.uniform(ARENA_LEFT + inset, ARENA_RIGHT - inset), ARENA_BOTTOM - margin
    if edge == 2:
        return ARENA_LEFT + margin, rng.uniform(ARENA_TOP + inset, ARENA_BOTTOM - inset)
    return ARENA_RIGHT - margin, rng.uniform(ARENA_TOP + inset, ARENA_BOTTOM - inset)


def wave_roster(wave: int, rng: random.Random) -> list[str]:
    """Gradually tougher waves, with one warden on each fifth wave."""
    if wave < 1:
        raise ValueError('Wave numbers begin at 1')
    count = min(6 + 2 * wave, 28)
    pool = ['hunter'] * 6
    if wave >= 2:
        pool += ['runner'] * 3
    if wave >= 3:
        pool += ['gunner'] * 3
    if wave >= 4:
        pool += ['bruiser'] * 2
    if wave >= 7:
        pool += ['gunner', 'bruiser', 'runner']
    roster = [rng.choice(pool) for _ in range(count)]
    rng.shuffle(roster)
    if wave % 5 == 0:
        roster.append('warden')
    return roster


def upgrade_choices(
    rng: random.Random,
    previous: set[str] | None = None,
    eligible: set[str] | None = None,
) -> list[str]:
    """Sample up to three useful upgrades, preferring choices not just offered.

    Never reintroduce ineligible (capped) upgrades merely to fill the cards.
    """
    pool = [key for key in UPGRADES if eligible is None or key in eligible]
    fresh = [key for key in pool if key not in (previous or set())]
    chosen = rng.sample(fresh, min(3, len(fresh)))
    if len(chosen) < 3:
        leftovers = [key for key in pool if key not in chosen]
        chosen.extend(rng.sample(leftovers, min(3 - len(chosen), len(leftovers))))
    rng.shuffle(chosen)
    return chosen


def format_seconds(seconds: float) -> str:
    n = max(0, int(seconds))
    return f'{n // 60:02d}:{n % 60:02d}'
