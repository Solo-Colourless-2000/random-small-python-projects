#include "engine_internal.h"

Snapshot s;
uint32_t rng_state;
float contact_cooldown;
float dash_timer;
float enemy_ai_time[MAX_ENEMIES];
float enemy_strafe[MAX_ENEMIES];

static unsigned int rnd(void) {
    uint32_t x=rng_state;
    x ^= x << 13; x ^= x >> 17; x ^= x << 5;
    rng_state=x;
    return x;
}
float rand01(void) { return (rnd() >> 8) * (1.0f/16777216.0f); }
float rand_range(float lo,float hi) { return lo+(hi-lo)*rand01(); }
void event_at(int kind,float x,float y,float value) {
    if(s.event_count>=MAX_EVENTS) return;
    Event *e=&s.events[s.event_count++];
    e->kind=kind;e->x=x;e->y=y;e->value=value;
}

void add_wall(float x,float y,float w,float h,int kind) {
    if(s.obstacle_count>=MAX_OBSTACLES) return;
    Obstacle *o=&s.obstacles[s.obstacle_count++];
    o->x=x;o->y=y;o->w=w;o->h=h;o->kind=kind;o->active=1;
    o->hp=kind?90.0f:999999.0f;
}


API int engine_api_version(void) { return API_VERSION; }
API int engine_snapshot_size(void) { return (int)sizeof(Snapshot); }
API void engine_reset(unsigned int seed) {
    memset(&s,0,sizeof(s));
    memset(enemy_ai_time,0,sizeof(enemy_ai_time));
    memset(enemy_strafe,0,sizeof(enemy_strafe));
    rng_state=seed?seed:0xB9A3DA17u;
    contact_cooldown=0;dash_timer=0;
    s.player_alive=1;
    s.player.active=1;s.player.type=-1;s.player.x=WORLD_W*0.5f;s.player.y=WORLD_H*0.5f;
    s.player.radius=23.0f;s.player.hp=140.0f;s.player.max_hp=140.0f;
    s.player.turret=-1.5707963f;s.player.angle=-1.5707963f;
    s.dash_energy=100;s.dash_regen=21;s.pulse_cooldown=0;s.pulse_cooldown_max=10.0f;
    s.shot_interval=0.185f;s.player_damage=29.0f;s.player_speed=250.0f;s.armor=0.0f;
    /* Cover groups leave broad open lanes and an unblocked player spawn. */
    add_wall(130,105,158,27,0);add_wall(832,105,158,27,0);
    add_wall(130,486,158,27,0);add_wall(832,486,158,27,0);
    add_wall(350,80,30,120,0);add_wall(740,80,30,120,0);
    add_wall(350,420,30,120,0);add_wall(740,420,30,120,0);
    add_wall(165,253,70,50,1);add_wall(885,318,70,50,1);
    add_wall(451,140,62,53,1);add_wall(605,427,62,53,1);
    add_wall(465,473,56,48,1);add_wall(593,99,56,48,1);
    add_wall(100,368,70,45,1);add_wall(950,208,70,45,1);
    add_wall(297,279,49,44,1);add_wall(774,297,49,44,1);
}
API void engine_next_wave(void) {
    if(!s.player_alive) return;
    for(int i=0;i<MAX_BULLETS;i++) s.bullets[i].active=0;
    for(int i=0;i<MAX_PICKUPS;i++) s.pickups[i].active=0;
    if(s.wave<9999) s.wave++;  /* Avoid signed overflow during extreme endurance runs. */
    int count=5+s.wave*2;
    if(count>32) count=32;
    if(s.wave%5==0) count-=3;
    for(int i=0;i<count;i++) {
        int type;
        float roll=rand01();
        if(s.wave<=1) type=roll<.58f?ENEMY_SCOUT:ENEMY_GUNNER;
        else if(s.wave<=3) type=roll<.38f?ENEMY_SCOUT:roll<.83f?ENEMY_GUNNER:ENEMY_BRUISER;
        else type=roll<.32f?ENEMY_SCOUT:roll<.70f?ENEMY_GUNNER:ENEMY_BRUISER;
        float r=type==ENEMY_BRUISER?26.0f:20.0f;
        for(int attempts=0;attempts<220;attempts++) {
            float x=rand_range(42.0f,WORLD_W-42.0f);
            float y=rand_range(42.0f,WORLD_H-42.0f);
            if(!spawn_valid(x,y,r)) continue;
            make_enemy(type,x,y);break;
        }
    }
    if(s.wave%5==0) {
        for(int attempts=0;attempts<300;attempts++) {
            float x=rand_range(65,WORLD_W-65),y=rand_range(65,WORLD_H-65);
            if(spawn_valid(x,y,35)) {make_enemy(ENEMY_BOSS,x,y);break;}
        }
    }
    event_at(EVENT_WAVE,s.player.x,s.player.y,(float)s.wave);
}

API void engine_step(const Control *ctrl,float dt) {
    if(!ctrl || !s.player_alive || !isfinite(dt) || dt<=0 ||
       !isfinite(ctrl->move_x) || !isfinite(ctrl->move_y) ||
       !isfinite(ctrl->aim_x) || !isfinite(ctrl->aim_y)) return;
    /* Preserve sub-millisecond steps exactly; a minimum of 1 ms
     * would make a valid 0.1 ms update advance simulation tenfold. */
    dt=minf(dt,0.0334f);
    s.event_count=0;s.time+=dt;
    s.combo_timer=maxf(0,s.combo_timer-dt);
    s.focus_timer=maxf(0,s.focus_timer-dt);
    if(s.combo_timer<=0) s.combo=0;
    s.invulnerability=maxf(0,s.invulnerability-dt);
    contact_cooldown=maxf(0,contact_cooldown-dt);
    s.pulse_cooldown=maxf(0,s.pulse_cooldown-dt);
    s.dash_energy=minf(100.0f,s.dash_energy+s.dash_regen*dt);
    Tank *p=&s.player;
    p->flash=maxf(0,p->flash-dt);
    p->reload=maxf(0,p->reload-dt);
    float aim=atan2f(ctrl->aim_y-p->y,ctrl->aim_x-p->x);
    p->turret=angle_approach(p->turret,aim,13.5f,dt);
    float vx=clampf(ctrl->move_x,-1,1),vy=clampf(ctrl->move_y,-1,1);
    norm(&vx,&vy);
    if(ctrl->dash && dash_timer<=0 && s.dash_energy>=66 && (vx!=0 || vy!=0)) {
        dash_timer=.18f;s.dash_energy-=66;
        s.invulnerability=maxf(s.invulnerability,.25f);
        event_at(EVENT_DASH,p->x,p->y,0);
    }
    if(dash_timer>0) dash_timer=maxf(0,dash_timer-dt);
    float speed=s.player_speed*(dash_timer>0?3.45f:1.0f);
    if(length2(vx,vy)>.001f) p->angle=angle_approach(p->angle,atan2f(vy,vx),10.0f,dt);
    p->vx=vx*speed;p->vy=vy*speed;
    move_tank(p,p->vx*dt,p->vy*dt);
    if(ctrl->fire && p->reload<=0) {
        float dir=p->turret;
        add_bullet(p->x+cosf(dir)*34,p->y+sinf(dir)*34,dir,760.0f,
                   s.player_damage*(s.focus_timer>0?1.5f:1.0f),0,1);
        p->reload=s.shot_interval;
    }
    if(ctrl->pulse && s.pulse_cooldown<=0) {
        s.pulse_cooldown=s.pulse_cooldown_max;
        event_at(EVENT_PULSE,p->x,p->y,168.0f);
        for(int i=0;i<MAX_ENEMIES;i++) {
            Tank *e=&s.enemies[i];
            float dist=sqrtf(length2(e->x-p->x,e->y-p->y));
            if(!e->active || dist>168.0f+e->radius) continue;
            e->hp=maxf(0,e->hp-62.0f);
            e->flash=.20f;e->stun=2.0f;
            event_at(EVENT_ENEMY_HIT,e->x,e->y,62.0f);
            if(e->hp<=0) kill_enemy(e);
        }
        for(int i=0;i<MAX_BULLETS;i++) {
            Bullet *b=&s.bullets[i];
            if(b->active && b->owner==1 && length2(b->x-p->x,b->y-p->y)<190.0f*190.0f)
                b->active=0;
        }
    }
    for(int i=0;i<MAX_ENEMIES;i++) update_enemy(i,dt);
    update_bullets(dt);
    if(!s.player_alive) return;
    for(int i=0;i<MAX_PICKUPS;i++) {
        Pickup *pick=&s.pickups[i];
        if(!pick->active) continue;
        pick->ttl-=dt;
        if(pick->ttl<=0) {pick->active=0;continue;}
        if(length2(p->x-pick->x,p->y-pick->y)<(p->radius+16)*(p->radius+16)) {
            if(pick->kind==PICKUP_REPAIR) p->hp=minf(p->max_hp,p->hp+27);
            else s.dash_energy=minf(100,s.dash_energy+42);
            pick->active=0;event_at(EVENT_PICKUP,pick->x,pick->y,(float)pick->kind);
        }
    }
}
API void engine_upgrade(int upgrade) {
    if(!s.player_alive) return;
    switch(upgrade) {
        case UPGRADE_REPAIR:s.player.hp=minf(s.player.max_hp,s.player.hp+58);break;
        case UPGRADE_DAMAGE:s.player_damage=minf(100,s.player_damage+8);break;
        case UPGRADE_ARMOR:s.armor=minf(.58f,s.armor+.10f);break;
        case UPGRADE_RELOAD:s.shot_interval=maxf(.07f,s.shot_interval*.88f);break;
        case UPGRADE_DASH:s.dash_regen=minf(65,s.dash_regen+7);break;
        case UPGRADE_PULSE:s.pulse_cooldown_max=maxf(4.0f,s.pulse_cooldown_max-1.4f);
            s.pulse_cooldown=minf(s.pulse_cooldown,s.pulse_cooldown_max);break;
        case UPGRADE_MOBILITY:s.player_speed=minf(400,s.player_speed+22);break;
        case UPGRADE_CORE:
            s.player.max_hp=minf(270,s.player.max_hp+30);
            s.player.hp=minf(s.player.max_hp,s.player.hp+30);break;
        case UPGRADE_SHIELD:
            s.invulnerability=maxf(s.invulnerability,6.0f);break;
        case UPGRADE_SALVAGE:
            s.score=(s.score>99999999-3000)?99999999:s.score+3000;break;
        case UPGRADE_FOCUS:
            s.focus_timer=maxf(s.focus_timer,9.0f);break;
        default:break;
    }
}
API void engine_snapshot(Snapshot *out) {
    if(!out) return;
    s.enemy_count=0;s.bullet_count=0;s.pickup_count=0;
    for(int i=0;i<MAX_ENEMIES;i++) if(s.enemies[i].active) s.enemy_count++;
    for(int i=0;i<MAX_BULLETS;i++) if(s.bullets[i].active) s.bullet_count++;
    for(int i=0;i<MAX_PICKUPS;i++) if(s.pickups[i].active) s.pickup_count++;
    memcpy(out,&s,sizeof(s));
}

#ifdef ENGINE_TESTING
/* Debug-only hooks are compiled into the test build, not the release library. */
API void debug_clear_enemies(void) {
    for(int i=0;i<MAX_ENEMIES;i++) s.enemies[i].active=0;
}
API void debug_clear_bullets(void) {
    for(int i=0;i<MAX_BULLETS;i++) s.bullets[i].active=0;
}
API void debug_player(float x,float y,float hp) {
    s.player.x=x;s.player.y=y;
    s.player.hp=clampf(hp,0,s.player.max_hp);
    s.player_alive=s.player.hp>0;
    s.invulnerability=0;
}
API void debug_enemy(int type,float x,float y,float hp) {
    make_enemy(type,x,y);
    for(int i=0;i<MAX_ENEMIES;i++) {
        Tank *e=&s.enemies[i];
        if(e->active && e->x==x && e->y==y) {e->hp=hp;e->max_hp=maxf(hp,e->max_hp);break;}
    }
}
API void debug_bullet(float x,float y,float vx,float vy,int owner,float damage,int ricochets) {
    Bullet *b=add_bullet(x,y,atan2f(vy,vx),sqrtf(length2(vx,vy)),damage,owner,ricochets);
    if(b) {b->radius=3;b->lifetime=3;}
}
API void debug_energy(float energy) {s.dash_energy=clampf(energy,0,100);}
API void debug_pulse_cd(float sec) {s.pulse_cooldown=maxf(0,sec);}
API void debug_wave(int wave) {s.wave=wave;}
API void debug_pickup(float x,float y,int kind) {add_pickup(x,y,kind);}
API void debug_invulnerability(float sec) {s.invulnerability=maxf(0,sec);}
API void debug_enemy_ready(float angle) {
    for(int i=0;i<MAX_ENEMIES;i++) {
        if(s.enemies[i].active) {s.enemies[i].turret=angle;s.enemies[i].reload=0;}
    }
}
API int debug_los(float x,float y,float xx,float yy) {return has_los(x,y,xx,yy);}
#endif
