#include "engine_internal.h"

Bullet *add_bullet(float x,float y,float angle,float speed,float damage,int owner,int bounces) {
    for(int i=0;i<MAX_BULLETS;i++) {
        Bullet *b=&s.bullets[i];
        if(b->active) continue;
        b->x=x;b->y=y;b->prev_x=x;b->prev_y=y;
        b->vx=cosf(angle)*speed;b->vy=sinf(angle)*speed;
        b->radius=owner==0?4.9f:4.8f;
        b->damage=damage;b->owner=owner;b->bounces=bounces;
        b->lifetime=owner==0?1.6f:2.3f;b->active=1;
        event_at(EVENT_SHOOT,x,y,(float)owner);
        return b;
    }
    return 0;
}
void add_pickup(float x,float y,int kind) {
    for(int i=0;i<MAX_PICKUPS;i++) {
        Pickup *p=&s.pickups[i];
        if(!p->active){p->x=x;p->y=y;p->ttl=11.0f;p->kind=kind;p->active=1;return;}
    }
}
void kill_enemy(Tank *t) {
    if(!t->active) return;
    t->active=0;s.kills++;
    if(s.combo_timer>0) s.combo=(s.combo<8)?s.combo+1:8;
    else s.combo=1;
    s.combo_timer=3.5f;
    int base=t->type==ENEMY_SCOUT?100:t->type==ENEMY_GUNNER?160:t->type==ENEMY_BRUISER?230:2000;
    int reward=base*s.combo;
    int old_score=s.score;
    if(s.score<99999999-reward) s.score+=reward;
    else s.score=99999999;
    event_at(EVENT_KILL,t->x,t->y,(float)t->type);
    /* A secured sector must actually be safe. Previously hostile bullets
     * could kill the player during the reward countdown after the last
     * enemy was gone, even while 'SECTOR SECURED' was on screen. */
    int remaining_enemies=0;
    for(int i=0;i<MAX_ENEMIES;i++)
        if(s.enemies[i].active) {remaining_enemies=1;break;}
    if(!remaining_enemies)
        for(int i=0;i<MAX_BULLETS;i++)
            if(s.bullets[i].active && s.bullets[i].owner==1)
                s.bullets[i].active=0;
    if(s.score>old_score) event_at(EVENT_SCORE,t->x,t->y,(float)(s.score-old_score));
    float roll=rand01();
    if(roll<0.15f) add_pickup(t->x,t->y,PICKUP_REPAIR);
    else if(roll<0.38f) add_pickup(t->x,t->y,PICKUP_ENERGY);
}
void damage_player(float damage,float bx,float by) {
    if(s.invulnerability>0 || !s.player_alive) return;
    float actual=maxf(1.0f,damage*(1.0f-s.armor));
    s.player.hp=maxf(0,s.player.hp-actual);
    s.player.flash=0.22f;
    s.invulnerability=0.58f;
    event_at(EVENT_PLAYER_HIT,bx,by,actual);
    if(s.player.hp<=0) {
        s.player_alive=0;
        event_at(EVENT_PLAYER_DEAD,s.player.x,s.player.y,0);
    }
}
/* Advance the unused fraction of a frame after a ricochet. Otherwise a shell
 * loses up to one full frame of travel every time it hits steel. */
void update_bullets(float dt) {
    for(int i=0;i<MAX_BULLETS;i++) {
        Bullet *b=&s.bullets[i];
        if(!b->active) continue;
        b->lifetime-=dt;
        if(b->lifetime<=0) {b->active=0;continue;}
        b->prev_x=b->x;b->prev_y=b->y;
        float remaining=dt;
        /* Each player shell can reflect at most once, so two sweeps suffice. */
        for(int sweep=0;sweep<2 && b->active;sweep++) {
            float dx=b->vx*remaining,dy=b->vy*remaining;
            float nearest=1.001f,nx=0,ny=0;
            int hit_kind=0,hit_idx=-1;
            for(int k=0;k<s.obstacle_count;k++) {
                Obstacle *o=&s.obstacles[k];float t,ox,oy;
                if(o->active && ray_box(b->x,b->y,dx,dy,o,b->radius,&t,&ox,&oy)
                   && t<nearest) {
                    nearest=t;nx=ox;ny=oy;hit_kind=1;hit_idx=k;
                }
            }
            if(b->owner==0) {
                for(int k=0;k<MAX_ENEMIES;k++) {
                    Tank *e=&s.enemies[k];float t;
                    if(e->active && ray_circle(b->x,b->y,dx,dy,e->x,e->y,
                         e->radius+b->radius,&t) && t<nearest) {
                        nearest=t;hit_kind=2;hit_idx=k;
                    }
                }
            } else if(s.player_alive) {
                float t;
                if(ray_circle(b->x,b->y,dx,dy,s.player.x,s.player.y,
                     s.player.radius+b->radius,&t) && t<nearest) {
                    nearest=t;hit_kind=3;
                }
            }
            if(hit_kind==0) {
                b->x+=dx;b->y+=dy;
                if(b->x<-20 || b->x>WORLD_W+20 || b->y<-20 || b->y>WORLD_H+20)
                    b->active=0;
                break;
            }
            b->x+=dx*nearest;b->y+=dy*nearest;
            if(hit_kind==1) {
                Obstacle *o=&s.obstacles[hit_idx];
                event_at(EVENT_IMPACT,b->x,b->y,(float)b->owner);
                if(o->kind==1) {
                    o->hp-=b->damage;
                    event_at(EVENT_COVER_HIT,b->x,b->y,o->hp);
                    if(o->hp<=0) {
                        o->active=0;
                        event_at(EVENT_KILL,o->x+o->w*.5f,o->y+o->h*.5f,-1);
                    }
                } else if(b->owner==0 && b->bounces>0 && (nx!=0 || ny!=0)) {
                    float dot=b->vx*nx+b->vy*ny;
                    b->vx-=2*dot*nx;b->vy-=2*dot*ny;
                    b->x+=nx*1.5f;b->y+=ny*1.5f;
                    b->prev_x=b->x;b->prev_y=b->y;
                    b->bounces--;
                    b->damage*=.72f;
                    remaining*=1.0f-nearest;
                    if(remaining>0.00001f) continue;
                    break;
                }
            } else if(hit_kind==2) {
                Tank *e=&s.enemies[hit_idx];
                e->hp=maxf(0,e->hp-b->damage);e->flash=.13f;
                event_at(EVENT_ENEMY_HIT,b->x,b->y,b->damage);
                if(e->hp<=0) kill_enemy(e);
            } else if(hit_kind==3) {
                damage_player(b->damage,b->x,b->y);
                event_at(EVENT_IMPACT,b->x,b->y,1);
            }
            b->active=0;
            if(!s.player_alive) return;
        }
    }
}
