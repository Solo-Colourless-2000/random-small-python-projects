
(() => {
'use strict';
const $ = (q) => document.querySelector(q);
const $$ = (q) => [...document.querySelectorAll(q)];
const sections = $$('.manual-section');
const targets = $$('.toc-item');
const key = 'snake-c-python-v5-development-manual-20261114';
let historyAnchor = '';
let active = 'home';
let saved = {};
try { saved = JSON.parse(localStorage.getItem(key) || '{}') || {}; } catch (_) {}
const done = new Set(Array.isArray(saved.done) ? saved.done : []);
let scale = Math.max(.8,Math.min(1.35,Number(saved.scale)||1));
const ui = $('#uiStatus');
let toast = 0;
function store(){ try {localStorage.setItem(key,JSON.stringify({done:[...done],scale}));}catch(_){} }
function status(text){ui.textContent=text; clearTimeout(toast);toast=setTimeout(()=>ui.textContent='',2300);}
function completion(){
 const c=$$('[data-progress]'); const n=c.filter(e=>done.has(e.dataset.progress)).length;
 $('#completion').textContent=`${n} / ${c.length} 工程を確認`;
 $('#topProgress').style.width=`${c.length?(100*n/c.length).toFixed(2):0}%`;
}
for (const box of $$('input[data-progress]')){
 box.checked=done.has(box.dataset.progress);
 box.addEventListener('change',()=>{box.checked?done.add(box.dataset.progress):done.delete(box.dataset.progress);store();completion();});
}
completion();document.documentElement.style.setProperty('--font-scale',String(scale));
function drawer(open){$('#sidebar').classList.toggle('open',open);$('#backdrop').classList.toggle('open',open);$('#menuButton').setAttribute('aria-expanded',String(open));}
$('#menuButton').addEventListener('click',()=>drawer(!$('#sidebar').classList.contains('open')));
$('#backdrop').addEventListener('click',()=>drawer(false));
$('#drawerClose').addEventListener('click',()=>drawer(false));
function go(to,updateHash=true){
 const element=document.getElementById(to)||document.getElementById('home');
 const section=element.closest('section.manual-section')||element;
 for (const s of sections){s.classList.toggle('active',s===section);}
 active=section.id;
 for (const b of targets){b.classList.toggle('active',b.dataset.target===active);}
 drawer(false);
 if(updateHash) {history.replaceState(null,'','#'+encodeURIComponent(to));}
 requestAnimationFrame(()=>{element.scrollIntoView({behavior:'instant',block: element===section?'start':'start'});});
}
function hashRoute(){
 let id='home';try {id=decodeURIComponent(location.hash.slice(1))||'home';}catch(_){}
 go(document.getElementById(id)?id:'home',false);
}
targets.forEach(b=>b.addEventListener('click',()=>go(b.dataset.target)));
$$('[data-move]').forEach(btn=>btn.addEventListener('click',()=>{let idx=sections.findIndex(x=>x.id===active);go(sections[Math.max(0,Math.min(sections.length-1,idx+Number(btn.dataset.move)))].id);}));
$$('a[href^="#"]').forEach(a=>a.addEventListener('click',event=>{
 const id=a.getAttribute('href').slice(1);if(!document.getElementById(id))return;
 if(a.classList.contains('source-jump')) {historyAnchor=a.closest('article')?.id||active; $('#returnToLesson').hidden=false;}
 event.preventDefault();go(id);
}));
$('#returnToLesson').addEventListener('click',()=>{if(historyAnchor) go(historyAnchor);$('#returnToLesson').hidden=true;});
window.addEventListener('hashchange',hashRoute);
$('#fontDown').addEventListener('click',()=>{scale=Math.max(.8,+(scale-.1).toFixed(2));document.documentElement.style.setProperty('--font-scale',String(scale));store();});
$('#fontUp').addEventListener('click',()=>{scale=Math.min(1.35,+(scale+.1).toFixed(2));document.documentElement.style.setProperty('--font-scale',String(scale));store();});
$('#focusButton').addEventListener('click',()=>{document.body.classList.toggle('focus');$('#focusButton').setAttribute('aria-pressed',String(document.body.classList.contains('focus')));});
$('#printButton').addEventListener('click',()=>window.print());
for (const copy of $$('.copy-btn')) {copy.addEventListener('click',async()=>{
 const node=copy.parentElement.querySelector('code');const value=node?.textContent||'';
 try {await navigator.clipboard.writeText(value);status('コードをコピーしました');}
 catch(_){ const temp=document.createElement('textarea');temp.value=value;temp.style.position='fixed';temp.style.opacity='0';document.body.append(temp);temp.select();const ok=document.execCommand('copy');temp.remove();status(ok?'コードをコピーしました':'選択して手動でコピーしてください'); }
});}
const input=$('#searchInput'),panel=$('#searchPanel'),results=$('#searchResults'),counter=$('#searchCount');
const searchItems = $$('.lesson-step').map(el=>({id:el.id,text:(el.dataset.searchTitle+' '+el.querySelector('.source-position')?.innerText+' '+el.querySelector(':scope > .code-wrap code')?.textContent).toLowerCase(),title:el.dataset.searchTitle}));
for (const s of sections) searchItems.push({id:s.id,text:(s.dataset.title+' '+(s.querySelector('.chapter-body')?.textContent||'')).toLowerCase(),title:s.dataset.title});
function updateSearch(){
 const q=input.value.trim().toLowerCase();results.replaceChildren();if(!q){panel.classList.remove('open');return;}
 const words=q.split(/\s+/).filter(Boolean);const found=searchItems.filter(x=>words.every(w=>x.text.includes(w))).slice(0,55);
 counter.textContent=`${found.length}件表示（先頭55件まで）`;
 for(const item of found){const b=document.createElement('button');b.type='button';b.className='search-result';b.textContent=item.title; b.addEventListener('click',()=>{go(item.id);panel.classList.remove('open');$('#headerSearch').classList.remove('mobile-search-open');});results.append(b);}
 if(!found.length)counter.textContent='該当なし。ファイル名、関数名、章名を試してください。';
 panel.classList.add('open');
}
input.addEventListener('input',updateSearch);
$('#searchButton').addEventListener('click',()=>{$('#headerSearch').classList.add('mobile-search-open');panel.classList.add('open');input.focus();updateSearch();});
$('#searchClose').addEventListener('click',()=>{$('#headerSearch').classList.remove('mobile-search-open');panel.classList.remove('open');input.value='';});
window.addEventListener('keydown',(e)=>{if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==='k'){e.preventDefault();input.focus();} if(e.key==='Escape'){panel.classList.remove('open');$('#headerSearch').classList.remove('mobile-search-open');drawer(false);}});
// On a local file:// URL, localStorage and Clipboard may be restricted; reading always works.
hashRoute();
})();
