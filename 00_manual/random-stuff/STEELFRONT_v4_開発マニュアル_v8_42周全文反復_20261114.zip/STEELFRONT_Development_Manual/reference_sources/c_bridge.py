"""ctypes ABI definitions for the real C simulation; no gameplay is simulated here."""
from __future__ import annotations
import ctypes as C
from build_engine import build

MAX_ENEMIES = 80
MAX_BULLETS = 420
MAX_OBSTACLES = 24
MAX_PICKUPS = 40
MAX_EVENTS = 220
WORLD_W = 1120
WORLD_H = 620

class Control(C.Structure):
    _fields_ = [("move_x", C.c_float), ("move_y", C.c_float),
                ("aim_x", C.c_float), ("aim_y", C.c_float),
                ("fire", C.c_int), ("dash", C.c_int), ("pulse", C.c_int)]

class Tank(C.Structure):
    _fields_ = [(name, C.c_float) for name in
                ("x", "y", "vx", "vy", "angle", "turret", "radius", "hp",
                 "max_hp", "reload", "stun", "flash")]
    _fields_ += [("active", C.c_int), ("type", C.c_int)]

class Bullet(C.Structure):
    _fields_ = [(name, C.c_float) for name in
                ("x", "y", "prev_x", "prev_y", "vx", "vy", "radius", "damage", "lifetime")]
    _fields_ += [(name, C.c_int) for name in ("active", "owner", "bounces")]

class Obstacle(C.Structure):
    _fields_ = [(name, C.c_float) for name in ("x", "y", "w", "h", "hp")]
    _fields_ += [("active", C.c_int), ("kind", C.c_int)]

class Pickup(C.Structure):
    _fields_ = [(name, C.c_float) for name in ("x", "y", "ttl")]
    _fields_ += [("active", C.c_int), ("kind", C.c_int)]

class Event(C.Structure):
    _fields_ = [("x", C.c_float), ("y", C.c_float), ("value", C.c_float), ("kind", C.c_int)]

class Snapshot(C.Structure):
    _fields_ = [(name, C.c_float) for name in
                ("time", "dash_energy", "pulse_cooldown", "pulse_cooldown_max", "dash_regen",
                 "shot_interval", "player_damage", "player_speed", "armor", "invulnerability")]
    _fields_ += [(name, C.c_int) for name in ("wave", "score", "kills", "combo", "player_alive")]
    _fields_ += [("combo_timer", C.c_float), ("focus_timer", C.c_float), ("player", Tank),
                 ("enemies", Tank * MAX_ENEMIES), ("bullets", Bullet * MAX_BULLETS),
                 ("obstacles", Obstacle * MAX_OBSTACLES), ("pickups", Pickup * MAX_PICKUPS),
                 ("events", Event * MAX_EVENTS)]
    _fields_ += [(name, C.c_int) for name in
                 ("enemy_count", "bullet_count", "obstacle_count", "pickup_count", "event_count")]

class Engine:
    def __init__(self):
        path = build()
        try:
            self.lib = C.CDLL(str(path))
        except OSError:
            # A Linux binary shipped for a different architecture may be
            # newer than its sources. Try a fresh local build once.
            self.lib = C.CDLL(str(build(force=True)))
        self.lib.engine_api_version.argtypes = []
        self.lib.engine_api_version.restype = C.c_int
        self.lib.engine_snapshot_size.argtypes = []
        self.lib.engine_snapshot_size.restype = C.c_int
        version = self.lib.engine_api_version()
        size = self.lib.engine_snapshot_size()
        if version != 4 or size != C.sizeof(Snapshot):
            raise RuntimeError(f"Engine API mismatch (version={version}, C={size}, Python={C.sizeof(Snapshot)}). Rebuild the C library.")
        self.lib.engine_reset.argtypes = [C.c_uint]
        self.lib.engine_reset.restype = None
        self.lib.engine_next_wave.argtypes = []
        self.lib.engine_next_wave.restype = None
        self.lib.engine_step.argtypes = [C.POINTER(Control), C.c_float]
        self.lib.engine_step.restype = None
        self.lib.engine_upgrade.argtypes = [C.c_int]
        self.lib.engine_upgrade.restype = None
        self.lib.engine_snapshot.argtypes = [C.POINTER(Snapshot)]
        self.lib.engine_snapshot.restype = None
        self.state = Snapshot()
        # The C library owns a process-global world. Explicitly reset it for
        # every new bridge instance so stale data cannot survive a reload.
        self.lib.engine_reset(0xB9A3DA17)
        self.refresh()

    def reset(self, seed: int):
        self.lib.engine_reset(seed)
        return self.refresh()

    def next_wave(self):
        self.lib.engine_next_wave()
        return self.refresh()

    def step(self, control: Control, dt: float):
        self.lib.engine_step(C.byref(control), dt)
        return self.refresh()

    def upgrade(self, kind: int):
        self.lib.engine_upgrade(kind)
        return self.refresh()

    def refresh(self):
        self.lib.engine_snapshot(C.byref(self.state))
        return self.state
