import sqlite3
import sys
from contextlib import closing

CASES = {"known": "blue", "missing": "none", "probe": "none' OR '1'='1"}


def count_rows(db, value):
    base = "SELECT COUNT(*) FROM notes WHERE label = "
    unsafe = db.execute(base + "'" + value + "'").fetchone()[0]
    bound = db.execute(base + "?", (value,)).fetchone()[0]
    return unsafe, bound


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script known|missing|probe", file=sys.stderr)
        return 2
    value = CASES[sys.argv[1]]
    with closing(sqlite3.connect(":memory:")) as db:
        db.execute("CREATE TABLE notes (label TEXT)")
        db.executemany("INSERT INTO notes VALUES (?)", [("blue",), ("red",)])
        unsafe, bound = count_rows(db, value)
    print(f"Concatenated count: {unsafe}")
    print(f"Bound count: {bound}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
