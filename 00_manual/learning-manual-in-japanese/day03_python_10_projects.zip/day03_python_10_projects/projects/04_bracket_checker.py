import sys


def main():
    pairs = {")": "(", "]": "["}
    if len(sys.argv) != 2:
        print("Usage: python3 04_bracket_checker.py brackets")
        return 2
    text = sys.argv[1]
    if not 1 <= len(text) <= 80:
        print("Error: use 1-80 bracket characters.")
        return 2
    for symbol in text:
        if symbol not in "()[]":
            print("Error: use ()[] only.")
            return 2
    stack = []
    for position, symbol in enumerate(text, 1):
        if symbol in "([":
            stack.append(symbol)
        else:
            if not stack or stack[-1] != pairs[symbol]:
                print(f"Mismatch at {position}")
                return 0
            stack.pop()
    if stack:
        print("Unclosed")
    else:
        print("Balanced")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
