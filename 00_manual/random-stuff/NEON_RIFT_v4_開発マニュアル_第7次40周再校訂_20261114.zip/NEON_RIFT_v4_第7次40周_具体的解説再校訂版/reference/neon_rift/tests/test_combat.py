"""Adversarial combat regression tests: collisions, timing, team separation."""
import math
import random
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from constants import ARENA_LEFT, ARENA_RIGHT, ARENA_TOP, ARENA_BOTTOM, CYAN, RED
from entities import Bullet, Enemy, Player
from mechanics import moving_circle_hit, sweep_circle, boundary_travel_fraction
from support import create_game


class SweptGeometryTests(unittest.TestCase):
    def test_fast_segment_hits_small_disc(self):
        self.assertIsNotNone(sweep_circle(0, 0, 100, 0, 50, 0, 3))

    def test_tangent_counts_as_touch(self):
        self.assertAlmostEqual(sweep_circle(0, 0, 100, 0, 50, 5, 5), .5)

    def test_zero_motion_inside(self):
        self.assertEqual(sweep_circle(1, 1, 1, 1, 0, 0, 3), 0)

    def test_zero_motion_outside(self):
        self.assertIsNone(sweep_circle(5, 5, 5, 5, 0, 0, 3))

    def test_moving_discs_toward_each_other(self):
        self.assertIsNotNone(moving_circle_hit(0, 0, 60, 0, 100, 0, 40, 0, 5))

    def test_moving_discs_same_velocity_miss(self):
        self.assertIsNone(moving_circle_hit(0, 0, 60, 0, 100, 0, 160, 0, 5))

    def test_moving_discs_moving_apart(self):
        self.assertIsNone(moving_circle_hit(0, 0, -20, 0, 50, 0, 80, 0, 3))

    def test_wall_fraction_clip(self):
        self.assertAlmostEqual(boundary_travel_fraction(ARENA_RIGHT - 10, 200, 100, 0), .1)

    def test_wall_fraction_no_clip(self):
        self.assertEqual(boundary_travel_fraction(400, 400, 10, 20), 1)


class CombatTests(unittest.TestCase):
    def setUp(self):
        self.g = create_game()
        self.g.pending.clear()
        self.g.enemies.clear()

    def enemy(self, x, y, kind='hunter', uid=1):
        e = Enemy(kind, x, y, uid=uid)
        e.speed = 0
        self.g.enemies.append(e)
        return e

    def friendly(self, x, y, vx, vy, damage=22, ttl=1):
        b = Bullet(x, y, vx, vy, 4.4, damage, ttl, True, CYAN)
        self.g.bullets.append(b)
        return b

    def hostile(self, x, y, vx, vy, damage=10):
        b = Bullet(x, y, vx, vy, 5.8, damage, 1, False, RED)
        self.g.bullets.append(b)
        return b

    def test_fast_bullet_cannot_tunnel(self):
        e = self.enemy(560, 350)
        self.friendly(440, 350, 7200, 0)
        self.g.update_bullets(1 / 30)
        self.assertLess(e.hp, e.max_hp)
        self.assertEqual(self.g.bullets, [])

    def test_first_hit_is_nearest_not_list_order(self):
        far = self.enemy(570, 350, uid=1)
        near = self.enemy(480, 350, uid=2)
        self.friendly(400, 350, 6000, 0)
        self.g.update_bullets(1 / 30)
        self.assertEqual(far.hp, far.max_hp)
        self.assertLess(near.hp, near.max_hp)

    def test_enemy_bullet_crossing_moving_player(self):
        p = self.g.player
        p.prev_x, p.prev_y = 480, 350
        p.x, p.y = 640, 350
        self.hostile(560, 290, 0, 3000)
        self.g.update_bullets(1 / 30)
        self.assertLess(p.hp, p.max_hp)

    def test_enemy_bullet_misses_player(self):
        p = self.g.player
        self.hostile(300, 200, 300, 0)
        self.g.update_bullets(1 / 30)
        self.assertEqual(p.hp, p.max_hp)

    def test_enemy_bullet_no_friendly_fire(self):
        e = self.enemy(400, 350)
        self.hostile(390, 350, 300, 0)
        self.g.update_bullets(1 / 30)
        self.assertEqual(e.hp, e.max_hp)

    def test_friendly_bullet_never_hurts_player(self):
        p = self.g.player
        self.friendly(p.x, p.y, 0, 0)
        self.g.update_bullets(1 / 60)
        self.assertEqual(p.hp, p.max_hp)

    def test_bullet_hits_before_ttl_expires(self):
        e = self.enemy(455, 350)
        self.friendly(400, 350, 6000, 0, ttl=.015)
        self.g.update_bullets(1 / 30)
        self.assertLess(e.hp, e.max_hp)

    def test_bullet_ttl_prevents_late_hit(self):
        e = self.enemy(600, 350)
        self.friendly(400, 350, 6000, 0, ttl=.01)
        self.g.update_bullets(1 / 30)
        self.assertEqual(e.hp, e.max_hp)

    def test_bullet_stops_at_wall(self):
        self.friendly(ARENA_RIGHT - 15, 350, 900, 0)
        self.g.update_bullets(1 / 30)
        self.assertEqual(len(self.g.bullets), 0)

    def test_target_movement_intersection(self):
        e = self.enemy(540, 410)
        e.prev_x, e.prev_y = 540, 290
        self.friendly(480, 350, 3000, 0)
        self.g.update_bullets(1 / 30)
        self.assertLess(e.hp, e.max_hp)

    def test_dead_target_does_not_absorb_next_bullet(self):
        e1 = self.enemy(480, 350, uid=1)
        e2 = self.enemy(520, 350, uid=2)
        self.friendly(450, 350, 4200, 0, damage=120)
        self.friendly(450, 350, 4200, 0, damage=120)
        self.g.update_bullets(1 / 30)
        self.assertTrue(e1.dead)
        self.assertTrue(e2.dead)
        self.assertEqual(self.g.total_kills, 2)

    def test_invulnerable_enemy_bullet_consumed(self):
        p = self.g.player
        p.invulnerable = 1
        self.hostile(p.x - 40, p.y, 2000, 0)
        self.g.update_bullets(1 / 30)
        self.assertEqual(p.hp, p.max_hp)
        self.assertEqual(self.g.bullets, [])

    def test_pulse_removes_hostile_bullets_only(self):
        p = self.g.player
        p.energy = 100
        self.hostile(p.x + 100, p.y, 0, 0)
        self.hostile(p.x + 240, p.y, 0, 0)
        self.friendly(p.x + 10, p.y, 0, 0)
        self.g.pulse()
        self.assertEqual(p.energy, 35)
        self.assertEqual(len(self.g.bullets), 2)

    def test_pulse_cannot_use_insufficient_energy(self):
        p = self.g.player
        p.energy = 64.9
        self.g.pulse()
        self.assertEqual(p.energy, 64.9)
        self.assertTrue(self.g.notification)

    def test_pulse_does_not_work_paused(self):
        self.g.state = 'paused'
        energy = self.g.player.energy
        self.g.pulse()
        self.assertEqual(self.g.player.energy, energy)

    def test_dash_hits_enemy_that_is_between_endpoints(self):
        p = self.g.player
        e = self.enemy(p.x + 90, p.y)
        self.g.keys.add('d')
        self.g.dash()
        self.g.update_player(1 / 30)
        for _ in range(3):
            self.g.update_player(1 / 30)
        self.g.resolve_dash_hits()
        self.assertLess(e.hp, e.max_hp)

    def test_dash_not_double_hits_same_enemy(self):
        p = self.g.player
        e = self.enemy(p.x + 20, p.y)
        self.g.keys.add('d')
        self.g.dash()
        self.g.update_player(1 / 30)
        self.g.resolve_dash_hits()
        hp_after = e.hp
        self.g.update_player(1 / 30)
        self.g.resolve_dash_hits()
        self.assertEqual(e.hp, hp_after)

    def test_firing_during_dash_never_accumulates_burst(self):
        g = self.g
        g.player.fire_interval = .075
        g.mouse_down = True
        g.keys.add('d')
        g.dash()
        for _ in range(11):
            g.update_player(1 / 60)
        self.assertEqual(len(g.bullets), 0)
        g.update_player(1 / 60)
        self.assertLessEqual(len(g.bullets), 1)

    def test_swept_dash_hits_between_widely_spaced_endpoints(self):
        p = self.g.player
        e = self.enemy(p.x + 110, p.y)
        p.prev_x, p.prev_y = p.x, p.y
        p.x += 250
        p.vx, p.vy = 1050, 0
        self.g._dash_active_this_tick = True
        self.g.resolve_dash_hits()
        self.assertLess(e.hp, e.max_hp)

    def test_dash_spans_only_remaining_duration(self):
        p = self.g.player
        self.g.keys.add('d')
        self.g.dash()
        p.dash_time = .002
        x = p.x
        self.g.update_player(1 / 30)
        self.assertAlmostEqual(p.x - x, 1050 * .002)

    def test_contact_detects_fast_crossing(self):
        p = self.g.player
        e = self.enemy(600, 350)
        p.prev_x, p.prev_y = 500, 350
        p.x = 680
        self.g._dash_active_this_tick = False
        self.g.resolve_enemy_contact()
        self.assertLess(p.hp, p.max_hp)

    def test_contact_while_dashing_not_damaging(self):
        p = self.g.player
        e = self.enemy(p.x, p.y)
        self.g.keys.add('d')
        self.g.dash()
        self.g.update_player(1 / 60)
        self.g.resolve_dash_hits()
        self.g.resolve_enemy_contact()
        self.assertEqual(p.hp, p.max_hp)

    def test_damage_is_blocked_during_iframes(self):
        p = self.g.player
        self.g.hurt_player(15)
        self.g.hurt_player(15)
        self.assertEqual(p.hp, 85)

    def test_lethal_damage_stops_game(self):
        self.g.hurt_player(999)
        self.assertEqual(self.g.state, 'gameover')
        self.assertEqual(self.g.player.hp, 0)
        self.g.hurt_player(999)
        self.assertEqual(self.g.player.hp, 0)

    def test_bullet_can_kill_before_contact(self):
        p = self.g.player
        e = self.enemy(p.x + 29, p.y)
        self.friendly(p.x + 10, p.y, 3000, 0, damage=100)
        self.g.update_bullets(1 / 60)
        self.g.resolve_enemy_contact()
        self.assertEqual(p.hp, p.max_hp)

if __name__ == '__main__':
    unittest.main()
