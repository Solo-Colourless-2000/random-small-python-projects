"""Real Tk UI integration tests; run under a display or `xvfb-run -a pytest`."""
import sys
from pathlib import Path
from types import SimpleNamespace
import tkinter as tk
import pytest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from main import TankArena, OX, OY

@pytest.fixture()
def app(monkeypatch,tmp_path):
    monkeypatch.setattr(TankArena,'_save_path',staticmethod(lambda: tmp_path/'save.json'))
    root=tk.Tk()
    game=TankArena(root)
    yield game
    try:root.destroy()
    except tk.TclError:pass

def key(name):return SimpleNamespace(keysym=name)
def mouse(x,y):return SimpleNamespace(x=x,y=y)

def test_01_initial_title(app):
    assert app.screen=='TITLE'
    assert app.engine.state.wave==0

def test_02_title_enter_to_intro(app):
    app.key_press(key('Return'))
    assert app.screen=='INTRO' and app.engine.state.wave==1

def test_03_title_mouse_button(app):
    app.mouse_press(mouse(round(640*app.scale),round(565*app.scale)))
    assert app.screen=='INTRO'

def test_04_initial_world_renders(app):
    app.new_game();app.render()
    assert app.canvas.find_withtag('cover')
    assert len(app.canvas.find_all())>80

def test_05_press_escape_pauses(app):
    app.new_game();app.screen='PLAYING'
    app.key_press(key('Escape'))
    assert app.screen=='PAUSED'

def test_06_pause_resumes_via_p(app):
    app.new_game();app.screen='PAUSED'
    app.key_press(key('p'))
    assert app.screen=='PLAYING'

def test_07_pause_resumes_via_button(app):
    app.new_game();app.screen='PAUSED'
    app.mouse_press(mouse(round(640*app.scale),round(513*app.scale)))
    assert app.screen=='PLAYING'

def test_08_focus_loss_pauses_and_clears_controls(app):
    app.new_game();app.screen='PLAYING'
    app.keys.update({'w','space'})
    app.mouse_down=True;app.focus_lost()
    assert app.screen=='PAUSED' and not app.keys and not app.mouse_down

def test_09_wasd_and_arrows(app):
    app.keys.update({'w','d'})
    control=app._input()
    assert control.move_y==-1 and control.move_x==1
    app.keys={'up','left'}
    control=app._input()
    assert control.move_y==-1 and control.move_x==-1

def test_10_click_and_space_fire(app):
    app.mouse_down=True
    assert app._input().fire==1
    app.mouse_down=False;app.keys={'space'}
    assert app._input().fire==1

def test_11_dash_consumed_once(app):
    app.screen='PLAYING'
    app.key_press(key('Shift_L'))
    assert app._input().dash==1
    assert app._input().dash==0
    app.key_press(key('Shift_L'))
    assert app._input().dash==0

def test_12_emp_consumed_once(app):
    app.screen='PLAYING'
    app.key_press(key('e'))
    assert app._input().pulse==1
    assert app._input().pulse==0

def test_13_pointer_maps_to_world(app):
    app.pointer=(OX+660,OY+290)
    control=app._input()
    assert control.aim_x==660 and control.aim_y==290

def test_14_mouse_release_stops_fire(app):
    app.mouse_down=True
    app.mouse_release(mouse(0,0))
    assert app.mouse_down is False

def test_15_upgrades_draw_three_cards(app):
    app.new_game();app.start_upgrade_screen();app.render()
    assert len(app.upgrade_choices)==3
    assert len(set(app.upgrade_choices))==3
    assert len(app.card_bounds)==3

def test_16_keyboard_upgrade_next_wave(app):
    app.new_game();app.start_upgrade_screen()
    previous=app.engine.state.wave
    app.key_press(key('1'))
    assert app.screen=='INTRO' and app.engine.state.wave==previous+1

def test_17_click_upgrade_next_wave(app):
    app.new_game();app.start_upgrade_screen();app.render()
    l,t,r,b=app.card_bounds[1]
    app.mouse_press(mouse(round((l+r)/2*app.scale),round((t+b)/2*app.scale)))
    assert app.engine.state.wave==2 and app.screen=='INTRO'

def test_18_no_double_upgrade(app):
    app.new_game();app.start_upgrade_screen()
    app.choose_upgrade(0)
    assert app.engine.state.wave==2
    app.choose_upgrade(1)
    assert app.engine.state.wave==2

def test_19_title_redeploy_resets_run(app):
    app.new_game()
    app.engine.upgrade(1)
    assert app.engine.state.player_damage>29
    app.screen='GAMEOVER'
    app.key_press(key('r'))
    assert app.engine.state.wave==1 and app.engine.state.player_damage==29

def test_20_best_score_record_file(app):
    app.new_game();app._store_best()
    assert app.best_wave==1
    assert app._save_path().is_file()

def test_21_reopen_save_file(app):
    app._save_path().write_text('{"best_wave":3,"high_score":4500}')
    assert app._load_best()==(4500,3)

def test_22_corrupted_save_fails_open(app):
    app._save_path().write_text('not-json')
    assert app._load_best()==(0,0)

def test_23_window_fits_screen(app):
    assert app.w<=app.root.winfo_screenwidth()
    assert app.h<=app.root.winfo_screenheight()

def test_24_stationary_overlay_not_recreated_each_tick(app):
    app.render()
    first=len(app.canvas.find_all())
    app.last_clock-=.02
    app.tick()
    assert len(app.canvas.find_all())==first

def test_25_dynamic_hud_cached(app):
    app.new_game();app.screen='PLAYING';app.render()
    old_ids=app.canvas.find_withtag('hud')
    assert len(old_ids)>10
    app.render()
    assert app.canvas.find_withtag('hud')==old_ids

def test_26_pause_freezes_simulation(app):
    app.new_game();app.screen='PAUSED'
    elapsed=app.engine.state.time
    app.last_clock-=.1
    app.tick()
    assert app.engine.state.time==elapsed

def test_27_intro_freezes_enemy_damage(app):
    app.new_game();app.wave_banner=.9
    t=app.engine.state.time
    app.last_clock-=.05
    app.tick()
    assert app.engine.state.time==t

def test_28_fps_robust_to_clock_jump(app):
    app.new_game();app.screen='PLAYING'
    app.last_clock-=10
    app.tick()
    assert app.accumulator<.12
    assert app.engine.state.time<=.12

def test_29_ui_all_modes_render_without_error(app):
    app.new_game()
    for mode in ('INTRO','PLAYING','PAUSED','UPGRADE','GAMEOVER','TITLE'):
        if mode=='UPGRADE':app.start_upgrade_screen()
        app.screen=mode
        app.render()
        assert app.canvas.find_all(),mode

def test_30_battlefield_corners_are_visible(app):
    app.new_game();app.render()
    assert app.canvas.find_withtag('static')
    assert app.canvas.find_withtag('cover')
