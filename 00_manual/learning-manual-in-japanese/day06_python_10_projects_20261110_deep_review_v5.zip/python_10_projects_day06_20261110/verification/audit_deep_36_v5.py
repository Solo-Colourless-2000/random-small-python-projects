"""36 focused, reproducible checks across source semantics, cases, and teaching notes."""
import ast
import importlib.util
import json
from pathlib import Path
import re
import subprocess
import sys
from html.parser import HTMLParser

ROOT=Path(__file__).resolve().parents[1]
DOC=(ROOT/'python_10_projects_day06_manual.html').read_text(encoding='utf-8')
FILES=sorted((ROOT/'projects').glob('*.py'))
sys.path.insert(0,str(ROOT/'tests'))
from cases import CASES
from test_materials import Manual
from test_deep_review_v5 import AppendixReader

TITLES=[
 '二段の復号と境界判定','SQLite文字列連結と束縛','IDの存在と所有者','Originの末尾一致','リダイレクト後の再確認',
 '拡張子とGIF先頭','HMAC本文とタグ','不信頼キーの試行制限','早期比較と全位置比較','ループバックTCPの読み取り']
BOUNDARIES=[
 '厳格なUTF-8デコードと不完全な%エスケープの違い','SQL構文とデータ値の区別','辞書未登録と他人の所有物の区別',
 '文字列反射と実ブラウザーのCORSの区別','固定辞書参照とDNS/HTTP実通信の区別','6バイトの先頭一致と有効な画像の区別',
 '共有鍵認証と機密性の区別','固定3試行と時間窓/分散制限の区別','回数の一定性と実時間の一定性の区別',
 '既知の接頭辞と実サービスの真正性の区別']
RESULTS=[]
def mark(n,subject,evidence):
    assert evidence,subject
    RESULTS.append({'number':n,'topic':subject,'result':'PASS','evidence':evidence})
for index,path in enumerate(FILES,1):
    src=path.read_text('ascii')
    ast.parse(src,feature_version=(3,10))
    nonblank=sum(bool(x.strip()) for x in src.splitlines())
    section=re.search(rf'<section[^>]*id="p{index:02d}"[^>]*>(.*?)</section>',DOC,re.S)
    assert section
    # 01-10: Read the complete logic and its teaching counterpart.
    mark(index,TITLES[index-1]+'：処理順と役割',f'{path.name}: {nonblank} nonblank lines; corresponding HTML chapter found')
    # 11-20: Reproduce the real CLI behavior, not only inspect the source.
    name=path.stem;records=CASES[name]
    observed=[]
    for args,code,out,err in (records[0],records[1],records[-1]):
        proc=subprocess.run([sys.executable,'-S',str(path),*args],capture_output=True,text=True,cwd=ROOT,timeout=8)
        assert (proc.returncode,proc.stdout,proc.stderr)==(code,out,err),(name,args)
        observed.append({'args':args,'code':code})
    mark(index+10,TITLES[index-1]+'：対照・変化・入力不正',f'{name}: 3 independent observed CLI cases agree; {observed}')
    # 21-30: Evaluate whether the manual overclaims real-system security.
    assert f'id="careful-reading-{index:02d}"' in section.group(1)
    assert f'id="verified-cases-{index:02d}"' in section.group(1)
    mark(index+20,TITLES[index-1]+'：検証限界',BOUNDARIES[index-1]+'; chapter contains explicit caution')

page=Manual(DOC)
for i,path in enumerate(FILES,1):
    full=path.read_text('ascii')
    assert ''.join(page.sources[f'step-{i:02d}-{s}'] for s in range(1,5))==full
    assert page.sources[f'src-{i:02d}']==full
mark(31,'HTML工程40個とソース10本・付録10本の完全一致','Every project source matches all four steps concatenated and appendix source exactly')
reader=AppendixReader();reader.feed(DOC)
rows=sum(bool(s.strip()) for p in FILES for s in p.read_text('ascii').splitlines())
assert reader.headings==10 and len(reader.rows)==rows==270
assert all(len(r)==4 for r in reader.rows)
mark(32,'非空行270件の構文分解','10 appendix tables / 270 rows / 4 columns each; source and reason and constituents')
assert all(path.read_bytes().isascii() for path in FILES)
mark(33,'ASCIIソースとPython 3.10文法','10 sources strictly ASCII and parsed successfully with feature_version 3.10')
case_count=0
for name,records in CASES.items():
    for args,code,out,err in records:
        proc=subprocess.run([sys.executable,'-S',str(ROOT/'projects'/(name+'.py')),*args],capture_output=True,text=True,cwd=ROOT,timeout=8)
        assert (proc.returncode,proc.stdout,proc.stderr)==(code,out,err)
        case_count+=1
assert case_count==59
mark(34,'標準出力・エラー・終了値を全59ケースで確認','All 59 original CLI fixtures reproduced (returncode, stdout, stderr)')
assert len(re.findall(r'<section[^>]*class="chapter"',DOC))==20
assert 'id="expression-reading"' in DOC
mark(35,'20章の目次と12構文一覧','20 chapter sections and Python expression reference found')
prev=ROOT/'verification/browser_v5_result.json'
assert prev.exists()
res=json.loads(prev.read_text('utf-8'))
assert {r['width'] for r in res['viewports']}=={320,390,768,1440}
assert all(not r['errors'] and r['layout']['documentWidth']<=r['width']+1 and r['layout']['codeLines']==270 for r in res['viewports'])
mark(36,'Chromiumでの4画面幅と付録操作','4 widths; actual search + appendix link return; no page errors; file:// persistence unverified')
assert len(RESULTS)==36
out=ROOT/'verification/review_36_topics_v5.json'
out.write_text(json.dumps({'source_archive':'day06_python_10_projects_20261110_144point_refined.zip',
 'important_limit':'36 distinct inspection themes, NOT 36 complete human cover-to-cover rereadings; preexisting audit logs retain their historical meaning',
 'checks':RESULTS},ensure_ascii=False,indent=2)+'\n','utf-8')
print('36/36 focused substantive reviews PASS; total CLI tested:',case_count)
