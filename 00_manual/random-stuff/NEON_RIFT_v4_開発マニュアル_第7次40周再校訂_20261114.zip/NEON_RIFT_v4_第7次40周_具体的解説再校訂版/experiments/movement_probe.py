"""Tiny movement prototype for the learning manual (not part of v4)."""
import tkinter as tk

W, H = 640, 420
root = tk.Tk()
root.title('Movement probe / NEON RIFT lab')
canvas = tk.Canvas(root, width=W, height=H, bg='#07121d', highlightthickness=0)
canvas.pack()
pressed = set()
x, y = W / 2, H / 2
speed = 5


def on_down(event):
    pressed.add(event.keysym.lower())


def on_up(event):
    pressed.discard(event.keysym.lower())


def frame():
    global x, y
    dx = int('d' in pressed or 'right' in pressed) - int('a' in pressed or 'left' in pressed)
    dy = int('s' in pressed or 'down' in pressed) - int('w' in pressed or 'up' in pressed)
    x = max(15, min(W - 15, x + dx * speed))
    y = max(15, min(H - 15, y + dy * speed))
    canvas.delete('all')
    canvas.create_rectangle(12, 12, W - 12, H - 12, outline='#1f6b77')
    canvas.create_oval(x - 15, y - 15, x + 15, y + 15, fill='#51edeb', outline='')
    canvas.create_text(W / 2, 26, text='WASD / ARROWS TO MOVE', fill='#d9f3f3')
    root.after(16, frame)


root.bind('<KeyPress>', on_down)
root.bind('<KeyRelease>', on_up)
canvas.focus_set()
frame()
root.mainloop()
