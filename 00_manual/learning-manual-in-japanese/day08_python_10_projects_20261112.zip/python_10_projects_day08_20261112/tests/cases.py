def ok(args, *lines):
    return args, 0, '\n'.join(lines) + '\n', ''


def bad(args, message):
    return args, 2, '', message + '\n'


CASES = {
    '01_symlink_scope': [
        ok(['linked'], 'Path location only: PRIVATE', 'Resolved scope: BLOCKED'),
        ok(['normal'], 'Path location only: PUBLIC', 'Resolved scope: PUBLIC'),
        bad(['../private'], 'Usage: script normal|linked'),
        bad([], 'Usage: script normal|linked'),
    ],
    '02_shell_boundary': [
        ok(['separator'], "Raw output: 'hello\\nINJECTED'", "Quoted output: 'hello; printf INJECTED\\n'"),
        ok(['normal'], "Raw output: 'hello\\n'", "Quoted output: 'hello\\n'"),
        bad(['hello; printf INJECTED'], 'Usage: script normal|separator'),
        bad([], 'Usage: script normal|separator'),
    ],
    '03_csrf_probe': [
        ok(['cross'], 'Cookie only: accept, balance=9', 'Token checked: reject, balance=10'),
        ok(['own'], 'Cookie only: accept, balance=9', 'Token checked: accept, balance=9'),
        ok(['anonymous'], 'Cookie only: reject, balance=10', 'Token checked: reject, balance=10'),
        bad(['LAB-CSRF'], 'Usage: script own|cross|anonymous'),
        bad([], 'Usage: script own|cross|anonymous'),
    ],
    '04_zip_budget': [
        ok(['repeat'], 'Declared bytes: 256', 'Read bytes: 0', 'Smaller when compressed: True', 'Metadata budget allows: False'),
        ok(['small'], 'Declared bytes: 3', 'Read bytes: 3', 'Smaller when compressed: False', 'Metadata budget allows: True'),
        bad(['big'], 'Usage: script small|repeat'),
        bad([], 'Usage: script small|repeat'),
    ],
    '05_http_framing': [
        ok(['ambiguous'], 'Front boundary: 0', 'Back boundary: 5', 'Ambiguity policy: reject'),
        ok(['length'], 'Front boundary: 4', 'Back boundary: 4', 'Ambiguity policy: accept'),
        bad(['short'], 'Invalid lab framing.'),
        bad([], 'Usage: script length|ambiguous|short'),
    ],
    '06_csv_formula': [
        ok(['formula'], 'CSV text: \'"=SUM(1,2)"\\n\'', "Recovered cell: '=SUM(1,2)'", 'Formula-like prefix: True'),
        ok(['word'], 'CSV text: \'"report"\\n\'', "Recovered cell: 'report'", 'Formula-like prefix: False'),
        ok(['negative'], 'CSV text: \'"-5"\\n\'', "Recovered cell: '-5'", 'Formula-like prefix: True'),
        bad(['=1+1'], 'Usage: script word|formula|negative'),
        bad([], 'Usage: script word|formula|negative'),
    ],
    '07_path_selection': [
        ok(['prepend'], 'Selected directory: incoming', 'Pinned directory: trusted'),
        ok(['trusted'], 'Selected directory: trusted', 'Pinned directory: trusted'),
        bad(['/usr/bin'], 'Usage: script trusted|prepend'),
        bad([], 'Usage: script trusted|prepend'),
    ],
    '08_offline_guess': [
        ok(['hit'], 'Candidate: river', 'Attempts: 2'),
        ok(['miss'], 'Candidate: (none)', 'Attempts: 3'),
        bad(['oak'], 'Usage: script hit|miss'),
        bad([], 'Usage: script hit|miss'),
    ],
    '09_lost_update': [
        ok(['interleave'], 'Stock: 0', 'Accepted: 2', 'Conservation holds: False'),
        ok(['serial'], 'Stock: 0', 'Accepted: 1', 'Conservation holds: True'),
        bad(['parallel'], 'Usage: script serial|interleave'),
        bad([], 'Usage: script serial|interleave'),
    ],
    '10_dns_wildcard': [
        ok(['deep'], 'Glob match: True', 'One-label match: False'),
        ok(['one'], 'Glob match: True', 'One-label match: True'),
        ok(['apex'], 'Glob match: False', 'One-label match: False'),
        bad(['*.example.test'], 'Usage: script one|deep|apex'),
        bad([], 'Usage: script one|deep|apex'),
    ],
}

for rows in CASES.values():
    message = rows[-1][3].rstrip("\n")
    rows.extend([bad([""], message), bad(["normal", "extra"], message)])
