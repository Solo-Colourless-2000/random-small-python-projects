"""Reproducible independent acceptance checks for the round-3 teaching ZIP.
Requires only Python standard library; browser evidence is read from JSON.
"""
import ast
from collections import Counter
from html.parser import HTMLParser
from pathlib import Path
import json
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
MANUAL = ROOT / 'python_10_projects_day05_manual.html'
TEXT = MANUAL.read_text(encoding='utf-8')
SOURCES = sorted((ROOT / 'projects').glob('*.py'))
ERRORS = json.loads((ROOT / 'verification/round3_error_examples.json').read_text())
BROWSER = json.loads((ROOT / 'verification/round3_browser_results.json').read_text())

sys.path.insert(0, str(ROOT / 'tests'))
from test_materials import Manual  # Uses stdlib HTMLParser, not an HTML reformatter.
M = Manual(TEXT)


class Markup(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.deep = []
        self.elements = []
        self.checks = []
        self.feed(TEXT)
    def handle_starttag(self, tag, attrs):
        d = dict(attrs)
        self.elements.append((tag,d))
        if tag == 'div' and 'deep-dive' in d.get('class','').split():
            self.deep.append(d.get('id'))
        if tag == 'input' and 'data-check' in d:
            self.checks.append(d['data-check'])

H = Markup()
RESULTS=[]
def check(label, result, evidence):
    RESULTS.append({'pass_number':len(RESULTS)+1,'label':label,'status':'PASS' if result else 'FAIL','evidence':str(evidence)[:230]})

check('1. Exactly ten completion source files',len(SOURCES)==10,len(SOURCES))
check('2. All ten project filenames are ordered',all(f.name.startswith(f'{n:02d}_') for n,f in enumerate(SOURCES,1)),[f.name for f in SOURCES])
check('3. Source code is ASCII',all(f.read_bytes().isascii() for f in SOURCES),'10 sources checked')
check('4. Python 3.10 grammar accepts every source',all(ast.parse(f.read_text(),feature_version=(3,10)) is not None for f in SOURCES),'ast.parse(..., feature_version=(3,10)) x 10')
check('5. Sources compile on current interpreter',all(compile(f.read_text(),str(f),'exec') is not None for f in SOURCES),sys.version.split()[0])
check('6. Each source has guarded entry point',all('if __name__ == "__main__":' in f.read_text() for f in SOURCES),'10 __main__ guards')
modules={'sys','html','pathlib','configparser','math','string'}
imports=[node.names[0].name for f in SOURCES for node in ast.walk(ast.parse(f.read_text())) if isinstance(node,ast.Import)]
check('7. Programs import only standard modules',set(imports)<=modules,sorted(set(imports)))
check('8. Forty teaching steps exist',len(M.steps)==40,len(M.steps))
check('9. Each project has four teaching steps',all(all(f'p{n:02d}-step{i}' in M.steps for i in range(1,5)) for n in range(1,11)),'40 step IDs')
check('10. Full appendix sources match Python files',all(M.code[f'src{n:02d}'].encode('ascii')==f.read_bytes() for n,f in enumerate(SOURCES,1)),'10 exact source matches')
check('11. Four consecutive step chunks reconstruct all programs',all(''.join(M.code[f'p{n:02d}-chunk{i}'] for i in range(1,5)).encode('ascii')==f.read_bytes() for n,f in enumerate(SOURCES,1)),'10 exact concatenations')
line_counts=[]
line_ok=True
for n,f in enumerate(SOURCES,1):
    expected={str(k):value for k,value in enumerate(f.read_text().splitlines(),1) if value.strip()}
    for scope in ('full','steps'):
        rows=[row for c,row in M.rows if c and ((scope=='full' and c==f'full-{n:02d}') or (scope=='steps' and c.startswith(f'p{n:02d}-step')))]
        line_counts.append(len(rows))
        if len(rows)!=len(expected) or any(len(row)<3 or expected.get(row[0]) != row[1] or not row[2].strip() for row in rows): line_ok=False
check('12. All nonempty source lines have two explanations',line_ok, f'{sum(line_counts)} examined explanation rows')
check('13. Exactly twenty chapters',len(M.chapters)==20,len(M.chapters))
check('14. HTML IDs contain no duplicates',len(M.ids)==len(set(M.ids)),len(M.ids))
check('15. All internal hyperlinks point to existing IDs',all(link[1:] in set(M.ids) for link in M.links if link.startswith('#')),len(M.links))
check('16. HTML loads no external scripts or stylesheets',M.external_assets==[],M.external_assets)
check('17. Ten per-project purpose cards',TEXT.count('class="tool-purpose"')==10,TEXT.count('class="tool-purpose"'))
check('18. Purpose descriptions have seven required subfields',all(all(f'id="purpose-{n:02d}-{x}"' in TEXT for x in ('what','when','how','result','limits','terms','try')) for n in range(1,11)),'70 section IDs')
check('19. Ten detailed walkthroughs plus workflow primer',H.deep==['workflow-mini']+[f'walkthrough-{n:02d}' for n in range(1,11)],H.deep)
check('20. Each walkthrough has a five-row value trace',all(re.search(fr'id="walkthrough-{n:02d}".*?<table class="trace-table">.*?<tbody>((?:(?!</tbody>).)*)</tbody>',TEXT,re.S) and len(re.findall('<tr>',re.search(fr'id="walkthrough-{n:02d}".*?<table class="trace-table">.*?<tbody>((?:(?!</tbody>).)*)</tbody>',TEXT,re.S).group(1)))==5 for n in range(1,11)),'10 traces / 50 data rows')
check('21. Ten question-and-answer sections',TEXT.count('class="guide-quiz"')==10,TEXT.count('class="guide-quiz"'))
check('22. All walkthroughs explain an error and a repair',all(all(key in TEXT[TEXT.index(f'id="walkthrough-{n:02d}"'):TEXT.index('<h3>\u521d\u51fa\u306e\u8a00\u8449',TEXT.index(f'id="walkthrough-{n:02d}"'))] for key in ('\u30a8\u30e9\u30fc\u306e\u539f\u56e0\uff1a','\u76f4\u3057\u65b9\uff1a','\u6b21\u306e\u7df4\u7fd2\uff1a')) for n in range(1,11)),'10 x 3 required subsections')
check('23. Ten real error examples are recorded',len(ERRORS)==10 and {e['number'] for e in ERRORS}==set(range(1,11)),len(ERRORS))
check('24. All measured error examples have status 2 and empty stderr',all(e['returncode']==2 and e['stderr']=='' and e['stdout'] for e in ERRORS),'10 error examples')
check('25. Fresh error subprocess outputs match the manual examples',all((lambda r,e:(r.returncode,r.stdout,r.stderr)==(e['returncode'],e['stdout'],e['stderr']))(subprocess.run([sys.executable,str(ROOT/'projects'/e['filename']),*e['args']],input=e['stdin'],text=True,capture_output=True,timeout=10,cwd=ROOT),e) for e in ERRORS),'10 reruns')
check('26. HTTP negative sample omits Host', 'Host:' not in (ROOT/'samples/request_no_host.txt').read_text(),'request_no_host.txt')
check('27. INI negative sample has inconsistent bounds', 'minimum=30' in (ROOT/'samples/filter_invalid.ini').read_text() and 'maximum=10' in (ROOT/'samples/filter_invalid.ini').read_text(),'filter_invalid.ini')
check('28. Newton zero explanation no longer asserts immediate division by zero','0\u3092\u53cd\u5fa9\u3078\u5165\u308c\u308b\u30680\u9664\u7b97\u306b\u81f3\u308a\u5f97\u308b' not in TEXT and TEXT.count('0\u306e\u5e73\u65b9\u6839\u306f\u53b3\u5bc6\u306b0\u306a\u306e\u3067')==2,'step and appendix corrected')
check('29. Project scripts, samples, tests remain ASCII',all(p.read_bytes().isascii() for folder in ('projects','samples','tests') for p in (ROOT/folder).rglob('*') if p.is_file() and p.suffix != '.pyc'),'Source/test/sample ASCII audit')
check('30. Setup ZIP filename matches the proposed distribution', 'unzip day05_python_10_projects_20261110_60point_refined.zip' in TEXT and 'ZIP\u540d\uff1aday05_python_10_projects_20261110_60point_refined.zip' in (ROOT/'README.txt').read_text(),'HTML/README')
check('31. Browser checks pass in three target widths',len(BROWSER)==37 and all(r['pass'] for r in BROWSER),f'{len(BROWSER)} checks')
check('32. Each project chapter has a working completion checkbox',all(f'p{n:02d}' in H.checks for n in range(1,11)),[x for x in H.checks if x.startswith('p')])
check('33. Each tutorial includes a relevant official references chapter', 'id="references"' in TEXT and 'https://docs.python.org' in TEXT,'Python docs URLs in source')
check('34. All tests are Python 3.10 parseable', all(ast.parse(p.read_text(),feature_version=(3,10)) is not None for p in (ROOT/'tests').glob('test_*.py')),'test_*.py grammar')
check('35. Responsive table behavior is explicitly styled', 'min-width:420px' in TEXT and 'overflow-x:auto' in TEXT, 'deep-dive CSS rules')
check('36. Archived baseline report is distinguished from round-3 results','round2_audit_report.json' in TEXT and 'round3_browser_results.json' in (ROOT/'README.txt').read_text(encoding='utf-8'),'Historical audit remains labeled')
check('37. Existing samples remain present',all((ROOT/'samples'/x).is_file() for x in ('filter.ini','request.txt','note_input.txt','card_expected.html')),'Four original samples')
check('38. No PDF / binary media are required to run core lessons',all(p.suffix in ('.py','.txt','.html','.ini','.json','.keep') for folder in ('projects','samples','tests') for p in (ROOT/folder).rglob('*') if p.is_file() and p.suffix != '.pyc'),'Program/sample/test resource formats')

out={'python_version':sys.version.split()[0],'total_independent_checks':len(RESULTS),'passed':sum(r['status']=='PASS' for r in RESULTS),'failed':sum(r['status']=='FAIL' for r in RESULTS),'description':'Independent targeted acceptance checks, not a claim that every sentence was manually reread 38 times.','checks':RESULTS}
(ROOT/'verification/round3_audit_38_passes.json').write_text(json.dumps(out,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'checks':out['total_independent_checks'],'passed':out['passed'],'failed':out['failed']},ensure_ascii=False))
for r in RESULTS:
 if r['status']=='FAIL': print(r)
if out['failed']:sys.exit(1)
