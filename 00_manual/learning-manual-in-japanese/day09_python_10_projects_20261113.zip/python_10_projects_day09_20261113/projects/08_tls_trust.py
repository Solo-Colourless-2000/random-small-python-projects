import socket
import ssl
import sys
from threading import Thread


def serve(listener, context, failures):
    try:
        peer, _ = listener.accept()
        with peer:
            peer.settimeout(2)
            with context.wrap_socket(peer, server_side=True) as secure:
                secure.sendall(b"LAB")
    except ssl.SSLError:
        return
    except OSError:
        failures.append(True)


def probe(unchecked):
    server = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    server.load_cert_chain("samples/lab_cert.pem", "samples/lab_key.pem")
    client = ssl.create_default_context()
    if unchecked:
        client.check_hostname = False
        client.verify_mode = ssl.CERT_NONE
    with socket.socket() as listener:
        listener.bind(("127.0.0.1", 0))
        listener.listen(1)
        listener.settimeout(2)
        failures = []
        worker = Thread(target=serve, args=(listener, server, failures), daemon=True)
        worker.start()
        try:
            with socket.create_connection(listener.getsockname(), timeout=2) as raw:
                try:
                    with client.wrap_socket(raw, server_hostname="localhost") as secure:
                        with secure.makefile("rb") as stream:
                            data = stream.read(3)
                        if data != b"LAB":
                            raise OSError("Incomplete lab payload.")
                        result = True, "LAB"
                except ssl.SSLCertVerificationError:
                    result = False, "(none)"
        finally:
            worker.join(3)
        if failures or worker.is_alive():
            raise OSError("Server did not finish normally.")
        return result


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ("default", "unchecked"):
        print("Usage: script default|unchecked", file=sys.stderr)
        return 2
    try:
        accepted, payload = probe(sys.argv[1] == "unchecked")
    except OSError:
        print("Loopback TLS experiment failed.", file=sys.stderr)
        return 1
    print(f"Certificate accepted: {accepted}")
    print(f"Payload: {payload}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
