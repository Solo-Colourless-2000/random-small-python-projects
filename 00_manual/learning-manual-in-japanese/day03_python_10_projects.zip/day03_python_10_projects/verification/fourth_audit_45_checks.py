"""45 independent critical review lenses over the supplied Day03 ZIP-derived contents.

These are 45 separate test dimensions, not 45 complete human read-throughs.
Run: python3 verification/fourth_audit_45_checks.py
"""
from __future__ import annotations
import ast
from collections import Counter
import hashlib
import itertools
import os
import json
from pathlib import Path
import re
import subprocess
import sys
import tempfile
import zipfile
from bs4 import BeautifulSoup

ROOT=Path(__file__).resolve().parents[1]
SOURCE_NAME='day03_python_10_projects_20261108_third_review_24pass.zip'
# Pass the original archive on the command line or set DAY03_SOURCE_ZIP to
# enable the three original-archive-dependent checks on another computer.
candidates=[Path(sys.argv[1])] if len(sys.argv)>1 else (
    [Path(os.environ['DAY03_SOURCE_ZIP'])] if os.environ.get('DAY03_SOURCE_ZIP') else
    [ROOT.parent/SOURCE_NAME,ROOT.parent.parent/SOURCE_NAME]
)
ORIGINAL=next((candidate for candidate in candidates if candidate.is_file()),candidates[0])
DOC=ROOT/'python_10_projects_day03_manual.html'
P=sorted((ROOT/'projects').glob('*.py'))
S=BeautifulSoup(DOC.read_text(encoding='utf-8'),'html.parser')
EXAMPLES=json.loads((ROOT/'verification/examples.json').read_text())
REPORT=[]


def record(label,run):
    try:
        detail=run()
        REPORT.append({'pass':len(REPORT)+1,'focus':label,'status':'PASS','evidence':str(detail)[:300]})
    except FileNotFoundError as exc:
        REPORT.append({'pass':len(REPORT)+1,'focus':label,'status':'SKIP','evidence':f'Original source ZIP not supplied: {exc}'[:300]})
    except Exception as exc:
        REPORT.append({'pass':len(REPORT)+1,'focus':label,'status':'FAIL','evidence':f'{type(exc).__name__}: {exc}'[:300]})


def verify(x,message='check failed'):
    if not x: raise AssertionError(message)
    return True


def sources():
    return [x.read_text(encoding='ascii') for x in P]


def code(id):
    node=S.find(id=id)
    verify(node is not None,f'missing {id}')
    return node.get_text()


def cli(n,*args,stdin=''):
    result=subprocess.run([sys.executable,str(P[n-1]),*args],input=stdin,text=True,
                          cwd=ROOT,capture_output=True,timeout=8)
    return result.returncode,result.stdout,result.stderr


record('01. Source archive integrity and CRC',lambda:verify(zipfile.ZipFile(ORIGINAL).testzip() is None))
record('02. Source archive has no unsafe traversing paths',lambda:verify(all(not (name.startswith('/') or '..' in Path(name).parts) for name in zipfile.ZipFile(ORIGINAL).namelist())))
record('03. Exactly 10 independently named Python projects',lambda:verify(len(P)==10 and all(p.name.startswith(f'{n:02d}_') for n,p in enumerate(P,1))))
record('04. Project scripts exclusively ASCII and UTF-8-safe',lambda:verify(all(p.read_bytes().decode('ascii').encode('ascii')==p.read_bytes() for p in P)))
record('05. Test cases and sample data exclusively ASCII',lambda:verify(all(f.read_bytes().isascii() for folder in ['tests','samples'] for f in (ROOT/folder).rglob('*') if f.is_file() and f.suffix!='.pyc')))
record('06. Python 3.10 grammar parses every source',lambda:verify(all(ast.parse(x,feature_version=(3,10)) for x in sources())))
record('07. All projects compile to Python code objects',lambda:verify(all(compile(x,p.name,'exec') for x,p in zip(sources(),P))))
record('08. Standard library imports only',lambda:verify(all(all(node.module.split('.')[0] in {'sys','pathlib','string','json','difflib','collections','fractions'} for node in ast.walk(ast.parse(x)) if isinstance(node,ast.ImportFrom)) and all(all(alias.name.split('.')[0] in {'sys','pathlib','string','json','difflib','collections','fractions'} for alias in node.names) for node in ast.walk(ast.parse(x)) if isinstance(node,ast.Import)) for x in sources())))
record('09. Every script has a main entrypoint',lambda:verify(all('if __name__ == "__main__":' in x for x in sources())))
record('10. Every script returns an explicit success status',lambda:verify(all('return 0' in x for x in sources())))
record('11. No eval / exec / shell / network behavior introduced',lambda:verify(all(not re.search(r'\b(eval|exec|os\.system|socket|requests|shell=True)\b',x) for x in sources())))
record('12. Python indentation uses spaces rather than tab bytes',lambda:verify(all(b'\t' not in p.read_bytes() for p in P)))
record('13. HTML retains exactly 20 chapters',lambda:verify(len(S.select('section.chapter'))==20))
record('14. Four exercise steps for each project',lambda:verify(all(len(S.select(f'#p{n:02d} article.step'))==4 for n in range(1,11))))
record('15. All 10 appendix code blocks exactly match sources',lambda:verify(all(code(f'src{n:02d}').encode('ascii')==p.read_bytes() for n,p in enumerate(P,1))))
record('16. Every 4-step combined source exactly matches project file',lambda:verify(all(''.join(code(f'p{n:02d}-chunk{k}') for k in range(1,5)).encode('ascii')==p.read_bytes() for n,p in enumerate(P,1))))
record('17. All code lines in the appendix have correct numbers',lambda:verify(all([int(row.find_all('td')[0].get_text()) for row in S.select(f'#full-{n:02d} tbody tr')]==[i for i,l in enumerate(p.read_text().splitlines(),1) if l.strip()] for n,p in enumerate(P,1))))
record('18. Each source line has a semantic description in appendix',lambda:verify(all(all(len(tr.find_all('td'))==3 and tr.find_all('td')[2].get_text(strip=True) for tr in S.select(f'#full-{n:02d} tbody tr')) for n in range(1,11))))
record('19. Every step has line-by-line explanation rows',lambda:verify(all(len(S.select(f'#p{n:02d} article.step tbody tr'))==len(S.select(f'#full-{n:02d} tbody tr')) for n in range(1,11))))
record('20. Every appendix line includes detailed token explanation',lambda:verify(all(len(S.select(f'#full-{n:02d} tbody tr details.syntax-breakdown'))==len(S.select(f'#full-{n:02d} tbody tr')) for n in range(1,11))))
record('21. Every step-level line includes detailed token explanation',lambda:verify(all(len(S.select(f'#p{n:02d} article.step tbody tr details.syntax-breakdown'))==len(S.select(f'#full-{n:02d} tbody tr')) for n in range(1,11))))
record('22. Token explanations contain specific descriptions',lambda:verify(all(d.find('dl') and d.find('dl').find('dt') and d.find('dl').find('dd').get_text(strip=True) for d in S.select('details.syntax-breakdown'))))
record('23. Ten project-specific state-tracing exercises',lambda:verify(all(S.find(id=f'guided-p{n:02d}') and len(S.find(id=f'guided-p{n:02d}').find_all('p'))>=2 for n in range(1,11))))
record('24. Source codes contain no Japanese or smart quotes',lambda:verify(all(p.read_bytes().isascii() for p in P)))
record('25. No duplicate HTML IDs',lambda:verify(all(num==1 for num in Counter(e.get('id') for e in S.select('[id]')).values())))
record('26. Every internal hash link resolves',lambda:verify(all(S.find(id=a['href'][1:]) for a in S.select('a[href^="#"]'))))
record('27. No external JavaScript, CSS, or embedded images required',lambda:verify(not S.select('img[src],script[src],iframe[src],link[rel="stylesheet"]')))
record('28. Dark color scheme intentionally remains fixed',lambda:verify('color-scheme:dark' in S.find('style').get_text() and 'prefers-color-scheme:light' not in S.find('style').get_text()))
record('29. Responsive CSS contains mobile rules',lambda:verify('@media(max-width:430px)' in S.find('style').get_text() and '@media(max-width:900px)' in S.find('style').get_text()))
record('30. All original sample contents unchanged',lambda:verify(all(zipfile.ZipFile(ORIGINAL).read('python_10_projects_day03_20261108/samples/'+p.name)==p.read_bytes() for p in (ROOT/'samples').iterdir() if p.is_file())))


def fixture(mode):
    with tempfile.TemporaryDirectory() as temp:
        t=Path(temp)
        (t/'practice').mkdir(); (t/'samples').mkdir()
        for p in (ROOT/'samples').iterdir(): (t/'samples'/p.name).write_bytes(p.read_bytes())
        for n,item in enumerate(EXAMPLES,1):
            spec=item[mode]
            res=subprocess.run([sys.executable,str(P[n-1]),*spec['args']],cwd=t,input=spec['input'],capture_output=True,text=True,timeout=8)
            verify((res.returncode,res.stdout,res.stderr)==(spec['status'],spec['stdout'],spec['stderr']),f'project {n}, mode {mode}: {(res.returncode,res.stdout,res.stderr)}')
            if n==7 and mode=='normal': verify((t/'practice/checklist.md').read_bytes()==(ROOT/'samples/checklist_expected.md').read_bytes())
    return '10 subprocesses matched expected status/stdout/stderr'
record('31. Ten independent positive command-line examples',lambda:fixture('normal'))

# Some negative fixture cases depend on the output generated by positive case (07).
def negative_fixture():
    with tempfile.TemporaryDirectory() as temp:
        t=Path(temp);(t/'practice').mkdir();(t/'samples').mkdir()
        for p in (ROOT/'samples').iterdir():(t/'samples'/p.name).write_bytes(p.read_bytes())
        (t/'practice/checklist.md').write_bytes((ROOT/'samples/checklist_expected.md').read_bytes())
        for n,item in enumerate(EXAMPLES,1):
            spec=item['error']
            res=subprocess.run([sys.executable,str(P[n-1]),*spec['args']],cwd=t,input=spec['input'],capture_output=True,text=True,timeout=8)
            verify((res.returncode,res.stdout,res.stderr)==(spec['status'],spec['stdout'],spec['stderr']),f'project {n} failed error specification')
    return '10 negative subprocess cases matched'
record('32. Ten independent negative/error command-line examples',negative_fixture)

record('33. Bit positions and masks for 13 correct',lambda:verify(cli(1,'13')[1].count('Bit ')==8 and cli(1,'13')[1].endswith('On bits: 3\n')))
record('34. Packing list normalizes case and preserves first order',lambda:verify(cli(2,'Pen, pen, Cup')==(0,'Items: 2\n1. pen\n2. cup\n','')))
record('35. Run-length encoding retains separate runs',lambda:verify(cli(3,'ABBBA')[1]=='Runs: A:1 B:3 A:1\nLength: 5\n'))
record('36. Bracket stack detects wrong nesting',lambda:verify(cli(4,'([)]')==(0,'Mismatch at 3\n','')))
record('37. Merge checks ascending input before merging',lambda:verify(cli(5,'3,1','2')[0]==2 and cli(5,'1,1','1')[1]=='Merged: 1 1 1\n'))
record('38. Text differencer preserves sample files',lambda:verify(cli(6,'samples/before.txt','samples/after.txt')[0]==0 and b'green\n' in (ROOT/'samples/before.txt').read_bytes()))


def json_probe(text,exists=False):
    with tempfile.TemporaryDirectory() as temp:
        t=Path(temp);i=t/'a.json';o=t/'b.md';i.write_text(text,encoding='utf-8')
        if exists:o.write_text('original\n')
        c,out,err=cli(7,str(i),str(o))
        return c,out,err,o.read_text() if o.exists() else None
record('39. Duplicate JSON keys fail rather than being overwritten',lambda:verify(json_probe('[{"name":"A","done":false,"done":true}]')[0:3]==(2,'Error: use valid JSON within 4096 characters.\n','')))
record('40. Existing files are never overwritten by checklist export',lambda:verify(json_probe('[{"name":"A","done":true}]',True)[0:4]==(1,'Error: cannot create output; choose a new path.\n','','original\n')))
record('41. Nested JSON duplicate keys are rejected',lambda:verify(json_probe('[{"name":"A","done":false,"extra":{"x":1,"x":2}}]')[0]==2))
record('42. Queue removes first-added name first',lambda:verify('Serving: Ada\n' in cli(8,stdin='add Ada\nadd Bob\nnext\nquit\n')[1]))
record('43. Fraction arithmetic is exact',lambda:verify(cli(9,'1/3','+','1/6')[1]=='Result: 1/2\nNumerator: 1\nDenominator: 2\n'))
record('44. Cell generations evolve with prior-state-only references',lambda:verify(cli(10,'00100','2')[1]=='0: 00100\n1: 01010\n2: 10001\n'))
record('45. No deprecated duplicate-key warning remains in lesson',lambda:verify('この教材は重複キー拒否までは実装していない' not in DOC.read_text(encoding='utf-8')))

with open(ROOT/'verification/fourth_audit_45_checks.json','w',encoding='utf-8') as f:
 json.dump({'description':'45 separate critical review checks spanning code, tests, manual and fixtures; not 45 full independent human readings','checks':REPORT,'total':len(REPORT),'passed':sum(x['status']=='PASS' for x in REPORT),'failed':sum(x['status']=='FAIL' for x in REPORT),'skipped':sum(x['status']=='SKIP' for x in REPORT)},f,ensure_ascii=False,indent=2)
print(f'Checked {len(REPORT)} dimensions: {sum(x["status"]=="PASS" for x in REPORT)} PASS, {sum(x["status"]=="SKIP" for x in REPORT)} SKIP, {sum(x["status"]=="FAIL" for x in REPORT)} FAIL')
for row in REPORT:
 if row['status']=='FAIL':print(row)
sys.exit(0 if all(x['status'] in ('PASS','SKIP') for x in REPORT) else 1)
