"""Deterministic native C gameplay tests, including adversarial collisions."""
import ctypes as ct
import math
from pathlib import Path
import random
import subprocess
import sys
import pytest

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from c_bridge import Control, Snapshot, Engine, WORLD_W, WORLD_H
from build_engine import SOURCES

@pytest.fixture(scope='session')
def dll(tmp_path_factory):
    out=tmp_path_factory.mktemp('native')/'test_engine.so'
    proc=subprocess.run(['gcc','-std=c11','-O2','-Wall','-Wextra','-Wpedantic',
                         '-DENGINE_TESTING','-fPIC','-shared',
                         *[str(src) for src in SOURCES],'-o',str(out),'-lm'],
                         text=True,capture_output=True)
    assert proc.returncode==0,proc.stderr
    lib=ct.CDLL(str(out))
    lib.engine_reset.argtypes=[ct.c_uint]
    lib.engine_next_wave.argtypes=[]
    lib.engine_snapshot.argtypes=[ct.POINTER(Snapshot)]
    lib.engine_step.argtypes=[ct.POINTER(Control),ct.c_float]
    lib.engine_upgrade.argtypes=[ct.c_int]
    lib.engine_api_version.restype=ct.c_int
    lib.engine_snapshot_size.restype=ct.c_int
    lib.debug_clear_enemies.argtypes=[]
    lib.debug_clear_bullets.argtypes=[]
    lib.debug_player.argtypes=[ct.c_float,ct.c_float,ct.c_float]
    lib.debug_enemy.argtypes=[ct.c_int,ct.c_float,ct.c_float,ct.c_float]
    lib.debug_bullet.argtypes=[ct.c_float,ct.c_float,ct.c_float,ct.c_float,ct.c_int,ct.c_float,ct.c_int]
    lib.debug_energy.argtypes=[ct.c_float]
    lib.debug_pulse_cd.argtypes=[ct.c_float]
    lib.debug_wave.argtypes=[ct.c_int]
    lib.debug_pickup.argtypes=[ct.c_float,ct.c_float,ct.c_int]
    lib.debug_invulnerability.argtypes=[ct.c_float]
    lib.debug_enemy_ready.argtypes=[ct.c_float]
    lib.debug_los.argtypes=[ct.c_float,ct.c_float,ct.c_float,ct.c_float]
    lib.debug_los.restype=ct.c_int
    return lib

@pytest.fixture()
def engine(dll):
    dll.engine_reset(28971)
    dll.debug_clear_enemies()
    return dll

def snap(dll):
    s=Snapshot();dll.engine_snapshot(ct.byref(s));return s

def step(dll,frames=1,move_x=0,move_y=0,aim_x=960,aim_y=300,fire=0,dash=0,pulse=0,dt=1/60):
    for _ in range(frames):
        u=Control(move_x,move_y,aim_x,aim_y,fire,dash,pulse)
        dll.engine_step(ct.byref(u),ct.c_float(dt))
    return snap(dll)

def test_01_abi(dll):
    assert dll.engine_api_version()==4
    assert dll.engine_snapshot_size()==ct.sizeof(Snapshot)

def test_02_reset_player(engine):
    s=snap(engine)
    assert (s.player.x,s.player.y)==(560,310)
    assert s.player_alive==1 and s.player.hp==140

def test_03_cover_geometry(engine):
    s=snap(engine)
    assert s.obstacle_count==18
    assert sum(o.kind==1 for o in s.obstacles if o.active)==10

def test_04_player_safe_start(engine):
    s=snap(engine)
    for o in s.obstacles:
        if o.active:
            dx=max(o.x-s.player.x,0,s.player.x-(o.x+o.w))
            dy=max(o.y-s.player.y,0,s.player.y-(o.y+o.h))
            assert dx*dx+dy*dy > s.player.radius*s.player.radius

def test_05_initial_wave(engine):
    engine.engine_next_wave();s=snap(engine)
    assert s.wave==1 and 2<=s.enemy_count<=7

def test_06_spawn_no_overlap_with_solid(engine):
    engine.engine_next_wave();s=snap(engine)
    for t in s.enemies:
        if not t.active:continue
        for o in s.obstacles:
            if not o.active:continue
            dx=max(o.x-t.x,0,t.x-(o.x+o.w))
            dy=max(o.y-t.y,0,t.y-(o.y+o.h))
            assert dx*dx+dy*dy>(t.radius+8)**2

def test_07_boss_every_five_waves(engine):
    engine.debug_wave(4);engine.engine_next_wave();s=snap(engine)
    assert s.wave==5
    assert sum(t.active and t.type==3 for t in s.enemies)==1

def test_08_no_boss_wave_four(engine):
    engine.debug_wave(2);engine.engine_next_wave();s=snap(engine)
    assert s.wave==3 and all(t.type!=3 for t in s.enemies if t.active)

def test_09_no_input_no_drift(engine):
    s=step(engine,60)
    assert abs(s.player.x-560)<.01 and abs(s.player.y-310)<.01

def test_10_diagonal_is_normalized(engine):
    s=step(engine,20,move_x=1,move_y=1)
    distance=math.hypot(s.player.x-560,s.player.y-310)
    assert 75<distance<86

def test_11_cardinal_movement(engine):
    s=step(engine,20,move_x=0,move_y=-1)
    assert 220<s.player.y<235 and s.player.x==560

def test_12_boundary_clamp(engine):
    s=step(engine,500,move_x=1)
    assert s.player.x<=WORLD_W-s.player.radius-12+.01

def test_13_collision_with_barrier(engine):
    engine.debug_player(327,148,140)
    s=step(engine,60,move_x=1)
    # Steel column occupies x=350..380 y=80..200; player radius=23.
    assert s.player.x<=327.01

def test_14_gun_aims_towards_cursor(engine):
    s=step(engine,20,aim_x=1020,aim_y=310)
    assert abs(math.remainder(s.player.turret,math.tau))<.04

def test_15_shooting_spawns_owned_bullet(engine):
    s=step(engine,1,fire=1)
    assert s.bullet_count==1
    assert any(b.owner==0 and b.active for b in s.bullets)

def test_16_reload_limits_hold_fire(engine):
    # Count muzzle events rather than live shells: bullets may have hit cover
    # or left the world before one second elapses.
    shots=0
    for _ in range(60):
        s=step(engine,1,fire=1)
        shots+=sum(e.kind==1 and e.value==0 for e in s.events[:s.event_count])
    assert 5<=shots<=6

def test_17_enemy_collision_uses_sweep(engine):
    engine.debug_enemy(0,660,310,20)
    engine.debug_bullet(580,310,5000,0,0,40,0)
    s=step(engine,1,dt=.0333)
    assert s.enemy_count==0 and s.kills==1

def test_18_scoring_kill(engine):
    engine.debug_enemy(0,660,310,20)
    engine.debug_bullet(580,310,3000,0,0,40,0)
    s=step(engine,2,dt=.0333)
    assert s.score==100 and s.combo==1

def test_19_combo_increases_reward(engine):
    for x in (650,750):
        engine.debug_enemy(0,x,310,20)
        engine.debug_bullet(x-60,310,4000,0,0,40,0)
        s=step(engine,1,dt=.0333)
    assert s.kills==2 and s.combo==2 and s.score==300

def test_20_combo_expiry(engine):
    engine.debug_enemy(0,650,310,20)
    engine.debug_bullet(600,310,4000,0,0,40,0)
    step(engine,1,dt=.0333)
    s=step(engine,230)
    assert s.combo==0

def test_21_breakable_cover_absorbs_damage(engine):
    engine.debug_bullet(414,162,2500,0,0,40,0)
    s=step(engine,1,dt=.0333)
    assert s.obstacles[10].hp==50 and s.bullet_count==0

def test_22_cover_is_destroyed_after_three_hits(engine):
    for _ in range(3):
        engine.debug_bullet(414,162,2500,0,0,40,0)
        s=step(engine,1,dt=.0333)
    assert s.obstacles[10].active==0

def test_23_ricochet_on_metal(engine):
    engine.debug_bullet(114,118,900,0,0,17,1)
    s=step(engine,1,dt=.0333)
    b=next(b for b in s.bullets if b.active)
    assert b.vx<0 and b.bounces==0 and b.damage<17

def test_24_wall_remains_after_shots(engine):
    for _ in range(3):
        engine.debug_bullet(114,118,1500,0,0,40,0)
        s=step(engine,1,dt=.0333)
    assert s.obstacles[0].active and s.obstacles[0].hp>999000

def test_25_enemy_bullet_hurts_player(engine):
    engine.debug_bullet(510,310,2000,0,1,23,0)
    s=step(engine,1,dt=.0333)
    assert s.player.hp==117

def test_26_invulnerability_prevents_repeat_hits(engine):
    engine.debug_bullet(510,310,2000,0,1,23,0)
    s=step(engine,1,dt=.0333)
    engine.debug_bullet(510,310,2000,0,1,23,0)
    s=step(engine,1,dt=.0333)
    assert s.player.hp==117

def test_27_armor_mitigates_damage(engine):
    engine.engine_upgrade(2)
    engine.debug_bullet(510,310,2000,0,1,20,0)
    s=step(engine,1,dt=.0333)
    assert s.player.hp==122

def test_28_repair_heals_no_overheal(engine):
    engine.debug_player(560,310,120)
    engine.engine_upgrade(0);s=snap(engine)
    assert s.player.hp==140

def test_29_core_increases_max_hp(engine):
    engine.engine_upgrade(7);s=snap(engine)
    assert s.player.max_hp==170 and s.player.hp==170

def test_30_damage_upgrade(engine):
    engine.engine_upgrade(1);s=snap(engine)
    assert s.player_damage==37

def test_31_rate_upgrade(engine):
    original=snap(engine).shot_interval
    engine.engine_upgrade(3)
    assert snap(engine).shot_interval<original

def test_32_dash_requires_direction(engine):
    s=step(engine,1,dash=1)
    assert s.dash_energy==100

def test_33_dash_uses_energy(engine):
    s=step(engine,1,move_x=1,dash=1)
    assert s.dash_energy<36 and s.invulnerability>0

def test_34_dash_cannot_activate_low_energy(engine):
    engine.debug_energy(0)
    s=step(engine,1,move_x=1,dash=1)
    assert s.dash_energy<1 and s.invulnerability==0

def test_35_dash_energy_regenerates(engine):
    engine.debug_energy(0)
    s=step(engine,60)
    assert 20<=s.dash_energy<=22

def test_36_energy_upgrade(engine):
    engine.engine_upgrade(4)
    assert snap(engine).dash_regen==28

def test_37_emp_hits_and_stuns(engine):
    engine.debug_enemy(0,635,310,110)
    s=step(engine,1,pulse=1)
    e=next(e for e in s.enemies if e.active)
    assert e.hp==48 and e.stun>1.9 and s.pulse_cooldown>9.9

def test_38_emp_outside_radius(engine):
    engine.debug_enemy(1,970,310,130)
    s=step(engine,1,pulse=1)
    e=next(e for e in s.enemies if e.active)
    assert e.hp==130

def test_39_emp_destroys_enemy_bullets(engine):
    engine.debug_bullet(600,310,0,0,1,9,0)
    s=step(engine,1,pulse=1)
    assert s.bullet_count==0

def test_40_emp_cannot_spam(engine):
    step(engine,1,pulse=1)
    before=snap(engine).pulse_cooldown
    s=step(engine,1,pulse=1)
    assert s.pulse_cooldown < before

def test_41_emp_upgrade(engine):
    engine.engine_upgrade(5)
    assert math.isclose(snap(engine).pulse_cooldown_max,8.6,abs_tol=.01)

def test_42_mobility_upgrade(engine):
    engine.engine_upgrade(6)
    assert snap(engine).player_speed==272

def test_43_repair_pickup(engine):
    engine.debug_player(560,310,65)
    engine.debug_pickup(560,310,0)
    s=step(engine)
    assert s.player.hp==92 and s.pickup_count==0

def test_44_energy_pickup(engine):
    engine.debug_energy(22)
    engine.debug_pickup(560,310,1)
    s=step(engine)
    assert 64<s.dash_energy<65 and s.pickup_count==0

def test_45_dead_player_stops_world(engine):
    engine.debug_player(560,310,0)
    engine.engine_next_wave()
    s=step(engine,100,fire=1)
    assert s.wave==0 and s.player_alive==0 and s.bullet_count==0

def test_46_invalid_upgrade_noop(engine):
    old=snap(engine)
    engine.engine_upgrade(-999)
    engine.engine_upgrade(999)
    s=snap(engine)
    assert (s.player_damage,s.player.hp,s.armor,s.shot_interval)==(old.player_damage,old.player.hp,old.armor,old.shot_interval)

def test_47_deterministic_spawn(dll):
    dll.engine_reset(103)
    dll.engine_next_wave()
    a=snap(dll)
    first=[(round(e.x,3),round(e.y,3),e.type) for e in a.enemies if e.active]
    dll.engine_reset(103)
    dll.engine_next_wave()
    b=snap(dll)
    second=[(round(e.x,3),round(e.y,3),e.type) for e in b.enemies if e.active]
    assert first==second

def test_48_spawning_never_exceeds_capacity(engine):
    engine.debug_wave(500)
    engine.engine_next_wave()
    assert 0<=snap(engine).enemy_count<=80

def test_49_many_violent_frames_stay_finite(dll):
    dll.engine_reset(91)
    dll.engine_next_wave()
    r=random.Random(22)
    for k in range(4500):
        if k%400==0 and k:
            dll.debug_clear_enemies()
            dll.engine_next_wave()
        u=Control(r.uniform(-1,1),r.uniform(-1,1),
                  r.uniform(-100,1200),r.uniform(-100,700),
                  r.randint(0,1),r.randint(0,13)==0,r.randint(0,120)==0)
        dll.engine_step(ct.byref(u),ct.c_float(1/60))
        if k%100==0:
            s=snap(dll)
            for v in (s.player.x,s.player.y,s.player.hp,s.dash_energy,s.pulse_cooldown):
                assert math.isfinite(v)
            for e in s.enemies:
                if e.active:assert math.isfinite(e.x) and math.isfinite(e.y)
            assert s.bullet_count<=420

def test_50_public_bridge_works():
    e=Engine();e.reset(101);e.next_wave()
    assert e.state.wave==1 and e.state.enemy_count>0


def test_51_line_of_sight_blocked_by_crate(engine):
    assert engine.debug_los(400,165,560,165)==0

def test_52_line_of_sight_open_corridor(engine):
    assert engine.debug_los(400,310,560,310)==1

def test_53_enemy_refuses_to_shoot_through_wall(engine):
    engine.debug_enemy(1,840,310,90)
    engine.debug_enemy_ready(math.pi)
    s=step(engine,1)
    assert not any(b.active and b.owner==1 for b in s.bullets)

def test_54_enemy_shoots_down_open_corridor(engine):
    engine.debug_enemy(1,730,310,90)
    engine.debug_enemy_ready(math.pi)
    s=step(engine,1)
    assert any(b.active and b.owner==1 for b in s.bullets)

def test_55_boss_spreads_three_projectiles(engine):
    engine.debug_enemy(3,730,310,650)
    engine.debug_enemy_ready(math.pi)
    s=step(engine,1)
    assert sum(b.active and b.owner==1 for b in s.bullets)==3

def test_56_dt_rejects_negative(engine):
    before=snap(engine).time
    s=step(engine,dt=-1)
    assert s.time==before

def test_57_dt_clamped_at_high_value(engine):
    s=step(engine,dt=99)
    assert .0333<s.time<.0335

def test_58_wave_reset_removes_shells(engine):
    engine.debug_bullet(560,310,200,0,0,20,0)
    engine.engine_next_wave()
    assert snap(engine).bullet_count==0

def test_59_health_at_zero_is_not_negative(engine):
    engine.debug_bullet(510,310,2000,0,1,900,0)
    s=step(engine,1,dt=.0333)
    assert s.player_alive==0 and s.player.hp==0

def test_60_maximum_upgrade_caps(engine):
    for _ in range(100):
        for upgrade in (1,2,3,4,5,6,7):engine.engine_upgrade(upgrade)
    s=snap(engine)
    assert 0<s.shot_interval<=.185
    assert s.armor<=.58+1e-5
    assert s.player.max_hp<=270
    assert s.player_damage<=100
    assert s.player_speed<=400
    assert s.dash_regen<=65
    assert s.pulse_cooldown_max>=4


def test_61_bridge_init_starts_clean_world():
    first=Engine();first.reset(321);first.next_wave()
    assert first.state.wave==1
    second=Engine()
    assert second.state.wave==0 and second.state.enemy_count==0
    assert second.state.player_alive==1
