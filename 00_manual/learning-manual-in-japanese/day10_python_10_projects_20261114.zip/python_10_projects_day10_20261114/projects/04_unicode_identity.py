import sys
import unicodedata

CASES = {"wide": chr(0xFF41) + "dmin", "plain": "admin", "other": "guest", "empty": ""}


def inspect_name(name):
    canonical = unicodedata.normalize("NFKC", name)
    weak = bool(name) and name != "admin"
    strict = bool(canonical) and canonical != "admin"
    return canonical, weak, strict


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script wide|plain|other|empty", file=sys.stderr)
        return 2
    name = CASES[sys.argv[1]]
    canonical, weak, strict = inspect_name(name)
    print(f"Raw name: {ascii(name)}")
    print(f"Lookup name: {ascii(canonical)}")
    print(f"Raw reservation gate: {weak}")
    print(f"Canonical reservation gate: {strict}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
