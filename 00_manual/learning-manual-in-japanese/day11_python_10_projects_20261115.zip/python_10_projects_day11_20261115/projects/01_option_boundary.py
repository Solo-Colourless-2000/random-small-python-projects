import getopt
import sys

CASES = {"option": "--debug", "normal": "note.txt", "empty": "", "unknown": "--missing"}


def inspect_argument(argument):
    weak_options, weak_files = getopt.getopt([argument], "", ["debug"])
    strict_options, strict_files = getopt.getopt(["--", argument], "", ["debug"])
    return weak_options, weak_files, strict_options, strict_files


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script option|normal|empty|unknown", file=sys.stderr)
        return 2
    try:
        weak_options, weak_files, strict_options, strict_files = inspect_argument(CASES[sys.argv[1]])
    except getopt.GetoptError:
        print("Invalid lab option.", file=sys.stderr)
        return 2
    print(f"Direct option count: {len(weak_options)}")
    print(f"Direct filenames: {weak_files}")
    print(f"Separated option count: {len(strict_options)}")
    print(f"Separated filenames: {strict_files}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
