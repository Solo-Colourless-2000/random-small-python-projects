"""Executable regression checks for the second day07 manual revision."""
import ast
from contextlib import redirect_stdout, redirect_stderr
from html.parser import HTMLParser
import importlib.util
from io import StringIO
from pathlib import Path
import sys
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
PAGE = (ROOT / 'python_10_projects_day07_manual.html').read_text(encoding='utf-8')
SOURCES = sorted((ROOT / 'projects').glob('*.py'))


def load(index):
    path = SOURCES[index-1]
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class Tags(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.ids = set()
        self.dupes = set()
        self.refs = []
        self.codes = []
        self.current = None
        self.guides = 0
        self.worked_rows = 0
        self.deep = 0

    def handle_starttag(self, name, attrs):
        a = dict(attrs)
        if 'id' in a:
            if a['id'] in self.ids:
                self.dupes.add(a['id'])
            self.ids.add(a['id'])
        if name == 'a' and a.get('href', '').startswith('#'):
            self.refs.append(a['href'][1:])
        classes = a.get('class', '').split()
        if 'worked-guide' in classes:
            self.guides += 1
        if name == 'tr' and a.get('id', '').startswith('worked-'):
            self.worked_rows += 1
        if 'deep-breakdown' in classes:
            self.deep += 1
        if name == 'code':
            self.current = []

    def handle_data(self, data):
        if self.current is not None:
            self.current.append(data)

    def handle_endtag(self, name):
        if name == 'code' and self.current is not None:
            self.codes.append(''.join(self.current))
            self.current = None


class SecondRevisionTests(unittest.TestCase):
    def test_01_query_parameter_decoding(self):
        p = load(1)
        self.assertEqual(p.compare('target=public&target=private'), (True, 'private', False))
        self.assertEqual(p.compare('%74arget=public&target=private'), (True, 'private', False))
        with self.assertRaises(ValueError):
            p.compare('target=public&&target=private')

    def test_02_authorization_filter(self):
        p = load(2)
        self.assertEqual(p.apply_update(p.CASES['role'], False)['role'], 'admin')
        self.assertEqual(p.apply_update(p.CASES['role'], True)['role'], 'reader')
        self.assertEqual(p.BASE['role'], 'reader')

    def test_03_regular_expression_literal(self):
        p = load(3)
        self.assertEqual(p.matches('.*', False), ','.join(p.NAMES))
        self.assertEqual(p.matches('.*', True), '(none)')
        self.assertEqual(p.matches('a.b', False), 'a.b,axb')

    def test_04_token_reuse(self):
        p = load(4)
        state = {p.TOKEN: 'alice'}
        self.assertEqual(p.redeem(state, p.TOKEN, True), 'accept')
        self.assertEqual(p.redeem(state, p.TOKEN, True), 'reject')
        self.assertEqual(state, {})

    def test_05_numeric_conversion_is_not_policy(self):
        p = load(5)
        self.assertEqual(p.purchase(-1, False), ('accept', 23, 6))
        self.assertEqual(p.purchase(-1, True), ('reject', 20, 5))
        self.assertEqual(int('\uff12'), 2)
        self.assertEqual(int(' 2 '), 2)
        self.assertEqual(int('-0100'), -100)
        for value in range(-100, 101):
            status, balance, stock = p.purchase(value, True)
            if status == 'accept':
                self.assertTrue(1 <= value <= 5)
                self.assertEqual((balance, stock), (20-3*value, 5-value))
            else:
                self.assertEqual((balance, stock), (20, 5))

    def test_05_cli_character_limit(self):
        p = load(5)
        output, errors = StringIO(), StringIO()
        with patch.object(sys, 'argv', ['script.py', '-0100']), redirect_stdout(output), redirect_stderr(errors):
            self.assertEqual(p.main(), 2)
        self.assertEqual(errors.getvalue(), 'Usage: script INTEGER (-100 to 100)\n')

    def test_06_cache_key_split(self):
        p = load(6)
        weak = {}
        p.fetch(weak, 'red', False)
        self.assertEqual(p.fetch(weak, 'blue', False), 'variant=red')
        keyed = {}
        p.fetch(keyed, 'red', True)
        self.assertEqual(p.fetch(keyed, 'blue', True), 'variant=blue')

    def test_07_session_rotation(self):
        p = load(7)
        state = {p.OLD_ID: 'anonymous'}
        self.assertEqual(p.login(state, True), p.NEW_ID)
        self.assertEqual(state.get(p.OLD_ID, 'invalid'), 'invalid')

    def test_08_pickle_is_inspected_not_restored(self):
        p = load(8)
        with patch('pickle.loads', side_effect=AssertionError('unexpected')):
            self.assertEqual(p.inspect(p.CASES['global']), ('GLOBAL', False))
            self.assertEqual(p.inspect(p.CASES['trailing']), ('(none)', True))

    def test_09_postparse_label_not_a_guard(self):
        p = load(9)
        self.assertEqual(p.expanded_length(p.CASES['entity']), 48)
        self.assertGreater(SOURCES[8].read_text().index('DTD policy:'), SOURCES[8].read_text().index('length = expanded_length(raw)'))

    def test_10_format_map_attribute_access(self):
        p = load(10)
        self.assertEqual(p.render(p.CASES['nested'], p.MINIMAL), '(missing field)')
        self.assertEqual(p.render('Type {user[name].__class__}', p.MINIMAL), "Type <class 'str'>")

    def test_manual_guides_and_search_ids(self):
        tags = Tags()
        tags.feed(PAGE)
        self.assertEqual(tags.guides, 10)
        self.assertGreaterEqual(tags.worked_rows, 45)
        self.assertGreaterEqual(tags.deep, 50)
        self.assertFalse(tags.dupes)
        self.assertFalse(set(tags.refs) - tags.ids)
        self.assertTrue(all(text.isascii() for text in tags.codes))
        for index in range(1, 11):
            self.assertIn(f'worked-{index:02}-summary', tags.ids)

    def test_explanations_do_not_edit_source(self):
        self.assertEqual(len(SOURCES), 10)
        self.assertEqual(sum(bool(l.strip()) for p in SOURCES for l in p.read_text().splitlines()), 245)
        for p in SOURCES:
            text = p.read_text(encoding='ascii')
            ast.parse(text, feature_version=(3, 10))
        for index, p in enumerate(SOURCES, 1):
            self.assertIn(f'"src-{index:02}"', PAGE)
            self.assertIn(f'"step-{index:02}-4"', PAGE)

    def test_xml_and_pickle_warnings_present(self):
        for word in ('DTD policy', '\u89e3\u6790\u5f8c', 'pickletools', '\u5fa9\u5143', 'format_map', '\u30b5\u30f3\u30c9\u30dc\u30c3\u30af\u30b9', '\u975e\u4fe1\u983cXML'):
            with self.subTest(word=word):
                self.assertIn(word, PAGE)


if __name__ == '__main__':
    unittest.main()
