import sys

CASES = {"escape": "user=" + chr(27) + "[31mguest", "plain": "user=guest", "newline": "user=guest\nstatus=OK", "empty": ""}


def visible(text):
    result = []
    count = 0
    for character in text:
        number = ord(character)
        if number < 32 or number == 127:
            result.append(f"\\x{number:02x}")
            count += 1
        else:
            result.append(character)
    return "".join(result), count


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script escape|plain|newline|empty", file=sys.stderr)
        return 2
    original = CASES[sys.argv[1]]
    rendered, count = visible(original)
    print(f"Raw representation: {ascii(original)}")
    print(f"Control count: {count}")
    print(f"Visible log: {rendered}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
