import socket
import sys
from threading import Thread


def exchange(request):
    failures = []
    with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as server:
        server.bind(("127.0.0.1", 0))
        server.settimeout(2)

        def reply():
            try:
                data, peer = server.recvfrom(64)
                if data in (b"Q", b"Q" * 60):
                    server.sendto(b"R" * 60, peer)
            except OSError:
                failures.append(True)

        worker = Thread(target=reply, daemon=True)
        worker.start()
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as client:
                client.settimeout(2)
                client.connect(server.getsockname())
                sent = client.send(request)
                payload = client.recv(128)
                if payload != b"R" * 60:
                    raise OSError("Unexpected lab reply")
        finally:
            worker.join(3)
        if worker.is_alive() or failures:
            raise OSError("Lab receiver failed")
    return sent, len(payload)


def main():
    cases = {"small": b"Q", "equal": b"Q" * 60}
    if len(sys.argv) != 2 or sys.argv[1] not in cases:
        print("Usage: script small|equal", file=sys.stderr)
        return 2
    try:
        sent, received = exchange(cases[sys.argv[1]])
    except OSError:
        print("Loopback UDP lab failed.", file=sys.stderr)
        return 1
    print(f"Request payload bytes: {sent}")
    print(f"Response payload bytes: {received}")
    print(f"Payload ratio: {received // sent}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
