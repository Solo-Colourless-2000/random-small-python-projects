from pathlib import Path
from playwright.sync_api import sync_playwright
import json
root=Path(__file__).resolve().parent.parent;html=next(root.glob('*.html')).read_text('utf8')
shim='''<script>
window.__mockStorage = new Map();
Object.defineProperty(window,'localStorage',{configurable:true,value:{getItem:k=>window.__mockStorage.get(k)||null,setItem:(k,v)=>window.__mockStorage.set(k,v)}});
Object.defineProperty(navigator,'clipboard',{configurable:true,value:{writeText:async t=>{window.__clipboard=t},readText:async()=>window.__clipboard||''}});
</script>'''
assert '<script>\n(() => {' in html
wrapped=html.replace('<script>\n(() => {',shim+'<script>\n(() => {',1)
results=[]
with sync_playwright() as pw:
 browser=pw.chromium.launch(headless=True,executable_path='/usr/bin/chromium',args=['--no-sandbox','--disable-dev-shm-usage'])
 for width in [1440,1024,768,393,360]:
  page=browser.new_page(viewport={'width':width,'height':900});page.set_default_timeout(8000);errs=[];page.on('pageerror',lambda exc:errs.append(str(exc)))
  page.set_content(wrapped,wait_until='domcontentloaded',timeout=60000)
  assert 'active' in page.locator('#home').get_attribute('class')
  if width<=768:
   page.locator('#menuButton').click();assert 'open' in page.locator('#sidebar').get_attribute('class')
   page.locator('#drawerClose').click()
  page.locator('[data-target="phase-03"]').evaluate('(e)=>e.click()')
  assert 'active' in page.locator('#phase-03').get_attribute('class')
  assert page.locator('#phase-03 .accuracy-note').count()==1
  page.locator('#edit-007 .line-breakdown').first.evaluate('(e)=>e.open=true')
  if width in (1440,393):
   page.locator('#edit-007 .precision-box').first.screenshot(path=str(root/'verification'/'review_previews'/f'v9_precision_{width}.png'))
  cb=page.locator('#edit-007 input[data-progress]');cb.check(force=True);assert cb.is_checked()
  assert page.evaluate('window.__mockStorage.size')>0
  (page.locator('#searchButton').click(force=True) if width<=768 else None);page.locator('#searchInput').fill('snake_set_direction');page.wait_for_timeout(100)
  hits=page.locator('.search-result').count();assert hits>0,(width,hits)
  page.locator('#searchInput').fill('')
  (page.locator('#searchClose').click(force=True) if width<=768 else None)
  page.locator('[data-target="phase-02"]').evaluate('(e)=>e.click()')
  btn=page.locator('#edit-005 > .code-wrap .copy-btn');btn.click(force=True)
  value=page.evaluate('navigator.clipboard.readText()');expected=page.locator('#edit-005 > .code-wrap code').text_content()
  assert value==expected,(width,'copy differs')
  overflow=page.evaluate('document.documentElement.scrollWidth>innerWidth');assert not overflow,(width,'horizontal overflow')
  page.locator('#fontUp').click(force=True)
  scale=float(page.evaluate('getComputedStyle(document.documentElement).getPropertyValue("--font-scale").trim()'));assert scale>1
  assert not errs,(width,errs)
  if width in (1440,393,360):
   page.locator('[data-target="phase-03"]').evaluate('(e)=>e.click()')
   page.screenshot(path=str(root/'verification'/'review_previews'/f'v9_phase3_{width}.png'))
  results.append({'width':width,'chapter_navigation':True,'progress_write_to_mock_storage':True,'search_hits':hits,'copy_content_matches':True,'font_scale':scale,'horizontal_overflow':overflow,'script_errors':errs})
  page.close()
 browser.close()
(root/'verification'/'v9_browser_report.json').write_text(json.dumps({'method':'Playwright set_content; localStorage and clipboard are explicitly mocked because the browser environment blocks local origins. This is not a real file:// persistence or OS clipboard test.','results':results},ensure_ascii=False,indent=2),encoding='utf8')
print(json.dumps(results,ensure_ascii=False,indent=2))
