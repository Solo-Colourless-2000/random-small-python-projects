#!/usr/bin/env python3
"""Recreate the taught source files from numbered UTF-8 fragments.
Only operates on an explicitly selected output directory; never modifies the original game.
"""
from __future__ import annotations
import argparse
import hashlib
import json
from pathlib import Path

BASE=Path(__file__).resolve().parent
parser=argparse.ArgumentParser(description='Replay manual edit steps to a separate workspace.')
parser.add_argument('--output',type=Path,required=True,help='Fresh workspace directory; must not contain existing files.')
parser.add_argument('--to',type=int,default=None,help='Last step to apply; default is all')
args=parser.parse_args()
manifest=json.loads((BASE/'STEP_MANIFEST.json').read_text(encoding='utf-8'))
last=args.to if args.to is not None else len(manifest['steps'])
if not 0<=last<=len(manifest['steps']): parser.error('Invalid step number')
output=args.output.resolve()
if output==BASE or output==BASE.parent or output==Path('/'): parser.error('Output cannot be manual/package root or filesystem root')
if output.exists() and any(output.iterdir()): parser.error('Output directory must be empty')
output.mkdir(parents=True,exist_ok=True)
for step in manifest['steps'][:last]:
    frag=(BASE/step['fragment']).read_bytes()
    assert hashlib.sha256(frag).hexdigest()==step['sha256'], f"Fragment modified: {step['fragment']}"
    path=output/step['path']; path.parent.mkdir(parents=True,exist_ok=True)
    with path.open('ab') as f: f.write(frag)
assert all((output/p).read_bytes()==(BASE/'reference_sources'/p).read_bytes()
           for p in manifest['files'] if any(s['path']==p and s['final'] and s['id']<=last for s in manifest['steps']))
if last==len(manifest['steps']):
    for p,meta in manifest['files'].items():
        assert hashlib.sha256((output/p).read_bytes()).hexdigest()==meta['sha256'], f'Mismatch: {p}'
print(f'Replayed {last} steps to {output}.')
if last==len(manifest['steps']): print(f'All {len(manifest["files"])} files match the v4 originals byte for byte.')
