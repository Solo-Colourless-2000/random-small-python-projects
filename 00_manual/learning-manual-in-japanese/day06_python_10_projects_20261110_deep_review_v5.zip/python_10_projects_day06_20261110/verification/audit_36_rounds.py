"""Repeat whole-package consistency checks with 36 distinct audit focuses."""
import ast
from collections import Counter
import hashlib
import json
from pathlib import Path
import re
import sys

ROOT = Path(__file__).resolve().parents[1]
TESTS = ROOT / "tests"
sys.path.insert(0, str(TESTS))
from test_materials import Manual
from cases import CASES

PY_FILES = sorted((ROOT / "projects").glob("*.py"))
MANUAL = ROOT / "python_10_projects_day06_manual.html"
READ_ME = (ROOT / "README.txt").read_text(encoding="utf-8")
RESULTS = json.loads((ROOT / "verification" / "cli_observations.json").read_text())
HISTORY = json.loads((ROOT / "PROJECT_HISTORY.json").read_text())


def verify(value, message):
    if not value:
        raise AssertionError(message)


def package_consistency(round_id):
    # A complete source-to-manual comparison runs in every round.
    page = Manual(MANUAL.read_text(encoding="utf-8"))
    verify(len(PY_FILES) == 10, "project count")
    verify(len(page.chapters) == 20, "chapter count")
    for idx, path in enumerate(PY_FILES, 1):
        name = f"{idx:02}"
        source = path.read_bytes()
        joined = "".join(page.sources[f"step-{name}-{part}"] for part in range(1, 5))
        verify(joined.encode("ascii") == source, f"step mismatch, round={round_id}, project={name}")
        verify(page.sources[f"src-{name}"].encode("ascii") == source, f"appendix mismatch, project={name}")
        line_numbers = [num for part in range(1, 5) for num in page.line_numbers[f"step-{name}-{part}"]]
        verify(line_numbers == list(range(1, source.count(b"\n") + 1)), f"line mismatch, project={name}")
    return page


def focus_01(page): verify(len(PY_FILES) == len(CASES) == len(RESULTS) == 10, "inventory")
def focus_02(page): verify(all(p.read_bytes().isascii() for p in PY_FILES), "source ASCII")
def focus_03(page):
    for p in PY_FILES: ast.parse(p.read_text("ascii"), feature_version=(3, 10))
def focus_04(page):
    allowed = {"sys", "sqlite3", "posixpath", "hmac", "socket", "pathlib", "urllib.parse", "contextlib"}
    for p in PY_FILES:
        tree = ast.parse(p.read_text("ascii"))
        mods = [n.module for n in ast.walk(tree) if isinstance(n, ast.ImportFrom)]
        mods += [a.name for n in ast.walk(tree) if isinstance(n, ast.Import) for a in n.names]
        verify(all(m in allowed for m in mods), p.name + " imports")
def focus_05(page):
    for p in PY_FILES: verify('if __name__ == "__main__":' in p.read_text("ascii"), p.name)
def focus_06(page):
    for p in PY_FILES: verify('len(sys.argv)' in p.read_text("ascii"), p.name)
def focus_07(page):
    for p in PY_FILES: verify('file=sys.stderr' in p.read_text("ascii"), p.name)
def focus_08(page): verify('Path(__file__).resolve().parent.parent' in PY_FILES[5].read_text("ascii"), "samples independent of cwd")
def focus_09(page): verify('"127.0.0.1"' in PY_FILES[9].read_text("ascii"), "loopback")
def focus_10(page):
    for p in PY_FILES:
        src = p.read_text("ascii")
        verify('urllib.request' not in src and 'requests.' not in src and 'subprocess.' not in src, p.name)
def focus_11(page): verify(len(page.chapters) == len(page.checks) == 20, "20 checks")
def focus_12(page): verify(all(f"step-{k:02}-4" in page.sources for k in range(1, 11)), "40 chunks")
def focus_13(page): verify(all(f"src-{k:02}" in page.sources for k in range(1, 11)), "10 appendices")
def focus_14(page):
    for idx,p in enumerate(PY_FILES,1): verify(page.line_numbers[f"src-{idx:02}"] == list(range(1,p.read_text("ascii").count("\n")+1)), p.name)
def focus_15(page): verify(not(set(page.anchors) - set(page.ids)), "broken anchors")
def focus_16(page): verify(max(page.ids.values()) == 1, "duplicate DOM id")
def focus_17(page): verify(all(f"glossary-extra-{n}" in page.ids for n in range(1,15)), "glossary")
def focus_18(page): verify(all(f"beginner-{k:02}-{n}" in page.ids for k in range(1,11) for n in range(1,5)), "40 teaching notes")
def focus_19(page): verify(all(f"beginner-{k:02}" in page.ids for k in range(1,11)), "searchable teaching cards")
def focus_20(page): verify(all(text.isascii() for text in page.sources.values()), "HTML code ASCII")
def focus_21(page): verify('@media (max-width: 850px)' in MANUAL.read_text(), "responsive CSS")
def focus_22(page): verify('background: var(--card)' in MANUAL.read_text(), "dark theme")
def focus_23(page): verify('navigator.clipboard.writeText' in MANUAL.read_text(), "copy")
def focus_24(page): verify(page.internal_assets == [], "offline assets")
def focus_25(page): verify(all(p.read_text("ascii").count('return 0') >= 1 for p in PY_FILES), "exit success")
def focus_26(page):
    src=PY_FILES[8].read_text("ascii")
    verify(src.count('raise ValueError("Length mismatch.")') == 2, "no prefix partial-match")
def focus_27(page): verify('db.execute(base + "?", (value,))' in PY_FILES[1].read_text("ascii"), "bound SQL")
def focus_28(page): verify('origin == TRUSTED' in PY_FILES[3].read_text("ascii"), "strict Origin")
def focus_29(page):
    src=PY_FILES[4].read_text("ascii")
    verify(src.index('parts = urlsplit(current)') < src.index('reply = PAGES.get(current)'), "check before fetch")
def focus_30(page): verify('stream.read(6)' in PY_FILES[5].read_text("ascii"), "signature length")
def focus_31(page): verify('hmac.compare_digest' in PY_FILES[6].read_text("ascii"), "MAC comparison")
def focus_32(page): verify('ACCOUNT = ("alice", "alice", "alice")' in PY_FILES[7].read_text("ascii"), "stable account")
def focus_33(page): verify('len(candidate) != 4' in PY_FILES[8].read_text("ascii"), "CLI length guard")
def focus_34(page): verify('stream.readline(64)' in PY_FILES[9].read_text("ascii"), "bounded read")
def focus_35(page): verify('https://docs.python.org' in MANUAL.read_text(), "reference links")
def focus_36(page):
    verify(HISTORY['last_completed_volume']==6 and HISTORY['next_volume']==7, "day ledger")
    verify(len(HISTORY['projects'])==60, "60 entries")

FOCUSES = [globals()[f"focus_{n:02}"] for n in range(1, 37)]
LABELS = [
 "Inventory", "Source ASCII", "Python 3.10 grammar", "Stdlib imports", "Direct-run entry",
 "CLI argument guards", "Error stream", "Sample path independent of cwd", "Loopback binding", "No real network client",
 "Chapter/check parity", "40 step code blocks", "10 appendix code blocks", "Appendix line sequence", "Internal anchors",
 "Unique HTML IDs", "Beginner glossary", "40 project explanations", "Note navigation IDs", "ASCII in displayed code",
 "Responsive stylesheet", "Dark color scheme", "Copy action source", "No external HTML assets", "Exit 0 path",
 "Direct function length guard", "SQLite parameter binding", "Exact trusted origin", "Redirect recheck order", "GIF prefix length",
 "HMAC comparison", "Rate-limit stable account", "CLI four-digit validation", "Bounded TCP banner", "Built-in reference URLs", "60-project handoff ledger"
]
assert len(LABELS)==len(FOCUSES)==36


def run():
    results=[]
    for idx,(func,label) in enumerate(zip(FOCUSES,LABELS),1):
        page=package_consistency(idx)
        func(page)
        result={"round":idx,"focus":label,"status":"PASS","project_sources_checked":len(PY_FILES),"html_step_chunks_verified":40,"appendix_sources_verified":10}
        results.append(result)
        print(f"ROUND {idx:02}: PASS | {label} | source/steps/appendices 10/40/10")
    dest=ROOT/"verification"/"audit_36_rounds.json"
    dest.write_text(json.dumps(results,indent=2,ensure_ascii=True)+"\n",encoding="ascii")
    print("ALL 36 ROUNDS PASS")
    return results

if __name__=='__main__':run()
