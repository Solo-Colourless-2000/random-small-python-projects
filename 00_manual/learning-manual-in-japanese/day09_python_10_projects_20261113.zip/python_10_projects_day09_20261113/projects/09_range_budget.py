import sys

CASES = {"single": "bytes=0-7", "repeat": "bytes=0-7,0-7,0-7", "edge": "bytes=7-7", "invalid": "bytes=0-8"}
SIZE = 8


def measure(header):
    if not header.startswith("bytes="):
        raise ValueError("Unsupported unit.")
    total = 0
    covered = set()
    for part in header[6:].split(","):
        start_text, end_text = part.split("-")
        start, end = int(start_text), int(end_text)
        if not 0 <= start <= end < SIZE:
            raise ValueError("Out of lab range.")
        total += end - start + 1
        covered.update(range(start, end + 1))
    return total, len(covered)


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script single|repeat|edge|invalid", file=sys.stderr)
        return 2
    try:
        total, unique = measure(CASES[sys.argv[1]])
    except ValueError:
        print("Invalid lab ranges.", file=sys.stderr)
        return 2
    print(f"Independent range bytes: {total}")
    print(f"Unique covered bytes: {unique}")
    print(f"Within one-file budget: {total <= SIZE}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
