Pythonペネトレーションテスト実習 day10
作成日 2026-11-14（日本時間）

最初に python_10_projects_day10_manual.html をブラウザーで開いてください。
ZIPを展開し、ターミナルを python_10_projects_day10_20261114/ に移動します。
現在地を pwd で、projects/ と samples/ が見えることを ls で確認します。

python3 --version
pwd
ls
mkdir -p practice
vim practice/01_unsigned_jwt.py

vimでは i で入力を開始し、Esc で戻って :wq とEnterで保存します。
字下げは半角スペース4個。全4工程を同じ実習ファイルへ追記します。
vimはnvimに置き換えられます。完成版はprojects/、自分で書く場所はpractice/です。

python3 practice/01_unsigned_jwt.py admin

完成版の試験入力（教材ルートで実行）
python3 projects/01_unsigned_jwt.py admin
python3 projects/02_expiry_edge.py equal
python3 projects/03_method_override.py override
python3 projects/04_unicode_identity.py wide
python3 projects/05_json_bool.py bool
python3 projects/06_nan_gate.py nan
python3 projects/07_state_binding.py cross
python3 projects/08_workflow_order.py skip
python3 projects/09_terminal_controls.py escape
python3 projects/10_dns_pointers.py backref

同じコマンドを再実行できます。配布物への書き込みはありません。
CLIは固定ケース名だけを受け取ります。
全作品がコード内の公開fixtureだけで完結します。通信や実データの変更はありません。
終了値は0が実験完了、2が入力エラー・固定構造の解析失敗、外部I/Oはありません。

python3 -m unittest discover -s tests -v

点検の範囲と実行環境は REVIEW_REPORT.txt、詳細は verification/ を参照してください。
次回はday11です。
