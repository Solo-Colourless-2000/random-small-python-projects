各作品のSTEP 01〜04をここへ入力する。完成版はprojects/。
