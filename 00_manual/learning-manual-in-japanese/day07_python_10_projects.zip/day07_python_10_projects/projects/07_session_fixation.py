import sys

OLD_ID = "LAB-OLD"
NEW_ID = "LAB-NEW"


def login(sessions, rotate):
    if rotate:
        del sessions[OLD_ID]
        sessions[NEW_ID] = "alice"
        return NEW_ID
    sessions[OLD_ID] = "alice"
    return OLD_ID


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ("login", "no-login"):
        print("Usage: script login|no-login", file=sys.stderr)
        return 2
    for rotate in (False, True):
        sessions = {OLD_ID: "anonymous"}
        current = OLD_ID
        if sys.argv[1] == "login":
            current = login(sessions, rotate)
        observer = sessions.get(OLD_ID, "invalid")
        label = "Rotate ID" if rotate else "Keep ID"
        print(f"{label}: current={current}, old-view={observer}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
