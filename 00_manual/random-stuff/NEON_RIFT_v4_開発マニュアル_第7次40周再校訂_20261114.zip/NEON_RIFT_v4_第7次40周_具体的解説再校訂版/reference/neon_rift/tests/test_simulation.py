"""Multi-minute no-GUI runs with randomized inputs and game invariants."""
from __future__ import annotations
import math
import random
import sys
import unittest
from pathlib import Path
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))

from constants import ARENA_BOTTOM, ARENA_LEFT, ARENA_RIGHT, ARENA_TOP
from support import create_game


class LongRunSimulationTests(unittest.TestCase):
    def test_multiple_seeded_runs_are_safe(self):
        frames = 4200
        for seed in (1, 7, 41, 117, 505):
            with self.subTest(seed=seed):
                g = create_game(seed)
                # Stress enemies and bullets without ending the run early.
                g.player.invulnerable = 9999
                rng = random.Random(seed + 10000)
                for frame in range(frames):
                    if frame % 37 == 0:
                        g.keys.clear()
                        g.keys.add(rng.choice(['w', 'a', 's', 'd']))
                    if frame % 95 == 0:
                        g.dash()
                    if frame % 125 == 0:
                        g.pulse()
                    g.mouse_down = True
                    if g.enemies:
                        target = min(g.enemies,
                                     key=lambda e: (e.x - g.player.x) ** 2 + (e.y - g.player.y) ** 2)
                        g.mouse_x, g.mouse_y = target.x, target.y
                    else:
                        g.mouse_x = 200 + 680 * rng.random()
                        g.mouse_y = 190 + 310 * rng.random()
                    g.tick(1 / 60)
                    if g.state == 'upgrade':
                        g.apply_upgrade(frame % len(g.upgrades_offered))
                    self.assertEqual(g.state, 'playing')
                    p = g.player
                    self.assertTrue(0 <= p.hp <= p.max_hp)
                    self.assertTrue(0 <= p.energy <= 100)
                    self.assertTrue(ARENA_LEFT + p.radius <= p.x <= ARENA_RIGHT - p.radius)
                    self.assertTrue(ARENA_TOP + p.radius <= p.y <= ARENA_BOTTOM - p.radius)
                    self.assertTrue(math.isfinite(g.score))
                    self.assertTrue(all(math.isfinite(b.x) and math.isfinite(b.y) for b in g.bullets))
                    self.assertLessEqual(len(g.particles), 300)
                    self.assertTrue(all(e.hp > 0 for e in g.enemies))
                    self.assertEqual(len({e.uid for e in g.enemies}), len(g.enemies))


if __name__ == '__main__':
    unittest.main()
