import importlib.util
import json
from pathlib import Path
import subprocess
import sys
import unittest
from unittest.mock import patch

from cases import CASES

ROOT = Path(__file__).resolve().parents[1]


def load(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / 'projects' / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class ProjectTests(unittest.TestCase):
    def check_cases(self, name):
        for args, code, stdout, stderr in CASES[name]:
            with self.subTest(args=args):
                result = subprocess.run([sys.executable, str(ROOT / 'projects' / (name + '.py')), *args],
                                        cwd=ROOT, stdin=subprocess.DEVNULL, capture_output=True,
                                        text=True, encoding='ascii', timeout=4)
                self.assertEqual((result.returncode, result.stdout, result.stderr), (code, stdout, stderr))

    def test_01_query(self):
        self.check_cases('01_query_pollution')

    def test_02_assignment(self):
        self.check_cases('02_mass_assignment')

    def test_03_regex(self):
        self.check_cases('03_regex_probe')

    def test_04_replay(self):
        self.check_cases('04_token_replay')

    def test_05_quantity(self):
        self.check_cases('05_quantity_probe')

    def test_06_cache(self):
        self.check_cases('06_cache_poison')

    def test_07_session(self):
        self.check_cases('07_session_fixation')

    def test_08_pickle(self):
        self.check_cases('08_pickle_inspector')

    def test_09_xml(self):
        self.check_cases('09_xml_expansion')

    def test_10_template(self):
        self.check_cases('10_template_probe')

    def test_all_duplicate_pair_orders(self):
        lab = load('01_query_pollution')
        for first in ('public', 'private'):
            for last in ('public', 'private'):
                self.assertEqual(lab.compare(f'target={first}&target={last}'),
                                 (first == 'public', last, False))
        with self.assertRaises(ValueError):
            lab.compare('target=public&')

    def test_assignment_baseline_and_restricted_unknown_field(self):
        lab = load('02_mass_assignment')
        baseline = dict(lab.BASE)
        self.assertEqual(lab.apply_update('{"role":"admin","extra":"x"}', True), baseline)
        lab.apply_update(lab.CASES['role'], False)
        self.assertEqual(lab.BASE, baseline)
        self.assertIsNot(lab.apply_update('{}', True), lab.BASE)

    def test_literal_regex_matches_exact_string(self):
        lab = load('03_regex_probe')
        for value in ('.*', 'a.b', 'axb', 'alice', 'missing'):
            expected = value if value in lab.NAMES else '(none)'
            self.assertEqual(lab.matches(value, True), expected)

    def test_token_consumption_changes_only_successful_state(self):
        lab = load('04_token_replay')
        state = {lab.TOKEN: 'alice'}
        self.assertEqual(lab.redeem(state, 'wrong', True), 'reject')
        self.assertEqual(state, {lab.TOKEN: 'alice'})
        self.assertEqual(lab.redeem(state, lab.TOKEN, True), 'accept')
        self.assertEqual(state, {})
        self.assertEqual(lab.redeem(state, lab.TOKEN, True), 'reject')

    def test_quantity_conservation_for_201_inputs(self):
        lab = load('05_quantity_probe')
        for quantity in range(-100, 101):
            status, balance, stock = lab.purchase(quantity, True)
            if status == 'accept':
                self.assertIn(quantity, range(1, 6))
                self.assertEqual(balance + 3 * (5 - stock), 20)
                self.assertGreaterEqual(balance, 0)
                self.assertLessEqual(balance, 20)
                self.assertGreaterEqual(stock, 0)
                self.assertLessEqual(stock, 5)
            else:
                self.assertEqual((balance, stock), (20, 5))
        self.assertEqual(lab.purchase(-1, False), ('accept', 23, 6))

    def test_cache_all_seed_and_victim_combinations(self):
        lab = load('06_cache_poison')
        for seed in ('red', 'blue'):
            for victim in ('red', 'blue'):
                cache = {}
                lab.fetch(cache, seed, True)
                self.assertEqual(lab.fetch(cache, victim, True), 'variant=' + victim)
                cache = {}
                lab.fetch(cache, seed, False)
                self.assertEqual(lab.fetch(cache, victim, False), 'variant=' + seed)

    def test_session_rotation_removes_old_identifier(self):
        lab = load('07_session_fixation')
        sessions = {lab.OLD_ID: 'anonymous'}
        current = lab.login(sessions, True)
        self.assertNotIn(lab.OLD_ID, sessions)
        self.assertEqual((current, sessions), (lab.NEW_ID, {lab.NEW_ID: 'alice'}))

    def test_pickle_inspection_never_uses_loads(self):
        lab = load('08_pickle_inspector')
        with patch('pickle.loads', side_effect=AssertionError('Unexpected deserialization')):
            self.assertEqual(lab.inspect(lab.CASES['global']), ('GLOBAL', False))
        with self.assertRaises(ValueError):
            lab.inspect(b'')
        self.assertEqual(lab.inspect(b'.'), ('(none)', False))
        self.assertEqual(lab.inspect(b'..'), ('(none)', True))

    def test_xml_hand_computed_expansion(self):
        lab = load('09_xml_expansion')
        self.assertEqual(lab.expanded_length(lab.CASES['entity']), 3 * 4 * 4)
        self.assertEqual(lab.expanded_length('<note/>'), 0)
        self.assertEqual(lab.expanded_length(lab.CASES['entity'].replace('LAB', 'AB')), 32)

    def test_minimal_template_context_and_no_mutation(self):
        lab = load('10_template_probe')
        before = json.dumps(lab.MINIMAL, sort_keys=True)
        self.assertEqual(lab.render(lab.CASES['nested'], lab.MINIMAL), '(missing field)')
        self.assertEqual(lab.render('{', lab.MINIMAL), '(missing field)')
        self.assertEqual(json.dumps(lab.MINIMAL, sort_keys=True), before)
