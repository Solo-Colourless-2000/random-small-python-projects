"""Tests for defects located in the v4 independent review cycles."""
from __future__ import annotations

import math
import random
import sys
import tempfile
import types
import unittest
from pathlib import Path
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
sys.path.insert(0, str(Path(__file__).resolve().parent))

import game as game_module
from constants import CYAN, RED
from entities import Bullet, Enemy, Pickup
from mechanics import distance_sq
from records import load_best_record, save_best_record
from support import create_game


class ProjectileBirthTests(unittest.TestCase):
    def test_player_new_shot_does_not_hit_enemy_before_it_existed(self):
        g = create_game()
        g.pending.clear()
        e = Enemy('hunter', g.player.x + 21, g.player.y, uid=1)
        g.enemies = [e]
        g.mouse_x, g.mouse_y = g.player.x + 200, g.player.y
        g.fire_player()
        self.assertTrue(g.bullets[0].fresh)
        g.update_bullets(1 / 60)
        self.assertEqual(e.hp, e.max_hp)
        self.assertFalse(g.bullets[0].fresh)
        g.update_bullets(1 / 60)
        self.assertLess(e.hp, e.max_hp)

    def test_new_enemy_bullet_cannot_retroactively_hit_moving_player(self):
        g = create_game()
        p = g.player
        p.prev_x, p.prev_y = 440, 350
        p.x, p.y = 560, 350
        e = Enemy('gunner', 390, 350)
        g.enemy_shoot(e, 0, count=1, speed=270)
        b = g.bullets[0]
        self.assertTrue(b.fresh)
        before = p.hp
        g.update_bullets(1 / 60)
        self.assertEqual(p.hp, before)
        self.assertFalse(b.fresh)

    def test_existing_projectile_still_sweeps_on_first_update(self):
        g = create_game()
        e = Enemy('hunter', 580, 350)
        g.enemies = [e]
        g.bullets = [Bullet(440, 350, 8000, 0, 4.4, 100, 1, True, CYAN)]
        g.update_bullets(1 / 30)
        self.assertTrue(e.dead)

    def test_fresh_projectile_can_be_removed_by_pulse(self):
        g = create_game()
        e = Enemy('gunner', g.player.x + 80, g.player.y)
        g.enemy_shoot(e, 0)
        self.assertTrue(g.bullets[0].fresh)
        g.pulse()
        self.assertFalse(g.bullets)

    def test_fresh_projectile_ttl_does_not_go_negative(self):
        g = create_game()
        g.bullets = [Bullet(500, 300, 10, 0, 3, 3, .001, True, CYAN, fresh=True)]
        g.update_bullets(1 / 60)
        self.assertEqual(len(g.bullets), 1)
        g.update_bullets(1 / 60)
        self.assertEqual(len(g.bullets), 0)


class PickupUseTests(unittest.TestCase):
    def test_full_health_repair_pickup_is_preserved(self):
        g = create_game()
        p = g.player
        g.pickups = [Pickup(p.x, p.y, 'repair')]
        g.update_pickups(1 / 60)
        self.assertEqual(len(g.pickups), 1)
        self.assertEqual(p.hp, p.max_hp)

    def test_full_energy_charge_pickup_is_preserved(self):
        g = create_game()
        p = g.player
        g.pickups = [Pickup(p.x, p.y, 'charge')]
        g.update_pickups(1 / 60)
        self.assertEqual(len(g.pickups), 1)

    def test_pickup_waits_then_collects_after_damage(self):
        g = create_game()
        p = g.player
        g.pickups = [Pickup(p.x, p.y, 'repair')]
        g.update_pickups(1 / 60)
        p.hp -= 23
        g.update_pickups(1 / 60)
        self.assertEqual(p.hp, p.max_hp)
        self.assertFalse(g.pickups)

    def test_pickup_at_full_resource_still_expires(self):
        g = create_game()
        p = g.player
        g.pickups = [Pickup(p.x, p.y, 'charge', ttl=.01)]
        g.update_pickups(1 / 60)
        self.assertFalse(g.pickups)

    def test_partial_repair_message_uses_actual_amount(self):
        g = create_game()
        p = g.player
        p.hp = 97
        g.pickups = [Pickup(p.x, p.y, 'repair')]
        g.update_pickups(1 / 60)
        self.assertIn('+3', g.notification)
        self.assertEqual(p.hp, 100)

    def test_partial_energy_message_uses_actual_amount(self):
        g = create_game()
        p = g.player
        p.energy = 98
        g.pickups = [Pickup(p.x, p.y, 'charge')]
        g.update_pickups(1 / 60)
        self.assertIn('+2', g.notification)
        self.assertEqual(p.energy, 100)


class SpawnSeparationTests(unittest.TestCase):
    def test_twelve_spawns_are_separated_across_multiple_seeds(self):
        for seed in range(12):
            with self.subTest(seed=seed):
                g = create_game(seed)
                for _ in range(12):
                    g.spawn_enemy('hunter')
                for n, e in enumerate(g.enemies):
                    self.assertGreater(distance_sq(e.x, e.y, g.player.x, g.player.y), 230 ** 2)
                    for other in g.enemies[n + 1:]:
                        self.assertGreater(distance_sq(e.x, e.y, other.x, other.y), 60 ** 2)

    def test_boss_spawn_keeps_distance_from_player(self):
        for seed in range(10):
            g = create_game(seed)
            g.wave = 5
            for _ in range(8):
                g.spawn_enemy('hunter')
            g.spawn_enemy('warden')
            boss = g.enemies[-1]
            self.assertGreater(distance_sq(boss.x, boss.y, g.player.x, g.player.y), 230 ** 2)

    def test_spawn_is_seed_reproducible(self):
        a, b = create_game(123), create_game(123)
        for _ in range(20):
            a.spawn_enemy('gunner')
            b.spawn_enemy('gunner')
        self.assertEqual([(e.x, e.y, e.orbit) for e in a.enemies],
                         [(e.x, e.y, e.orbit) for e in b.enemies])


class SaveRetryTests(unittest.TestCase):
    def test_failed_write_retries_without_new_score(self):
        g = create_game()
        del g.save_best
        g.score = 1050
        with patch.object(game_module, 'save_best_record', side_effect=[False, True]) as writer:
            g.save_best()
            self.assertTrue(g.record_save_failed)
            self.assertEqual((g.best, g._saved_best), (1050, 0))
            g.save_best()
            self.assertFalse(g.record_save_failed)
            self.assertEqual((g.best, g._saved_best), (1050, 1050))
            self.assertEqual(writer.call_count, 2)

    def test_success_does_not_rewrite_same_best(self):
        g = create_game()
        del g.save_best
        g.score = 500
        with patch.object(game_module, 'save_best_record', return_value=True) as writer:
            g.save_best()
            g.save_best()
            self.assertEqual(writer.call_count, 1)

    def test_failed_write_is_retried_when_closing_game(self):
        g = create_game()
        del g.save_best
        g.score = 600
        with patch.object(game_module, 'save_best_record', side_effect=[False, True]) as writer:
            g.save_best()
            g.close()
            self.assertEqual(writer.call_count, 2)
            self.assertTrue(g.root.destroyed)

    def test_previous_best_remains_if_new_score_is_smaller(self):
        g = create_game()
        del g.save_best
        g.best = g._saved_best = 4500
        g.score = 300
        with patch.object(game_module, 'save_best_record') as writer:
            g.save_best()
            writer.assert_not_called()
            self.assertEqual(g.best, 4500)

    def test_record_writer_rejects_invalid_scores(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'record.json'
            for value in (-1, True, False, 1.3, '77', None):
                with self.subTest(value=value):
                    self.assertFalse(save_best_record(path, value))
            self.assertFalse(path.exists())

    def test_atomic_record_replace_then_reload(self):
        with tempfile.TemporaryDirectory() as folder:
            path = Path(folder) / 'record.json'
            self.assertTrue(save_best_record(path, 123))
            self.assertTrue(save_best_record(path, 456))
            self.assertEqual(load_best_record(path), 456)


class StateCycleTests(unittest.TestCase):
    def test_pause_does_not_age_pickups(self):
        g = create_game()
        g.pickups = [Pickup(300, 240, 'charge')]
        g.state = 'paused'
        g.tick(1 / 30)
        self.assertEqual(g.pickups[0].ttl, 12)

    def test_upgrade_does_not_retain_live_projectiles(self):
        g = create_game()
        g.pending.clear()
        g.bullets = [Bullet(500, 300, 500, 0, 3, 5, 1, True, CYAN)]
        g.finish_wave()
        self.assertEqual(g.state, 'upgrade')
        self.assertFalse(g.bullets)

    def test_game_over_after_shot_does_not_award_future_kills(self):
        g = create_game()
        g.pending.clear()
        g.enemies = [Enemy('hunter', 800, 300)]
        g.player.hp = 1
        g.bullets = [Bullet(g.player.x - 30, g.player.y, 3000, 0, 5.8, 100, 1, False, RED),
                     Bullet(790, 300, 500, 0, 4, 100, 1, True, CYAN)]
        g.update_bullets(1 / 60)
        self.assertEqual(g.state, 'gameover')
        self.assertEqual(g.total_kills, 0)


if __name__ == '__main__':
    unittest.main()
