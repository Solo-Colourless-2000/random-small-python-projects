"""UI smoke and state-transition tests (needs a screen or Xvfb)."""
from __future__ import annotations

from dataclasses import replace
from pathlib import Path
import tempfile
import tkinter as tk
import time
import unittest
from unittest.mock import patch

from snake_app.engine import Frame, Status
from snake_app.ui import GameApp


class UiTests(unittest.TestCase):
    def setUp(self) -> None:
        # UI tests must never write real player records in the user's home.
        isolated = tempfile.TemporaryDirectory(prefix="snake_gui_test_")
        self.addCleanup(isolated.cleanup)
        path_patch = patch("snake_app.storage.save_path",
                           return_value=Path(isolated.name) / "highscores.json")
        path_patch.start()
        self.addCleanup(path_patch.stop)
        patcher = patch("snake_app.ui.load_scores", return_value={"EASY": 0, "NORMAL": 0, "HARD": 0})
        patcher.start()
        self.addCleanup(patcher.stop)
        try:
            self.app = GameApp()
        except tk.TclError as exc:
            self.skipTest(f"No working GUI display: {exc}")
        self.addCleanup(self.app.close)
        self.app.root.update()

    def key(self, keysym: str) -> None:
        event = type("Key", (), {"keysym": keysym})()
        self.app._on_key(event)

    def test_menu_and_speed_selection(self) -> None:
        self.assertEqual(self.app.mode, "menu")
        self.key("1")
        self.assertEqual(self.app.difficulty, "EASY")
        self.key("3")
        self.assertEqual(self.app.difficulty, "HARD")

    def test_enter_starts_and_escape_returns_to_menu(self) -> None:
        self.key("Return")
        self.assertEqual(self.app.mode, "playing")
        self.key("Escape")
        self.assertEqual(self.app.mode, "menu")

    def test_space_pauses_and_resumes(self) -> None:
        self.key("space")
        self.assertEqual(self.app.mode, "playing")
        self.key("space")
        self.assertEqual(self.app.mode, "paused")
        self.key("space")
        self.assertEqual(self.app.mode, "playing")

    def test_keypad_direction_keys_and_menu_number(self) -> None:
        self.key("KP_3")
        self.assertEqual(self.app.difficulty, "HARD")
        self.key("Return")
        self.key("KP_Up")
        self.key("KP_4")
        self.app.engine.tick()
        self.assertEqual(self.app.engine.snapshot().direction.name, "UP")
        self.app.engine.tick()
        self.assertEqual(self.app.engine.snapshot().direction.name, "LEFT")

    def test_direction_ignored_when_paused(self) -> None:
        self.key("Return")
        self.key("p")
        before = self.app.engine.snapshot()
        self.key("Up")
        self.assertEqual(self.app.engine.snapshot(), before)
        self.assertEqual(self.app.mode, "paused")

    def test_r_restarts_after_game_over(self) -> None:
        self.app.mode = "over"
        self.app.frame = replace(self.app.frame, status=Status.LOST)
        self.key("r")
        self.assertEqual(self.app.mode, "playing")
        self.assertEqual(self.app.frame.score, 0)

    def test_all_screen_states_render(self) -> None:
        for mode in ("menu", "playing", "paused", "over"):
            self.app.mode = mode
            self.app._draw(1.0)
            self.app.root.update_idletasks()
            self.assertGreater(len(self.app.canvas.find_all()), 40)

    def test_click_play_button(self) -> None:
        self.app._draw(1.0)
        self.app.root.update()
        self.app.canvas.event_generate("<Motion>", x=425, y=435)
        self.app.canvas.event_generate("<Button-1>", x=425, y=435)
        self.assertEqual(self.app.mode, "playing")

    def test_click_difficulty_button(self) -> None:
        self.app._draw(1.0)
        self.app.root.update()
        self.app.canvas.event_generate("<Motion>", x=315, y=360)
        self.app.canvas.event_generate("<Button-1>", x=315, y=360)
        self.assertEqual(self.app.difficulty, "EASY")

    def test_text_bounds_fit_all_four_screens(self) -> None:
        for mode in ("menu", "playing", "paused", "over"):
            with self.subTest(mode=mode):
                self.app.mode = mode
                self.app._draw(time.monotonic())
                for item in self.app.canvas.find_all():
                    if self.app.canvas.type(item) != "text":
                        continue
                    x0, y0, x1, y1 = self.app.canvas.bbox(item)
                    self.assertGreaterEqual(x0, 0)
                    self.assertGreaterEqual(y0, 0)
                    self.assertLessEqual(x1, 850)
                    self.assertLessEqual(y1, 700)

    def test_full_board_render_does_not_accumulate_tcl_callbacks(self) -> None:
        body = tuple((x, y) for y in range(18) for x in range(26))
        frame = Frame(26, 18, body, None, 464, self.app.frame.direction, Status.WON)
        self.app.frame = self.app.previous = frame
        self.app.mode = "over"
        before = len(self.app.canvas._tclCommands or [])
        for _ in range(30):
            self.app._draw(time.monotonic())
        self.assertEqual(len(self.app.canvas._tclCommands or []), before)
        self.assertGreater(len(self.app.canvas.find_all()), 450)

    def test_victory_overlay_says_you_win(self) -> None:
        self.app.mode = "over"
        self.app.frame = replace(self.app.frame, status=Status.WON, food=None)
        self.app._draw(1.0)
        texts = [self.app.canvas.itemcget(item, "text") for item in self.app.canvas.find_all()
                 if self.app.canvas.type(item) == "text"]
        self.assertIn("YOU WIN", texts)

    def test_real_key_event_is_received_by_window(self) -> None:
        self.app.root.focus_force()
        self.app.root.event_generate("<KeyPress-Return>")
        self.app.root.update()
        self.assertEqual(self.app.mode, "playing")

    def test_repeated_menu_draws_do_not_leak_tcl_callbacks(self) -> None:
        start = len(self.app.canvas._tclCommands or [])
        for mode in ("menu", "paused", "over", "playing"):
            self.app.mode = mode
            for _ in range(40):
                self.app._draw(1.0)
            self.assertEqual(len(self.app.canvas._tclCommands or []), start)

    def test_hitboxes_are_only_active_in_visible_overlay(self) -> None:
        self.app.mode = "menu"
        self.app._draw(1.0)
        self.assertEqual(len(self.app._hitboxes), 4)
        self.app.canvas.event_generate("<Button-1>", x=100, y=100)
        self.assertEqual(self.app.mode, "menu")
        self.app.mode = "playing"
        self.app._draw(1.0)
        self.assertEqual(self.app._hitboxes, [])
        self.app.canvas.event_generate("<Button-1>", x=425, y=435)
        self.assertEqual(self.app.mode, "playing")

    def test_pointer_feedback_on_hover(self) -> None:
        self.app._draw(1.0)
        self.app.canvas.event_generate("<Motion>", x=425, y=435)
        self.assertEqual(self.app._cursor, "hand2")
        self.app.canvas.event_generate("<Motion>", x=200, y=200)
        self.assertEqual(self.app._cursor, "")

    def test_focus_loss_autopauses_and_resume_avoids_time_jump(self) -> None:
        self.key("Return")
        self.app.last_step = -1e9
        self.app._on_focus_out(type("Focus", (), {"widget": self.app.root})())
        self.assertEqual(self.app.mode, "paused")
        self.assertEqual(self.app.pause_reason, "AUTO-PAUSED")
        old = self.app.frame
        self.app._loop()
        self.assertEqual(self.app.frame, old)
        self.key("space")
        self.assertEqual(self.app.mode, "playing")
        self.app._loop()
        self.assertEqual(self.app.frame, old)

    def test_focus_out_from_other_widget_is_ignored(self) -> None:
        self.key("Return")
        self.app._on_focus_out(type("Focus", (), {"widget": self.app.canvas})())
        self.assertEqual(self.app.mode, "playing")

    def test_save_failure_is_visible(self) -> None:
        self.key("Return")
        # Find a reproducible seed that puts food directly ahead of the head.
        for seed in range(1, 10000):
            self.app.engine.reset(seed=seed)
            self.app.frame = self.app.engine.snapshot()
            if self.app.frame.food == (14, 9):
                break
        else:
            self.fail("No nearby food seed found")
        self.app.previous = self.app.frame
        self.app.last_step = time.monotonic() - self.app._interval() - 0.01
        with patch("snake_app.ui.save_scores", return_value=False) as saver:
            self.app._loop()
            self.assertEqual(saver.call_count, 0)  # No disk write per food.
            self.assertTrue(self.app._scores_dirty)
            self.key("space")  # Pause flushes the latest high score.
        saver.assert_called_once()
        self.assertEqual(self.app.frame.score, 1)
        self.assertTrue(self.app.save_warning)
        self.app._draw(time.monotonic())
        texts = [self.app.canvas.itemcget(item, "text") for item in self.app.canvas.find_all()
                 if self.app.canvas.type(item) == "text"]
        self.assertIn("BEST SCORE NOT SAVED", texts)

    def test_interval_monotonically_increases_speed_but_is_bounded(self) -> None:
        from snake_app.config import BASE_INTERVAL
        intervals = {}
        for level in ("EASY", "NORMAL", "HARD"):
            self.app.difficulty = level
            self.app.frame = replace(self.app.frame, score=0)
            start = self.app._interval()
            self.assertEqual(start, BASE_INTERVAL[level])
            self.app.frame = replace(self.app.frame, score=20)
            middle = self.app._interval()
            self.app.frame = replace(self.app.frame, score=400)
            end = self.app._interval()
            self.assertGreater(start, middle)
            self.assertGreaterEqual(middle, end)
            self.assertEqual(end, 0.060)
            intervals[level] = start
        self.assertGreater(intervals["EASY"], intervals["NORMAL"])
        self.assertGreater(intervals["NORMAL"], intervals["HARD"])

    def test_animation_progress_is_clamped(self) -> None:
        self.key("Return")
        self.app.last_step = 100.0
        self.assertEqual(self.app._animation_progress(10.0), 0.0)
        self.assertGreater(self.app._animation_progress(100.02), 0.0)
        self.assertEqual(self.app._animation_progress(200.0), 1.0)
        self.key("space")
        self.assertEqual(self.app._animation_progress(10.0), 1.0)

    def test_immediate_close_cancels_idle_focus_callback(self) -> None:
        extra = GameApp()
        extra.close()  # No event-loop cycle, so focus_after_id is still pending.
        self.assertTrue(extra._closed)

    def test_close_twice_is_safe(self) -> None:
        self.app.close()
        self.app.close()
        self.assertTrue(self.app._closed)

    def test_pause_resume_does_not_instantly_tick(self) -> None:
        self.key("Return")
        self.key("space")
        self.key("space")
        before = self.app.frame
        self.app._loop()
        if self.app._after_id:
            self.app.root.after_cancel(self.app._after_id)
            self.app._after_id = None
        self.assertEqual(self.app.frame, before)

    def test_delayed_save_coalesces_high_scores(self) -> None:
        self.key("Return")
        self.app.scores["NORMAL"] = 23
        self.app._scores_dirty = True
        with patch("snake_app.ui.save_scores", return_value=True) as save:
            self.app._last_save_attempt = time.monotonic()
            self.app._loop()
            self.assertEqual(save.call_count, 0)
            self.app._last_save_attempt -= 10
            self.app._loop()
            self.assertEqual(save.call_count, 1)
            self.assertFalse(self.app._scores_dirty)
            self.app._loop()
            self.assertEqual(save.call_count, 1)

    def test_failed_save_can_recover(self) -> None:
        self.app._scores_dirty = True
        with patch("snake_app.ui.save_scores", side_effect=[False, True]) as save:
            self.app._save_if_dirty()
            self.assertTrue(self.app.save_warning)
            self.app._save_if_dirty()
        self.assertEqual(save.call_count, 2)
        self.assertFalse(self.app.save_warning)
        self.assertFalse(self.app._scores_dirty)

    def test_menu_and_restart_flush_pending_score(self) -> None:
        self.key("Return")
        self.app._scores_dirty = True
        with patch("snake_app.ui.save_scores", return_value=True) as save:
            self.key("Escape")
            self.assertEqual(save.call_count, 1)
            self.assertEqual(self.app.mode, "menu")
            self.key("Return")
            self.app._scores_dirty = True
            self.key("r")
            self.assertEqual(save.call_count, 2)
            self.assertEqual(self.app.mode, "playing")

    def test_no_unnecessary_score_write_without_new_record(self) -> None:
        self.key("Return")
        with patch("snake_app.ui.save_scores", return_value=True) as save:
            self.key("space")
            self.key("Escape")
            self.app.close()
        self.assertEqual(save.call_count, 0)

    def test_regular_frames_keep_fractional_elapsed_time(self) -> None:
        # Simulate a busy GUI: updates every 40 ms, with a 125 ms snake step.
        # Old scheduling snapped the step timestamp to 160/320/480ms;
        # fixed-step scheduling keeps the true 125/250/375ms phase.
        self.key("Return")
        self.app.last_step = 100.0
        with patch("snake_app.ui.time.monotonic", return_value=100.0):
            self.app._loop()
        for millisecond in range(40, 481, 40):
            with patch("snake_app.ui.time.monotonic", return_value=100.0 + millisecond / 1000):
                self.app._loop()
            if self.app.mode != "playing":
                break
        self.assertEqual(self.app.frame.body[0], (16, 9))
        self.assertAlmostEqual(self.app.last_step, 100.375, places=6)

    def test_lag_spike_does_not_trigger_unbounded_catchup(self) -> None:
        self.key("Return")
        self.app.last_step = 100.0
        with patch("snake_app.ui.time.monotonic", return_value=200.0):
            self.app._loop()
        self.assertEqual(self.app.frame.body[0], (13, 9))
        self.assertAlmostEqual(self.app.last_step, 200.0, places=6)

    def test_suspend_near_wall_does_not_kill_without_player_input(self) -> None:
        self.key("Return")
        # The original code performed a surprise tick after a large stall.
        # At the wall that would be an unearned game over.
        for _ in range(12):
            self.app.engine.tick()
        self.app.frame = self.app.engine.snapshot()
        self.app.previous = self.app.frame
        self.assertEqual(self.app.frame.body[0], (25, 9))
        self.app.last_step = 100.0
        with patch("snake_app.ui.time.monotonic", return_value=200.0):
            self.app._loop()
        self.assertEqual(self.app.mode, "playing")
        self.assertEqual(self.app.frame.body[0], (25, 9))
        self.assertAlmostEqual(self.app.last_step, 200.0)

    def test_engine_owned_by_app_is_closed_if_initial_snapshot_fails(self) -> None:
        class BrokenEngine:
            closed = False
            def snapshot(self):
                raise RuntimeError("snapshot unavailable")
            def close(self):
                self.closed = True
        broken = BrokenEngine()
        with patch("snake_app.ui.SnakeEngine", return_value=broken):
            with self.assertRaisesRegex(RuntimeError, "snapshot unavailable"):
                GameApp()
        self.assertTrue(broken.closed)

    def test_external_engine_is_not_closed_if_snapshot_fails(self) -> None:
        class BrokenEngine:
            closed = False
            def snapshot(self):
                raise RuntimeError("snapshot unavailable")
            def close(self):
                self.closed = True
        external_root = tk.Toplevel(self.app.root)
        external_engine = BrokenEngine()
        try:
            with self.assertRaisesRegex(RuntimeError, "snapshot unavailable"):
                GameApp(root=external_root, engine=external_engine)
            self.assertTrue(external_root.winfo_exists())
            self.assertFalse(external_engine.closed)
        finally:
            external_root.destroy()

    def test_pause_restart_clears_stale_time_debt(self) -> None:
        self.key("Return")
        self.app.last_step = -100.0
        self.key("space")
        self.key("space")
        self.app._loop()
        self.assertEqual(self.app.frame.body[0], (13, 9))

    def test_pause_keeps_food_halo_stationary(self) -> None:
        self.key("Return")
        self.key("space")
        self.app._draw(10.0)
        first = [self.app.canvas.coords(i) for i in self.app.canvas.find_all()
                 if self.app.canvas.type(i) == "oval"]
        self.app._draw(100.0)
        second = [self.app.canvas.coords(i) for i in self.app.canvas.find_all()
                  if self.app.canvas.type(i) == "oval"]
        self.assertEqual(first, second)

    def test_idle_frames_use_lower_refresh_rate(self) -> None:
        from snake_app.config import FRAME_DELAY_MS, IDLE_FRAME_DELAY_MS
        self.assertGreater(IDLE_FRAME_DELAY_MS, FRAME_DELAY_MS)
        with patch.object(self.app.root, "after", wraps=self.app.root.after) as after:
            self.app._loop()
        self.assertEqual(after.call_args.args[0], IDLE_FRAME_DELAY_MS)
        self.key("Return")
        with patch.object(self.app.root, "after", wraps=self.app.root.after) as after:
            self.app._loop()
        self.assertEqual(after.call_args.args[0], FRAME_DELAY_MS)

    def test_startup_build_failure_does_not_destroy_external_root(self) -> None:
        with patch("snake_app.ui.SnakeEngine", side_effect=RuntimeError("broken compiler")):
            external = tk.Toplevel(self.app.root)
            try:
                with self.assertRaisesRegex(RuntimeError, "broken compiler"):
                    GameApp(root=external)
                self.assertTrue(external.winfo_exists())
            finally:
                external.destroy()

    def test_startup_build_failure_destroys_its_own_root(self) -> None:
        original_tk = tk.Tk
        roots: list[tk.Tk] = []
        def new_root() -> tk.Tk:
            instance = original_tk()
            roots.append(instance)
            return instance
        with patch("snake_app.ui.tk.Tk", side_effect=new_root), patch(
                "snake_app.ui.SnakeEngine", side_effect=RuntimeError("bad build")):
            with self.assertRaisesRegex(RuntimeError, "bad build"):
                GameApp()
        self.assertEqual(len(roots), 1)
        try:
            exists = roots[0].winfo_exists()
        except tk.TclError:  # Destroyed Tcl application on some Tk releases.
            exists = 0
        self.assertFalse(exists)

    def test_score_display_merges_saved_best_from_other_instance(self) -> None:
        self.app.scores = {"EASY": 2, "NORMAL": 3, "HARD": 0}
        self.app._scores_dirty = True
        with patch("snake_app.ui.save_scores", return_value=True), patch(
                "snake_app.ui.load_scores", return_value={"EASY": 21, "NORMAL": 1, "HARD": 0}):
            self.app._save_if_dirty()
        self.assertEqual(self.app.scores, {"EASY": 21, "NORMAL": 3, "HARD": 0})

    def test_close_flushes_dirty_scores(self) -> None:
        self.app._scores_dirty = True
        with patch("snake_app.ui.save_scores", return_value=True) as save:
            self.app.close()
        save.assert_called_once()
        self.assertFalse(self.app._scores_dirty)

    def test_resume_cannot_be_triggered_by_stale_hitbox(self) -> None:
        self.key("Return")
        self.key("space")
        self.app._draw(time.monotonic())
        self.assertEqual(self.app._hitboxes[0][-1], "resume")
        self.key("space")
        self.assertEqual(self.app.mode, "playing")
        self.app.canvas.event_generate("<Button-1>", x=425, y=386)
        self.assertEqual(self.app.mode, "playing")
        self.assertEqual(self.app._hitboxes, [])

    def test_renderer_has_declarative_actions_only(self) -> None:
        for mode in ("menu", "paused", "over"):
            self.app.mode = mode
            self.app._draw(time.monotonic())
            self.assertTrue(all(isinstance(box[4], str) for box in self.app._hitboxes))

    def test_renderer_does_not_mutate_game_state(self) -> None:
        self.key("Return")
        frame = self.app.engine.snapshot()
        for _ in range(80):
            self.app._draw(time.monotonic())
        self.assertEqual(self.app.engine.snapshot(), frame)


if __name__ == "__main__":
    unittest.main()
