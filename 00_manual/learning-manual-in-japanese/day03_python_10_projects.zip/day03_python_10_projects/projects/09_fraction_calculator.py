import sys
from fractions import Fraction


def main():
    if len(sys.argv) != 4:
        print("Usage: python3 09_fraction_calculator.py left operator right")
        return 2
    values = []
    try:
        for text in (sys.argv[1], sys.argv[3]):
            if not 1 <= len(text) <= 12:
                raise ValueError
            if any(ch not in "0123456789-/" for ch in text):
                raise ValueError
            parts = text.split("/")
            if len(parts) not in (1, 2):
                raise ValueError
            numerator = int(parts[0])
            denominator = int(parts[1]) if len(parts) == 2 else 1
            if abs(numerator) > 10000 or not 1 <= denominator <= 10000:
                raise ValueError
            value = Fraction(numerator, denominator)
            values.append(value)
    except ValueError:
        print("Error: use small integers or fractions such as -1/2.")
        return 2
    left, right = values
    operator = sys.argv[2]
    if operator == "+":
        result = left + right
    elif operator == "-":
        result = left - right
    elif operator == "*":
        result = left * right
    elif operator == "/" and right != 0:
        result = left / right
    else:
        print("Error: use + - * /; division needs a nonzero right value.")
        return 2
    print(f"Result: {result}")
    print(f"Numerator: {result.numerator}")
    print(f"Denominator: {result.denominator}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
