import sys


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 05_insertion_sort.py values")
        return 2
    try:
        if len(sys.argv[1]) > 32:
            raise ValueError
        values = []
        for part in sys.argv[1].split(","):
            value = int(part)
            if not -20 <= value <= 20:
                raise ValueError
            values.append(value)
        if not 1 <= len(values) <= 8:
            raise ValueError
    except ValueError:
        print("Error: use 1-8 integers from -20 to 20.")
        return 2
    for index in range(1, len(values)):
        key = values[index]
        position = index - 1
        while position >= 0 and values[position] > key:
            values[position + 1] = values[position]
            position -= 1
        values[position + 1] = key
        print(f"After {index}: {values}")
    print("Sorted:", *values)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
