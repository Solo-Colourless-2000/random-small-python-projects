import json
import sys

CASES = {"bool": "true", "integer": "1", "zero": "0", "float": "1.0", "null": "null", "broken": "["}


def gates(value):
    weak = isinstance(value, int) and 1 <= value <= 3
    strict = type(value) is int and 1 <= value <= 3
    return weak, strict


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script bool|integer|zero|float|null|broken", file=sys.stderr)
        return 2
    try:
        value = json.loads(CASES[sys.argv[1]])
    except json.JSONDecodeError:
        print("Invalid lab JSON.", file=sys.stderr)
        return 2
    weak, strict = gates(value)
    print(f"Parsed type: {type(value).__name__}")
    print(f"Subclass gate: {weak}")
    print(f"Exact integer gate: {strict}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
