import contextlib
import hmac
import importlib.util
import io
from pathlib import Path
import struct
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from cases import CASES

ROOT = Path(__file__).resolve().parents[1]


def load(name):
    spec = importlib.util.spec_from_file_location(name, ROOT / 'projects' / (name + '.py'))
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class ProjectTests(unittest.TestCase):
    def check_cases(self, name):
        for args, code, stdout, stderr in CASES[name]:
            with self.subTest(args=args):
                result = subprocess.run([sys.executable, str(ROOT / 'projects' / (name + '.py')), *args],
                                        cwd=ROOT, stdin=subprocess.DEVNULL, capture_output=True,
                                        text=True, encoding='ascii', timeout=8)
                self.assertEqual((result.returncode, result.stdout, result.stderr), (code, stdout, stderr))
    def test_01_symlink(self):
        self.check_cases('01_symlink_scope')

    def test_02_shell(self):
        self.check_cases('02_shell_boundary')

    def test_03_csrf(self):
        self.check_cases('03_csrf_probe')

    def test_04_zip(self):
        self.check_cases('04_zip_budget')

    def test_05_framing(self):
        self.check_cases('05_http_framing')

    def test_06_csv(self):
        self.check_cases('06_csv_formula')

    def test_07_path(self):
        self.check_cases('07_path_selection')

    def test_08_guess(self):
        self.check_cases('08_offline_guess')

    def test_09_interleaving(self):
        self.check_cases('09_lost_update')

    def test_10_dns(self):
        self.check_cases('10_dns_wildcard')

    def test_temporary_directories_are_removed(self):
        for name, call in [('01_symlink_scope', lambda lab: lab.probe('linked')),
                           ('07_path_selection', lambda lab: lab.select(True))]:
            lab = load(name)
            locations = []

            @contextlib.contextmanager
            def capture_directory():
                with tempfile.TemporaryDirectory() as folder:
                    locations.append(Path(folder))
                    yield folder

            with patch.object(lab, 'TemporaryDirectory', capture_directory):
                call(lab)
            self.assertTrue(locations)
            self.assertTrue(all(not path.exists() for path in locations))

    def test_io_errors_return_one(self):
        for name, argument, function, message in [
            ('01_symlink_scope', 'linked', 'probe', 'Temporary filesystem experiment failed.'),
            ('02_shell_boundary', 'normal', 'run_case', 'Fixed shell experiment failed.'),
            ('04_zip_budget', 'small', 'inspect', 'ZIP experiment failed.'),
            ('07_path_selection', 'trusted', 'select', 'PATH experiment failed.'),
        ]:
            lab = load(name)
            output = io.StringIO()
            with patch.object(sys, 'argv', ['script', argument]), patch.object(lab, function, side_effect=OSError):
                with contextlib.redirect_stderr(output):
                    self.assertEqual(lab.main(), 1)
            self.assertEqual(output.getvalue(), message + '\n')

    def test_shell_timeout_returns_one(self):
        lab = load('02_shell_boundary')
        with patch.object(sys, 'argv', ['script', 'normal']):
            with patch.object(lab, 'run_case', side_effect=subprocess.TimeoutExpired('fixture', 2)):
                with contextlib.redirect_stderr(io.StringIO()):
                    self.assertEqual(lab.main(), 1)

    def test_csrf_authentication_and_request_token_matrix(self):
        lab = load('03_csrf_probe')
        for authenticated in (False, True):
            for token in ('', 'wrong', lab.EXPECTED):
                expected = ('accept', 9) if authenticated and token == lab.EXPECTED else ('reject', 10)
                self.assertEqual(lab.transfer(authenticated, token, True), expected)

    def test_zip_budget_boundary_and_rejected_read(self):
        lab = load('04_zip_budget')
        self.assertEqual(lab.inspect(b'A' * 64)[0:2], (64, 64))
        self.assertTrue(lab.inspect(b'A' * 64)[3])
        self.assertEqual(lab.inspect(b'A' * 65)[0:2], (65, 0))
        with patch.object(lab.zipfile.ZipFile, 'read', side_effect=AssertionError('Rejected member read')):
            self.assertFalse(lab.inspect(b'A' * 65)[3])

    def test_http_boundary_matches_known_zero_chunk(self):
        lab = load('05_http_framing')
        body = b'0\r\n\r\nNEXT'
        front, back, decision = lab.boundaries(0, True, body)
        self.assertEqual((front, back, decision), (0, 5, 'reject'))
        self.assertEqual(body[front:], body)
        self.assertEqual(body[back:], b'NEXT')
        with self.assertRaises(ValueError):
            lab.boundaries(4, False, b'PI')
        with self.assertRaises(ValueError):
            lab.boundaries(0, True, b'1\r\nA\r\n0\r\n\r\n')

    def test_csv_round_trip_preserves_formula_and_quotes(self):
        lab = load('06_csv_formula')
        for value in ('=SUM(1,2)', 'a"b,c', '', '  =1+1', '-5'):
            text, recovered, warning = lab.round_trip(value)
            self.assertEqual(recovered, value)
            self.assertEqual(warning, value in ('=SUM(1,2)', '  =1+1', '-5'))
        self.assertEqual(lab.round_trip('a"b,c')[0], '"a""b,c"\n')

    def test_pbkdf2_matches_independent_hmac_expansion(self):
        lab = load('08_offline_guess')
        word = b'river'
        block = hmac.digest(word, lab.SALT + struct.pack('>I', 1), 'sha256')
        accumulated = bytearray(block)
        for _ in range(999):
            block = hmac.digest(word, block, 'sha256')
            for index, value in enumerate(block):
                accumulated[index] ^= value
        self.assertEqual(lab.derive(word), bytes(accumulated))
        self.assertEqual(len(lab.derive(word)), 32)

    def test_schedule_has_same_stock_but_different_accepts(self):
        lab = load('09_lost_update')
        self.assertEqual(lab.simulate(False), (0, 1))
        self.assertEqual(lab.simulate(True), (0, 2))

    def test_one_label_rejects_empty_deeper_and_sibling(self):
        lab = load('10_dns_wildcard')
        for host in ('x.example.test', 'abc.example.test'):
            self.assertTrue(lab.one_label(host))
        for host in ('.example.test', 'x.y.example.test', 'example.test', 'x.example.test.evil'):
            self.assertFalse(lab.one_label(host))
