import sys

BALANCE = 20
STOCK = 5
PRICE = 3


def purchase(quantity, guarded):
    total = quantity * PRICE
    if guarded and quantity <= 0:
        return "reject", BALANCE, STOCK
    if total > BALANCE or quantity > STOCK:
        return "reject", BALANCE, STOCK
    return "accept", BALANCE - total, STOCK - quantity


def main():
    if len(sys.argv) != 2 or len(sys.argv[1]) > 4:
        print("Usage: script INTEGER (-100 to 100)", file=sys.stderr)
        return 2
    try:
        quantity = int(sys.argv[1])
    except ValueError:
        print("Invalid integer.", file=sys.stderr)
        return 2
    if not -100 <= quantity <= 100:
        print("Out of lab range.", file=sys.stderr)
        return 2
    for guarded in (False, True):
        status, balance, stock = purchase(quantity, guarded)
        label = "Positive quantity" if guarded else "Upper bounds"
        print(f"{label}: {status}, balance={balance}, stock={stock}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
