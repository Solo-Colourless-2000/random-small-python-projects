import sys


def move(count, source, target, spare):
    if count == 0:
        return
    move(count - 1, source, spare, target)
    print(f"Move {count}: {source} -> {target}")
    move(count - 1, spare, target, source)


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 10_hanoi_moves.py disks")
        return 2
    try:
        if len(sys.argv[1]) > 2:
            raise ValueError
        disks = int(sys.argv[1])
        if not 1 <= disks <= 4:
            raise ValueError
    except ValueError:
        print("Error: disks must be an integer from 1 to 4.")
        return 2
    move(disks, "A", "C", "B")
    print(f"Moves: {2 ** disks - 1}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
