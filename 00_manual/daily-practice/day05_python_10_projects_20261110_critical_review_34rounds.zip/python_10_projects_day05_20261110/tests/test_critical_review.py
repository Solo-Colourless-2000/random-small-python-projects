"""Thirty manually curated counterexamples with actual program execution."""
from html import unescape
from html.parser import HTMLParser
import shutil
import json
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]
CASES = json.loads((ROOT / 'verification/round5_thirty_critical_cases.json').read_text(encoding='utf-8'))
SOURCES = sorted((ROOT / 'projects').glob('*.py'))
MANUAL = (ROOT / 'python_10_projects_day05_manual.html').read_text(encoding='utf-8')

class CriticalCases(unittest.TestCase):
    """Each case asserts output, exit code, file contents and no stderr."""

    def verify_case(self, row):
        with tempfile.TemporaryDirectory() as temp:
            base = Path(temp)
            (base / 'practice').mkdir()
            (base / 'samples').mkdir()
            for sample in (ROOT / 'samples').iterdir():
                if sample.is_file():
                    (base / 'samples' / sample.name).write_bytes(sample.read_bytes())
            for name, data in row['prepared'].items():
                (base / name).write_bytes(data.encode('ascii'))
            cmd = [sys.executable, str(SOURCES[row['project'] - 1]), *row['args']]
            result = subprocess.run(cmd, input=row['stdin'], text=True,
                                    capture_output=True, cwd=base, timeout=12)
            self.assertEqual(result.returncode, row['exit'])
            self.assertEqual(result.stdout, row['stdout'])
            self.assertEqual(result.stderr, row['stderr'])
            if row['created']:
                self.assertEqual((base / row['args'][1]).read_text(encoding='utf-8'), row['created'])

    def test_all_answers_explain_observed_outcomes(self):
        self.assertEqual(len(CASES), 30)
        self.assertEqual([c['round'] for c in CASES], list(range(1, 31)))
        for project in range(1, 11):
            self.assertIn(f'id="critical-{project:02d}"', MANUAL)
            self.assertEqual(sum(c['project'] == project for c in CASES), 3)
        self.assertEqual(MANUAL.count('class="critical-answer"'), 30)
        for row in CASES:
            self.assertIn(f'id="critical-case-{row["round"]:02d}"', MANUAL)
            self.assertTrue(row['reason'] in unescape(MANUAL), f"Missing case explanation {row['round']}")
            self.assertTrue(row['stdout'].rstrip() in unescape(MANUAL), f"Missing case output {row['round']}")
        self.assertIn('09\u306890\u306f\u3044\u305a\u308c\u3082\u691c\u67fb\u68411', MANUAL)
        self.assertIn('Host\u306b\u7a7a\u767d\u304c\u3042\u308b\u5024', MANUAL)
        self.assertIn('\u51fa\u529b\u3060\u3051\u3067\u5b89\u5b9a\u6027\u3092\u5b9f\u8a3c\u3059\u308b\u3053\u3068\u306f\u3067\u304d\u307e\u305b\u3093', MANUAL)

class ReviewCommandParser(HTMLParser):
    """Collect executable code blocks inside a review question."""
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.current = None
        self.in_code = False
        self.buffer = ''
        self.commands = {}
        self.feed(MANUAL)

    def handle_starttag(self, tag, attrs):
        props = dict(attrs)
        if tag == 'div' and 'critical-case' in props.get('class', '').split():
            self.current = props['id']
            self.commands[self.current] = []
        if tag == 'code' and self.current:
            self.in_code = True
            self.buffer = ''

    def handle_data(self, data):
        if self.in_code:
            self.buffer += data

    def handle_endtag(self, tag):
        if tag == 'code' and self.in_code:
            self.commands[self.current].append(self.buffer)
            self.in_code = False
        if tag == 'div' and self.current:
            self.current = None


def test_shell_commands_from_manual(self):
    """Run the exact copyable shell commands, not only Python argv."""
    cmd_map = ReviewCommandParser().commands
    self.assertEqual(len(cmd_map), 30)
    for row in CASES:
        with self.subTest(case=row['round']):
            with tempfile.TemporaryDirectory() as temp:
                base = Path(temp)
                (base / 'practice').mkdir()
                shutil.copytree(ROOT / 'samples', base / 'samples')
                shutil.copytree(ROOT / 'projects', base / 'projects')
                blocks = cmd_map[f'critical-case-{row["round"]:02d}']
                if row['prepared']:
                    prep = subprocess.run(['bash', '-c', blocks[0]], cwd=base,
                                          text=True, capture_output=True, timeout=12)
                    self.assertEqual((prep.returncode, prep.stdout, prep.stderr), (0, '', ''))
                    for file_name, expected_data in row['prepared'].items():
                        self.assertEqual((base / file_name).read_bytes(), expected_data.encode('ascii'))
                    command = blocks[1]
                else:
                    command = blocks[0]
                result = subprocess.run(['bash', '-c', command],cwd=base,
                                        text=True,capture_output=True,timeout=12)
                self.assertEqual((result.returncode,result.stdout,result.stderr),
                                 (row['exit'],row['stdout'],row['stderr']))
                if row['created']:
                    self.assertEqual((base / row['args'][1]).read_text('utf-8'), row['created'])

setattr(CriticalCases, 'test_31_all_copyable_shell_commands', test_shell_commands_from_manual)

def test_for_case(row):
    def test_method(self):
        self.verify_case(row)
    return test_method

for row in CASES:
    setattr(CriticalCases, f'test_case_{row["round"]:02d}_project_{row["project"]:02d}', test_for_case(row))

if __name__ == '__main__':
    unittest.main()
