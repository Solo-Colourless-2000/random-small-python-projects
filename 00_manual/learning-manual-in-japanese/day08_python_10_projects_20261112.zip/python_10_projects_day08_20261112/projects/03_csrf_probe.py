import sys

CASES = {"own": (True, "LAB-CSRF"), "cross": (True, ""), "anonymous": (False, "")}
EXPECTED = "LAB-CSRF"


def transfer(authenticated, token, check_token):
    if not authenticated:
        return "reject", 10
    if check_token and token != EXPECTED:
        return "reject", 10
    return "accept", 9


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script own|cross|anonymous", file=sys.stderr)
        return 2
    authenticated, token = CASES[sys.argv[1]]
    for check_token in (False, True):
        status, balance = transfer(authenticated, token, check_token)
        label = "Token checked" if check_token else "Cookie only"
        print(f"{label}: {status}, balance={balance}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
