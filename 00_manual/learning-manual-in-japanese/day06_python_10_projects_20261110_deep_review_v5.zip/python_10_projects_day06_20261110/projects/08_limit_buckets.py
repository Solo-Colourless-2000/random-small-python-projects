import sys

CASES = {
    "same": ("edge-a", "edge-a", "edge-a"),
    "rotate": ("edge-a", "edge-b", "edge-c"),
}
ACCOUNT = ("alice", "alice", "alice")


def decisions(keys):
    counts = {}
    result = []
    for key in keys:
        counts[key] = counts.get(key, 0) + 1
        result.append("allow" if counts[key] <= 2 else "deny")
    return " ".join(result)


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script same|rotate", file=sys.stderr)
        return 2
    labels = CASES[sys.argv[1]]
    print(f"Header key: {decisions(labels)}")
    print(f"Account key: {decisions(ACCOUNT)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
