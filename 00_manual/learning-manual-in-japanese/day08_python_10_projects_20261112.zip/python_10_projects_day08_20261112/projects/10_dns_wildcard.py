import fnmatch
import sys

PATTERN = "*.example.test"
CASES = {"one": "api.example.test", "deep": "a.b.example.test", "apex": "example.test"}


def one_label(host):
    labels = host.split(".")
    expected = PATTERN.split(".")
    return len(labels) == len(expected) and bool(labels[0]) and labels[1:] == expected[1:]


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script one|deep|apex", file=sys.stderr)
        return 2
    host = CASES[sys.argv[1]]
    print(f"Glob match: {fnmatch.fnmatchcase(host, PATTERN)}")
    print(f"One-label match: {one_label(host)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
