import math
import struct
import sys
import wave
from pathlib import Path


def main():
    if len(sys.argv) != 4:
        print("Usage: python3 08_tone_wav.py frequency duration_ms output.wav")
        return 2
    try:
        if len(sys.argv[1]) > 4 or len(sys.argv[2]) > 4:
            raise ValueError
        frequency = int(sys.argv[1])
        duration = int(sys.argv[2])
        if not 100 <= frequency <= 2000 or not 100 <= duration <= 500:
            raise ValueError
    except ValueError:
        print("Error: use frequency 100-2000 and duration 100-500 ms as integers.")
        return 2
    rate = 8000
    frames = rate * duration // 1000
    data = bytearray()
    for index in range(frames):
        time = index / rate
        angle = 2 * math.pi * frequency * time
        value = int(8000 * math.sin(angle))
        data.extend(struct.pack("<h", value))
    try:
        with Path(sys.argv[3]).open("xb") as stream:
            with wave.open(stream, "wb") as output:
                output.setnchannels(1)
                output.setsampwidth(2)
                output.setframerate(rate)
                output.writeframes(data)
    except (OSError, wave.Error):
        print("Error: cannot create WAV; choose a new path.")
        return 1
    print(f"Saved: {sys.argv[3]}")
    print(f"Frames: {frames}")
    print(f"Rate: {rate} Hz")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
