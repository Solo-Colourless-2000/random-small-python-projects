"""Tkinter application controller: input, timing, game states and progression.

Simulation details are in combat.py and enemy_ai.py. This module intentionally
owns only the session lifecycle, wave flow, UI events and lightweight effects.
"""
from __future__ import annotations

import math
import random
import time
from pathlib import Path
import tkinter as tk

from combat import CombatMixin
from constants import (BG, CYAN, FPS, GREEN, HEIGHT, MAX_DT,
                       UPGRADES, WIDTH)
from enemy_ai import EnemyAIMixin
from entities import Particle, Pickup, Player, Ring
from mechanics import clamp, moving_circle_hit, upgrade_choices, wave_roster
from records import load_best_record, save_best_record
from renderer import Renderer
from upgrades import apply_to_player, available_upgrades

SAVE_PATH = Path.home() / '.neon_rift_record.json'


class Game(CombatMixin, EnemyAIMixin):
    def __init__(self, root: tk.Tk, *, seed: int | None = None,
                 auto_loop: bool = True):
        self.root = root
        root.title('NEON RIFT  |  Arena Survival')
        root.configure(bg=BG)
        root.resizable(False, False)
        self.canvas = tk.Canvas(root, width=WIDTH, height=HEIGHT, bg=BG,
                                bd=0, highlightthickness=0, cursor='crosshair')
        self.canvas.pack()
        self.rng = random.Random(seed)
        self.fx_rng = random.Random(None if seed is None else seed ^ 0xC0FFEE)
        self.renderer = Renderer(self.canvas)
        self.keys: set[str] = set()
        self._key_release_jobs: dict[str, str] = {}
        self.mouse_x, self.mouse_y = WIDTH * .5, HEIGHT * .32
        self.mouse_down = False
        self.state = 'menu'
        self.global_time = 0.0
        self.last_clock = time.perf_counter()
        self._frame_debt = 0.0
        self.running = True
        self.best = self.load_best()
        self._saved_best = self.best
        self.record_save_failed = False
        self.reset_session()
        root.bind('<KeyPress>', self.on_key_down)
        root.bind('<KeyRelease>', self.on_key_up)
        self.canvas.bind('<Motion>', self.on_motion)
        self.canvas.bind('<ButtonPress-1>', self.on_click)
        root.bind('<ButtonRelease-1>', self.on_mouse_up)
        self.canvas.bind('<Leave>', self.on_mouse_leave)
        root.bind('<FocusOut>', self.on_focus_out)
        root.protocol('WM_DELETE_WINDOW', self.close)
        self.canvas.focus_set()
        self.renderer.draw(self)
        if auto_loop:
            self.root.after(round(1000 / FPS), self.loop)

    def reset_session(self) -> None:
        self.player = Player(x=WIDTH / 2, y=HEIGHT / 2)
        self.enemies = []
        self.bullets = []
        self.particles: list[Particle] = []
        self.rings: list[Ring] = []
        self.pickups: list[Pickup] = []
        self.wave = 0
        self.wave_time = 0.0
        self.pending: list[str] = []
        self.spawn_timer = 0.0
        self.clear_timer = 0.0
        self.total_kills = 0
        self.score = 0
        self.combo = 0
        self.combo_timer = 0.0
        self.elapsed = 0.0
        self.shake = 0.0
        self.banner = ''
        self.banner_timer = 0.0
        self.upgrades_offered: list[str] = []
        self.last_upgrades: set[str] = set()
        self.next_enemy_id = 0
        self.notification = ''
        self.notification_time = 0.0
        self._dash_active_this_tick = False
        self.mouse_down = False
        self._clear_held_keys()

    def _clear_held_keys(self) -> None:
        for job in self._key_release_jobs.values():
            self.root.after_cancel(job)
        self._key_release_jobs.clear()
        self.keys.clear()

    @staticmethod
    def load_best() -> int:
        return load_best_record(SAVE_PATH)

    def save_best(self) -> None:
        # The displayed best may be ahead of the last *persisted* best when
        # the file system fails. Retry later instead of silently giving up.
        self.best = max(self.best, self.score)
        if self.best <= self._saved_best:
            return
        if save_best_record(SAVE_PATH, self.best):
            self._saved_best = self.best
            self.record_save_failed = False
        else:
            self.record_save_failed = True

    def close(self) -> None:
        self.running = False
        self.save_best()
        self.root.destroy()

    def on_focus_out(self, _event: tk.Event) -> None:
        # Switching focus from the root window to its Canvas is NOT leaving
        # the game. Examine the final focused widget after Tk processes it.
        self.root.after_idle(self._pause_if_outside_window)

    def _pause_if_outside_window(self) -> None:
        if not self.running:
            return
        try:
            focused = self.root.focus_get()
            if focused is not None and focused.winfo_toplevel() is self.root:
                return
        except tk.TclError:
            return  # The window or focused child was destroyed meanwhile.
        self._clear_held_keys()
        self.mouse_down = False
        if self.state == 'playing':
            self.state = 'paused'

    def on_motion(self, event: tk.Event) -> None:
        self.mouse_x, self.mouse_y = event.x, event.y

    def on_mouse_up(self, _event: tk.Event) -> None:
        self.mouse_down = False

    def on_mouse_leave(self, _event: tk.Event) -> None:
        # OS window managers do not always deliver a button release that
        # happens outside the Canvas. Never leave the weapon stuck firing.
        self.mouse_down = False

    def on_click(self, event: tk.Event) -> None:
        self.canvas.focus_set()
        self.mouse_x, self.mouse_y = event.x, event.y
        if self.state in ('menu', 'gameover'):
            self.start()
        elif self.state == 'upgrade':
            for n in range(len(self.upgrades_offered)):
                x = 98 + n * 314
                if x <= event.x <= x + 294 and 292 <= event.y <= 500:
                    self.apply_upgrade(n)
                    break
        elif self.state == 'playing':
            self.mouse_down = True

    def on_key_down(self, event: tk.Event) -> None:
        key = event.keysym.lower()
        # X11 synthesizes KeyRelease/KeyPress pairs for held-key repeats.
        # Keep the key held across such a pair so P/E/Space trigger once.
        if key in self._key_release_jobs:
            self.root.after_cancel(self._key_release_jobs.pop(key))
            return
        if key in self.keys:
            return
        self.keys.add(key)
        if self.state in ('menu', 'gameover'):
            if key in ('return', 'kp_enter'):
                self.start()
        elif self.state == 'playing':
            if key in ('escape', 'p'):
                self.state = 'paused'
                self.mouse_down = False
            elif key in ('space', 'shift_l', 'shift_r'):
                self.dash()
            elif key == 'e':
                self.pulse()
        elif self.state == 'paused':
            if key in ('escape', 'p', 'return'):
                self.state = 'playing'
                self.last_clock = time.perf_counter()
                self._frame_debt = 0.0
        elif self.state == 'upgrade':
            number = key[3:] if key.startswith('kp_') else key
            if number in ('1', '2', '3'):
                self.apply_upgrade(int(number) - 1)

    def on_key_up(self, event: tk.Event) -> None:
        key = event.keysym.lower()
        if key in self._key_release_jobs:
            self.root.after_cancel(self._key_release_jobs.pop(key))
        def release() -> None:
            self.keys.discard(key)
            self._key_release_jobs.pop(key, None)
        self._key_release_jobs[key] = self.root.after(35, release)

    def start(self) -> None:
        self.reset_session()
        self.state = 'playing'
        self.start_wave()

    def start_wave(self) -> None:
        self.wave += 1
        self.wave_time = 0.0
        self.clear_timer = 0.0
        self.pending = wave_roster(self.wave, self.rng)
        self.spawn_timer = 0.5
        self.banner = f'WAVE {self.wave:02d}' + ('  //  BOSS INCOMING' if self.wave % 5 == 0 else '')
        self.banner_timer = 2.15
        self.rings.append(Ring(WIDTH / 2, HEIGHT / 2, 12, 240, .55, .55, CYAN))
        self.mouse_down = False

    def loop(self) -> None:
        if not self.running:
            return
        now = time.perf_counter()
        elapsed = max(0.0, now - self.last_clock)
        self.last_clock = now
        # Simulate fixed 60-Hz steps even when drawing is slower than 60 FPS.
        # Bounding debt avoids a death spiral after suspending the process.
        step = 1 / FPS
        self._frame_debt = min(0.12, self._frame_debt + elapsed)
        steps = 0
        while self._frame_debt + 1e-10 >= step and steps < 7:
            self.tick(step)
            self._frame_debt -= step
            steps += 1
        self.renderer.draw(self)
        render_ms = (time.perf_counter() - now) * 1000
        self.root.after(max(1, round(1000 / FPS - render_ms)), self.loop)

    def tick(self, dt: float) -> None:
        dt = clamp(dt, 0.0, MAX_DT)
        if dt <= 0:
            return
        self.global_time += dt
        if self.state == 'playing':
            self.elapsed += dt
            self.update_player(dt)
            self.update_waves(dt)
            if self.state == 'playing':
                self.update_enemies(dt)
                self.resolve_dash_hits()
                self.update_bullets(dt)
            if self.state == 'playing':
                self.update_pickups(dt)
                self.resolve_enemy_contact()
            self.combo_timer = max(0.0, self.combo_timer - dt)
            if self.combo_timer == 0:
                self.combo = 0
            self.banner_timer = max(0.0, self.banner_timer - dt)
            self.notification_time = max(0.0, self.notification_time - dt)
        if self.state in ('playing', 'menu', 'gameover'):
            self.update_effects(dt)
        self.shake = max(0.0, self.shake - 28 * dt)

    def update_waves(self, dt: float) -> None:
        self.wave_time += dt
        if self.pending:
            self.spawn_timer -= dt
            if self.spawn_timer <= 0:
                self.spawn_enemy(self.pending.pop(0))
                self.spawn_timer = max(.19, .59 - self.wave * .027)
        elif not self.enemies and self.wave_time > 1.0:
            self.clear_timer += dt
            if self.clear_timer >= 1.0:
                self.finish_wave()
        else:
            self.clear_timer = 0.0

    def update_pickups(self, dt: float) -> None:
        retained = []
        p = self.player
        for item in self.pickups:
            item.age += dt
            item.ttl -= dt
            # Both ordinary movement and a full dash must be able to collect
            # an item without requiring a frame to land on its center.
            touched = moving_circle_hit(p.prev_x, p.prev_y, p.x, p.y,
                                        item.x, item.y, item.x, item.y,
                                        p.radius + 23) is not None
            usable = ((item.kind == 'repair' and p.hp < p.max_hp) or
                      (item.kind == 'charge' and p.energy < 100))
            if touched and usable:
                if item.kind == 'repair':
                    gained = min(26, p.max_hp - p.hp)
                    p.hp += gained
                    self.notify(f'HULL REPAIRED  +{gained:.0f}')
                else:
                    gained = min(38, 100 - p.energy)
                    p.energy += gained
                    self.notify(f'ENERGY RESTORED  +{gained:.0f}')
                self.rings.append(Ring(item.x, item.y, 7, 65, .35, .35, GREEN))
            elif item.ttl > 0:
                retained.append(item)
        self.pickups = retained

    def emit(self, x: float, y: float, color: str, count: int, *,
             speed: float = 100, ttl: float = .42, size: float = 3.0) -> None:
        for _ in range(count):
            a = self.fx_rng.random() * math.tau
            s = speed * self.fx_rng.uniform(.35, 1)
            life = ttl * self.fx_rng.uniform(.5, 1.2)
            self.particles.append(Particle(x, y, math.cos(a) * s,
                                           math.sin(a) * s, life, life,
                                           color, size * self.fx_rng.uniform(.65, 1.4)))
        if len(self.particles) > 300:
            del self.particles[:len(self.particles) - 300]

    def update_effects(self, dt: float) -> None:
        for p in self.particles:
            p.x += p.vx * dt
            p.y += p.vy * dt
            p.vx *= max(0, 1 - 2.5 * dt)
            p.vy *= max(0, 1 - 2.5 * dt)
            p.ttl -= dt
        self.particles = [p for p in self.particles if p.ttl > 0]
        for r in self.rings:
            r.life -= dt
            fraction = 1 - clamp(r.life / r.max_life, 0, 1)
            r.radius += (r.max_radius - r.radius) * min(1, dt * 8 + fraction * .06)
        self.rings = [r for r in self.rings if r.life > 0]

    def finish_wave(self) -> None:
        if self.state != 'playing' or self.pending or self.enemies:
            return
        self.state = 'upgrade'
        self.bullets.clear()
        self.pickups.clear()
        self.player.hp = min(self.player.max_hp, self.player.hp + 10)
        self.player.energy = min(100, self.player.energy + 20)
        self.save_best()  # Keep record of a completed wave even if the app closes unexpectedly.
        self.upgrades_offered = upgrade_choices(
            self.rng, self.last_upgrades, available_upgrades(self.player))
        self.last_upgrades = set(self.upgrades_offered)
        self.mouse_down = False

    def apply_upgrade(self, index: int) -> None:
        if self.state != 'upgrade' or not (0 <= index < len(self.upgrades_offered)):
            return
        name = self.upgrades_offered[index]
        apply_to_player(self.player, name)
        self.state = 'playing'
        self.notify(f'UPGRADE INSTALLED: {UPGRADES[name][0]}')
        self.start_wave()

    def notify(self, text: str) -> None:
        self.notification = text
        self.notification_time = 1.6

    def game_over(self) -> None:
        if self.state != 'playing':
            return
        self.state = 'gameover'
        self.mouse_down = False
        self.save_best()
        self.banner_timer = 0
