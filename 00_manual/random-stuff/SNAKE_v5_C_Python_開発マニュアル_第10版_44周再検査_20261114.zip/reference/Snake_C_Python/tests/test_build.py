"""Inspect the build's failure safety and reproducibility in an isolated tree."""
from __future__ import annotations

import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

import build as module


class BuildTests(unittest.TestCase):
    def setUp(self) -> None:
        self.folder = tempfile.TemporaryDirectory()
        self.addCleanup(self.folder.cleanup)
        root = Path(self.folder.name)
        native = root / "native"
        native.mkdir()
        self.source = native / "snake.c"
        self.header = native / "snake.h"
        self.food_source = native / "food.c"
        self.private_header = native / "snake_internal.h"
        shutil.copyfile(module.SOURCE, self.source)
        shutil.copyfile(module.HEADER, self.header)
        shutil.copyfile(module.FOOD_SOURCE, self.food_source)
        shutil.copyfile(module.PRIVATE_HEADER, self.private_header)
        script = root / "build.py"
        shutil.copyfile(module.BUILD_SCRIPT, script)
        patcher = patch.multiple(module, ROOT=root, SOURCE=self.source, HEADER=self.header, FOOD_SOURCE=self.food_source,
                                 PRIVATE_HEADER=self.private_header, BUILD_SCRIPT=script,
                                 BUILD=root / "build")
        patcher.start()
        self.addCleanup(patcher.stop)

    def test_public_api_only_is_exported_on_linux(self) -> None:
        if not sys.platform.startswith("linux") or not shutil.which("nm"):
            self.skipTest("ELF symbol inspection needs Linux and nm")
        path = module.ensure_library()
        symbols = subprocess.run(["nm", "-D", "--defined-only", str(path)],
                                 text=True, capture_output=True, check=True).stdout
        for name in ("snake_create", "snake_destroy", "snake_reset",
                     "snake_set_direction", "snake_tick", "snake_snapshot"):
            self.assertIn(name, symbols)
        self.assertNotIn("snake_place_food", symbols)

    def test_compiler_output_can_be_loaded(self) -> None:
        path = module.ensure_library()
        self.assertTrue(path.is_file())
        self.assertGreater(path.stat().st_size, 1000)
        from snake_app.engine import SnakeEngine, load_library
        with SnakeEngine(8, 8, library=load_library(path), seed=77) as engine:
            self.assertEqual(len(engine.snapshot().body), 4)

    def test_up_to_date_build_does_not_recompile(self) -> None:
        path = module.ensure_library()
        original = path.stat().st_mtime_ns
        self.assertEqual(module.ensure_library(), path)
        self.assertEqual(path.stat().st_mtime_ns, original)

    def test_failed_compilation_preserves_last_good_library(self) -> None:
        path = module.ensure_library()
        good = path.read_bytes()
        self.source.write_text("this is not valid C code\n", encoding="utf-8")
        with self.assertRaises(RuntimeError):
            module.ensure_library(force=True)
        self.assertEqual(path.read_bytes(), good)
        self.assertEqual(sorted(p.name for p in path.parent.iterdir()), [path.name])

    def test_build_script_changes_trigger_rebuild(self) -> None:
        path = module.ensure_library()
        old_time = path.stat().st_mtime_ns
        new_time = max(old_time, module.BUILD_SCRIPT.stat().st_mtime_ns) + 4_000_000_000
        os.utime(module.BUILD_SCRIPT, ns=(new_time, new_time))
        self.assertEqual(module.ensure_library(), path)
        self.assertGreater(path.stat().st_mtime_ns, old_time)

    def test_secondary_source_changes_trigger_rebuild(self) -> None:
        path = module.ensure_library()
        original = path.stat().st_mtime_ns
        changed = max(original, self.food_source.stat().st_mtime_ns) + 4_000_000_000
        os.utime(self.food_source, ns=(changed, changed))
        self.assertEqual(module.ensure_library(), path)
        self.assertGreater(path.stat().st_mtime_ns, original)

    def test_private_header_changes_trigger_rebuild(self) -> None:
        path = module.ensure_library()
        original = path.stat().st_mtime_ns
        changed = max(original, self.private_header.stat().st_mtime_ns) + 4_000_000_000
        os.utime(self.private_header, ns=(changed, changed))
        self.assertEqual(module.ensure_library(), path)
        self.assertGreater(path.stat().st_mtime_ns, original)

    def test_secondary_source_compile_failure_keeps_old_binary(self) -> None:
        path = module.ensure_library()
        old_binary = path.read_bytes()
        self.food_source.write_text("this is not C\n", encoding="utf-8")
        with self.assertRaises(RuntimeError):
            module.ensure_library(force=True)
        self.assertEqual(path.read_bytes(), old_binary)

    def test_bad_optional_cc_uses_installed_compiler(self) -> None:
        with patch.dict(os.environ, {"CC": "'unbalanced"}):
            self.assertTrue(module.compiler_candidates())
            self.assertTrue(module.ensure_library())


if __name__ == "__main__":
    unittest.main()
