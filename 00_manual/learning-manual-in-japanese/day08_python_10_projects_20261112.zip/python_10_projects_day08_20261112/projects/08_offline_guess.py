import hashlib
import hmac
import sys

SALT = b"LAB-SALT"
WORDS = ("cloud", "river", "maple")
CASES = {"hit": b"river", "miss": b"oak"}


def derive(word):
    return hashlib.pbkdf2_hmac("sha256", word, SALT, 1000)


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script hit|miss", file=sys.stderr)
        return 2
    target = derive(CASES[sys.argv[1]])
    found = "(none)"
    attempts = 0
    for word in WORDS:
        attempts += 1
        candidate = derive(word.encode("ascii"))
        if hmac.compare_digest(candidate, target):
            found = word
            break
    print(f"Candidate: {found}")
    print(f"Attempts: {attempts}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
