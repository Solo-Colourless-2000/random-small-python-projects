import sys

CASES = {"clean": "blue", "poison": "red"}
PATH = "/front"


def fetch(cache, variant, keyed):
    key = (PATH, variant) if keyed else PATH
    if key not in cache:
        cache[key] = "variant=" + variant
    return cache[key]


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script clean|poison", file=sys.stderr)
        return 2
    seed = CASES[sys.argv[1]]
    for keyed in (False, True):
        cache = {}
        fetch(cache, seed, keyed)
        victim = fetch(cache, "blue", keyed)
        label = "Variant key" if keyed else "Path key"
        print(f"{label}: {victim}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
