#ifndef STEELFRONT_ENGINE_INTERNAL_H
#define STEELFRONT_ENGINE_INTERNAL_H
/* Shared internals for the single-world C simulation. Not part of the ctypes API. */
#include "tank_engine.h"
#include <math.h>
#include <stdint.h>
#include <string.h>
#include <limits.h>
#ifndef M_PI
#define M_PI 3.14159265358979323846
#endif
extern Snapshot s;
extern uint32_t rng_state;
extern float contact_cooldown, dash_timer;
extern float enemy_ai_time[MAX_ENEMIES], enemy_strafe[MAX_ENEMIES];
static inline float minf(float a,float b) { return a < b ? a : b; }
static inline float maxf(float a,float b) { return a > b ? a : b; }
static inline float clampf(float v,float a,float b) { return minf(maxf(v,a),b); }
static inline float length2(float x,float y) { return x*x+y*y; }
static inline float norm(float *x,float *y) {
    float l=sqrtf((*x)*(*x)+(*y)*(*y));
    if(l>0.0001f){*x/=l;*y/=l;} else {*x=0;*y=0;}
    return l;
}
static inline float angular_delta(float from,float to) {
    float d=remainderf(to-from, (float)(2*M_PI));
    return d;
}
static inline float angle_approach(float from,float to,float speed,float dt) {
    return from+clampf(angular_delta(from,to),-speed*dt,speed*dt);
}
float rand01(void);
float rand_range(float lo,float hi);
void event_at(int kind,float x,float y,float value);
void add_wall(float x,float y,float w,float h,int kind);
void move_tank(Tank *t,float dx,float dy);
int ray_box(float x,float y,float dx,float dy,const Obstacle *o,float radius,float *hit_t,float *nx,float *ny);
int ray_circle(float x,float y,float dx,float dy,float cx,float cy,float r,float *hit_t);
int has_los(float x,float y,float tx,float ty);
Bullet *add_bullet(float x,float y,float angle,float speed,float damage,int owner,int bounces);
void add_pickup(float x,float y,int kind);
void kill_enemy(Tank *t);
void damage_player(float damage,float bx,float by);
void update_bullets(float dt);
void make_enemy(int type,float x,float y);
int spawn_valid(float x,float y,float radius);
void update_enemy(int idx,float dt);
#endif
