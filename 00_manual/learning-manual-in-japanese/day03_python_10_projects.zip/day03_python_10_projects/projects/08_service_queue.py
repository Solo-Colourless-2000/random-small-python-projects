import string
from collections import deque


def main():
    queue = deque()
    print("Commands: add NAME, next, show, quit")
    for turn in range(50):
        try:
            command = input("Queue> ")
        except (EOFError, KeyboardInterrupt):
            print("\nStopped.")
            return 1
        if not 1 <= len(command) <= 40:
            print("Error: use 1-40 characters.")
            return 2
        parts = command.split()
        if len(parts) == 2 and parts[0] == "add":
            name = parts[1]
            if len(name) > 12 or any(ch not in string.ascii_letters for ch in name):
                print("Error: name needs 1-12 ASCII letters.")
                return 2
            if len(queue) == 5:
                print("Error: queue is full.")
                return 2
            queue.append(name)
            print(f"Added: {name}")
        elif parts == ["next"]:
            if queue:
                print(f"Serving: {queue.popleft()}")
            else:
                print("Empty")
        elif parts == ["show"]:
            print("Waiting: " + ", ".join(queue))
        elif parts == ["quit"]:
            print("Bye")
            return 0
        else:
            print("Error: unknown command.")
            return 2
    print("Error: command limit reached.")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
