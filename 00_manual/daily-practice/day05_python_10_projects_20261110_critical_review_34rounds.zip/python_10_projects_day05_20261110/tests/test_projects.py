from collections import Counter, deque
import contextlib
from html.parser import HTMLParser
import importlib.util
import io
import itertools
import math
import os
from pathlib import Path
import re
import select
import signal
import subprocess
import sys
import tempfile
import time
import unittest
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
FILES = sorted((ROOT / "projects").glob("*.py"))
RUNS = []
DIRECT_CASES = 0
REACHABLE_BOARDS = 0


def run(number, args=(), data="", cwd=None):
    result = subprocess.run([sys.executable, str(FILES[number - 1]), *args], input=data, text=True, capture_output=True, cwd=cwd or ROOT, timeout=5)
    RUNS.append({"project": number, "args": list(args), "input": data, "status": result.returncode, "stdout": result.stdout, "stderr": result.stderr})
    return result


def load(number):
    spec = importlib.util.spec_from_file_location("lesson", FILES[number - 1])
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class TextCard(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.tags = []
        self.in_p = False
        self.text = ""
        self.feed(text)

    def handle_starttag(self, tag, attrs):
        self.tags.append(tag)
        if tag == "p":
            self.in_p = True

    def handle_endtag(self, tag):
        if tag == "p":
            self.in_p = False

    def handle_data(self, data):
        if self.in_p:
            self.text += data


class Programs(unittest.TestCase):
    def check(self, number, args, status, output, data="", cwd=None):
        result = run(number, args, data, cwd)
        self.assertEqual((result.returncode, result.stdout, result.stderr), (status, output, ""))
        return result

    def errors(self, number, cases, data=""):
        for args in cases:
            with self.subTest(args=args):
                result = run(number, args, data)
                self.assertEqual(result.returncode, 2)
                self.assertIn("Error:", result.stdout)
                self.assertEqual(result.stderr, "")

    def test_01_check_digit_known(self):
        self.check(1, ["123"], 0, "Check digit: 0\nNumber: 1230\n")
        self.check(1, ["9"], 0, "Check digit: 1\nNumber: 91\n")
        self.check(1, ["000"], 0, "Check digit: 0\nNumber: 0000\n")
        self.check(1, ["7992739871"], 0, "Check digit: 3\nNumber: 79927398713\n")

    def test_01_check_digit_independent_final_validation(self):
        for payload in ["0", "1", "8", "99", "00123", "123456789012", "9" * 12]:
            with self.subTest(payload=payload):
                result = run(1, [payload])
                final = result.stdout.splitlines()[1].removeprefix("Number: ")
                self.assertEqual(final[:-1], payload)
                self.assertEqual(len(final), len(payload) + 1)
                # Validation doubles odd positions of the complete number,
                # then sums decimal digits, rather than subtracting nine.
                total = 0
                for index, character in enumerate(reversed(final)):
                    value = int(character)
                    if index % 2:
                        value *= 2
                    total += sum(divmod(value, 10))
                self.assertEqual(total % 10, 0)
                self.assertEqual(result.returncode, 0)
                self.assertEqual(result.stderr, "")

    def test_02_html_literal_text_and_structure(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "card.html"
            for text in ['A < B & "C"', "<script>alert(1)</script>", "<b>Hi</b>", "' & >", "a" * 80]:
                with self.subTest(text=text):
                    result = run(2, [text, str(output)])
                    self.assertEqual(result.returncode, 0)
                    self.assertEqual(result.stderr, "")
                    parsed = TextCard(output.read_text(encoding="utf-8"))
                    self.assertEqual(parsed.text, text)
                    self.assertEqual(parsed.tags, ["html", "meta", "title", "body", "p"])
                    self.assertTrue(output.read_bytes().endswith(b"\n"))
                    output.unlink()

    def test_02_html_exclusive_and_io(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            output = base / "card.html"
            output.write_bytes(b"KEEP")
            for target in [output, base, base / "missing/card.html"]:
                with self.subTest(target=target):
                    self.check(2, ["Hello", str(target)], 1, "Error: cannot create HTML; choose a new path.\n")
            self.assertEqual(output.read_bytes(), b"KEEP")

    def test_02_html_invalid_no_file(self):
        with tempfile.TemporaryDirectory() as directory:
            output = Path(directory) / "card.html"
            for text in ["", "a" * 81, "a\nb", "a\tb", "a" + chr(127)]:
                with self.subTest(text=text):
                    self.errors(2, [[text, str(output)]])
                    self.assertFalse(output.exists())

    def test_03_moving_average_known(self):
        self.check(3, ["3", "2,4,6,8,10"], 0, "Window 0-2: 4.00\nWindow 1-3: 6.00\nWindow 2-4: 8.00\n")

    def test_03_moving_average_model_and_edges(self):
        for values in [[0], [100], [1, 2, 3], [0, 100] * 5, [1, 1, 2, 3, 5, 8, 13, 21]]:
            for width in range(1, min(5, len(values)) + 1):
                with self.subTest(values=values, width=width):
                    result = run(3, [str(width), ",".join(map(str, values))])
                    # Prefix sums are independent of the program's slicing sum.
                    prefix = [0]
                    for value in values:
                        prefix.append(prefix[-1] + value)
                    expected = []
                    for start in range(len(values) - width + 1):
                        value = (prefix[start + width] - prefix[start]) / width
                        expected.append(f"Window {start}-{start + width - 1}: {value:.2f}")
                    self.assertEqual(result.stdout, "\n".join(expected) + "\n")
                    self.assertEqual(result.returncode, 0)
                    self.assertEqual(result.stderr, "")

    def test_04_tic_tac_toe_known(self):
        self.check(4, ["XXXOO...."], 0, "X wins\n")
        self.check(4, ["XX.OOOX.."], 0, "O wins\n")
        self.check(4, ["XOXOOXXXO"], 0, "Draw\n")
        self.check(4, ["........."], 0, "Ongoing\n")

    def test_04_tic_tac_toe_all_boards_against_legal_play(self):
        global DIRECT_CASES, REACHABLE_BOARDS
        def outcome(board):
            rows = [board[0:3], board[3:6], board[6:9]]
            columns = [board[i::3] for i in range(3)]
            diagonals = [board[0] + board[4] + board[8], board[2] + board[4] + board[6]]
            for line in rows + columns + diagonals:
                if line == "XXX":
                    return "X wins"
                if line == "OOO":
                    return "O wins"
            return "Ongoing" if "." in board else "Draw"
        # Generate only games that alternate turns and stop at a winner.
        reachable = {".........": "Ongoing"}
        pending = deque([(".........", "X")])
        while pending:
            board, hand = pending.popleft()
            if reachable[board] != "Ongoing":
                continue
            for position, cell in enumerate(board):
                if cell != ".":
                    continue
                following = board[:position] + hand + board[position + 1:]
                if following not in reachable:
                    reachable[following] = outcome(following)
                    pending.append((following, "O" if hand == "X" else "X"))
        self.assertEqual(len(reachable), 5478)
        module = load(4)
        for cells in itertools.product("XO.", repeat=9):
            board = "".join(cells)
            stream = io.StringIO()
            with patch.object(sys, "argv", [str(FILES[3]), board]), contextlib.redirect_stdout(stream):
                status = module.main()
            DIRECT_CASES += 1
            if board in reachable:
                self.assertEqual((status, stream.getvalue()), (0, reachable[board] + "\n"), board)
            else:
                self.assertEqual(status, 2, board)
                self.assertTrue(stream.getvalue().startswith("Error:"), board)
        REACHABLE_BOARDS = len(reachable)

    def test_05_insertion_sort_known(self):
        self.check(5, ["4,1,3"], 0, "After 1: [1, 4, 3]\nAfter 2: [1, 3, 4]\nSorted: 1 3 4\n")
        self.check(5, ["1"], 0, "Sorted: 1\n")

    def test_05_insertion_sort_permutations_and_limits(self):
        sequences = list(itertools.permutations([-2, 0, 1, 1]))
        sequences += [tuple(range(7, -1, -1)), (-20, 20), (0,) * 8]
        for values in sequences:
            with self.subTest(values=values):
                result = run(5, [",".join(map(str, values))])
                actual = list(map(int, result.stdout.splitlines()[-1].removeprefix("Sorted: ").split()))
                self.assertEqual(actual, sorted(values))
                self.assertEqual(Counter(actual), Counter(values))
                self.assertEqual(len(result.stdout.splitlines()) - 1, len(values) - 1)
                self.assertEqual(result.returncode, 0)
                self.assertEqual(result.stderr, "")

    def test_06_undo_known(self):
        self.check(6, [], 0, "Enter a note, /undo or /quit.\nNote> Note: Alpha\nNote> Note: Beta\nNote> Note: Alpha\nNote> Bye\n", "Alpha\nBeta\n/undo\n/quit\n")

    def test_06_undo_history_and_turn_limits(self):
        intro = "Enter a note, /undo or /quit.\n"
        self.check(6, [], 0, intro + "Note> Nothing to undo.\nNote: (empty)\nNote> Bye\n", "/undo\n/quit\n")
        result = run(6, [], "a\nb\nc\nd\ne\n" + "/undo\n" * 5 + "/quit\n")
        self.assertEqual(result.returncode, 0)
        self.assertTrue(result.stdout.endswith("Note> Note: (empty)\nNote> Bye\n"))
        result = run(6, [], "a\nb\nc\nd\ne\nf\n")
        self.assertEqual(result.returncode, 2)
        self.assertTrue(result.stdout.endswith("Note> Error: history is full.\n"))
        result = run(6, [], "/undo\n" * 19 + "/quit\n")
        self.assertEqual(result.returncode, 0)
        result = run(6, [], "/undo\n" * 20)
        self.assertEqual(result.returncode, 2)
        self.assertTrue(result.stdout.endswith("Error: command limit reached.\n"))
        self.check(6, [], 0, intro + "Note> Note: " + "a" * 30 + "\nNote> Bye\n", "a" * 30 + "\n/quit\n")

    def test_06_undo_invalid_and_eof(self):
        for data in ["\n", " \n", "a" * 31 + "\n", "a\tb\n"]:
            with self.subTest(data=data):
                self.errors(6, [[]], data)
        self.check(6, [], 1, "Enter a note, /undo or /quit.\nNote> \nStopped.\n", "")

    @unittest.skipUnless(os.name == "posix", "POSIX signal test")
    def test_06_undo_interrupt(self):
        process = subprocess.Popen([sys.executable, "-u", str(FILES[5])], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        output = b""
        deadline = time.monotonic() + 5
        try:
            while not output.endswith(b"Note> "):
                self.assertLess(time.monotonic(), deadline)
                ready, _, _ = select.select([process.stdout], [], [], .1)
                if ready:
                    chunk = os.read(process.stdout.fileno(), 4096)
                    self.assertTrue(chunk)
                    output += chunk
            process.send_signal(signal.SIGINT)
            rest, error = process.communicate(timeout=5)
            output += rest
            self.assertEqual(process.returncode, 1)
            self.assertTrue(output.endswith(b"Note> \nStopped.\n"))
            self.assertEqual(error, b"")
            RUNS.append({"project": 6, "args": [], "signal": "SIGINT", "status": 1, "stdout": output.decode(), "stderr": ""})
        finally:
            if process.poll() is None:
                process.kill()
                process.communicate()

    def test_07_http_known(self):
        self.check(7, ["samples/request.txt"], 0, "Method: GET\nTarget: /notes?page=2\nHost: example.test\nHeaders: 2\n")

    def test_07_http_variations_and_boundaries(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "request.txt"
            for newline, method, extras in [("\n", "GET", []), ("\r\n", "HEAD", ["X-1: a:b"]), ("\n", "GET", [f"X-{i}: z" for i in range(5)])]:
                with self.subTest(newline=newline, method=method, extras=extras):
                    text = newline.join([method + " / HTTP/1.1", "hOsT: example.test", *extras, "", ""])
                    path.write_bytes(text.encode("ascii"))
                    self.check(7, [str(path)], 0, f"Method: {method}\nTarget: /\nHost: example.test\nHeaders: {1 + len(extras)}\n")
                    self.assertEqual(path.read_bytes(), text.encode("ascii"))
            # A valid 1024-character example uses permitted header OWS spaces.
            prefix, suffix = "GET / HTTP/1.1\nHost:", "x\n\n"
            text = prefix + " " * (1024 - len(prefix) - len(suffix)) + suffix
            self.assertEqual(len(text), 1024)
            path.write_text(text, encoding="ascii")
            self.check(7, [str(path)], 0, "Method: GET\nTarget: /\nHost: x\nHeaders: 1\n")
            path.write_text(text.replace("Host:", "Host: ", 1), encoding="ascii")
            self.errors(7, [[str(path)]])

    def test_07_http_invalid_content(self):
        examples = ["", "GET / HTTP/1.1\nHost: a\n", "GET / HTTP/1.1\n\n", "POST / HTTP/1.1\nHost: a\n\n", "GET / HTTP/1.0\nHost: a\n\n", "GET  / HTTP/1.1\nHost: a\n\n", "GET example.test HTTP/1.1\nHost: a\n\n", "GET / HTTP/1.1\nHost: a\nhost: b\n\n", "GET / HTTP/1.1\nHost:\n\n", "GET / HTTP/1.1\nX: a\n\n", "GET / HTTP/1.1\nHost a\n\n", "GET / HTTP/1.1\nHost: a\n\nbody", "GET / HTTP/1.1\nHost: a\n" + "X: z\n" * 6 + "\n", "GET / HTTP/1.1\nHost: a\nBad_Name: b\n\n", "GET / HTTP/1.1\vHost: a\v\v", "x" * 1025]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "request.txt"
            for text in examples:
                with self.subTest(text=text):
                    path.write_text(text, encoding="ascii")
                    self.errors(7, [[str(path)]])

    def test_07_http_ambiguous_line_endings_and_header_whitespace(self):
        # Preserve the original line endings in the file, not just Python text.
        base = b"GET / HTTP/1.1\nHost: a\n\n"
        invalid = [
            b"GET / HTTP/1.1\rHost: a\r\r",
            b"GET / HTTP/1.1\nHost: a\r\n",
            b"GET / HTTP/1.1\n Host: a\n\n",
            b"GET / HTTP/1.1\nHost : a\n\n",
            b"GET / HTTP/1.1\nHost  : a\n\n",
            b"GET / HTTP/1.1\n\tHost: a\n\n",
        ]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "request.txt"
            for body in invalid:
                with self.subTest(body=body):
                    path.write_bytes(body)
                    self.check(7, [str(path)], 2, "Error: use a small GET/HEAD HTTP/1.1 request with unique headers and Host.\n")
            path.write_bytes(base)
            self.check(7, [str(path)], 0, "Method: GET\nTarget: /\nHost: a\nHeaders: 1\n")
            valid = b"GET / HTTP/1.1\r\nHost: a\r\n\r\n"
            path.write_bytes(valid)
            self.check(7, [str(path)], 0, "Method: GET\nTarget: /\nHost: a\nHeaders: 1\n")
            # Physical CRLF length is counted before normalisation.
            prefix = b"GET / HTTP/1.1\r\nHost:"
            suffix = b"x\r\n\r\n"
            valid = prefix + b" " * (1024 - len(prefix) - len(suffix)) + suffix
            self.assertEqual(len(valid), 1024)
            path.write_bytes(valid)
            self.check(7, [str(path)], 0, "Method: GET\nTarget: /\nHost: x\nHeaders: 1\n")
            path.write_bytes(valid + b" ")
            self.check(7, [str(path)], 2, "Error: use a small GET/HEAD HTTP/1.1 request with unique headers and Host.\n")

    def test_07_http_io_errors(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "request.txt"
            self.check(7, [str(path)], 1, "Error: cannot read the UTF-8 request.\n")
            self.check(7, [directory], 1, "Error: cannot read the UTF-8 request.\n")
            path.write_bytes(bytes([255]))
            self.check(7, [str(path)], 1, "Error: cannot read the UTF-8 request.\n")

    def test_08_ini_known(self):
        self.check(8, ["samples/filter.ini", "5,12,30,40"], 0, "Range: 10..30\nKept: 12 30\n")
        self.check(8, ["samples/filter.ini", "5,5,50"], 0, "Range: 10..30\nKept: (none)\n")

    def test_08_ini_valid_boundaries(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "filter.ini"
            for text, values, output in [("[filter]\nminimum=-100\nmaximum=100\n", "-100,0,100", "Range: -100..100\nKept: -100 0 100\n"), ("[filter]\nminimum=20\nmaximum=20\n", "20,20,19", "Range: 20..20\nKept: 20 20\n"), ("[DEFAULT]\n[filter]\nMINIMUM=0\nMAXIMUM=1\n", "0,1", "Range: 0..1\nKept: 0 1\n")]:
                with self.subTest(text=text):
                    path.write_text(text, encoding="ascii")
                    self.check(8, [str(path), values], 0, output)
            text = "[filter]\nminimum=0\nmaximum=1\n"
            text += "#" + "a" * (512 - len(text) - 1)
            self.assertEqual(len(text), 512)
            path.write_text(text, encoding="ascii")
            self.check(8, [str(path), "0"], 0, "Range: 0..1\nKept: 0\n")

    def test_08_ini_invalid_settings(self):
        examples = ["", "minimum=1", "[other]\nminimum=0\nmaximum=1\n", "[filter]\nminimum=1\n", "[filter]\nminimum=0\nmaximum=1\nextra=2\n", "[DEFAULT]\nx=1\n[filter]\nminimum=0\nmaximum=1\n", "[filter]\nminimum=2\nmaximum=1\n", "[filter]\nminimum=-101\nmaximum=1\n", "[filter]\nminimum=0\nmaximum=101\n", "[filter]\nminimum=0.5\nmaximum=1\n", "[filter]\nminimum=0\nminimum=1\nmaximum=2\n", "[filter]\nminimum=%(x)s\nmaximum=1\n", "#" * 513]
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "filter.ini"
            for text in examples:
                with self.subTest(text=text):
                    path.write_text(text, encoding="ascii")
                    self.errors(8, [[str(path), "0"]])

    def test_08_ini_io_errors(self):
        with tempfile.TemporaryDirectory() as directory:
            path = Path(directory) / "filter.ini"
            self.check(8, [str(path), "1"], 1, "Error: cannot read UTF-8 settings.\n")
            self.check(8, [directory, "1"], 1, "Error: cannot read UTF-8 settings.\n")
            path.write_bytes(bytes([255]))
            self.check(8, [str(path), "1"], 1, "Error: cannot read UTF-8 settings.\n")

    def test_09_newton_known(self):
        self.check(9, ["0"], 0, "Root: 0.000000\n")
        result = run(9, ["2"])
        self.assertEqual(result.stdout.splitlines()[-1], "Root: 1.414214")
        self.assertEqual(len(result.stdout.splitlines()) - 1, 5)
        self.assertEqual(result.returncode, 0)
        self.assertEqual(result.stderr, "")

    def test_09_newton_against_sqrt(self):
        for text in ["0.000001", "0.000002", "0.01", "0.25", "1", "2", "9", "100", "9999", "10000"]:
            with self.subTest(text=text):
                result = run(9, [text])
                self.assertEqual(result.returncode, 0)
                root = float(result.stdout.splitlines()[-1].split(": ")[1])
                self.assertAlmostEqual(root, math.sqrt(float(text)), delta=0.00000051)
                self.assertLessEqual(len(result.stdout.splitlines()) - 1, 20)
                self.assertEqual(result.stderr, "")

    def test_10_dice_known(self):
        self.check(10, ["2"], 0, "Sum 2: 1/4 = 25.0%\nSum 3: 2/4 = 50.0%\nSum 4: 1/4 = 25.0%\nOutcomes: 4\n")

    def test_10_dice_triangular_model(self):
        for faces in range(2, 7):
            with self.subTest(faces=faces):
                result = run(10, [str(faces)])
                counts = []
                for row in result.stdout.splitlines()[:-1]:
                    match = re.fullmatch(r"Sum (\d+): (\d+)/(\d+) = ([\d.]+)%", row)
                    self.assertIsNotNone(match)
                    score, count, total = map(int, match.groups()[:3])
                    expected = faces - abs(score - (faces + 1))
                    self.assertEqual(count, expected)
                    self.assertEqual(total, faces * faces)
                    self.assertEqual(float(match[4]), round(count / total * 100, 1))
                    counts.append(count)
                self.assertEqual(sum(counts), faces * faces)
                self.assertEqual(counts, list(reversed(counts)))
                self.assertEqual(result.returncode, 0)
                self.assertEqual(result.stderr, "")

    def test_invalid_numeric_and_string_arguments(self):
        cases = {1: [[""], ["a"], ["1" * 13], ["+1"], ["1.0"]], 3: [["0", "1"], ["6", "1,2,3,4,5,6"], ["3", "1,2"], ["1", ""], ["1", "-1"], ["1", "101"], ["1", "1,,2"], ["1", ",".join(["1"] * 11)]], 4: [[""], [".........X"], ["x........"], ["OO......."], ["XXXOOO..."], ["XXXOO.O.."]], 5: [[""], ["1,,2"], ["-21"], ["21"], [",".join(["1"] * 9)], ["1.5"], ["1" * 33]], 8: [["samples/filter.ini", ""], ["samples/filter.ini", "101"], ["samples/filter.ini", "-101"], ["samples/filter.ini", "1.5"], ["samples/filter.ini", ",".join(["1"] * 11)], ["samples/filter.ini", "1" * 51]], 9: [[""], ["nan"], ["inf"], ["-inf"], ["-1"], ["0.0000001"], ["10001"], ["1" * 21]], 10: [[""], ["1"], ["7"], ["-1"], ["2.5"], ["000"]]}
        for number, inputs in cases.items():
            with self.subTest(number=number):
                self.errors(number, inputs)

    def test_argument_counts(self):
        valid = {1: ["1"], 2: ["a", "out.html"], 3: ["1", "1"], 4: ["........."], 5: ["1"], 7: ["a.txt"], 8: ["a.ini", "1"], 9: ["1"], 10: ["2"]}
        for number, args in valid.items():
            for wrong in [[], args + ["extra"]]:
                with self.subTest(number=number, args=wrong):
                    result = run(number, wrong)
                    self.assertEqual(result.returncode, 2)
                    self.assertTrue(result.stdout.startswith("Usage:"))
                    self.assertEqual(result.stderr, "")

    def test_import_has_no_side_effects(self):
        for file in FILES:
            with self.subTest(file=file.name):
                code = "import importlib.util; s=importlib.util.spec_from_file_location('lesson', " + repr(str(file)) + "); m=importlib.util.module_from_spec(s); s.loader.exec_module(m)"
                result = subprocess.run([sys.executable, "-c", code], text=True, capture_output=True, timeout=5, cwd=ROOT)
                self.assertEqual((result.returncode, result.stdout, result.stderr), (0, "", ""))

    @unittest.skipIf(os.name != "posix" or os.geteuid() == 0, "needs non-root POSIX")
    def test_file_permission_errors(self):
        with tempfile.TemporaryDirectory() as directory:
            base = Path(directory)
            locked = base / "locked.txt"
            locked.write_text("test", encoding="ascii")
            locked.chmod(0)
            try:
                self.check(7, [str(locked)], 1, "Error: cannot read the UTF-8 request.\n")
                self.check(8, [str(locked), "1"], 1, "Error: cannot read UTF-8 settings.\n")
            finally:
                locked.chmod(0o600)
            folder = base / "locked"
            folder.mkdir()
            folder.chmod(0o500)
            try:
                self.check(2, ["text", str(folder / "card.html")], 1, "Error: cannot create HTML; choose a new path.\n")
                self.assertFalse((folder / "card.html").exists())
            finally:
                folder.chmod(0o700)


if __name__ == "__main__":
    unittest.main()
