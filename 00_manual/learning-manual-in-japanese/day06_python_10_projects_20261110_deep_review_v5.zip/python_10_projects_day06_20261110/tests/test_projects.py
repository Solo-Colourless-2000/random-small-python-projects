import importlib.util
from pathlib import Path
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch

from cases import CASES


ROOT = Path(__file__).resolve().parents[1]


def run(name, args, cwd=ROOT):
    return subprocess.run(
        [sys.executable, "-S", str(ROOT / "projects" / (name + ".py")), *args],
        cwd=cwd,
        stdin=subprocess.DEVNULL,
        capture_output=True,
        text=True,
        encoding="ascii",
        timeout=6,
    )


def load(name):
    path = ROOT / "projects" / (name + ".py")
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class ProjectTests(unittest.TestCase):
    def check_cases(self, name):
        for args, code, stdout, stderr in CASES[name]:
            with self.subTest(args=args):
                result = run(name, args)
                self.assertEqual((result.returncode, result.stdout, result.stderr),
                                 (code, stdout, stderr))

    def test_01_traversal(self):
        self.check_cases("01_traversal")

    def test_02_sql_probe(self):
        self.check_cases("02_sql_probe")

    def test_03_object_access(self):
        self.check_cases("03_object_access")

    def test_04_origin_policy(self):
        self.check_cases("04_origin_policy")

    def test_05_redirect_scope(self):
        self.check_cases("05_redirect_scope")

    def test_06_upload_probe(self):
        self.check_cases("06_upload_probe")

    def test_07_token_tamper(self):
        self.check_cases("07_token_tamper")

    def test_08_limit_buckets(self):
        self.check_cases("08_limit_buckets")

    def test_09_compare_oracle(self):
        self.check_cases("09_compare_oracle")

    def test_10_banner_probe(self):
        self.check_cases("10_banner_probe")

    def test_traversal_sibling_is_outside(self):
        module = load("01_traversal")
        first, target, early, fixed = module.resolve("/public/../publicity/notes")
        self.assertEqual((first, target, early, fixed),
                         ("/public/../publicity/notes", "/publicity/notes", False, False))

    def test_redirect_blocks_before_fixture_lookup(self):
        module = load("05_redirect_scope")

        class GuardedRoutes(dict):
            def get(self, key):
                if key.startswith("https://inside.example.test/"):
                    raise AssertionError("Blocked host was accessed")
                return super().get(key)

        with patch.object(module, "PAGES", GuardedRoutes(module.PAGES)):
            self.assertEqual(module.follow("https://public.example.test/jump", True),
                             "blocked https://inside.example.test/info")
            self.assertEqual(module.follow("https://public.example.test/absent", True),
                             "no fixture")

    def test_sample_path_is_independent_of_terminal_directory(self):
        expected = run("06_upload_probe", ["header"])
        with tempfile.TemporaryDirectory() as folder:
            actual = run("06_upload_probe", ["header"], cwd=folder)
        self.assertEqual((actual.returncode, actual.stdout, actual.stderr),
                         (expected.returncode, expected.stdout, expected.stderr))
        self.assertEqual(actual.returncode, 0)

    def test_sample_missing_returns_io_failure(self):
        module = load("06_upload_probe")
        with patch.object(sys, "argv", ["script", "header"]):
            with patch.object(Path, "open", side_effect=FileNotFoundError):
                with patch("builtins.print") as mock_print:
                    self.assertEqual(module.main(), 1)
                    self.assertEqual(mock_print.call_args.args[0],
                                     "Cannot read the bundled sample.")
                    self.assertIs(mock_print.call_args.kwargs["file"], sys.stderr)

    def test_sample_location_shared_by_practice_and_final_code(self):
        module = load("06_upload_probe")
        for label, filename in module.FILES.items():
            with self.subTest(label=label):
                expected = module.compare(ROOT / "samples" / filename)
                self.assertEqual(len(expected), 3)
        with tempfile.TemporaryDirectory() as folder:
            folder = Path(folder)
            (folder / "practice").mkdir()
            (folder / "samples").mkdir()
            (folder / "samples" / "header.gif").write_bytes(b"GIF89aABCD")
            source = ROOT / "projects" / "06_upload_probe.py"
            (folder / "practice" / source.name).write_bytes(source.read_bytes())
            command = subprocess.run([sys.executable, "-S", str(folder / "practice" / source.name), "header"],
                                     cwd=ROOT, capture_output=True, text=True, timeout=6)
            self.assertEqual((command.returncode, command.stdout, command.stderr),
                             (0, "Prefix: b'GIF89a'\nSuffix check: True\nSignature check: True\n", ""))

    def test_origin_and_redirect_extra_negative_cases(self):
        origin = load("04_origin_policy")
        for spoof in ("https://trap-app.example.test", "http://app.example.test", "https://xapp.example.test"):
            with self.subTest(spoof=spoof):
                weak, strict = origin.headers(spoof)
                self.assertEqual(weak, spoof)
                self.assertEqual(strict, "(omitted)")
        redirect = load("05_redirect_scope")
        self.assertEqual(redirect.follow("https://public.example.test/jump", True),
                         "blocked https://inside.example.test/info")

    def test_path_decoding_and_invalid_inputs(self):
        module = load("01_traversal")
        self.assertEqual(module.resolve("/public/%252e%252e/private/notes"),
                         ("/public/%2e%2e/private/notes", "/private/notes", True, False))
        for bad in ("/public/%00", "/public/%ff", "/public/%0a"):
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError):
                    module.resolve(bad)

    def test_comparison_known_positions(self):
        module = load("09_compare_oracle")
        for value, expected in (("0000", 1), ("4800", 3), ("4820", 4), ("4827", 4)):
            with self.subTest(value=value):
                self.assertEqual(module.early_count(value), (value == "4827", expected))
                self.assertEqual(module.full_count(value), (value == "4827", 4))

    def test_project_modules_have_no_extra_import_side_effects(self):
        for path in sorted((ROOT / "projects").glob("*.py")):
            with self.subTest(source=path.name):
                result = subprocess.run([sys.executable, "-S", "-c", "import runpy; runpy.run_path("+repr(str(path))+")"],
                                        cwd=ROOT, capture_output=True, text=True, timeout=6)
                self.assertEqual((result.returncode, result.stdout, result.stderr), (0, "", ""))

    def test_samples_unchanged_after_repeat(self):
        samples = ROOT / "samples"
        before = {path.name: path.read_bytes() for path in samples.iterdir()}
        for _ in range(2):
            self.assertEqual(run("06_upload_probe", ["header"]).returncode, 0)
        self.assertEqual({path.name: path.read_bytes() for path in samples.iterdir()}, before)

    def test_hmac_sha256_known_vector(self):
        module = load("07_token_tamper")
        key = bytes([11]) * 20
        expected = "b0344c61d8db38535ca8afceaf0bf12b881dc200c9833da726e9376c2e32cff7"
        with patch.object(module, "LAB_KEY", key):
            self.assertEqual(module.tag(b"Hi There").hex(), expected)

    def test_rate_limit_runs_do_not_share_state(self):
        module = load("08_limit_buckets")
        self.assertEqual(module.decisions(("a", "b", "a", "a")), "allow allow allow deny")
        self.assertEqual(module.decisions(("a",)), "allow")
        self.assertEqual(module.decisions(()), "")

    def test_oracle_rejects_short_and_long_direct_calls(self):
        module = load("09_compare_oracle")
        for candidate in ("", "48", "482", "48270", "4827extra"):
            with self.subTest(candidate=candidate):
                with self.assertRaisesRegex(ValueError, "Length mismatch"):
                    module.early_count(candidate)
                with self.assertRaisesRegex(ValueError, "Length mismatch"):
                    module.full_count(candidate)

    def test_oracle_for_all_four_digit_candidates(self):
        module = load("09_compare_oracle")
        by_checks = [0, 0, 0, 0]
        for number in range(10000):
            candidate = f"{number:04d}"
            early, checks = module.early_count(candidate)
            self.assertEqual(early, candidate == "4827")
            self.assertEqual(module.full_count(candidate), (early, 4))
            by_checks[checks - 1] += 1
        self.assertEqual(by_checks, [9000, 900, 90, 10])

    def test_banner_reader_bound_and_incomplete_line(self):
        module = load("10_banner_probe")
        self.assertEqual(module.capture(b"A" * 70 + b"\n"), b"A" * 64)
        self.assertEqual(module.capture(b""), b"")
        with patch.object(sys, "argv", ["script", "lab"]):
            with patch.object(module, "capture", return_value=b"LAB/1 partial"):
                with patch.object(sys, "stderr") as error:
                    self.assertEqual(module.main(), 1)
                    self.assertIn("Missing complete banner.", error.write.call_args_list[0].args[0])

    def test_socket_io_failure(self):
        module = load("10_banner_probe")
        with patch.object(sys, "argv", ["script", "lab"]):
            with patch.object(module, "capture", side_effect=TimeoutError):
                with patch.object(sys, "stderr") as error:
                    self.assertEqual(module.main(), 1)
                    self.assertIn("Loopback experiment failed.", error.write.call_args_list[0].args[0])
