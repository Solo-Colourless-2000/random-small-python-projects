#include "engine_internal.h"

void make_enemy(int type,float x,float y) {
    for(int i=0;i<MAX_ENEMIES;i++) {
        Tank *e=&s.enemies[i];
        if(e->active) continue;
        memset(e,0,sizeof(*e));
        e->active=1;e->type=type;e->x=x;e->y=y;
        e->radius=(type==ENEMY_BOSS?35.0f:type==ENEMY_BRUISER?26.0f:20.0f);
        float factor=1.0f+minf(s.wave-1,20)*0.085f;
        e->max_hp=(type==ENEMY_SCOUT?42.0f:type==ENEMY_GUNNER?75.0f:
                    type==ENEMY_BRUISER?160.0f:650.0f)*factor;
        e->hp=e->max_hp;e->angle=rand_range(-3.14f,3.14f);e->turret=e->angle;
        e->reload=rand_range(.4f,2.0f);
        enemy_strafe[i]=(rand01()<.5f)?-1.0f:1.0f;
        enemy_ai_time[i]=rand_range(.4f,1.7f);
        return;
    }
}
int spawn_valid(float x,float y,float radius) {
    if(length2(x-s.player.x,y-s.player.y)<260.0f*260.0f) return 0;
    for(int i=0;i<s.obstacle_count;i++) {
        const Obstacle *o=&s.obstacles[i];
        if(!o->active) continue;
        float cx=clampf(x,o->x,o->x+o->w),cy=clampf(y,o->y,o->y+o->h);
        if(length2(cx-x,cy-y)<(radius+12)*(radius+12)) return 0;
    }
    for(int i=0;i<MAX_ENEMIES;i++) {
        const Tank *e=&s.enemies[i];
        if(e->active && length2(x-e->x,y-e->y)<(radius+e->radius+16)*(radius+e->radius+16)) return 0;
    }
    return 1;
}


void update_enemy(int idx,float dt) {
    Tank *e=&s.enemies[idx];
    if(!e->active || !s.player_alive) return;
    e->flash=maxf(0,e->flash-dt);e->reload=maxf(0,e->reload-dt);
    if(e->stun>0) {e->stun=maxf(0,e->stun-dt);return;}
    enemy_ai_time[idx]-=dt;
    if(enemy_ai_time[idx]<=0) {
        enemy_strafe[idx]=-enemy_strafe[idx];
        enemy_ai_time[idx]=rand_range(1.5f,3.5f);
    }
    float dx=s.player.x-e->x,dy=s.player.y-e->y;
    float dist=norm(&dx,&dy);
    float target_dir=atan2f(dy,dx);
    e->turret=angle_approach(e->turret,target_dir,3.1f,dt);
    float mx=dx,my=dy;
    if(e->type==ENEMY_GUNNER || e->type==ENEMY_BOSS) {
        float want=e->type==ENEMY_BOSS?265.0f:315.0f;
        float pull=clampf((dist-want)/120.0f,-1,1);
        mx=dx*pull-dy*enemy_strafe[idx]*.58f;
        my=dy*pull+dx*enemy_strafe[idx]*.58f;
    } else if(e->type==ENEMY_BRUISER) {
        mx=dx*clampf((dist-92)/100.0f,-.25f,1);
        my=dy*clampf((dist-92)/100.0f,-.25f,1);
    }
    /* Local separation keeps the crowd from collapsing into one tank. */
    for(int j=0;j<MAX_ENEMIES;j++) {
        if(j==idx || !s.enemies[j].active) continue;
        Tank *other=&s.enemies[j];
        float sep_x=e->x-other->x,sep_y=e->y-other->y;
        float sq=length2(sep_x,sep_y);
        float avoid=e->radius+other->radius+7;
        if(sq>0.001f && sq<avoid*avoid) {
            float d=sqrtf(sq),force=(avoid-d)/avoid;
            mx+=(sep_x/d)*force*2.0f;
            my+=(sep_y/d)*force*2.0f;
        }
    }
    norm(&mx,&my);
    /* A direct pursuit vector can pin a bruiser against a flat wall forever.
     * Probe one tank-length ahead and steer toward a deterministic wall tangent.
     * This remains a local avoidance rule, not global pathfinding. */
    if(length2(mx,my)>.0001f) {
        float look=e->radius+39.0f;
        float probe_x=e->x+mx*look,probe_y=e->y+my*look;
        for(int k=0;k<s.obstacle_count;k++) {
            const Obstacle *o=&s.obstacles[k];
            if(!o->active) continue;
            float near_x=clampf(probe_x,o->x,o->x+o->w);
            float near_y=clampf(probe_y,o->y,o->y+o->h);
            if(length2(probe_x-near_x,probe_y-near_y)>
               (e->radius+5.0f)*(e->radius+5.0f)) continue;
            float to_x=o->x+o->w*.5f-e->x;
            float to_y=o->y+o->h*.5f-e->y;
            float cross=mx*to_y-my*to_x;
            float side=cross>=0 ? -1.0f : 1.0f;
            float tangent_x=-my*side,tangent_y=mx*side;
            mx=mx*.22f+tangent_x*1.4f;
            my=my*.22f+tangent_y*1.4f;
            norm(&mx,&my);
            break;
        }
    }
    if(length2(mx,my)>.0001f) e->angle=angle_approach(e->angle,atan2f(my,mx),4.2f,dt);
    float speed=e->type==ENEMY_SCOUT?149:e->type==ENEMY_GUNNER?96:e->type==ENEMY_BRUISER?78:70;
    move_tank(e,mx*speed*dt,my*speed*dt);
    float new_dist=sqrtf(length2(s.player.x-e->x,s.player.y-e->y));
    if(new_dist<e->radius+s.player.radius+7 && contact_cooldown<=0) {
        damage_player(e->type==ENEMY_BOSS?29:e->type==ENEMY_BRUISER?23:14,e->x,e->y);
        contact_cooldown=0.55f;
    }
    if(e->reload<=0 && e->type!=ENEMY_SCOUT && dist<710 &&
       fabsf(angular_delta(e->turret,target_dir))<0.35f &&
       has_los(e->x,e->y,s.player.x,s.player.y)) {
        float aim=atan2f(s.player.y-e->y,s.player.x-e->x);
        float spread=e->type==ENEMY_GUNNER?.075f:e->type==ENEMY_BRUISER?.12f:.095f;
        int n=e->type==ENEMY_BOSS?3:1;
        for(int b=0;b<n;b++) {
            float offset=(n==1?0:((float)b-1.0f)*.13f);
            add_bullet(e->x+cosf(aim)*e->radius,e->y+sinf(aim)*e->radius,
                       aim+offset+rand_range(-spread,spread),
                       e->type==ENEMY_BOSS?440:340,
                       e->type==ENEMY_BRUISER?17:e->type==ENEMY_BOSS?16:12,1,0);
        }
        e->reload=e->type==ENEMY_BOSS?1.15f:e->type==ENEMY_BRUISER?2.1f:1.35f;
    }
}
