"""Independent v4 review scenarios, including playable regressions absent in v3.

These are behavioral assertions against the rebuilt C core and real Tk widgets,
not a loop that repeats a single green smoke test 40 times.
"""
from __future__ import annotations
import ctypes as ct
import math
import time
from pathlib import Path
from types import SimpleNamespace
import tkinter as tk

import pytest
from test_engine import dll, engine, snap, step
from test_ui import app, key, mouse
from c_bridge import Control, Snapshot
from arena_scores import read_best, write_best
from main import TankArena


def test_quality_01_submillisecond_time_is_not_artificially_accelerated(engine):
    s=step(engine, dt=0.0001)
    assert s.time==pytest.approx(0.0001,rel=1e-5)


def test_quality_02_large_time_step_respects_upper_bound(engine):
    assert step(engine,dt=2.0).time==pytest.approx(0.0334,rel=1e-5)


def test_quality_03_negative_time_step_is_ignored(engine):
    assert step(engine,dt=-.25,fire=1).time==0


def test_quality_04_nan_aim_is_ignored_before_any_shots(engine):
    s=step(engine,aim_y=math.nan,fire=1)
    assert s.time==0 and s.bullet_count==0


def test_quality_05_movement_clamps_enormous_controller_input(engine):
    a=step(engine,12,move_x=10000,aim_x=900)
    engine.engine_reset(28971)
    b=step(engine,12,move_x=1,aim_x=900)
    assert a.player.x==pytest.approx(b.player.x)


def test_quality_06_zero_input_never_moves_even_with_turret_rotation(engine):
    a=step(engine,40,aim_x=0,aim_y=0)
    assert a.player.x==560 and a.player.y==310


def test_quality_07_dash_requires_actual_movement(engine):
    a=step(engine,1,dash=1)
    assert a.dash_energy>99.0
    assert a.invulnerability==0


def test_quality_08_dash_uses_energy_and_grants_short_shield(engine):
    a=step(engine,1,move_x=1,dash=1)
    assert 33<a.dash_energy<36 and .2<a.invulnerability<.3


def test_quality_09_insufficient_dash_energy_prevents_ability(engine):
    engine.debug_energy(55)
    a=step(engine,1,move_y=-1,dash=1)
    assert a.invulnerability==0 and a.dash_energy>55


def test_quality_10_dash_energy_regeneration_is_capped(engine):
    engine.debug_energy(99.9)
    assert step(engine,60).dash_energy==100


def test_quality_11_emp_damages_and_stuns_enemies(engine):
    engine.debug_enemy(2,645,310,150)
    a=step(engine,1,pulse=1)
    e=next(e for e in a.enemies if e.active)
    assert e.hp<150 and e.stun>1.9


def test_quality_12_emp_clears_hostile_projectiles_in_radius(engine):
    engine.debug_bullet(610,310,500,0,1,10,0)
    a=step(engine,1,pulse=1)
    assert not any(b.active and b.owner==1 for b in a.bullets)


def test_quality_13_emp_never_erases_friendly_projectiles(engine):
    engine.debug_bullet(610,310,200,0,0,10,0)
    a=step(engine,1,pulse=1)
    assert any(b.active and b.owner==0 for b in a.bullets)


def test_quality_14_emp_cooldown_prevents_spamming(engine):
    a=step(engine,1,pulse=1)
    c=a.pulse_cooldown
    b=step(engine,1,pulse=1)
    assert b.pulse_cooldown<c and b.pulse_cooldown>9.9


def test_quality_15_emp_just_outside_blast_does_not_damage_enemy(engine):
    engine.debug_enemy(1,790,310,200)
    a=step(engine,1,pulse=1)
    e=next(e for e in a.enemies if e.active)
    assert e.hp==e.max_hp


def test_quality_16_armor_upgrade_has_finite_upper_cap(engine):
    for _ in range(12):engine.engine_upgrade(2)
    assert snap(engine).armor==pytest.approx(.58)


def test_quality_17_reload_upgrade_has_finite_lower_cap(engine):
    for _ in range(50):engine.engine_upgrade(3)
    assert snap(engine).shot_interval==pytest.approx(.07)


def test_quality_18_mobility_upgrade_does_not_exceed_design_speed(engine):
    for _ in range(30):engine.engine_upgrade(6)
    assert snap(engine).player_speed==400


def test_quality_19_reactor_upgrade_respects_health_caps(engine):
    for _ in range(30):engine.engine_upgrade(7)
    s=snap(engine)
    assert s.player.max_hp==270 and s.player.hp<=270


def test_quality_20_score_upgrades_saturate_without_wrap(engine):
    for _ in range(34000):engine.engine_upgrade(9)
    s=snap(engine)
    assert s.score==99_999_999


def test_quality_21_last_enemy_kill_makes_sector_safe_from_old_bullets(engine):
    engine.debug_enemy(0,660,310,10)
    engine.debug_bullet(645,310,900,0,0,40,0)  # First allocated: kills enemy.
    engine.debug_bullet(600,310,-1500,0,1,50,0) # Second: would hit player.
    a=step(engine,1,dt=.0333)
    assert a.enemy_count==0 and a.kills==1
    assert a.player_alive and a.player.hp==140
    assert not any(b.active and b.owner==1 for b in a.bullets)


def test_quality_22_nonfinal_kill_does_not_disarm_active_enemies(engine):
    engine.debug_enemy(0,660,310,10)
    engine.debug_enemy(1,960,390,70)
    engine.debug_bullet(645,310,900,0,0,40,0)
    engine.debug_bullet(700,550,0,-100,1,10,0)
    a=step(engine,1,dt=.0333)
    assert a.enemy_count==1 and any(b.active and b.owner==1 for b in a.bullets)


def test_quality_23_new_wave_retires_leftover_player_shots(engine):
    engine.debug_bullet(560,310,50,0,0,10,0)
    engine.engine_next_wave()
    assert snap(engine).bullet_count==0


def test_quality_24_new_wave_increments_once_and_has_targets(engine):
    engine.engine_next_wave()
    a=snap(engine)
    assert a.wave==1 and a.enemy_count>=1


def test_quality_25_boss_is_reserved_for_fifth_wave(engine):
    engine.debug_wave(3);engine.engine_next_wave()
    a=snap(engine)
    assert a.wave==4 and all(e.type!=3 for e in a.enemies if e.active)


def test_quality_26_every_fifth_wave_has_one_boss(engine):
    engine.debug_wave(9);engine.engine_next_wave()
    a=snap(engine)
    assert a.wave==10 and sum(e.active and e.type==3 for e in a.enemies)==1


def test_quality_27_high_speed_shell_cannot_tunnel_through_enemy(engine):
    engine.debug_enemy(0,680,310,10)
    engine.debug_bullet(570,310,6000,0,0,50,0)
    a=step(engine,1,dt=.0333)
    assert a.enemy_count==0 and a.kills==1


def test_quality_28_projectile_must_not_reflect_on_wood(engine):
    engine.debug_bullet(275,305,1900,0,0,25,1)
    a=step(engine,1,dt=.0333)
    assert a.bullet_count==0
    assert any(e.kind==8 for e in a.events[:a.event_count])


def test_quality_29_player_movement_is_bounded_after_long_push(engine):
    a=step(engine,300,move_x=-1,move_y=-1)
    assert 35<=a.player.x<=1085 and 35<=a.player.y<=585


def test_quality_30_health_pickup_cannot_overheal(engine):
    engine.debug_pickup(560,310,0)
    a=step(engine,1)
    assert a.player.hp==a.player.max_hp and a.pickup_count==0


def test_quality_31_energy_pickup_cannot_overcharge(engine):
    engine.debug_pickup(560,310,1)
    a=step(engine,1)
    assert a.dash_energy==100 and a.pickup_count==0


def test_quality_32_shift_pressed_before_movement_still_queues_dash(app):
    app.new_game();app.screen='PLAYING'
    app.key_press(key('Shift_L'))
    assert app._input().dash==1 # A frame without movement consumes first edge.
    app.key_press(key('w'))
    c=app._input()
    assert c.move_y==-1 and c.dash==1
    assert app._input().dash==0


def test_quality_33_shift_release_cancels_pending_dash(app):
    app.new_game();app.screen='PLAYING'
    app.key_press(key('Shift_L'))
    app.key_release(key('Shift_L'))
    app.key_press(key('w'))
    assert app._input().dash==0


def test_quality_34_shift_held_does_not_auto_dash_repeatedly(app):
    app.new_game();app.screen='PLAYING'
    app.key_press(key('w'));app.key_press(key('Shift_L'))
    assert app._input().dash==1
    assert app._input().dash==0
    app.key_press(key('Shift_L'))
    assert app._input().dash==0


def test_quality_35_keyboard_pause_clears_pressed_movement(app):
    app.new_game();app.screen='PLAYING'
    app.key_press(key('w'));app.key_press(key('p'))
    assert app.screen=='PAUSED' and not app.keys


def test_quality_36_pause_resume_preserves_precombat_countdown(app):
    app.new_game();app.wave_banner=.8
    app.pause();app.resume()
    assert app.screen=='INTRO' and app.wave_banner==.8


def test_quality_37_invalid_card_index_does_not_start_wave(app):
    app.new_game();app.start_upgrade_screen()
    before=app.engine.state.wave
    app.choose_upgrade(99)
    assert app.screen=='UPGRADE' and app.engine.state.wave==before


def test_quality_38_tiny_screen_geometry_never_exceeds_desktop(monkeypatch,tmp_path):
    root=tk.Tk()
    monkeypatch.setattr(root,'winfo_screenwidth',lambda:300)
    monkeypatch.setattr(root,'winfo_screenheight',lambda:210)
    monkeypatch.setattr(TankArena,'_save_path',staticmethod(lambda:tmp_path/'tiny.json'))
    app=TankArena(root)
    try:
        assert app.w<=300 and app.h<=210 and app.scale>0
    finally:app.close()


def test_quality_39_save_read_roundtrip_preserves_two_records(tmp_path):
    p=tmp_path/'best.json'
    assert write_best(p,1234567,67)
    assert read_best(p)==(1234567,67)


def test_quality_40_bad_save_fails_open_then_allows_new_highscore(tmp_path):
    p=tmp_path/'best.json';p.write_text('{garbage',encoding='utf-8')
    assert read_best(p)==(0,0)
    assert write_best(p,400,5) and read_best(p)==(400,5)
