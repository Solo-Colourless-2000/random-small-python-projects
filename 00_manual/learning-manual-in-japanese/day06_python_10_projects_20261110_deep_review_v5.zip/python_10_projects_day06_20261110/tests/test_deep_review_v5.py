"""Independent semantic and pedagogy checks for the fifth revision (stdlib only)."""
import ast
import importlib.util
from pathlib import Path
import subprocess
import sys
import unittest
from html.parser import HTMLParser

ROOT = Path(__file__).resolve().parents[1]
DOCUMENT = (ROOT / 'python_10_projects_day06_manual.html').read_text(encoding='utf-8')
PROJECTS = sorted((ROOT / 'projects').glob('*.py'))


class AppendixReader(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.in_appendix = False
        self.in_table = False
        self.in_tbody = False
        self.in_row = False
        self.columns = []
        self.rows = []
        self.headings = 0
        self.in_td = False
        self.ids = set()

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if a.get('id') == 'appendix-a':
            self.in_appendix = True
        if a.get('id') == 'appendix-b':
            self.in_appendix = False
        if a.get('id') is not None:
            self.ids.add(a['id'])
        if not self.in_appendix:
            return
        if tag == 'table': self.in_table = True; self.headings += 1
        if tag == 'tbody': self.in_tbody = True
        if tag == 'tr' and self.in_tbody: self.in_row = True; self.columns = []
        if tag == 'td' and self.in_row: self.in_td = True; self.columns.append('')

    def handle_data(self, data):
        if self.in_td and self.columns:
            self.columns[-1] += data

    def handle_endtag(self, tag):
        if not self.in_appendix:
            return
        if tag == 'td': self.in_td = False
        if tag == 'tr' and self.in_row:
            self.rows.append([col.strip() for col in self.columns]); self.in_row = False
        if tag == 'tbody': self.in_tbody = False
        if tag == 'table': self.in_table = False


def load_project(index):
    path = PROJECTS[index - 1]
    spec = importlib.util.spec_from_file_location('review_project_' + str(index), path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class FifthRevisionTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.reader = AppendixReader()
        cls.reader.feed(DOCUMENT)

    def test_all_270_nonblank_lines_get_role_and_constituent_explanation(self):
        count = sum(bool(line.strip()) for p in PROJECTS for line in p.read_text('ascii').splitlines())
        self.assertEqual(count, 270)
        self.assertEqual(self.reader.headings, 10)
        self.assertEqual(len(self.reader.rows), count)
        self.assertTrue(all(len(row) == 4 for row in self.reader.rows))
        self.assertTrue(all(len(row[2]) >= 8 and len(row[3]) >= 16 for row in self.reader.rows))

    def test_original_sources_remain_identical_to_step_code(self):
        from test_materials import Manual
        page = Manual(DOCUMENT)
        for number, path in enumerate(PROJECTS, 1):
            with self.subTest(project=number):
                code = path.read_text('ascii')
                joined = ''.join(page.sources[f'step-{number:02d}-{n}'] for n in range(1, 5))
                self.assertEqual(joined, code)
                self.assertEqual(page.sources[f'src-{number:02d}'], code)
                ast.parse(code, feature_version=(3, 10))

    def test_each_project_has_a_limit_specific_to_its_demo(self):
        for n in range(1, 11):
            self.assertIn(f'careful-reading-{n:02d}', self.reader.ids)
            self.assertIn(f'id="verified-cases-{n:02d}"', DOCUMENT)

    def test_python_symbols_cover_actual_source_usage(self):
        self.assertIn('id="expression-reading"', DOCUMENT)
        for item in ('fetchone()[0]', '(value,)', 'Path(__file__).resolve()',
                     'mismatches == 0', 'is None', 'not in', 'with path.open'):
            self.assertIn(item, DOCUMENT)

    def test_traversal_two_decodes_and_invalid_utf8(self):
        mod = load_project(1)
        first, target, weak, fixed = mod.resolve('/public/%252e%252e/private/notes')
        self.assertEqual((first, target, weak, fixed),
                         ('/public/%2e%2e/private/notes', '/private/notes', True, False))
        with self.assertRaises(ValueError):
            mod.resolve('/public/%FF')
        # A malformed percent escape is deliberately not rejected by unquote.
        self.assertEqual(mod.resolve('/public/%GG')[1], '/public/%GG')

    def test_sql_probe_unsafe_and_bound_results(self):
        import sqlite3
        from contextlib import closing
        mod = load_project(2)
        with closing(sqlite3.connect(':memory:')) as db:
            db.execute('CREATE TABLE notes(label TEXT)')
            db.executemany('INSERT INTO notes VALUES(?)', [('blue',), ('red',)])
            self.assertEqual(mod.count_rows(db, mod.CASES['probe']), (2, 0))
            self.assertEqual(mod.count_rows(db, mod.CASES['known']), (1, 1))

    def test_owner_requirement_is_distinct_from_existence(self):
        mod = load_project(3)
        self.assertEqual(mod.compare('alice', '101'), ('200', '200'))
        self.assertEqual(mod.compare('alice', '102'), ('200', '403'))
        self.assertEqual(mod.compare('alice', '103'), ('404', '404'))

    def test_cors_suffix_is_not_exact_origin(self):
        mod = load_project(4)
        self.assertEqual(mod.headers('https://trap-app.example.test'),
                         ('https://trap-app.example.test', '(omitted)'))
        self.assertEqual(mod.headers(mod.TRUSTED), (mod.TRUSTED, mod.TRUSTED))

    def test_redirect_rechecks_before_second_fixture_read(self):
        mod = load_project(5)
        start = 'https://public.example.test/jump'
        self.assertEqual(mod.follow(start, False), 'read inside-note')
        self.assertEqual(mod.follow(start, True), 'blocked https://inside.example.test/info')
        self.assertEqual(mod.follow('https://public.example.test/loop', True), 'hop limit')

    def test_upload_magic_header_is_not_complete_file_validation(self):
        mod = load_project(6)
        prefix, suffix, signature = mod.compare(ROOT / 'samples/header.gif')
        self.assertEqual((prefix, suffix, signature), (b'GIF89a', True, True))
        self.assertEqual((ROOT / 'samples/header.gif').stat().st_size, 10)
        self.assertEqual(mod.compare(ROOT / 'samples/short.gif')[2], False)
        self.assertEqual(mod.compare(ROOT / 'samples/header.txt')[1], False)

    def test_hmac_issued_tag_is_not_reusable_after_tamper(self):
        import hmac
        mod = load_project(7)
        self.assertIsInstance(mod.tag(mod.ORIGINAL), bytes)
        self.assertEqual(len(mod.tag(mod.ORIGINAL)), 32)
        self.assertTrue(hmac.compare_digest(mod.tag(mod.ORIGINAL), mod.tag(mod.ORIGINAL)))
        self.assertFalse(hmac.compare_digest(mod.tag(mod.ORIGINAL), mod.tag(mod.ALTERED)))

    def test_rate_limit_per_key_and_per_account_are_distinct_models(self):
        mod = load_project(8)
        self.assertEqual(mod.decisions(mod.CASES['same']), 'allow allow deny')
        self.assertEqual(mod.decisions(mod.CASES['rotate']), 'allow allow allow')
        self.assertEqual(mod.decisions(mod.ACCOUNT), 'allow allow deny')

    def test_comparison_count_is_not_wall_clock_time(self):
        mod = load_project(9)
        self.assertEqual(mod.early_count('0000'), (False, 1))
        self.assertEqual(mod.early_count('4800'), (False, 3))
        self.assertEqual(mod.full_count('0000'), (False, 4))
        with self.assertRaises(ValueError): mod.early_count('482')
        with self.assertRaises(ValueError): mod.full_count('48270')

    def test_tcp_module_has_only_loopback_address(self):
        src = PROJECTS[9].read_text('ascii')
        self.assertIn('"127.0.0.1"', src)
        self.assertIn('listener.bind', src)
        self.assertIn('stream.readline(64)', src)
        self.assertNotIn('sys.argv[2]', src)

    def test_chapter_flow_and_references_are_retained(self):
        for n in range(1, 11):
            self.assertIn(f'id="p{n:02}"', DOCUMENT)
        for x in ('id="guide"', 'id="python"', 'id="terms"',
                  'id="references"', 'id="appendix-a"', 'id="appendix-b"'):
            self.assertIn(x, DOCUMENT)

    def test_cli_original_samples_still_run_with_python_S(self):
        from cases import CASES
        for name, records in CASES.items():
            path = ROOT / 'projects' / (name + '.py')
            args, expected_exit, stdout, stderr = records[0]
            result = subprocess.run([sys.executable, '-S', str(path), *args],
                                    cwd=ROOT, capture_output=True, text=True, timeout=6)
            self.assertEqual((result.returncode, result.stdout, result.stderr),
                             (expected_exit, stdout, stderr))


if __name__ == '__main__':
    unittest.main()
