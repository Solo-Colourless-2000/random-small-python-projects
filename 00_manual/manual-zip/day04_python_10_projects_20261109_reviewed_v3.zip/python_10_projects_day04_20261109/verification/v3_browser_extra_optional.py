from pathlib import Path
from playwright.sync_api import sync_playwright
import json
R=Path(__file__).resolve().parents[1]
s=(R/'python_10_projects_day04_manual.html').read_text(encoding='utf-8')
rows=[];interactions=[]
with sync_playwright() as play:
 browser=play.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-dev-shm-usage'])
 for width,zoom in [(320,1),(360,1),(390,1),(600,1),(768,1),(1440,1),(320,1.25),(390,1.25),(768,1.25),(320,1.5),(390,1.5),(1440,1.5)]:
  page=browser.new_page(viewport={'width':width,'height':880})
  errors=[]
  page.on('pageerror',lambda err:errors.append(str(err)))
  page.set_content(s,wait_until='load')
  page.evaluate('(z) => { document.documentElement.style.zoom=String(z); }',zoom)
  for i in range(1,11):
   page.evaluate('(i) => {location.hash="#p"+String(i).padStart(2,"0")}',i)
   page.wait_for_function('(i) => document.querySelector(".chapter.active")?.id==="p"+String(i).padStart(2,"0")',arg=i)
   page.locator('#p%02d .v3-lab'%i).scroll_into_view_if_needed()
   row=page.evaluate('''(i) => {
    const e=document.querySelector('#p'+String(i).padStart(2,'0')+' .v3-lab');
    const r=e.getBoundingClientRect(),doc=document.documentElement;
    const es=[...e.querySelectorAll('h3,p,pre,details,.codebox')].filter(x=>x.getClientRects().length);
    const outward=es.filter(x=>{let rr=x.getBoundingClientRect();return rr.left< -1 || rr.right>innerWidth+1}).map(x=>x.tagName+' '+x.className).slice(0,5);
    const code=e.querySelectorAll('.codebox');
    const needed=[...code].filter(b=>b.querySelector('pre').scrollWidth>b.querySelector('pre').clientWidth+3).length;
    return {project:i,document_width:doc.scrollWidth,viewport_width:innerWidth,lab_left:r.left,lab_right:r.right,outward,scroll_codes:needed};
   }''',i)
   row.update({'width':width,'zoom':zoom,'pass':row['document_width']<=width+1 and not row['outward'] and row['lab_left']>=-1 and row['lab_right']<=width+1})
   rows.append(row)
  if width in [320,390,1440] and zoom==1:
   page.evaluate('location.hash="#p05"')
   page.wait_for_function('document.querySelector(".chapter.active")?.id==="p05"')
   page.locator('#p05 .v3-lab').screenshot(path=str(R/f'verification/v3_lab05_{width}.png'),timeout=20000)
  interactions.append({'width':width,'zoom':zoom,'javascript_errors':errors})
  page.close()
 # Check the same instructions without javascript and with all optional explanations expanded.
 for width in [320,390,768]:
  page=browser.new_page(viewport={'width':width,'height':880},java_script_enabled=False)
  page.set_content(s,wait_until='load')
  a=page.evaluate('''()=>({all_chapters:[...document.querySelectorAll('.chapter')].filter(e=>e.getClientRects().length).length,scrollWidth:document.documentElement.scrollWidth,viewport:innerWidth})''')
  interactions.append({'width':width,'nojs':a,'pass':a['all_chapters']==20 and a['scrollWidth']<=width+1})
  page.close()
 browser.close()
result={'viewport_and_zoom_results':rows,'additional_interactions':interactions,'count':len(rows),'passed':sum(r['pass'] for r in rows),'failures':[r for r in rows if not r['pass']]}
(R/'verification/v3_browser_extra.json').write_text(json.dumps(result,ensure_ascii=False,indent=2))
print('additional',len(rows),'passed',result['passed'],'failed',len(result['failures']))
if result['failures']:print(result['failures'][:10])
for i in interactions:
 if i.get('javascript_errors'):print('JS ERROR',i)
 if i.get('pass') is False:print('NOJS FAIL',i)
