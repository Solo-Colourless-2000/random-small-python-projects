import sys
from pathlib import Path

FILES = {"header": "header.gif", "fake": "fake.gif", "rename": "header.txt", "short": "short.gif"}
SIGNATURES = (b"GIF87a", b"GIF89a")


def compare(path):
    with path.open("rb") as stream:
        prefix = stream.read(6)
    suffix_ok = path.suffix.lower() == ".gif"
    prefix_ok = prefix in SIGNATURES
    return prefix, suffix_ok, prefix_ok


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in FILES:
        print("Usage: script header|fake|rename|short", file=sys.stderr)
        return 2
    path = Path(__file__).resolve().parent.parent / "samples" / FILES[sys.argv[1]]
    try:
        prefix, suffix_ok, prefix_ok = compare(path)
    except OSError:
        print("Cannot read the bundled sample.", file=sys.stderr)
        return 1
    print(f"Prefix: {prefix!r}")
    print(f"Suffix check: {suffix_ok}")
    print(f"Signature check: {prefix_ok}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
