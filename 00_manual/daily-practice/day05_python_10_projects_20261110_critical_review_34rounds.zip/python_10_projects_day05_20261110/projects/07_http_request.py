import string
import sys
from pathlib import Path


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 07_http_request.py request.txt")
        return 2
    try:
        with Path(sys.argv[1]).open("r", encoding="utf-8", newline="") as stream:
            text = stream.read(1025)
    except (OSError, UnicodeError):
        print("Error: cannot read the UTF-8 request.")
        return 1
    try:
        if len(text) > 1024 or "\r" in text.replace("\r\n", ""):
            raise ValueError
        text = text.replace("\r\n", "\n")
        if not text.isascii() or any(ord(ch) < 32 and ch != "\n" for ch in text):
            raise ValueError
        lines = text.splitlines()
        end = lines.index("")
        if not 2 <= end <= 7 or len(lines) != end + 1:
            raise ValueError
        method, target, version = lines[0].split(" ")
        if method not in ("GET", "HEAD") or version != "HTTP/1.1":
            raise ValueError
        if not target.startswith("/") or not 1 <= len(target) <= 80 or any(not 33 <= ord(ch) <= 126 for ch in target):
            raise ValueError
        headers = {}
        for line in lines[1:end]:
            name, value = line.split(":", 1)
            if name != name.strip():
                raise ValueError
            name = name.lower()
            value = value.strip()
            if not name or any(ch not in string.ascii_lowercase + string.digits + "-" for ch in name):
                raise ValueError
            if name in headers or not 1 <= len(value) <= 80 or any(not 32 <= ord(ch) <= 126 for ch in value):
                raise ValueError
            headers[name] = value
        if "host" not in headers:
            raise ValueError
    except ValueError:
        print("Error: use a small GET/HEAD HTTP/1.1 request with unique headers and Host.")
        return 2
    print(f"Method: {method}")
    print(f"Target: {target}")
    print(f"Host: {headers['host']}")
    print(f"Headers: {len(headers)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
