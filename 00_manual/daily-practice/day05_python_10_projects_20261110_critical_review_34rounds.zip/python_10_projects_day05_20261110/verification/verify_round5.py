"""34 distinct, evidence-linked critical review passes (stdlib only).
This is not 34 independent human full-manual readings. The 30 project-specific
cases were selected following source and instructional-text review. Every case
is executed against real code and cross-checked with its manual explanation.
"""
import ast
from collections import Counter
from html import unescape
from html.parser import HTMLParser
import json
from pathlib import Path
import subprocess
import sys
import tempfile

ROOT=Path(__file__).resolve().parents[1]
MANUAL=(ROOT/'python_10_projects_day05_manual.html').read_text('utf-8')
TEXT=unescape(MANUAL)
PROJECTS=sorted((ROOT/'projects').glob('*.py'))
CASES=json.loads((ROOT/'verification/round5_thirty_critical_cases.json').read_text('utf-8'))
sys.path.insert(0,str(ROOT/'tests'))
from test_materials import Manual

class Inspect(HTMLParser):
    def __init__(self):
        super().__init__()
        self.all_ids=[]
        self.local=[]
        self.external=[]
        self.critical=[]
        self.feed(MANUAL)
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if attrs.get('id'):
            self.all_ids.append(attrs['id'])
        if tag=='a' and attrs.get('href','').startswith('#'):
            self.local.append(attrs['href'][1:])
        if tag in ('img','script','iframe') and attrs.get('src'):
            self.external.append(attrs['src'])
        if tag=='div' and 'critical-review' in attrs.get('class','').split():
            self.critical.append(attrs.get('id'))
        if tag=='section' and 'critical-review' in attrs.get('class','').split():
            self.critical.append(attrs.get('id'))

def evidence_case(row):
    with tempfile.TemporaryDirectory() as tmp:
        base=Path(tmp)
        (base/'samples').mkdir();(base/'practice').mkdir()
        for original in (ROOT/'samples').iterdir():
            if original.is_file():(base/'samples'/original.name).write_bytes(original.read_bytes())
        for file,body in row['prepared'].items():
            (base/file).write_bytes(body.encode('ascii'))
        result=subprocess.run([sys.executable,str(PROJECTS[row['project']-1]),*row['args']],
                              input=row['stdin'],text=True,capture_output=True,cwd=base,timeout=12)
        assert (result.returncode,result.stdout,result.stderr)==(row['exit'],row['stdout'],row['stderr'])
        if row['created']:
            assert (base/row['args'][1]).read_text('utf-8')==row['created']
        assert f'id="critical-case-{row["round"]:02d}"' in MANUAL
        assert row['reason'] in TEXT
        assert row['stdout'].rstrip() in TEXT
        assert len(row['reason'])>=15
        return {'exit':result.returncode,'stdout_last':result.stdout.splitlines()[-1],
                'reason_length':len(row['reason']),'prepared_files':list(row['prepared'])}

def integrities():
    doc=Manual(MANUAL)
    assert len(PROJECTS)==10
    assert len(doc.chapters)==20 and len(doc.steps)==40
    for project,file in enumerate(PROJECTS,1):
        source=file.read_bytes()
        assert source.isascii() and b'\t' not in source
        ast.parse(source.decode('ascii'),feature_version=(3,10))
        assert source==doc.code[f'src{project:02d}'].encode('ascii')
        assert source==''.join(doc.code[f'p{project:02d}-chunk{k}'] for k in range(1,5)).encode('ascii')
    return {'projects':10,'chapters':20,'steps':40,'python_parse':'3.10 grammar'}

def explanations():
    doc=Manual(MANUAL)
    lines=0
    for project,file in enumerate(PROJECTS,1):
        expected={str(i):line for i,line in enumerate(file.read_text('ascii').splitlines(),1) if line.strip()}
        for scope in ('full','steps'):
            rows=[row for context,row in doc.rows if context and (context==f'full-{project:02d}' if scope=='full' else context.startswith(f'p{project:02d}-step'))]
            assert len(rows)==len(expected)
            for num,code,description in rows:
                assert expected.get(num)==code and len(description.strip())>3
                lines+=1
    return {'explained_line_occurrences':lines,'two_scopes':'individual steps and source appendix'}

def architecture():
    d=Inspect()
    assert len(d.all_ids)==len(set(d.all_ids))
    assert all(id in set(d.all_ids) for id in d.local)
    assert len(d.critical)==10 and not d.external
    assert 'class="tool-purpose"' in MANUAL
    assert all(f'id="critical-{n:02d}"' in MANUAL for n in range(1,11))
    assert len(CASES)==30 and all(r['round']==i for i,r in enumerate(CASES,1))
    assert all(code.isascii() for code in Manual(MANUAL).code.values())
    return {'unique_ids':len(d.all_ids),'local_anchors':len(d.local),'critical_sections':len(d.critical),'external_assets':len(d.external)}

def cross_product_semantics():
    p01=[r for r in CASES if r['project']==1]
    assert [r['stdout'].splitlines()[0] for r in p01[:2]]==['Check digit: 1','Check digit: 1']
    assert p01[0]['stdout']!=p01[1]['stdout']
    assert '\u5b89\u5b9a\u6027\u3092\u5b9f\u8a3c\u3059\u308b\u3053\u3068\u306f\u3067\u304d\u307e\u305b\u3093' in TEXT
    assert 'Host\u306b\u7a7a\u767d\u304c\u3042\u308b\u5024' in TEXT
    assert '99.9%' in TEXT
    assert sum(r['exit']==2 for r in CASES)==7
    assert (ROOT/'README.txt').read_text('ascii').count('critical_review_34rounds.zip')==1
    assert all(f'python3 projects/{p.name}' in (ROOT/'README.txt').read_text('ascii') for p in PROJECTS)
    return {'luhn_transposition':'09/90 share check digit 1','invalid_input_cases':7,
            'documents_stability_observability':True,'http_host_limit':True,'readme_commands':10}

reviews=[]
for row in CASES:
    try:
        extra=evidence_case(row)
        reviews.append({'round':row['round'],'project':row['project'],'focus':row['title'],
                        'question':row['hypothesis'],'result':'PASS','evidence':extra})
    except Exception as exc:
        reviews.append({'round':row['round'],'project':row['project'],'focus':row['title'],
                        'result':'FAIL','error':repr(exc)})
    print(f"{reviews[-1]['round']:02d}/34 {reviews[-1]['result']}: {row['title']}",flush=True)
for index,(name,fn) in enumerate([('Complete source vs four steps and appendix',integrities),
                                  ('Line-by-line explanatory coverage',explanations),
                                  ('Manual navigation and self-contained offline layout',architecture),
                                  ('Cross-project counterexamples and user instructions',cross_product_semantics)],31):
    try:
        details=fn()
        reviews.append({'round':index,'focus':name,'result':'PASS','evidence':details})
    except Exception as exc:
        reviews.append({'round':index,'focus':name,'result':'FAIL','error':repr(exc)})
    print(f'{index:02d}/34 {reviews[-1]["result"]}: {name}',flush=True)
summary={'method':'Thirty independently designed, source-reviewed boundary/counterexample experiments plus four cross-material consistency reviews. Each of the thirty experiments reruns the real completed program and checks text against the exact manual answer. Not 34 word-by-word human readings.',
         'passes':len(reviews),'passed':sum(r['result']=='PASS' for r in reviews),
         'failed':sum(r['result']=='FAIL' for r in reviews),'results':reviews}
(ROOT/'verification/round5_34_distinct_reviews.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print('SUMMARY',summary['passed'],'/',summary['passes'],flush=True)
raise SystemExit(bool(summary['failed']))
