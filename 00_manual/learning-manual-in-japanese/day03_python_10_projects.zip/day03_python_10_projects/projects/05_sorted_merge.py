import sys


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 05_sorted_merge.py left right")
        return 2
    lists = []
    for text in sys.argv[1:]:
        try:
            if len(text) > 40:
                raise ValueError
            values = []
            for part in text.split(","):
                value = int(part)
                if not -99 <= value <= 99:
                    raise ValueError
                values.append(value)
            if not 1 <= len(values) <= 8:
                raise ValueError
            if values != sorted(values):
                raise ValueError
        except ValueError:
            print("Error: each list needs 1-8 sorted integers from -99 to 99.")
            return 2
        lists.append(values)
    left, right = lists
    i = 0
    j = 0
    merged = []
    while i < len(left) and j < len(right):
        if left[i] <= right[j]:
            merged.append(left[i])
            i += 1
        else:
            merged.append(right[j])
            j += 1
    merged.extend(left[i:])
    merged.extend(right[j:])
    print("Merged:", *merged)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
