#!/usr/bin/env python3
"""Editorial revision of attached v6 source. No external sources or older editions."""
import ast, collections, html, json, re, hashlib
from pathlib import Path
from bs4 import BeautifulSoup
from editorial_notes import NOTES
W=Path('/mnt/data/neon_v10_work')
R=W/'NEON_RIFT_v4_第6次40周精読校訂版'
P=R/'NEON_RIFT_v4_開発マニュアル_第6次40周精読校訂版.html'
S=BeautifulSoup(P.read_text(encoding='utf-8'), 'lxml')
manifest=json.loads((R/'verification/edit_steps.json').read_text(encoding='utf8'))
refs={str(p.relative_to(R/'reference/neon_rift')):p.read_text(encoding='utf-8').splitlines() for p in (R/'reference/neon_rift').rglob('*.py')}
refs['experiments/movement_probe.py']=(R/'experiments/movement_probe.py').read_text(encoding='utf-8').splitlines()
for _q in (R/'reference/neon_rift').glob('start_*'):
 refs[_q.name]=_q.read_text(encoding='utf-8').splitlines()
index={}
for step in S.select('article.lesson-step'):
 sid=step.get('id','')
 if sid.startswith('probe-step-'):
  file='experiments/movement_probe.py'; rows=step.select('.micro-quiz tr')
 else:
  item=next((x for x in manifest if x['id']==sid),None)
  if not item: continue
  file=item['file'];rows=step.select('.unit-guide tbody tr')
 for tr in rows:
  c=tr.find('td')
  if not c:continue
  m=re.search(r'^L(\d+)$',c.get_text(' ',strip=True).split()[0])
  if not m:continue
  n=int(m.group(1));index[(file,n)]=tr
  if 1<=n<=len(refs[file]):
   code=tr.select_one('code.one-line')
   assert code and (code.get_text().strip()==refs[file][n-1].strip() or (not refs[file][n-1].strip() and code.get_text().strip()=='（空行）')),(file,n,code)

def add_note(tr, text):
 for old in tr.select('.verified-line-note,.editorial-added'):
  old.decompose()
 p=S.new_tag('p',attrs={'class':'verified-line-note editorial-added'})
 strong=S.new_tag('strong');strong.string='実コードに即した読み解き：';p.append(strong);p.append(text)
 # before breakdown and after short action
 anchor=tr.select_one('details.lexeme-breakdown')
 if anchor:anchor.insert_before(p)
 else:tr.find_all('td')[-1].append(p)

for key,note in NOTES.items():
 assert key in index,key
 assert refs[key[0]][key[1]-1].strip(),key
 add_note(index[key],note)

# Rectify concrete misinformation in legacy token-level notes of the movement prototype.
for n in (11,26,27):
 tr=index[('experiments/movement_probe.py',n)]
 if n==11:
  act=tr.select_one('p.meaning-action')
  if act:act.string='この行で起きること：speedへ5を代入。この試作では1回のframe()実行ごとに移動する5pxを意味し、毎秒5pxではない。'
 for li in tr.select('li'):
  t=li.select_one('code');content=t.get_text() if t else ''
  if content in ('speed','5') and 'ピクセル/秒' in li.get_text():
   value='この試作では1回のframe()ごとに5px進む量。完成版のPlayer.speed（px/秒）とは単位が異なる。'
   li.clear();q=S.new_tag('code');q.string=content;li.append(q);li.append('：'+value)
  if n in (26,27) and content in ('min','max'):
   desc=('右端の上限625pxに移動後xを収める' if n==26 else '下端の上限405pxに移動後yを収める') if content=='min' else ('左端の下限15pxに移動後xを収める' if n==26 else '上端の下限15pxに移動後yを収める')
   li.clear();q=S.new_tag('code');q.string=content;li.append(q);li.append('：'+desc+'組込み関数。')
  if n==27 and content=='dy':
   li.clear();q=S.new_tag('code');q.string='dy';li.append(q);li.append('：現在押している上/下キーから計算した垂直方向の符号（上=-1、下=+1、無操作=0）。')

# Replace the vague catch-all explanations of string literals with context-aware descriptions.
STRING_ROLES={
 'playing':'ゲーム進行中を示すstate値。「playing」のときだけ戦闘・移動を更新する。',
 'menu':'タイトルメニュー表示を示すstate値。',
 'paused':'一時停止画面を示すstate値。戦闘用tickを進めない。',
 'upgrade':'ウェーブ間の強化選択を示すstate値。',
 'gameover':'HPが0になった敗北状態を示すstate値。',
 'all':'Tkinter Canvasのすべての図形を指定するタグ。Pythonの識別子や変数allではない。',
 'repair':'HP回復用Pickupのkindを表す識別文字列。',
 'charge':'エネルギー回復用Pickupのkindを表す識別文字列。',
 'hunter':'追跡型敵の種類名。ENEMY_SPECSのキー。',
 'runner':'機動型敵の種類名。ENEMY_SPECSのキー。',
 'gunner':'射撃型敵の種類名。ENEMY_SPECSのキー。',
 'bruiser':'突進型敵の種類名。ENEMY_SPECSのキー。',
 'warden':'5ウェーブごとに登場するボス敵の種類名。ENEMY_SPECSのキー。',
 'best':'最高得点のJSON辞書に格納するキー名。',
 'd':'右移動キーを表すTkinterのkeysym値。',
 'a':'左移動キーを表すTkinterのkeysym値。',
 's':'下移動キーを表すTkinterのkeysym値。',
 'w':'上移動キーを表すTkinterのkeysym値。',
 'right':'右矢印キー名を小文字にした値。',
 'left':'左矢印キー名を小文字にした値。',
 'up':'上矢印キー名を小文字にした値。',
 'down':'下矢印キー名を小文字にした値。',
 'space':'スペースキーでダッシュするための判定用キー名。',
 'escape':'Escキーで一時停止/再開を切り替えるための判定用キー名。',
 'return':'Enterキーを表すkeysym。開始・再開の判定に使用する。',
 'kp_enter':'テンキーのEnterを表すkeysym。',
 'normal':'フォントの太さを通常にする指定値。',
 'center':'Canvasの文字配置の中心を座標に合わせるanchor指定値。',
 'crosshair':'マウスカーソルを十字型へ変更するTkinterの指定文字列。',
 '1':'1番目の強化候補を選択するキー名。',
 '2':'2番目の強化候補を選択するキー名。',
 '3':'3番目の強化候補を選択するキー名。',
 'utf-8':'日本語などを安全に読み書きするためのファイル文字コード指定。',
}
revised_strings=0
for (file,n),tr in index.items():
 src=refs[file][n-1]
 for li in tr.select('.token-notes li'):
  if '画面表示・キー・辞書のID等の値として使用' not in li.get_text():continue
  code=li.select_one('code')
  if not code:continue
  text=code.get_text()
  try:v=ast.literal_eval(text)
  except (SyntaxError,ValueError):continue
  if not isinstance(v,str):continue
  if v in STRING_ROLES and not (v in ('1','2','3','normal','center') and file not in ('renderer.py','game.py','experiments/movement_probe.py')):desc=STRING_ROLES[v]
  elif re.fullmatch(r'#[0-9a-fA-F]{6}',v):desc='Canvas等がRGB色として解釈する「#RRGGBB」形式。%sは赤%s・緑%s・青%sの16進値。'%(v,v[1:3],v[3:5],v[5:7])
  elif file=='constants.py' and n>=33:desc='UPGRADESにある表示名・ユーザー向け説明の文字列。数値を実際に変更する処理はupgrades.py側。'
  elif file=='renderer.py':desc='Canvasの画面に描く文字列、文字設定、または色指定。引用符の内容はPythonの命令として実行されない。'
  elif file=='experiments/movement_probe.py':desc='移動試作で使う画面表示、Canvasのタグ、またはTkイベント名を表す文字列。引用符内は実行されない。'
  elif v=='':desc='長さ0の空文字列。Canvasのoutlineなどの描画属性では、輪郭を描かない指定に使う。'
  elif v.startswith('<') and v.endswith('>'):desc='Tkinterが識別するイベント名。bind()でこの入力の発生時に呼ぶコールバックを登録する。'
  elif file.startswith('tests/'):
   desc='テストで用いる具体的な文字列データ。実装の入力・表示・例外の期待値として比較するため、文字列の内容に意味がある。'
  else:desc='この行で値として使う文字列「%s」。文字列の文字はPythonのキーワードではなく、比較や表示/辞書検索の対象になる。'%v[:60]
  li.clear();cc=S.new_tag('code');cc.string=text;li.append(cc);li.append('：'+desc)
  revised_strings+=1

# Improve generic call descriptions with precise call-site facts where AST single-line works.
CALL_ROLES={
 'assertEqual':'2つの値が等しいことを検証するunittestメソッド',
 'assertTrue':'条件がTrueになることを検証するunittestメソッド',
 'assertFalse':'条件がFalseになることを検証するunittestメソッド',
 'update':'辞書の値の更新またはメソッドによるゲーム状態更新（呼出し対象で区別）',
 'append':'リストの末尾へ1個の要素を追加するメソッド',
 'label':'現在のCanvasに指定座標・文字・書式でテキストを描くRendererの補助メソッド',
 'box':'指定の四隅・塗り・線で長方形を描くRendererの補助メソッド',
 'line':'指定した2点を線で結ぶRendererの補助メソッド',
 'world_circle':'画面揺れ補正を加えた位置に円を描くRendererの補助メソッド',
 'event_generate':'Tkウィジェットへ指定の仮想イベントを発行するテスト/操作用メソッド',
 'update_bullets':'弾の移動、寿命、壁と敵/プレイヤーの連続衝突を更新するCombatMixinのメソッド',
}
revised_calls=0
for (file,n),tr in index.items():
 p=tr.select_one('p.meaning-action')
 if not p or '引数はこの行の括弧内で指定する' not in p.get_text() and 'この行で渡す引数は括弧内に並ぶ' not in p.get_text():continue
 src=refs[file][n-1].strip()
 try:root=ast.parse(src)
 except SyntaxError:continue
 calls=[node for node in ast.walk(root) if isinstance(node,ast.Call)]
 if not calls:continue
 outer=max(calls,key=lambda x:(getattr(x,'end_col_offset',0)-getattr(x,'col_offset',0)))
 name=outer.func.attr if isinstance(outer.func,ast.Attribute) else outer.func.id if isinstance(outer.func,ast.Name) else None
 if name not in CALL_ROLES:continue
 if name=='update':
  callee=ast.unparse(outer.func)
  if callee.startswith(('root.','self.root.')):local_role='Tkの待機イベントを処理し、保留中の画面変更を反映するメソッド'
  elif callee.startswith(('d.','data.','payload.')):local_role='辞書へ別のキーと値を追加・更新するメソッド'
  else:continue
 else:local_role=CALL_ROLES[name]
 args=[ast.unparse(x) for x in outer.args[:5]]
 kws=[f'{x.arg}={ast.unparse(x.value)}' for x in outer.keywords[:6]]
 arg_text='、'.join(args+kws)
 if len(arg_text)>155:arg_text=arg_text[:155]+'…'
 p.string=f'この行で起きること：{local_role}。この呼び出しで実際に渡している値・式：{arg_text or "引数なし"}。'
 revised_calls+=1

# Add source-anchored editorial table in a new standalone section but keep original chapter count and navigation.
home=S.select_one('#home .cover-card') or S.select_one('#home')
insert=S.new_tag('section',attrs={'class':'chapter-body editorial-guide','aria-label':'今回の再校訂で直した典型的な誤解'})
h=S.new_tag('h3');h.string='第7次校訂：コードを読んで初めて分かる7つの注意点';insert.append(h)
topics=[
('試作と完成版の速度単位','試作はspeed=5px/更新。完成版はPlayer.speed=278px/秒で位置 += 速度×dt。試作の5を5px/秒と説明すると学習者の理解を壊す。'),
('importと変数への代入','import tkinter as tkはtkinterモジュールをtkという名前で利用可能にする。root=tk.Tk()のrootはTkウィンドウへの参照を受け取る代入先であり、キーワード引数ではない。'),
('描画と当たり判定は別','Rendererのworld_circleは見た目を描くが、実際の命中はmechanics.moving_circle_hitで位置と半径を使って計算する。エフェクトの輪の半径と命中半径は同一とは限らない。'),
('時間を指定する予約と固定tick','root.afterは最短の予約をするだけで正確な実行間隔を保証しない。Game.loopはperf_counterで実時間を測り、1/60秒のtickを繰り返す。'),
('弾が発射された瞬間の処理順','生成したBullet(fresh=True)は当該tickでは飛ばさず、次のtickから移動・当たり判定する。生成前の敵移動をさかのぼって命中させない。'),
('最高得点の表示値と保存成功値','Game.bestはメモリ内の最高点、_saved_bestはディスクへ保存成功した最高点。保存に失敗したら差が残り、次の保存機会に再試行する。'),
('関数の引数と返り値、副作用','pop(0)は先頭の敵名を返すだけでなくpendingから削除する。apply_to_playerはNoneを返すがPlayerの属性を書き換える。値を返さない処理もゲーム状態を変える。')]
ul=S.new_tag('ul')
for title,text in topics:
 li=S.new_tag('li');b=S.new_tag('strong');b.string=title;li.append(b);li.append('：'+text);ul.append(li)
insert.append(ul);home.append(insert)

# Remove older explanatory paragraphs when a more precise source-anchored note replaces them.
removed_repetition=0
for _tr in S.select('tr:has(.editorial-added):has(.meaning-deep)'):
 for _old in _tr.select('p.meaning-deep'):
  _old.decompose();removed_repetition+=1

# Semantically neutral CSS visual improvements: source explanations can wrap without stretching the layout.
css=S.find('style')
if css:
 css.append('\n/* Editorial revision: information density without horizontal overflow. */\n.editorial-guide{border-left:4px solid var(--teal);margin-top:24px}.editorial-guide li{margin:12px 0}.editorial-added{background:rgba(30,77,83,.22);padding:10px 14px;border-left:3px solid var(--lime);line-height:1.8}.token-notes li{margin:.36em 0;overflow-wrap:anywhere}.unit-guide td,.micro-quiz td{vertical-align:top}.unit-guide .one-line{white-space:pre-wrap;overflow-wrap:anywhere}@media(max-width:900px){.editorial-added{padding:9px 11px}}@media print{.editorial-added{background:#fff!important;color:#111!important}}\n')
# Update only version labels in cover; do not alter game version v4.
if S.title:S.title.string='NEON RIFT v4 ゼロから作るGUIゲーム開発マニュアル 第7次説明精査'
header=S.select_one('.brand-ver')
if header:header.string='v4 / 説明第7次'
report={"authored_source_line_notes":len(NOTES),"specific_source_file_count":len({f for f,_ in NOTES}),"generic_string_descriptions_replaced":revised_strings,"generic_call_descriptions_replaced":revised_calls,"source_files_modified":0,"new_reading_pitfalls":len(topics),"redundant_old_paragraphs_removed":removed_repetition}
out=W/'NEON_RIFT_v4_開発マニュアル_第7次具体解説40周再校訂版.html'
out.write_text(str(S),encoding='utf-8')
(W/'editorial_revision.json').write_text(json.dumps(report,indent=2,ensure_ascii=False),encoding='utf-8')
print(out,out.stat().st_size,report)
