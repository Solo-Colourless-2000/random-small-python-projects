import base64
import binascii
import sys

CASES = {"normal": "Basic YWxpY2U6REVNTw==", "colon": "Basic YWxpY2U6REVNTzox", "broken": "Basic ???", "wrong": "Bearer LAB"}


def decode(header):
    scheme, encoded = header.split(" ", 1)
    if scheme.lower() != "basic":
        raise ValueError("Wrong scheme.")
    text = base64.b64decode(encoded, validate=True).decode("ascii")
    user, separator, password = text.partition(":")
    if not separator:
        raise ValueError("Missing separator.")
    return user, password


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script normal|colon|broken|wrong", file=sys.stderr)
        return 2
    try:
        user, password = decode(CASES[sys.argv[1]])
    except (ValueError, binascii.Error):
        print("Invalid lab Basic header.", file=sys.stderr)
        return 2
    print(f"User: {user}")
    print(f"Password: {password}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
