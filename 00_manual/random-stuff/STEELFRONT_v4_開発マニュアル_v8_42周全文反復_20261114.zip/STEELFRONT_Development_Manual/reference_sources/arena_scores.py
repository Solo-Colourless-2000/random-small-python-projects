"""Small, dependency-free, crash-resistant personal best record persistence."""
from __future__ import annotations
import json
import os
from pathlib import Path
import tempfile

MAX_RECORD = 99_999_999
MAX_WAVE = 9_999

def read_best(path: Path) -> tuple[int,int]:
    try:
        data = json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(data, dict):
            return 0, 0
        score = min(MAX_RECORD, max(0, int(data.get('high_score', 0))))
        wave = min(MAX_WAVE, max(0, int(data.get('best_wave', 0))))
        return score, wave
    except (OSError, ValueError, TypeError, OverflowError):
        return 0, 0

def write_best(path: Path, score: int, wave: int) -> bool:
    """Replace save atomically; never leave a half-written existing save."""
    temp_name = None
    try:
        with tempfile.NamedTemporaryFile(mode='w', encoding='utf-8',
                dir=path.parent, prefix='.steelfront-', suffix='.tmp',
                delete=False) as tmp:
            temp_name = tmp.name
            json.dump({'high_score': min(MAX_RECORD, max(0, int(score))),
                       'best_wave': min(MAX_WAVE, max(0, int(wave)))}, tmp)
            tmp.flush()
            os.fsync(tmp.fileno())
        os.replace(temp_name, path)
        return True
    except (OSError, ValueError, TypeError, OverflowError):
        return False
    finally:
        if temp_name is not None:
            try:
                os.unlink(temp_name)
            except FileNotFoundError:
                pass
            except OSError:
                pass
