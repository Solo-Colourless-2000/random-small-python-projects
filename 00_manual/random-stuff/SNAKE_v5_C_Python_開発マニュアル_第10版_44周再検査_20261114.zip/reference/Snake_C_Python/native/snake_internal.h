#ifndef SNAKE_INTERNAL_H
#define SNAKE_INTERNAL_H

#include "snake.h"

/* Engine state is private to native sources. Python sees only snake.h. */
#define SNAKE_MIN_SIDE 8
#define SNAKE_MAX_SIDE 64
#define SNAKE_START_LENGTH 4
#define SNAKE_TURN_BUFFER_SIZE 2

struct SnakeGame {
    int width;
    int height;
    int capacity;
    SnakeCell *body; /* Head at index 0. */
    int length;
    int food_x;
    int food_y;
    int score;
    int direction;
    int pending[SNAKE_TURN_BUFFER_SIZE];
    int pending_count;
    int status;
    uint32_t rng;
};

/* Called only with valid game state; no external ABI exposure. */
void snake_place_food(SnakeGame *game);

#endif
