"""Standalone grid and input experiment. Not part of the Snake game."""
import tkinter as tk

CELL = 28
COLS = 12
ROWS = 8

root = tk.Tk()
root.title("Snake learning lab / grid probe")
canvas = tk.Canvas(root, width=COLS * CELL, height=ROWS * CELL,
                   bg="#102127", highlightthickness=0)
canvas.pack()
position = [COLS // 2, ROWS // 2]


def draw() -> None:
    canvas.delete("all")
    for x in range(COLS + 1):
        canvas.create_line(x * CELL, 0, x * CELL, ROWS * CELL, fill="#254047")
    for y in range(ROWS + 1):
        canvas.create_line(0, y * CELL, COLS * CELL, y * CELL, fill="#254047")
    x, y = position
    canvas.create_rectangle(x * CELL + 2, y * CELL + 2,
                            (x + 1) * CELL - 2, (y + 1) * CELL - 2,
                            fill="#b7eb68", outline="")


def on_key(event: tk.Event) -> None:
    moves = {"Up": (0, -1), "Right": (1, 0),
             "Down": (0, 1), "Left": (-1, 0)}
    dx, dy = moves.get(event.keysym, (0, 0))
    position[0] = max(0, min(COLS - 1, position[0] + dx))
    position[1] = max(0, min(ROWS - 1, position[1] + dy))
    draw()


root.bind("<KeyPress>", on_key)
draw()
root.after_idle(root.focus_set)
root.mainloop()
