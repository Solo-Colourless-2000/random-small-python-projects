"""Run 38 distinct, documented checks of the day07 revised package."""
import ast
from collections import Counter
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import shutil
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
MANUAL = ROOT / 'python_10_projects_day07_manual.html'
PROJECTS = sorted((ROOT / 'projects').glob('*.py'))
TESTS = sorted((ROOT / 'tests').glob('*.py'))
SYNTAX = re.compile(r'class="line-breakdown"')

class Page(HTMLParser):
    def __init__(self, content):
        super().__init__(convert_charrefs=True)
        self.ids = Counter()
        self.links = []
        self.chapters = []
        self.checks = []
        self.code = None
        self.codes = {}
        self.lines = {}
        self.scripts = []
        self.assets = []
        self.feed(content)
        self.close()

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if a.get('id'):
            self.ids[a['id']] += 1
        if tag == 'a' and a.get('href', '').startswith('#'):
            self.links.append(a['href'][1:])
        if tag == 'section' and 'chapter' in a.get('class', '').split():
            self.chapters.append(a.get('id'))
        if tag == 'input' and 'data-check' in a:
            self.checks.append(a['data-check'])
        if tag == 'code' and a.get('data-kind'):
            self.code = a.get('id')
            self.codes[self.code] = ''
            self.lines[self.code] = []
        if tag == 'span' and self.code and 'data-line' in a:
            self.lines[self.code].append(int(a['data-line']))
        if tag in {'script', 'iframe', 'img'} and 'src' in a:
            self.assets.append(a['src'])
        if tag == 'link' and a.get('rel') == 'stylesheet':
            self.assets.append(a.get('href'))

    def handle_data(self, data):
        if self.code:
            self.codes[self.code] += data

    def handle_endtag(self, tag):
        if tag == 'code':
            self.code = None


def check_all(predicate, evidence):
    assert all(predicate(path) for path in PROJECTS)
    return evidence


def check(cond, evidence):
    assert cond, evidence
    return evidence


def round_one_to_ten(n, text, page):
    path = PROJECTS[n - 1]
    num = f'{n:02}'
    src = path.read_text(encoding='ascii')
    joined = ''.join(page.codes[f'step-{num}-{step}'] for step in range(1, 5))
    assert joined == src
    assert page.codes[f'src-{num}'] == src
    indexes = [i for i, line in enumerate(src.splitlines(), 1) if line.strip()]
    assert len(indexes) >= 19
    assert len(page.lines[f'src-{num}']) == len(src.splitlines())
    for index in indexes:
        assert f'#src-{num}-L{index}' in text
    assert f'aria-label="Project {num}of' not in text
    return f'{path.name}: 4 steps, complete appendix, {len(indexes)} linked lines'


def run():
    passes = []
    original = json.loads((ROOT / 'verification' / 'original_sha256.json').read_text())
    revised_cli = json.loads((ROOT / 'verification' / 'revision_cli_observations.json').read_text())
    browser = json.loads((ROOT / 'verification' / 'revision_browser_observations.json').read_text())
    sys.path.insert(0, str(ROOT / 'tests'))
    from cases import CASES

    def add(name, runner):
        # Re-read the actual deliverables on every pass.
        text = MANUAL.read_text(encoding='utf-8')
        source = {p.name: p.read_bytes() for p in PROJECTS}
        tests = {p.name: p.read_bytes() for p in TESTS}
        page = Page(text)
        assert len(source) == 10 and len(tests) >= 3
        detail = runner(text, source, page)
        passes.append({'round': len(passes) + 1, 'focus': name, 'status': 'PASS', 'evidence': str(detail)})

    for n in range(1, 11):
        add(f'Project {n:02}: source, four steps, appendix and line references',
            lambda text, src, page, n=n: round_one_to_ten(n, text, page))

    add('Original byte-for-byte source preservation',
        lambda text, src, page: check(all(hashlib.sha256(raw).hexdigest() == original[name] for name, raw in src.items()), '10 original source hashes match'))
    add('ASCII source code and LF line endings',
        lambda text, src, page: check(all(raw.isascii() and b'\r' not in raw for raw in src.values()), '10 sources ASCII and LF'))
    add('Python 3.10-compatible source grammar',
        lambda text, src, page: check(all(ast.parse(raw.decode('ascii'), filename=name, feature_version=(3, 10)) for name, raw in src.items()), '10 AST parses'))
    add('All nonempty source lines have a breakdown',
        lambda text, src, page: check(len(SYNTAX.findall(text)) == sum(sum(bool(line.strip()) for line in raw.decode('ascii').splitlines()) for raw in src.values()) == 245, '245 of 245 annotated'))
    add('Code line counts and positions are continuous',
        lambda text, src, page: check(all(page.lines[f'src-{i:02}'] == list(range(1, len(PROJECTS[i-1].read_text().splitlines())+1)) for i in range(1, 11)), 'all 10 appendix line indexes match'))
    add('40 code chunks exactly preserve sources',
        lambda text, src, page: check(all(''.join(page.codes[f'step-{i:02}-{j}'] for j in range(1, 5)).encode() == PROJECTS[i-1].read_bytes() for i in range(1, 11)), '40 chunks join to 10 originals'))
    add('10 appendix code sections exactly preserve sources',
        lambda text, src, page: check(all(page.codes[f'src-{i:02}'].encode() == PROJECTS[i-1].read_bytes() for i in range(1, 11)), '10 complete appendix copies'))
    add('10 guided code-reading sections',
        lambda text, src, page: check(text.count('class="reader-guide"') == 10, '10 guided before-you-code walkthroughs'))
    add('10 explicit common-pitfall explanations',
        lambda text, src, page: check(text.count('\u9593\u9055\u3048\u3084\u3059\u3044\u70b9\uff1a') == 10, '10 individualized pitfalls'))
    add('10 independent learner self-checks',
        lambda text, src, page: check(text.count('\u624b\u3092\u52d5\u304b\u3057\u3066\u78ba\u8a8d\uff1a') == 10, '10 understanding prompts'))
    add('XML post-parse DTD label accurately qualified',
        lambda text, src, page: check('\u89e3\u6790\u5f8c\u306e\u8868\u793a\u3060\u3051' in text and 'DTD\u3092\u89e3\u6790\u524d\u306b\u62d2\u5426\u3059\u308b\u51e6\u7406\u3067\u306f\u306a\u3044' in text, 'explicit non-enforcement warning'))
    add('Pickle disassembly limitations documented',
        lambda text, src, page: check('\u4efb\u610f\u306e\u58ca\u308c\u305fpickle' in text and 'pickle.loads' in text, 'no unsafe deserialization claim'))
    add('Python int Unicode decimal input caveat',
        lambda text, src, page: check('Unicode\u5341\u9032\u6570\u5b57' in text, 'not misrepresented as ASCII-only parsing'))
    add('Template minimal context limitations documented',
        lambda text, src, page: check('\u5b89\u5168\u6027\u4fdd\u8a3c\u3067\u306f\u306a\u3044' in text and 'MINIMAL' in text, 'minimum context is not sandboxing'))
    add('All 20 chapters and completion checkboxes retained',
        lambda text, src, page: check(len(page.chapters) == len(page.checks) == 20 and page.chapters == page.checks, '20 chapters / 20 checks'))
    add('Internal anchor targets are unique',
        lambda text, src, page: check(all(n == 1 for n in page.ids.values()), f'{len(page.ids)} unique ids'))
    add('All internal anchors resolve',
        lambda text, src, page: check(set(page.links) <= set(page.ids), f'{len(page.links)} valid internal links'))
    add('No external script, image or CSS assets',
        lambda text, src, page: check(not page.assets, 'zero remote assets'))
    add('Responsive small-screen and print CSS',
        lambda text, src, page: check('@media (max-width: 720px)' in text and '@media (max-width: 850px)' in text and '@media print' in text, '720px / 850px / print CSS'))
    add('Search, progress and focus controls remain present',
        lambda text, src, page: check(all(f'id="{name}"' in text for name in ('search','progress','focus','wrap','smaller','larger','clear-search')), 'seven visible controls and states'))
    add('Source and appendix search indexing remains present',
        lambda text, src, page: check(text.count('data-find') > 500 and 'querySelectorAll("[data-find]")' in text, 'full-text lookup markers'))
    add('Original README execution steps retained',
        lambda text, src, page: check('python3 -m unittest discover -s tests -v' in (ROOT/'README.txt').read_text() and 'vim practice/01_query_pollution.py' in (ROOT/'README.txt').read_text(), 'CLI and vim instructions'))
    add('Project history keeps day07 and next day08',
        lambda text, src, page: check((lambda h: h['last_completed_volume'] == 7 and h['next_volume'] == 8 and len(h['projects']) == 70)(json.loads((ROOT/'PROJECT_HISTORY.json').read_text())), '70 project history entries, next day08'))
    add('New CLI transcript agrees with 62 expected case outputs',
        lambda text, src, page: check(all((r['args'], r['returncode'], r['stdout'], r['stderr']) == expected for name, cases in CASES.items() for r, expected in zip(revised_cli[name], cases)) and sum(map(len, revised_cli.values())) == 62, '62/62 real subprocess outputs matched'))
    add('Python import execution safety boundaries',
        lambda text, src, page: check(not any(b'pickle.loads(' in raw or b'eval(' in raw or b'exec(' in raw for raw in src.values()), 'no pickle.loads / eval / exec in projects'))
    add('Browser desktop and mobile widths checked',
        lambda text, src, page: check(all(browser[str(width)]['document_overflow']['document'] == width for width in (1280, 390, 320)), '1280px, 390px and 320px no document overflow'))
    add('Browser search, font, wrap and focus verified',
        lambda text, src, page: check(all(browser[str(w)]['wrap_enabled'] and browser[str(w)]['focus_enabled'] and browser[str(w)]['font_scale'] == '1.05' for w in (1280,390,320)), 'UI controls operated at 3 widths'))
    add('Browser keyboard, copy and no-JS verification',
        lambda text, src, page: check((lambda b: b['ctrl_k_focus'] and b['search_count_has_number'] and b['no_js_20_sections_shown'] and b['no_js_page_errors'])(browser['extras']), 'Ctrl+K, search, 20 JS-off chapters'))
    assert len(passes) == 38, len(passes)
    report = {'document':'day07 revised manual','review_rounds':len(passes), 'passed':len(passes),'failed':0,'rounds':passes}
    (ROOT/'verification'/'revision_review_38_passes.json').write_text(json.dumps(report,ensure_ascii=False,indent=2)+'\n', encoding='utf-8')
    print('Review passes:', len(passes), 'Passed:',len(passes))
    for entry in passes:
        print(f"{entry['round']:02} {entry['focus']}: {entry['evidence']}")

if __name__ == '__main__':
    run()
