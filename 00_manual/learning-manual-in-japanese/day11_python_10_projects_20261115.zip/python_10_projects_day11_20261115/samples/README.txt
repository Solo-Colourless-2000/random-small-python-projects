All fixtures are embedded in individual scripts. No external sample files are required.
