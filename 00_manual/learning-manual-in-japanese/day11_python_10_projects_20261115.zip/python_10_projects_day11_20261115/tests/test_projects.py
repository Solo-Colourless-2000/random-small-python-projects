from contextlib import redirect_stdout, redirect_stderr
import getopt
from io import BytesIO, StringIO
import importlib.util
import ipaddress
import itertools
from pathlib import Path
import re
import sqlite3
import subprocess
import sys
import threading
import unittest
from unittest.mock import patch
import warnings

from cases import CASES

ROOT = Path(__file__).resolve().parents[1]


def load(index):
    path = sorted((ROOT / "projects").glob("*.py"))[index - 1]
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


class ProjectTests(unittest.TestCase):
    def test_options_are_not_filenames_until_separated(self):
        m = load(1)
        self.assertEqual(m.inspect_argument("--debug"), ([("--debug", "")], [], [], ["--debug"]))
        for name in ("note.txt", "", "--debug", "--deb"):
            self.assertEqual(m.inspect_argument(name)[2:], ([], [name]))
        with self.assertRaises(getopt.GetoptError):
            m.inspect_argument("--missing")

    def test_crlf_and_lf_have_different_parse_results(self):
        m = load(2)
        self.assertEqual(m.inspect_value(b"ok\r\nX-Admin: yes"), (2, True, False))
        self.assertEqual(m.inspect_value(b"X-Admin: yes"), (1, False, True))
        for value in (b"\r", b"\n", b"\r\n"):
            self.assertFalse(m.inspect_value(value)[2])
        self.assertEqual(m.inspect_value(b""), (1, False, True))

    def test_xml_prefix_is_not_namespace_identity(self):
        m = load(3)
        for prefix in ("a", "b"):
            text = f'<r xmlns:{prefix}="urn:lab"><{prefix}:role>admin</{prefix}:role></r>'
            self.assertEqual(m.inspect_xml(text), (True, True))
        self.assertEqual(m.inspect_xml('<r xmlns="urn:other"><role>admin</role></r>'), (True, False))
        self.assertEqual(m.inspect_xml('<r xmlns="urn:lab"><role>user</role></r>'), (False, False))
        self.assertEqual(m.inspect_xml('<r xmlns="urn:lab"><x><role>admin</role></x></r>'), (False, False))

    def test_zip_member_selection_and_scoped_warning_filter(self):
        m = load(4)
        with warnings.catch_warnings(record=True) as observed:
            warnings.simplefilter("always")
            self.assertEqual(m.inspect_archive(True), (b"mode=safe", b"mode=debug", False))
            warnings.warn("sentinel", UserWarning)
            self.assertEqual([str(item.message) for item in observed], ["sentinel"])
        self.assertEqual(m.inspect_archive(False), (b"mode=safe", b"mode=safe", True))
        memories = []
        def tracked_memory():
            memory = BytesIO()
            memories.append(memory)
            return memory
        with patch.object(m, "BytesIO", tracked_memory):
            m.inspect_archive(True)
        self.assertTrue(all(memory.closed for memory in memories))


    def test_acl_all_last_octets_against_declared_policy(self):
        m = load(5)
        address = ipaddress.ip_address
        for last in range(256):
            target = address(f"10.0.0.{last}")
            self.assertEqual(m.decide(target, m.RULES), "allow")
            expected = "deny" if last == 7 else "allow"
            self.assertEqual(m.decide(target, m.RULES[::-1]), expected)
        for target in ("9.255.255.255", "10.0.1.0", "10.0.1.255"):
            self.assertEqual(m.decide(address(target), m.RULES), "deny")
        self.assertEqual(m.decide(address("10.0.0.7"), ()), "deny")

    def test_regex_partition_count_uses_independent_cut_masks(self):
        m = load(6)
        for size in range(1, 9):
            cuts = list(itertools.product((False, True), repeat=size - 1))
            self.assertEqual(m.partitions(size), len(cuts))
            self.assertIsNone(re.fullmatch("(a+)+", "a" * size + "!"))
            self.assertIsNotNone(re.fullmatch("a+", "a" * size))
        self.assertEqual(m.partitions(0), 1)

    def test_snapshot_shared_mutation_and_fresh_state(self):
        m = load(7)
        self.assertEqual(m.capture(False, True), (True, "admin", "admin"))
        self.assertEqual(m.capture(True, True), (False, "user", "admin"))
        self.assertEqual(m.capture(False, False), (True, "user", "user"))
        self.assertEqual(m.capture(True, False), (False, "user", "user"))
        self.assertEqual(m.capture(False, True), (True, "admin", "admin"))

    def test_transaction_rollback_conservation_and_close(self):
        m = load(8)
        real_connect = sqlite3.connect
        connections = []
        def tracked(*args, **kwargs):
            db = real_connect(*args, **kwargs)
            connections.append(db)
            return db
        with patch.object(m.sqlite3, "connect", tracked):
            self.assertEqual(m.stopped_transfer(False), (40, 60))
            self.assertEqual(m.stopped_transfer(True), (30, 60))
            self.assertEqual(m.stopped_transfer(False), (40, 60))
        for db in connections:
            with self.assertRaises(sqlite3.ProgrammingError):
                db.execute("SELECT 1")
        stdout, stderr = StringIO(), StringIO()
        with patch.object(m.sys, "argv", ["script", "atomic"]), patch.object(m.sqlite3, "connect", side_effect=sqlite3.OperationalError("lab failure")), redirect_stdout(stdout), redirect_stderr(stderr):
            self.assertEqual(m.main(), 1)
        self.assertEqual((stdout.getvalue(), stderr.getvalue()), ("", "Database lab failed.\n"))

    def test_udp_payload_counts_cleanup_and_failure_status(self):
        m = load(9)
        before = {id(t) for t in threading.enumerate()}
        self.assertEqual(m.exchange(b"Q"), (1, 60))
        self.assertEqual(m.exchange(b"Q" * 60), (60, 60))
        with self.assertRaises(OSError):
            m.exchange(b"?")
        self.assertEqual({id(t) for t in threading.enumerate()}, before)
        stdout, stderr = StringIO(), StringIO()
        with patch.object(m.sys, "argv", ["script", "small"]), patch.object(m.socket, "socket", side_effect=OSError("lab failure")), redirect_stdout(stdout), redirect_stderr(stderr):
            self.assertEqual(m.main(), 1)
        self.assertEqual((stdout.getvalue(), stderr.getvalue()), ("", "Loopback UDP lab failed.\n"))

    def test_short_read_assembly_all_lengths_and_eof(self):
        m = load(10)
        for size in range(9):
            body = b"A" * size
            packet = bytes([size]) + body
            self.assertEqual(m.frame(packet, True), body)
            self.assertEqual(m.frame(packet, False), body[:1])
        for packet in (b"", b"\x03LA", b"\x09ABCDEFGHI"):
            with self.assertRaises((EOFError, ValueError)):
                m.frame(packet, True)
        with BytesIO(b"XYZ") as stream:
            self.assertEqual(m.read_exact(stream, 0), b"")
            self.assertEqual(m.read_exact(stream, 3), b"XYZ")
            with self.assertRaises(EOFError):
                m.read_exact(stream, 1)


def cli_test(name, cases):
    def test(self):
        for args, code, stdout, stderr in cases:
            with self.subTest(args=args):
                result = subprocess.run([sys.executable, str(ROOT / "projects" / (name + ".py")), *args],
                                        input="", capture_output=True, text=True, timeout=7)
                self.assertEqual((result.returncode, result.stdout, result.stderr), (code, stdout, stderr))
    return test


for name, cases in CASES.items():
    setattr(ProjectTests, "test_cli_" + name, cli_test(name, cases))
