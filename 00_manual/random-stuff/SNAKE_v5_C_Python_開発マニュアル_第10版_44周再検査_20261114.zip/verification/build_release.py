from pathlib import Path
import hashlib,zipfile,os
R=Path(__file__).resolve().parent.parent
out=Path('/mnt/data/SNAKE_v5_C_Python_開発マニュアル_第10版_44周再検査_20261114.zip')
keep=[]
for p in R.rglob('*'):
 if not p.is_file():continue
 rel=p.relative_to(R)
 if '__pycache__' in rel.parts or '.pytest_cache' in rel.parts or rel.name.endswith(('.pyc','.pyo','.so','.dylib','.dll')) or rel.name=='SHA256SUMS.txt':continue
 if rel.as_posix().startswith('verification/__'):continue
 keep.append((rel.as_posix(),p))
keep.sort()
sh=R/'SHA256SUMS.txt'
sh.write_text(''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {rel}\n' for rel,p in keep),encoding='utf8')
keep.append(('SHA256SUMS.txt',sh))
with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=8) as z:
 for rel,p in keep:z.write(p,arcname=rel)
with zipfile.ZipFile(out) as z:
 err=z.testzip()
 assert not err,err
 names=z.namelist()
 assert len(names)==len(set(names))
 assert 'README_最初に読んでください.txt' in names
 assert any(n.endswith('.html') for n in names)
 for line in z.read('SHA256SUMS.txt').decode('utf8').splitlines():
  sha,name=line.split('  ',1)
  assert hashlib.sha256(z.read(name)).hexdigest()==sha,name
 print(f'{out}\nfiles {len(names)} verified hashes {len(names)-1} zip_bytes {out.stat().st_size}')
