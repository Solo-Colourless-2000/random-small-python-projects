# SNAKE | C + Python（重点再レビュー Ver.5）

C言語でゲームの状態とルールを管理し、Python標準ライブラリのTkinterで描画・入力を担当するスネークゲームです。ソースコード、ビルド処理、テスト、画面画像を含みます。**Pythonの外部パッケージは不要**です。

![プレイ画面](docs/preview.png)

## 必要なもの

- Python 3.10以降（Tkinterが利用できること）
- Cコンパイラ：GCCまたはClang（WindowsではMinGW-w64 GCCなど。Pythonと同じ32/64ビットのコンパイラを使用）
- GUI画面を表示できるWindows、macOS、Linux

**動作確認した環境：** Linux、Python 3.13.5、GCC 14.2 / Clang 17、Tkinter、Xvfb。Windows/macOSでの実機確認は行っていません。

## 起動方法

1. ZIPを展開します。
2. 展開先の `Snake_C_Python/` フォルダでターミナルを開きます。
3. 次を実行します。

```bash
python main.py
```

環境によっては `python3 main.py` またはWindowsの `py -3 main.py` を使います。`start_windows.bat`（Windows）と `start_unix.sh`（macOS/Linux）も使用できます。

初回起動時にCエンジンを `build/` 内の共有ライブラリへ自動コンパイルします。Cのソースやヘッダーに変更があった場合は自動再コンパイルします。コンパイルのみを行いたいときは `python build.py` を実行してください。

コンパイラが見つからない、またはGUIを起動できない場合は、ターミナルにエラーが表示されます。LinuxでTkinterが見つからない場合、配布元のPythonに対応する `python3-tk` 等を導入してください。

## 操作とルール

| キー / 操作 | 動作 |
|---|---|
| 矢印キー / W A S D / テンキー方向キー | 上・右・下・左に曲がる |
| Enter / PLAYボタン | ゲーム開始、終了後の再挑戦 |
| Space / P | 一時停止・再開（タイトル・終了画面では開始） |
| R | その場で最初からやり直す |
| Esc | タイトル画面に戻る |
| 1 / 2 / 3（タイトル画面のみ） | EASY / NORMAL / HARD |
| 難易度ボタン / RESUME / RESTART | マウスで画面の操作 |

- エサを食べるたびに1点増加し、体が1マス伸びます。
- 壁や、自分の体（今回退く尻尾を除く）にぶつかると終了します。
- エサを取るにつれて速くなりますが、極端に速くならない下限があります。
- すべてのマスを埋めると勝利です。
- 方向転換は最大2回先行入力できます。即座の180度反転はできません。
- 描画フレームの端数時間を持ち越すため、画面更新間隔による速度低下を抑えます。長時間の停止（スリープやデバッガによる停止など）から復帰した最初の画面更新では、予期しない1マスの移動も起こさないよう時間の基準をリセットします。
- ウィンドウのフォーカスを失った場合は自動的に停止します。戻っても自動再開しません。

ハイスコアは難易度ごとに保存します。複数のゲームを同時に起動していても、**ローカルファイルシステムではファイルロックを用いて読み込み・最高値の統合・置換をひとまとまりに扱い**、別プロセスの最高記録を消さないようにします。Windowsは `msvcrt`、Linux/macOSは `fcntl.flock`（いずれも標準ライブラリ）を使用します。ネットワークファイルシステムや一部の特殊な共有フォルダでは、ロックの動作が環境によって異なります。ディスクに毎回書き込まないため、新記録はゲーム中は最大約5秒間隔でまとめて保存し、**一時停止・再挑戦・メニューへの移動・ゲーム終了・アプリ終了でも保存を試みます**。保存できなかった場合、画面上部に警告が表示されます。書き込めない場合もゲームは続行できます。

JSONと同じフォルダに `highscores.json.lock` という小さなロック用ファイルが残ります。これは正常な動作で、**プレイ中に削除しないでください**。保存に失敗した場合は警告を出し、ゲームは継続します。

保存場所：

- Windows：`%APPDATA%/SnakeCPython/highscores.json`
- macOS：`~/Library/Application Support/SnakeCPython/highscores.json`
- Linux：`${XDG_DATA_HOME:-~/.local/share}/SnakeCPython/highscores.json`

## 役割別のファイル構成

```text
Snake_C_Python/
├── main.py                  起動・エラーメッセージ
├── build.py                 Cのコンパイルと再ビルド判定
├── start_windows.bat        Windowsの起動補助
├── start_unix.sh            macOS/Linuxの起動補助
├── native/
│   ├── snake.h              外部公開するC API
│   ├── snake_internal.h     Cエンジン内部の状態定義（外部には非公開）
│   ├── snake.c              移動、入力キュー、衝突、勝利・敗北
│   └── food.c               乱数とエサの生成
├── snake_app/
│   ├── config.py            画面レイアウト、速度、補間の純粋関数
│   ├── engine.py            ctypesを介したCとの接続
│   ├── renderer.py          描画と画面用ボタン領域の定義
│   ├── ui.py                キー・マウス・画面遷移・タイマー・保存制御
│   └── storage.py           スコアの検証・読み書き
├── tests/                   C検証、ゲーム進行、GUI、ビルド、構成のテスト
├── docs/
│   ├── QUALITY_CHECKS.md    50巡のレビューと再現手順
│   ├── FINAL_TEST_RUN.txt   実行ログの記録
│   ├── preview.png          プレイ画面
│   ├── menu.png             タイトル画面
│   ├── paused.png           一時停止画面
│   └── game_over.png        終了画面
└── LICENSE
```

**保守・拡張の指針：** 新しいゲームルールは基本的に `native/snake.c`、エサの種類や抽選ルールは `native/food.c`、描画は `snake_app/renderer.py`、操作や画面遷移は `snake_app/ui.py`、保存は `snake_app/storage.py` に追加します。PythonからはCの内部構造体を直接操作せず、公開APIで状態スナップショットを取得します。

## テストと再現方法

```bash
python -m unittest discover -s tests -v
python -m compileall -q main.py build.py snake_app tests
```

GUIテストはデスクトップ画面が必要です。画面のないLinuxでは、Xvfbを導入したうえで次のように実行できます。

```bash
xvfb-run -a python -m unittest discover -s tests -v
```

Cの警告検査、サニタイザ、再ビルド試験、独立モデルとの比較、画面確認、同時保存競合テスト、35周を超える観点別の再レビュー結果とコマンドは `docs/QUALITY_CHECKS.md` にまとめています。GUIテストが実際のプレイヤーの保存先に書き込まないよう、一時ディレクトリに隔離しています。**テストに成功しても、未知のバグが存在しないことを保証するものではありません。**

## 使用技術について

- `ctypes` は標準ライブラリで、Cの共有ライブラリをPythonから呼び出します。ヘビ全体の描画データを一括で取り出します。
- Tkinterの `after()` でGUIを止めずに更新し、`Canvas`で描画しています。
- Cの公開関数だけを共有ライブラリの外へ出し、内部関数・データを隠しています。
- ビルドは一時ディレクトリで行い、成功した共有ライブラリだけを置き換えます。ビルドスクリプトを変更した場合も再コンパイルを試みます。
- 保存はロックのもとで既存最高値と統合し、一時ファイルの書き込み完了後に置き換えます。破損・不正データを読み飛ばす仕組みです。

## ライセンス

このプロジェクトのオリジナルコードはMITライセンスです。詳細は `LICENSE` を参照してください。
