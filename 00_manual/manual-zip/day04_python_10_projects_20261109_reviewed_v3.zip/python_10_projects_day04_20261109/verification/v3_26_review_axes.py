"""Offline, standard-library-only 26-axis audit over ten day04 projects."""
import ast
from collections import Counter
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / 'tests'))
from test_materials import Manual
from test_v3 import lab

html = (ROOT / 'python_10_projects_day04_manual.html').read_text(encoding='utf-8')
manual = Manual(html)
readme = (ROOT / 'README.txt').read_text(encoding='utf-8')
examples = json.loads((ROOT / 'verification/examples.json').read_text())
files = sorted((ROOT/'projects').glob('*.py'))
assert len(files)==10
results=[]
for index,file in enumerate(files,1):
    src=file.read_text(encoding='ascii')
    lines=src.splitlines()
    sec=html.split(f'id="p{index:02d}"',1)[1].split('</section><section class="chapter"',1)[0]
    samples=examples[index-1]
    explanation_rows=[row for context,row in manual.rows if context==f'full-{index:02d}']
    step_rows=[row for context,row in manual.rows if context and context.startswith(f'p{index:02d}-step')]
    target={str(j):line for j,line in enumerate(lines,1) if line.strip()}
    normal=samples.get('normal',{})
    negative=samples.get('error',{})
    checks=[
      ('01 source name and existence',file.name.startswith(f'{index:02d}_') and file.is_file()),
      ('02 ASCII source encoding',all(ord(c)<128 for c in src)),
      ('03 Python 3.10 grammar',bool(ast.parse(src,feature_version=(3,10)))),
      ('04 bytecode compiles',bool(compile(src,file.name,'exec'))),
      ('05 newline at EOF',src.endswith('\n') and not src.endswith('\n\n\n')),
      ('06 no indentation tabs','\t' not in src),
      ('07 consistent LF newlines','\r' not in src),
      ('08 no trailing spaces',all(l==l.rstrip(' ') for l in lines)),
      ('09 beginner-scale source (<=100 lines)',len(lines)<=100),
      ('10 explicit main', 'def main():' in src),
      ('11 callable CLI entry point','raise SystemExit(main())' in src),
      ('12 usage message with own filename',f'Usage: python3 {file.name}' in src),
      ('13 command-line argument length checked before use',src.index('len(sys.argv)') < src.index('sys.argv[1')),
      ('14 expected exit codes in source', 'return 0' in src and 'return 2' in src),
      ('15 chapter contains own objective',f'{index:02d}' in sec and '入力と出力の仕様' in sec),
      ('16 four teaching steps',all(f'id="p{index:02d}-step{k}"' in sec for k in range(1,5))),
      ('17 four real code snippets',all(f'p{index:02d}-chunk{k}' in manual.code for k in range(1,5))),
      ('18 steps reconstruct complete source',''.join(manual.code[f'p{index:02d}-chunk{k}'] for k in range(1,5))==src),
      ('19 appendix matches source exactly',manual.code[f'src{index:02d}']==src),
      ('20 appendix line-to-code coverage',{r[0]:r[1] for r in explanation_rows}==target and all(r[2].strip() for r in explanation_rows)),
      ('21 step line-to-code coverage',{r[0]:r[1] for r in step_rows}==target and all(r[2].strip() for r in step_rows)),
      ('22 four source-jump anchors',all(f'href="#src{index:02d}-L' in sec.split(f'id="p{index:02d}-step{k}"',1)[1].split('</article>',1)[0] for k in range(1,5))),
      ('23 specific supplemental trace exists',f'id="deep-{index:02d}"' in sec),
      ('24 v3 individual lab and question exists',f'id="v3-lab-{index:02d}"' in sec and '確認問題と答えを開く' in sec),
      ('25 v3 lab command and expected stdout included',len(lab(index))==2 and lab(index)[0].startswith('python3 projects/') and lab(index)[1].endswith('\n')),
      ('26 both normal and invalid examples documented',bool(normal) and bool(negative) and normal.get('status')==0 and negative.get('status') in (1,2) and f'projects/{file.name}' in readme),
    ]
    failures=[name for name,ok in checks if not ok]
    results.append({'project':file.name,'checks':[{'axis':name,'pass':bool(ok)} for name,ok in checks],'passes':26-len(failures),'failures':failures})
summary={'axes_per_project':26,'project_count':10,'checks_executed':260,'checks_passed':sum(x['passes'] for x in results),'all_pass':all(not x['failures'] for x in results),'results':results,'scope':'26 distinct static/structural review axes applied independently to each of the ten projects; dynamic regressions and browser checks are recorded separately.'}
(ROOT/'verification/v3_review_26_axes.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2))
print(summary['checks_passed'],'/',summary['checks_executed'],'all_pass',summary['all_pass'])
for r in results:
 if r['failures']:print(r['project'],r['failures'])
if not summary['all_pass']:raise SystemExit(1)
