import sys

CASES = {"name": "Hello {user[name]}", "nested": "Value {user[lab_token]}", "missing": "Hello {user[absent]}"}
FULL = {"user": {"name": "Alice", "lab_token": "DEMO-ONLY"}}
MINIMAL = {"user": {"name": "Alice"}}


def render(template, context):
    try:
        return template.format_map(context)
    except (KeyError, ValueError):
        return "(missing field)"


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script name|nested|missing", file=sys.stderr)
        return 2
    template = CASES[sys.argv[1]]
    print(f"Full context: {render(template, FULL)}")
    print(f"Minimal context: {render(template, MINIMAL)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
