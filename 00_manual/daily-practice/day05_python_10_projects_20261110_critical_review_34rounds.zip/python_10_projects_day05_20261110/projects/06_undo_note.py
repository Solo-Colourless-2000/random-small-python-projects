def main():
    text = ""
    history = []
    print("Enter a note, /undo or /quit.")
    for turn in range(20):
        try:
            command = input("Note> ")
        except (EOFError, KeyboardInterrupt):
            print("\nStopped.")
            return 1
        if command == "/quit":
            print("Bye")
            return 0
        if command == "/undo":
            if history:
                text = history.pop()
            else:
                print("Nothing to undo.")
        else:
            if not 1 <= len(command) <= 30 or not command.strip():
                print("Error: use 1-30 characters with visible content.")
                return 2
            if any(not 32 <= ord(ch) <= 126 for ch in command):
                print("Error: note must be printable ASCII.")
                return 2
            if len(history) == 5:
                print("Error: history is full.")
                return 2
            history.append(text)
            text = command
        print(f"Note: {text or '(empty)'}")
    print("Error: command limit reached.")
    return 2


if __name__ == "__main__":
    raise SystemExit(main())
