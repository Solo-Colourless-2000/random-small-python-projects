History: v9 reports and screenshots are archival and do not describe v10 results.
