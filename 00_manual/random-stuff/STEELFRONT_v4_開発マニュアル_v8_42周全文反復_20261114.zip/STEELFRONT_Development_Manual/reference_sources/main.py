"""STEELFRONT game coordinator, input state, screen transitions and fixed-step loop."""
from __future__ import annotations
import random
import sys
import time
from pathlib import Path
import tkinter as tk
from tkinter import messagebox
from c_bridge import Control, Engine, WORLD_W, WORLD_H
from arena_config import SCREEN_W, SCREEN_H, OX, OY, UPGRADES, C
from arena_effects import VisualEffects
from arena_visual import ArenaRenderer
from arena_scores import read_best, write_best

class TankArena(VisualEffects, ArenaRenderer):
    def __init__(self, root: tk.Tk):
        self.root = root
        self.root.title('STEELFRONT  //  TANK ARENA')
        self.root.configure(bg=C['bg'])
        self.root.resizable(False, False)
        self.root.update_idletasks()
        # Respect small virtual/physical screens; never force an 800px-wide
        # window onto a display that has fewer than 800 pixels.
        sw = max(1, self.root.winfo_screenwidth()-60)
        sh = max(1, self.root.winfo_screenheight()-90)
        self.scale = min(1.0, sw / SCREEN_W, sh / SCREEN_H)
        self.w = round(SCREEN_W*self.scale)
        self.h = round(SCREEN_H*self.scale)
        self.root.geometry(f'{self.w}x{self.h}')
        self.canvas = tk.Canvas(self.root, width=self.w, height=self.h,
                                bg=C['bg'], highlightthickness=0, borderwidth=0,
                                cursor='crosshair')
        self.canvas.pack(fill='both', expand=True)
        self.keys=set()
        self.pointer=(OX+WORLD_W/2, OY+WORLD_H/2-170)
        self.mouse_down=False
        self.dash_queue=False
        self.pulse_queue=False
        self.screen='TITLE'
        self.paused_from='PLAYING'
        self.clear_timer=None
        self.flash_timer=0.0
        self.wave_banner=0.0
        self.particles=[]
        self.floats=[]
        self.upgrade_choices=[]
        self.card_bounds=[]
        self.seed=0
        self.last_clock=time.perf_counter()
        self.accumulator=0.0
        self._cover_signature=None
        self.draw_tag='dynamic'
        self.hud_last_updated=-100.0
        self.last_rendered_screen=None
        self.last_rendered_hover=None
        self.fps=60.0
        self.high_score,self.best_wave=self._load_best()
        self._pending_save=False
        self.engine=Engine()
        self._bind_events()
        self._create_background()
        self.render()
        self.root.after(16,self.tick)

    @staticmethod
    def _save_path():
        return Path.home() / '.steelfront_tank_arena.json'

    def _load_best(self):
        return read_best(self._save_path())

    def _store_best(self):
        s=self.engine.state
        old=(self.high_score,self.best_wave)
        self.high_score=max(self.high_score,s.score)
        self.best_wave=max(self.best_wave,s.wave)
        if old != (self.high_score, self.best_wave) or self._pending_save:
            self._pending_save = not write_best(
                self._save_path(), self.high_score, self.best_wave)

    def _bind_events(self):
        self.root.bind('<KeyPress>',self.key_press)
        self.root.bind('<KeyRelease>',self.key_release)
        self.canvas.bind('<Motion>',self.mouse_move)
        self.canvas.bind('<Button-1>',self.mouse_press)
        # Release may occur outside the Canvas; leaving it also stops firing.
        self.root.bind('<ButtonRelease-1>',self.mouse_release)
        self.canvas.bind('<Leave>',self.mouse_leave)
        self.canvas.bind('<FocusOut>',self.focus_lost)
        self.root.bind('<FocusOut>',self.focus_lost)
        self.root.protocol('WM_DELETE_WINDOW',self.close)
        self.canvas.focus_set()

    def close(self):
        self._store_best()
        self.root.destroy()

    def focus_lost(self,event=None):
        self.keys.clear()
        self.mouse_down=False
        self.dash_queue=False
        self.pulse_queue=False
        if self.screen in ('PLAYING','INTRO'):
            self.pause()

    def pause(self):
        if self.screen not in ('PLAYING','INTRO'):
            return
        self.paused_from=self.screen
        self.screen='PAUSED'
        self.keys.clear()
        self.mouse_down=False
        self.dash_queue=False
        self.pulse_queue=False

    def key_press(self,event):
        k=event.keysym.lower()
        was_down=k in self.keys
        self.keys.add(k)
        if not was_down:
            if self.screen == 'PLAYING':
                if k in ('shift_l', 'shift_r'): self.dash_queue = True
                if k == 'e': self.pulse_queue = True
                # Shift held before a movement key should still cause one dash.
                # The first input frame may arrive before the movement event.
                if k in ('w','a','s','d','up','down','left','right') and \
                        ('shift_l' in self.keys or 'shift_r' in self.keys):
                    self.dash_queue = True
            if k in ('escape','p'):
                if self.screen in ('PLAYING','INTRO'):self.pause()
                elif self.screen=='PAUSED':self.resume()
            elif k in ('return','kp_enter'):
                if self.screen in ('TITLE','GAMEOVER'):self.new_game()
                elif self.screen=='PAUSED':self.resume()
            elif self.screen=='UPGRADE' and k in ('1','2','3'):
                self.choose_upgrade(int(k)-1)
            elif self.screen=='TITLE' and k in ('space',):
                self.new_game()
            elif self.screen=='GAMEOVER' and k=='r':
                self.new_game()
        # Key-repeat is not allowed to queue another dash / EMP or choose twice.

    def key_release(self,event):
        k=event.keysym.lower()
        self.keys.discard(k)
        if k in ('shift_l','shift_r') and not (self.keys & {'shift_l','shift_r'}):
            # Releasing Shift cancels a pending boost instead of triggering
            # one later when the user begins moving.
            self.dash_queue=False

    def mouse_move(self,event):
        self.pointer=(event.x/self.scale,event.y/self.scale)

    def mouse_press(self,event):
        self.canvas.focus_set()
        x,y=event.x/self.scale,event.y/self.scale
        self.pointer=(x,y)
        if self.screen=='PLAYING':self.mouse_down=True
        elif self.screen in ('TITLE','GAMEOVER'):
            if 478<=x<=802 and 528<=y<=595:self.new_game()
        elif self.screen=='PAUSED':
            if 466<=x<=814 and 481<=y<=544:self.resume()
        elif self.screen=='UPGRADE':
            for i,(l,t,r,b) in enumerate(self.card_bounds):
                if l<=x<=r and t<=y<=b:
                    self.choose_upgrade(i)
                    break

    def mouse_release(self,event):
        self.mouse_down=False

    def mouse_leave(self,event):
        self.mouse_down=False

    def new_game(self):
        self.seed=random.SystemRandom().randrange(1,2**32)
        self.engine.reset(self.seed)
        self.engine.next_wave()
        self.keys.clear();self.mouse_down=False
        self.dash_queue=False;self.pulse_queue=False
        self.particles.clear();self.floats.clear()
        self.clear_timer=None
        self.accumulator=0.0
        self.wave_banner=1.6
        self.screen='INTRO'

    def resume(self):
        self.screen=self.paused_from if self.paused_from=='INTRO' else 'PLAYING'
        self.last_clock=time.perf_counter()
        self.accumulator=0.0
        self.keys.clear();self.mouse_down=False
        self.dash_queue=False;self.pulse_queue=False

    def choose_upgrade(self,idx):
        if self.screen!='UPGRADE' or not (0<=idx<len(self.upgrade_choices)):
            return
        self.engine.upgrade(self.upgrade_choices[idx])
        self.engine.next_wave()
        self.screen='INTRO'
        self.keys.clear()
        self.accumulator=0.0
        self.wave_banner=1.65
        self.clear_timer=None
        self.particles.clear()
        self.mouse_down=False
        self.dash_queue=False
        self.pulse_queue=False

    def start_upgrade_screen(self):
        self._store_best()
        self.screen='UPGRADE'
        self.keys.clear()
        self.mouse_down=False
        self.dash_queue=False
        self.pulse_queue=False
        s=self.engine.state
        possible=list(range(len(UPGRADES)))
        if s.player.hp>=s.player.max_hp-0.1:possible.remove(0)
        if s.armor>=.58-1e-4:possible.remove(2)
        if s.shot_interval<=.071:possible.remove(3)
        if s.pulse_cooldown_max<=4.01:possible.remove(5)
        if s.player_speed>=399:possible.remove(6)
        if s.dash_regen>=64.9:possible.remove(4)
        if s.player.max_hp>=269.9:possible.remove(7)
        if s.player_damage >= 99.9: possible.remove(1)
        # The three veteran modules are repeatable, even when every permanent
        # stat has reached its cap; never present a completely useless card.
        rng=random.Random(self.seed+(s.wave*179424673))
        self.upgrade_choices=rng.sample(possible,3)

    def _input(self):
        mx=int('d' in self.keys or 'right' in self.keys)-int('a' in self.keys or 'left' in self.keys)
        my=int('s' in self.keys or 'down' in self.keys)-int('w' in self.keys or 'up' in self.keys)
        px,py=self.pointer
        control=Control(float(mx),float(my),float(px-OX),float(py-OY),
                        int(self.mouse_down or 'space' in self.keys),
                        int(self.dash_queue),int(self.pulse_queue))
        self.dash_queue=False;self.pulse_queue=False
        return control

    def tick(self):
        now=time.perf_counter()
        measured=now-self.last_clock
        self.last_clock=now
        dt=min(max(0.0,measured),0.10)
        if measured>0:
            self.fps=self.fps*.92+min(144.0,1.0/measured)*.08
        if self.screen=='INTRO':
            self.wave_banner-=dt
            if self.wave_banner<=0:self.screen='PLAYING'
        elif self.screen=='PLAYING':
            # Fixed-timestep combat remains real-time even if Tk draws below 60 FPS.
            self.accumulator=min(0.12,self.accumulator+dt)
            steps=0
            while self.accumulator>=1.0/60.0 and steps<6:
                self.engine.step(self._input(),1.0/60.0)
                self.process_events()
                self.accumulator-=1.0/60.0
                steps+=1
                if not self.engine.state.player_alive:
                    self._store_best();self.screen='GAMEOVER'
                    self.mouse_down=False
                    self.accumulator=0.0
                    break
            state=self.engine.state
            if self.screen=='PLAYING' and state.enemy_count==0:
                if self.clear_timer is None:self.clear_timer=1.1
                else:
                    self.clear_timer-=dt
                    if self.clear_timer<=0:self.start_upgrade_screen()
            elif state.enemy_count>0:self.clear_timer=None
        if self.screen in ('PLAYING','INTRO','GAMEOVER','TITLE','UPGRADE'):
            self.update_particles(dt)
        self.flash_timer=max(0,self.flash_timer-dt)
        # Menus are motionless; redrawing hundreds of widgets accomplishes nothing.
        stationary=self.screen in ('TITLE','PAUSED','GAMEOVER','UPGRADE')
        hover=None
        if self.screen=='UPGRADE':
            mx,my=self.pointer
            for i,(l,t,r,b) in enumerate(self.card_bounds):
                if l<=mx<=r and t<=my<=b:hover=i
        redraw=not stationary or self.screen!=self.last_rendered_screen or hover!=self.last_rendered_hover
        try:
            if redraw:self.render()
        except tk.TclError:
            return
        self.root.after(16,self.tick)


def main():
    try:
        root = tk.Tk()
    except tk.TclError as exc:
        print(f"Cannot start the display: {exc}", file=sys.stderr)
        raise SystemExit(1) from exc
    try:
        TankArena(root)
    except Exception as exc:
        root.withdraw()
        messagebox.showerror('STEELFRONT startup error',
                             'The native C engine could not be loaded.\n\n'
                             +str(exc)+'\n\nSee README.md for compiler instructions.')
        root.destroy()
        raise SystemExit(1) from exc
    root.mainloop()

if __name__=='__main__':
    main()
