"""Build the C snake engine as a shared library. Requires GCC or Clang."""
from __future__ import annotations

import os
from pathlib import Path
import shlex
import shutil
import subprocess
import sys
import tempfile

ROOT = Path(__file__).resolve().parent
SOURCE = ROOT / "native" / "snake.c"
FOOD_SOURCE = ROOT / "native" / "food.c"
HEADER = ROOT / "native" / "snake.h"
PRIVATE_HEADER = ROOT / "native" / "snake_internal.h"
BUILD_SCRIPT = Path(__file__).resolve()
BUILD = ROOT / "build"


def library_path() -> Path:
    if sys.platform == "win32":
        name = "snake_core.dll"
    elif sys.platform == "darwin":
        name = "libsnake_core.dylib"
    else:
        name = "libsnake_core.so"
    return BUILD / name


def compiler_candidates() -> list[list[str]]:
    found: list[list[str]] = []
    if os.environ.get("CC", "").strip():
        try:
            found.append(shlex.split(os.environ["CC"], posix=sys.platform != "win32"))
        except ValueError:
            # A malformed optional CC override must not disable the defaults.
            pass
    found.extend([[name] for name in ("gcc", "clang", "cc")])
    return [args for args in found if args and shutil.which(args[0])]


def ensure_library(*, force: bool = False) -> Path:
    output = library_path()
    if (not force and output.is_file() and
            output.stat().st_mtime_ns >= max(path.stat().st_mtime_ns for path in
                   (SOURCE, FOOD_SOURCE, HEADER, PRIVATE_HEADER, BUILD_SCRIPT))):
        return output

    candidates = compiler_candidates()
    if not candidates:
        raise RuntimeError(
            "Cコンパイラが見つかりません。GCC または Clang をインストールして、"
            "ターミナルから python build.py を実行してください。"
        )
    BUILD.mkdir(parents=True, exist_ok=True)
    errors: list[str] = []
    # Build off to the side. An interrupted compilation must never leave a
    # partially written binary at the path used by the next game launch.
    with tempfile.TemporaryDirectory(prefix=".snake_build_", dir=BUILD) as tmp:
        staging = Path(tmp) / output.name
        for compiler in candidates:
            command = compiler + ["-std=c11", "-O2", "-Wall", "-Wextra", "-Wpedantic",
                                  "-DSNAKE_BUILD"]
            if sys.platform == "darwin":
                command += ["-dynamiclib", "-fPIC", "-fvisibility=hidden"]
            elif sys.platform == "win32":
                command += ["-shared"]
            else:
                command += ["-shared", "-fPIC", "-fvisibility=hidden"]
            command += [str(SOURCE), str(FOOD_SOURCE), "-o", str(staging)]
            try:
                process = subprocess.run(command, capture_output=True, text=True,
                                         timeout=90, check=False, cwd=ROOT)
            except (OSError, subprocess.TimeoutExpired) as exc:
                errors.append(f"{' '.join(compiler)}: {exc}")
                continue
            if process.returncode == 0 and staging.is_file() and staging.stat().st_size:
                try:
                    os.replace(staging, output)
                    return output
                except OSError as exc:
                    errors.append(f"インストールできません ({output}): {exc}")
                    break
            errors.append(f"{' '.join(compiler)}: {process.stderr.strip() or 'build failed'}")
            staging.unlink(missing_ok=True)

    raise RuntimeError("Cエンジンのビルドに失敗しました。\n" + "\n".join(errors))


if __name__ == "__main__":
    try:
        print(f"Build succeeded: {ensure_library(force=True)}")
    except RuntimeError as exc:
        print(exc, file=sys.stderr)
        raise SystemExit(1) from exc
