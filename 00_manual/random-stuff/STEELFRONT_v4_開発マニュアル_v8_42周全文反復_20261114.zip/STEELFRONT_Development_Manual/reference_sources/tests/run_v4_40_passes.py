"""Execute 40 v4 behavioral scenarios and verify each JUnit test case by name.

Usage: xvfb-run -a python tests/run_v4_40_passes.py
Runs one ordinary pytest invocation, then checks 40 separately named test results.
"""
from __future__ import annotations
import re
import subprocess
import sys
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
TEST = ROOT/'tests'/'test_v4_quality.py'
OUT = ROOT/'tests'/'logs'/'v4'

def run():
    OUT.mkdir(parents=True,exist_ok=True)
    names=re.findall(r'^def (test_quality_\d\d_[^(]+)\(',TEST.read_text(encoding='utf-8'),re.M)
    if len(names)!=40 or len(set(names))!=40:
        raise RuntimeError(f'Expected 40 unique tests, found {len(names)}')
    report=OUT/'quality_40_junit.xml'
    proc=subprocess.run([sys.executable,'-m','pytest','-q','--tb=short',
                         '--junitxml',str(report),'tests/test_v4_quality.py'],
                         cwd=ROOT,capture_output=True,text=True,timeout=120)
    (OUT/'quality_40_pytest.txt').write_text(proc.stdout+'\n'+proc.stderr,encoding='utf-8')
    if proc.returncode!=0 or not report.exists():
        print(proc.stdout,proc.stderr,file=sys.stderr)
        return 1
    cases={}
    for case in ET.parse(report).iter('testcase'):
        if case.get('name') in names:
            name=case.get('name')
            cases[name]=case.find('failure') is None and case.find('error') is None and case.find('skipped') is None
    lines=[]
    for i,name in enumerate(names,1):
        passed=cases.get(name,False)
        lines.append(f'{i:02}/40 {"PASS" if passed else "FAIL"} {name}')
    (OUT/'quality_40_verified.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    print('\n'.join(lines))
    return 0 if all(cases.get(n,False) for n in names) and len(cases)==40 else 2

if __name__=='__main__':raise SystemExit(run())
