import http.client
from http.server import BaseHTTPRequestHandler, HTTPServer
import sys
from threading import Thread


class Handler(BaseHTTPRequestHandler):
    timeout = 2

    def do_TRACE(self):
        body = self.headers.get("X-Lab-Token", "(none)").encode("ascii")
        self.send_response(200)
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, format, *args):
        return


def probe(include):
    with HTTPServer(("127.0.0.1", 0), Handler) as server:
        server.timeout = 2
        worker = Thread(target=server.handle_request, daemon=True)
        worker.start()
        client = http.client.HTTPConnection(*server.server_address, timeout=2)
        try:
            headers = {"X-Lab-Token": "DEMO-ONLY"} if include else {}
            client.request("TRACE", "/", headers=headers)
            response = client.getresponse()
            return response.status, response.read(32).decode("ascii")
        finally:
            client.close()
            worker.join(3)
            if worker.is_alive():
                raise OSError("HTTP worker did not finish.")


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ("token", "bare"):
        print("Usage: script token|bare", file=sys.stderr)
        return 2
    try:
        status, body = probe(sys.argv[1] == "token")
    except (OSError, http.client.HTTPException):
        print("Loopback HTTP experiment failed.", file=sys.stderr)
        return 1
    print(f"Status: {status}")
    print(f"Reflected value: {body}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
