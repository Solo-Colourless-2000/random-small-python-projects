import configparser
import sys
from pathlib import Path


def main():
    if len(sys.argv) != 3:
        print("Usage: python3 08_ini_filter.py settings.ini values")
        return 2
    try:
        with Path(sys.argv[1]).open("r", encoding="utf-8") as stream:
            text = stream.read(513)
    except (OSError, UnicodeError):
        print("Error: cannot read UTF-8 settings.")
        return 1
    try:
        if len(text) > 512 or len(sys.argv[2]) > 50:
            raise ValueError
        config = configparser.ConfigParser(interpolation=None)
        config.read_string(text)
        if config.sections() != ["filter"] or config.defaults():
            raise ValueError
        if set(config["filter"]) != {"minimum", "maximum"}:
            raise ValueError
        minimum = config.getint("filter", "minimum")
        maximum = config.getint("filter", "maximum")
        if not -100 <= minimum <= maximum <= 100:
            raise ValueError
        values = []
        for part in sys.argv[2].split(","):
            value = int(part)
            if not -100 <= value <= 100:
                raise ValueError
            values.append(value)
        if not 1 <= len(values) <= 10:
            raise ValueError
    except (ValueError, configparser.Error):
        print("Error: use only [filter] bounds -100..100 and 1-10 integers -100..100.")
        return 2
    kept = []
    for value in values:
        if minimum <= value <= maximum:
            kept.append(value)
    print(f"Range: {minimum}..{maximum}")
    if kept:
        print("Kept:", *kept)
    else:
        print("Kept: (none)")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
