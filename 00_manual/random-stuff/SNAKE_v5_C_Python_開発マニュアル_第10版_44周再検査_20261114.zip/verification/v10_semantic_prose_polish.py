#!/usr/bin/env python3
"""Second source-aware editorial layer for the v9 ZIP manual. No code snippets are changed."""
from pathlib import Path
from bs4 import BeautifulSoup
from collections import Counter
import json,re
R=Path(__file__).resolve().parent.parent
DOC=next(R.glob('*.html'))
s=BeautifulSoup(DOC.read_text(encoding='utf8'),'html.parser')
C={
 'self._text':'Renderer._textはCanvasへ文字を配置する。引数x/yが表示座標、valueが表示文字、size・color・anchorなどが見た目を決める',
 'self.app._loop':'GameApp._loopはゲーム時計と描画の周期処理。現在時刻からtick回数を決め、必要な更新後に次回afterを予約する',
 'self.app.canvas.event_generate':'GUIテストがTk Canvasに指定したイベントを発生させ、マウス操作・フォーカス処理が反応するか確かめる',
 'self.addCleanup':'unittestがテスト終了後に呼ぶ後片付け関数を登録する。検査途中で例外が出てもclose等を実行する',
 'unittest.main':'スクリプトを直接起動したときunittestのテスト探索と実行を開始する',
 'self.path.parent.mkdir':'テスト用のPathが指す親ディレクトリを作成する。ゲームの通常の保存先ではなく一時テストディレクトリ',
 'self._save_if_dirty':'スコアに未保存の変更がある場合だけ、難易度別の最高得点を保存し、結果に応じて警告を更新する',
 'self._set_cursor':'ホバー状態に応じてCanvasのマウスカーソルを変更する。変更不要な場合は再設定しない',
 'self._rounded_rect':'角を丸めた長方形をCanvasの多角形として描く。位置・半径・塗り・線を引数で指定する',
 'c.create_rectangle':'RendererがCanvasに矩形を追加する。矩形座標はピクセル単位で、蛇の体データ自体は変更しない',
 'GameApp':'Cエンジン・Tkウィンドウ・描画器・スコア保存を束ねるGameAppを生成する。ゲームルール本体はCへ委譲する',
 'e.reset':'テスト対象のSnakeEngineの体・方向・得点・餌を再初期化する。同じPythonオブジェクトを使って状態を作り直す',
 'self.path.write_text':'テストファイルに意図したJSON文字列を書き込み、次のload_scoresが不正値や境界値を正しく扱うか検査する',
 'print':'引数の文字列を標準出力または指定したfileへ書き出す。ゲーム状態を進める関数ではない',
 'c.create_line':'Canvasに線分を描く。2点の座標、色、幅などを渡す',
 'self.canvas.create_oval':'Canvasに楕円形を描く。餌などの視覚表現に使用する',
 'self._button':'ボタンの見た目を描くと同時にクリック可能な矩形とactionをヒットボックス一覧へ追加する',
 'self._start':'CエンジンをリセットしFrameを取り直してplayingに切り替え、移動時計を初期化する',
 'self.fail':'unittestのテストをその時点で失敗させる。ここに到達しないことを確認するために使う',
 'self.app.root.update':'テスト環境で未処理のTkイベントを処理し、UIの状態や描画を同期する',
 'self.canvas.bind':'Canvasで起きた指定イベントをメソッドへ関連付ける。関数を直接実行するのではなく発生時に呼ぶ',
 'self.root.after_cancel':'afterで予約した未実行のタイマーコールバックをID指定で取り消す',
 'game.reset':'SnakeEngineを初期化しゲームを初期状態に戻す',
 'os.utime':'対象ファイルのアクセス時刻・更新時刻を設定し、ビルド更新判定のテスト条件を作る',
 'self.app._save_if_dirty':'テスト対象GameAppのスコア保存判定を実行し、保存成功・失敗と警告の変化を確認する',
 'canvas.create_line':'Tk Canvasへ指定した2点を結ぶ線を描く',
 'draw':'現在の描画データからCanvas画像を構築し、操作可能な領域を返す',
 'self.canvas.create_text':'Canvasの指定座標に文字を描く。色、フォント、アンカーで配置を調整する',
 'handle.seek':'保存競合用ロックファイルの現在位置を変更する。Windowsではロックするバイトの位置を0へ戻す',
 'msvcrt.locking':'Windowsでファイル記述子の1バイトをロック／解除する。固定名のsidecarファイルを複数ゲーム間の共通対象にする',
 'self.root.destroy':'Tkウィンドウを破棄する。ゲーム終了時の画面とTkリソースの後片付け',
 'self.root.bind':'Tkウィンドウへ入力・フォーカスイベントの処理関数を登録する',
 'self.root.focus_set':'キー入力を受け付けるようTkウィンドウにフォーカスを移す',
 'patcher.start':'テスト用パッチの適用を開始し、モジュール内のパス定数などを一時ディレクトリの値へ差し替える',
 'self.skipTest':'GUIなど必要な実行条件がない場合、テストを失敗ではなくスキップとして記録する',
 'module.ensure_library':'テスト対象のビルド関数を実行し、ビルドが必要か、エラーや更新時刻を適切に処理するか検査する',
 'path.extend':'既存の座標列へ生成された複数座標をまとめて追加する',
 'route.extend':'勝利経路のリストへ続く座標を追加し、盤面全体を通るテストルートを構成する',
 'found.extend':'候補リストへ新たなコンパイラ名の候補を追加する',
 'BUILD.mkdir':'ビルド出力先ディレクトリを作る。parents=Trueなら親も作り、exist_ok=Trueなら既存でも失敗しない',
 'staging.unlink':'途中生成した共有ライブラリの仮ファイルを削除する。missing_ok=Trueなら存在しなくても例外を出さない',
 'self._lib.snake_reset':'Cのsnake_resetにゲームポインタと乱数seedを渡し、C側の体・スコア・餌を初期化する',
 'handle.write':'ロック用ファイルに1バイトを書き込む。Windowsで初回の空ファイルに対するバイトロックの対象を作る',
 'handle.flush':'Python側のファイルバッファからOSへデータを送り、続く操作から読み取れる状態にする（ディスク永続化の保証ではない）',
 'fcntl.flock':'POSIXのファイルロックで固定の.lockファイルを排他的に取得・解放する。読み込み→最大値統合→置換を直列化する',
 'destination.parent.mkdir':'ハイスコア保存先の親ディレクトリを再帰的に作る',
 'stream.write':'ハイスコアのJSON末尾へ改行を1つ追加する。人が読んだときの扱いやすさのため',
 'stream.flush':'Pythonのバッファに残ったデータをOSへ送る。次にfsyncでファイル本体の同期を要求する',
 'os.unlink':'ファイル名を指定して一時ファイルを削除する。保存失敗時の残骸を片付ける',
 'self.canvas.delete':'Canvasの前フレーム描画要素を削除し、今のフレームから描画し直す',
 'self._draw_food':'餌をCanvas上に描画する。sin波等による見た目の変化で、C側の餌座標を変更しない',
 'self._draw_snake':'Frame.bodyの各座標から蛇の体をCanvasへ描く。ゲームロジックは変えない',
 'self._draw_overlay':'メニュー、一時停止、ゲームオーバーなど現在の画面モードに応じたオーバーレイを表示する',
 'self._draw_eyes':'蛇の進行方向に合わせて目の位置を決め、頭部のCanvas描画へ重ねる',
 'self.root.geometry':'Tkウィンドウの初期サイズを文字列で指定する',
 'self.root.resizable':'ウィンドウの水平／垂直方向のサイズ変更可否を指定する',
 'self.root.configure':'Tkウィンドウの背景色などの表示設定を変更する',
 'self.canvas.pack':'CanvasをTkウィンドウ内へ配置する',
 'self._loop':'時刻・移動・描画・次回予約をまとめて実行するGameAppの定期処理',
 'self.root.mainloop':'Tkイベントループへ入り、ウィンドウを閉じるまでGUIイベントを受け付ける',
 'self.canvas.configure':'Canvasのcursorなど、表示属性を更新する',
 'self._choose':'メニューで選ばれたEASY/NORMAL/HARDの難易度を保存する。プレイ中の変更は拒否する',
 'self._menu':'未保存スコアを処理し、エンジンを初期状態へ戻してメニュー画面に切り替える',
 'modules.update':'集合modulesへ調べた複数のモジュール名を追加する',
 'modules.add':'集合modulesへモジュール名を1つ追加する',
 'native.mkdir':'ビルドテスト専用のnativeディレクトリを作る',
 'self.source.write_text':'テスト対象のCソースに変更を加えた状態を一時ディレクトリに書き込み、再ビルド判定を検査する',
 'self.food_source.write_text':'テスト用のfood.cへ変更を加え、ソース更新によってビルドが起きることを検査する',
 'self.lib.snake_reset':'テスト中のCエンジンへseedを渡し、状態を初期化してから結果を検査する',
 'self.lib.snake_destroy':'テストで確保したCのSnakeGame領域と体配列を解放する',
 'engine.reset':'ゲームエンジンを初期化し直し、蛇の状態と餌を作り直す',
 'self.path.mkdir':'テスト用ディレクトリを作り、保存エラーや正常ケースを再現する',
 'start.touch':'テスト用パスに空ファイルを作り、ファイルが既に存在する状態を作る',
 'worker.kill':'終了しない子プロセスを強制終了する。並列保存テストが無限に待たないための後片付け',
 'worker.communicate':'子プロセスの標準出力・標準エラーを回収して終了を待つ',
 'save_scores':'難易度別最高得点をJSONへ統合して保存する。失敗時はFalseを返す',
 'path_patch.start':'テスト専用の保存パス差替えを有効にする。通常プレイの保存データへの書込みを防ぐ',
 'self.app.root.event_generate':'テスト対象のTkウィンドウへ疑似イベントを発生させる',
 'self.app.engine.reset':'GameAppが保持するゲームエンジンを初期化する',
 'self.app.root.after_cancel':'テスト後などにGameAppの周期処理として予約済みのTkタイマーを取り消す',
 'external_root.destroy':'外部から渡したTkルートを破棄する。外部所有のルートをGameApp.closeが勝手に破棄しないことを確かめる',
 'external.destroy':'外部から渡したエンジンを明示的に閉じる。GameAppが所有していないエンジンを閉じない仕様の確認',
}
ROLES={
 '_menu':'セーブ対象を確認してCエンジンを初期化し、modeをmenuへ戻す',
 '_start':'ゲームを最初から開始し、Frame・移動時計・モードを初期化する',
 '_save_if_dirty':'未保存のスコアだけを保存し、保存失敗の警告表示を更新する',
 '_set_cursor':'マウスポインタの表示形状を必要時だけ更新する',
 '_on_focus_out':'ウィンドウからフォーカスが外れた場合、playingなら自動で一時停止する',
 '_on_canvas_click':'ヒットボックスとクリック座標を比較してstart/resume/difficultyを呼び分ける',
 '_on_canvas_motion':'マウスポインタがボタン領域上にあるかを判定してカーソルを変更する',
 '_on_canvas_leave':'キャンバスからマウスが離れたらカーソルを元に戻す',
 '_loop':'秒単位の経過時間をtickの回数に変換し、連続移動の上限・保存・再描画・次回after予約を実行する',
 '_draw':'FrameをRenderStateへまとめ、Renderer.drawに渡してヒットボックスを受け取る',
 '_choose':'難易度選択をmenu中だけ受け付け、EASY/NORMAL/HARDを設定する',
 '_rounded_rect':'Canvasの多角形から角丸の四角形を描く',
 '_text':'Canvasへ指定座標・フォントで文字を描く',
 '_button':'ボタンの矩形領域を登録し、見た目を描く',
 'draw':'RenderStateから1フレームの画面を描き、クリック判定用Hitbox一覧を返す',
 '_animation_progress':'論理tickからの経過時間を0〜1に制限した描画補間の進捗に変換する',
 '_draw_snake':'体の各セルの描画位置を補間してCanvasへ描く',
 '_draw_eyes':'方向に応じて蛇の目の位置を求める',
 '_draw_food':'餌をCanvasへ描く。ゲーム状態は変更しない',
 '_draw_overlay':'ゲームモードごとのメニューや結果表示を重ねる',
 'animation_progress':'play中の経過時間から描画の進捗を0〜1に収め、異常な時刻差では端値を返す',
 'game_interval':'難易度とスコアから秒単位の次の移動間隔を決定する',
 'compiler_candidates':'環境変数CCとgcc/clang/ccを候補にして、実行できるものだけを返す',
 'library_path':'OSに応じた共有ライブラリの拡張子を決めてPathを返す',
 '__enter__':'with SnakeEngine(...)の開始時にエンジン自身を返す',
 '__exit__':'with SnakeEngine(...)の終了時にCゲームハンドルをcloseする',
 '_handle':'close済みか確認したうえでCへ渡すハンドル値を返す',
 '_validated_seed':'Pythonの整数seedが0〜2^32−1の範囲内か検査し、Noneなら秘密値から初期値を生成する',
}
change=[]
for article in s.select('article.lesson-step'):
 fname=article.h2.get_text(' ',strip=True).split(' L')[0]
 for row in article.select('table.line-analysis tr:has(code.one-line)'):
  code=row.select_one('code.one-line').get_text(' ',strip=True)
  p=row.select_one('p.syntactic')
  if not p:continue
  orig=p.get_text(' ',strip=True)
  if 'この呼出しの定義元を前の工程' in orig:
   m=re.match(r'呼出し\s+([\w.]+)\(',orig)
   if m and m.group(1) in C:
    callee=m.group(1);reason=C[callee]
    p.string=f'{callee}の実行。{reason}。引数・キーワード引数は、この行の括弧内の実際の値を使う。'
    change.append((fname,code,'call'))
  if 'の機能を提供する。' in orig and code.lstrip().startswith('def '):
   m=re.search(r'\s(\w+)の機能を提供する。',orig)
   if m and m.group(1) in ROLES:
    p.string=orig.replace(m.group(1)+'の機能を提供する。',ROLES[m.group(1)]+'。')
    change.append((fname,code,'function_role'))
  if 'そのモジュールが公開する関数・型' in orig and code.lstrip().startswith('import '):
   p.string=orig.replace('そのモジュールが公開する関数・型','ゲームの処理やテストで必要な機能')
  if 'このファイルで必要な名前・処理を参照できる' in orig and code.startswith('from unittest.mock'):
   p.string='unittest.mockからpatchを取り込む。テスト対象が参照する保存先・ビルドパスなどを差し替え、元の環境に影響させず挙動を検証する。';change.append((fname,code,'import'))
  if code.startswith('self._focus_after_id: str | None = '):
   p.string='Tkinterのafter_idleでフォーカス設定をイベントループに予約し、その予約ID（文字列かNone）を_f​ocus_after_idに保持する。予約を解除するときにこのIDを使用する。'.replace('\u200b','')
   change.append((fname,code,'annotation_assignment'))
  if fname=='tests/test_engine.py' and code.startswith('self.engine(') and 'の実行。' in p.get_text():
   p.string=p.get_text(' ',strip=True).replace('SnakeEngineを生成','テスト用SnakeEngineを生成')
  if code.startswith('class ') and '基底クラス' not in p.get_text(' ',strip=True) and '(' in code:
   p.string='class文で新しいクラスを作り、丸括弧の中に継承元を指定する。これは関数呼出しではない。末尾のコロンから字下げしたクラス本体が始まる。';change.append((fname,code,'class'))
  # Remove wrong pseudo-guarantees from docs.
  if '必ず成功' in p.get_text(' ',strip=True) and 'テスト' not in p.get_text(' ',strip=True):
   p.string=p.get_text(' ',strip=True).replace('必ず成功','所定の条件では成功')

# Add targeted worked-reading cards at the exact implementation step; not generated repetitions.
LABS=[
 ('native/snake.c',21,'Cの2段階メモリ確保と失敗時の片付け',
  '最初のcalloc(1, sizeof(*game))は構造体本体、次のcalloc(capacity, sizeof(*game->body))は体の配列を確保する。どちらかが失敗したときNULLを返し、2段階目が失敗したら既に取ったgameだけをfreeする。',
  'width=8,height=8ならcapacity=64。配列にはSnakeCellを64個確保し、長さが伸びても容量64を超えない。sizeofの対象は型名ではなく、その変数が指す要素型。'),
 ('native/snake.c',69,'入力予約の2つの状態を手で追う',
  'pending_count=0ならlastはdirection。右へ進行中に上入力を受けるとpending[0]へ上を書いて件数1。続けて左入力ならlastは予約済みの上なので左をpending[1]へ入れられる。',
  '右へ移動中にいきなり左を受けると、(direction+2)%4==lastとなり逆走として拒否。配列への書込みは境界チェックの後なので2件を超えない。'),
 ('native/snake.c',93,'次に移動するマスと衝突判定を分ける',
  'body[0]が現在の頭の座標。switchの方向別加減算で候補(x,y)を先に求め、盤面外か確認する。座標をいきなりbody[0]へ書き戻さないのは、衝突時に体の配列を壊さないため。',
  '例えば頭(4,4)でUPなら(4,3)を判定する。上辺でyが0のときは候補(4,-1)となり、体配列を動かす前にSNAKE_DIEDを返す。'),
 ('native/snake.c',108,'尻尾のマスに入れる条件',
  '食べなければ体は1マス移動し、旧尻尾は消える。このため衝突チェックでは最後の1要素を外す。一方、餌を食べるtickでは体が伸び旧尻尾が残るので最後の要素も検査する。',
  '長さ3で「頭A、胴B、尻尾C」なら、通常移動の検査対象はA・Bの2つ。成長時はA・B・Cの3つ。この違いを消すと合法な尻尾移動が誤って死亡判定される。'),
 ('native/food.c',17,'乱数の剰余の偏りを避ける理由',
  'uint32_tの状態候補は2^32通り。boundで単純に割った剰余だけを使うと、余りの候補数が一部だけ1つ多くなる。thresholdより小さい値を棄却し、均等個数の候補から選ぶ。',
  'bound=10なら2^32 mod 10 = 6。0〜5を棄却すると残る2^32−6通りが10で割り切れる。ただしxorshift32自体の統計的品質や暗号強度を保証するものではない。'),
 ('native/food.c',33,'餌の空きマスを1回ずつ数える',
  'taken[y * width + x]が1なら蛇の体で占有、0なら空き。乱数で0〜free_cells−1のchoiceを選び、盤面を左上から走査して空きだけを数え、choiceが0のマスへ餌を置く。',
  'width=8で(x,y)=(3,2)なら一次元添字は2×8+3=19。占有マスではchoiceを減らさず、空きマスだけで番号を進める。'),
 ('snake_app/engine.py',68,'ctypesの引数型と戻り値型を登録しない危険',
  'snake_createは(int,int,uint32_t)を受け取りSnakeGame*を返す。argtypesにint,int,uint32型を設定し、restypeをc_void_pにする。Cが64ビットのアドレスを返すのにPythonが32ビット整数と解釈すると、ポインタが欠けてクラッシュし得る。',
  'snake_destroyなどはrestype=None（戻り値void）であり、snake_tickなどは戻り値をintとして受け取る。すべての関数で同じrestypeにしてはいけない。'),
 ('snake_app/engine.py',135,'1回のsnapshot呼出しで何を受け取るか',
  'Python側が_CSnapshot構造体と_CCellの配列を用意し、Cのsnake_snapshotに書込み先のアドレスを渡す。Cが両方を埋めてから、Python側で整数列挙型・tupleへ変換してFrameを作る。',
  'Cの生のポインタを画面に使い回すのでなく、FrameとしてコピーするのでC側の次tickとPython側の描画状態を分離できる。'),
 ('snake_app/storage.py',50,'ロック対象をJSONではなく別ファイルにする理由',
  'os.replaceでJSON本体のファイル名が新しいinodeを指す場合、旧JSONをロックしていた別の実行体と排他がずれる。固定名の.lockファイルに排他を掛け、その間に保存済みスコアを読み直してmaxでマージする。',
  'ロックファイルを毎回消すと、同時起動した別プロセスが異なるinodeを掴む危険がある。小さなsidecarを残す設計には理由がある。'),
 ('snake_app/storage.py',89,'原子的な置換とクラッシュ耐性は別',
  '先に同じディレクトリ内の一時ファイルへJSONを書き、flushとfsync後、os.replaceで名前を切り替える。書込み途中のJSONを次回起動が読むリスクを下げられる。',
  'ただし親ディレクトリのfsyncは行っていないため、電源断後に新しい名前が永続的に残ることまでは保証しない。ロックは競合を防ぎ、replaceは途中状態の露出を減らす。それぞれ役割が違う。'),
 ('snake_app/ui.py',217,'処理停止後にヘビを勝手に進めない',
  '現在時刻nowとlast_stepの差が長すぎるときは、スリープ復帰やデバッガ停止の可能性がある。MAX_UPDATE_GAPを超える差はゲーム時間として加算せず、last_stepを現在へ戻す。',
  '通常の遅延はMAX_CATCHUP_TICKSまで追い付き処理するが、無制限には進めない。PCが一時停止しただけでプレイヤーが即座に死亡しないようにする。'),
 ('snake_app/renderer.py',69,'描画とクリック判定を一つの呼出しで結ぶ',
  'drawはFrameを描くだけでなく、各ボタンの矩形座標とactionを記録したヒットボックス一覧を返す。UIはそのリストでクリック座標を判定する。',
  '見た目のボタンだけ増やして_hitboxesへ登録し忘れると押せない。逆に矩形座標だけ古いと表示とは別の場所でクリックが反応する。'),
 ('tests/test_engine.py',16,'テストでeが表すものを確認',
  'self.engine(width,height,seed)はテスト用SnakeEngineを生成し、closeするための後片付けも設定する。テスト内でe=self.engine()とした場合eはエンジンであり、exceptで捕捉した例外ではない。',
  'e.turn(Direction.UP)はゲームの方向を予約し、e.tick()で1ステップ進め、e.snapshot()で観察する。この3つを「入力→更新→観測」として区別する。'),
 ('tests/test_build.py',1,'ビルドテストは本物のソースを変更しない',
  'tests/test_build.pyは一時ディレクトリへCソース・ヘッダー・build.pyをコピーし、その場所でタイムスタンプ更新やコンパイラ失敗を再現する。',
  'patch.multipleはモジュールの複数のパス属性をまとめて差し替えるAPIで、複数プロセスを実行する意味ではない。'),
]
for fname,start,title,one,two in LABS:
 for article in s.select('article.lesson-step'):
  if article.h2.get_text(' ',strip=True).split(' L')[0]!=fname:continue
  # Add only to the step containing the relevant source line.
  span=article.select_one('.source-meta');m=re.search(r'L(\d+)[–-]L?(\d+)',span.get_text(' ',strip=True) if span else '')
  if not m:continue
  if int(m.group(1))<=start<=int(m.group(2)):
   aside=s.new_tag('aside',attrs={'class':'precision-box','data-verified-lineno':str(start)})
   h=s.new_tag('h4');h.string=title;aside.append(h)
   p=s.new_tag('p');p.string=one;aside.append(p)
   p=s.new_tag('p');p['class']=['caution'];p.string=two;aside.append(p)
   before=article.select_one('details.line-breakdown')
   if before:before.insert_before(aside)
   change.append((fname,title,'worked-example'))
   break

DOC.write_text(str(s),encoding='utf8')
(R/'verification/v10_semantic_polish.json').write_text(json.dumps({'counts':dict(Counter(x[-1] for x in change)),'items':[list(x) for x in change]},ensure_ascii=False,indent=2),encoding='utf8')
print('additional corrections',Counter(x[-1] for x in change))
