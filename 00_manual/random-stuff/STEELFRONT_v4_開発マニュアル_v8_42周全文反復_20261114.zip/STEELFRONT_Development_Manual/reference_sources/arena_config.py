"""Shared presentation constants and module-card copy (no simulation code)."""

SCREEN_W, SCREEN_H = 1280, 800
OX, OY = 80, 112

C = {
    'bg': '#080f17', 'floor': '#121f2a', 'floor2': '#172631',
    'grid': '#1c323b', 'outline': '#284b55', 'fog': '#0a151e',
    'text': '#d8e8e7', 'muted': '#708d99', 'cyan': '#69edd9',
    'gold': '#ffc77e', 'red': '#ff6f72', 'steel': '#516e7b',
    'blue': '#70bde0', 'amber': '#fc955b', 'green': '#99efab',
}

UPGRADES = [
    ('FIELD REPAIR', 'Restore 58 hull integrity.', 'HULL', '#92e8b6'),
    ('ARMOR-PIERCING', '+8 damage per main-cannon shell.', 'FIREPOWER', '#ffbe7e'),
    ('REINFORCED PLATING', '+10% incoming damage resistance.', 'DEFENSE', '#80c9ff'),
    ('CYCLIC LOADER', '12% faster reload cycle.', 'FIRE RATE', '#ffd68b'),
    ('TURBO CHARGER', '+7 dash energy regenerated each second.', 'MOBILITY', '#7ce8dc'),
    ('EMP CAPACITOR', 'EMP cooldown reduced by 1.4 seconds.', 'TACTICAL', '#b4a1fb'),
    ('TRACK OVERDRIVE', '+22 maximum movement speed.', 'MOBILITY', '#9ae6a5'),
    ('REACTOR CORE', '+30 maximum health and heal 30 HP.', 'HULL', '#f3a3ae'),
    ('EMERGENCY SHIELD', '6 seconds of temporary invulnerability.', 'TACTICAL', '#9bc6ff'),
    ('SALVAGE CACHE', 'Gain 3,000 tactical points.', 'SCORE', '#ffd17a'),
    ('COMBAT FOCUS', '50% extra cannon damage for 9 seconds.', 'FIREPOWER', '#f6aa82'),
]


# Compact copy is used when Canvas is scaled below 70% of design size.
# The standard card text would otherwise spill across neighboring cards.
UPGRADE_COMPACT = (
    'Restore 58 HP.',
    'Shell damage +8.',
    'Armor +10%.',
    'Reload 12% faster.',
    'Dash regen +7 / sec.',
    'EMP cooldown -1.4s.',
    'Movement speed +22.',
    'Max HP +30; heal 30.',
    'Shield for 6 seconds.',
    'Gain 3,000 points.',
    'Cannon +50% for 9s.',
)
