import base64
import json
import sys

HEADER = "eyJhbGciOiJub25lIn0"
CLAIMS = {"admin": "eyJyb2xlIjoiYWRtaW4ifQ", "user": "eyJyb2xlIjoidXNlciJ9"}


def decode_claims(token):
    header, body, signature = token.split(".")
    if header != HEADER or signature != "":
        raise ValueError("Unsupported fixture")
    raw = base64.b64decode(body + "=" * (-len(body) % 4), altchars=b"-_", validate=True)
    claims = json.loads(raw.decode("ascii"))
    if type(claims) is not dict or type(claims.get("role")) is not str:
        raise ValueError("Invalid claims")
    return claims


def main():
    cases = dict(CLAIMS, broken="?")
    if len(sys.argv) != 2 or sys.argv[1] not in cases:
        print("Usage: script admin|user|broken", file=sys.stderr)
        return 2
    try:
        claims = decode_claims(HEADER + "." + cases[sys.argv[1]] + ".")
    except (ValueError, UnicodeError):
        print("Invalid lab JWT.", file=sys.stderr)
        return 2
    print(f"Decode-only admin: {claims['role'] == 'admin'}")
    print("Signed-only gate: False")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
