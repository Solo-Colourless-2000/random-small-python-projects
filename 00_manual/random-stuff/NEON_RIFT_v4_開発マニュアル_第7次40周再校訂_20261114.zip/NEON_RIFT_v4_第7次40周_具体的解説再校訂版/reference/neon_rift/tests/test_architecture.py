"""Static architectural checks, separate from gameplay regressions."""
import ast
import sys
import unittest
from pathlib import Path

PROJECT = Path(__file__).resolve().parents[1]
MODULES = {p.stem: p for p in PROJECT.glob('*.py')}


class ArchitecturalTests(unittest.TestCase):
    def test_all_python_sources_parse(self):
        for path in [*PROJECT.glob('*.py'), *(PROJECT / 'tests').glob('*.py')]:
            with self.subTest(path=path.name):
                ast.parse(path.read_text(encoding='utf-8'), filename=str(path))

    def test_import_graph_has_no_cycles(self):
        graph = {}
        for name, path in MODULES.items():
            tree = ast.parse(path.read_text(encoding='utf-8'))
            dependencies = set()
            for node in ast.walk(tree):
                if isinstance(node, ast.ImportFrom) and node.module in MODULES:
                    dependencies.add(node.module)
                if isinstance(node, ast.Import):
                    dependencies.update(a.name for a in node.names if a.name in MODULES)
            graph[name] = dependencies
        visited, visiting = set(), set()
        def inspect(name):
            if name in visiting:
                self.fail(f'Circular import: {name}')
            if name in visited:
                return
            visiting.add(name)
            for dependency in graph[name]:
                inspect(dependency)
            visiting.remove(name)
            visited.add(name)
        for name in graph:
            inspect(name)

    def test_core_logic_has_no_gui_imports(self):
        for name in ('combat', 'enemy_ai', 'mechanics', 'upgrades',
                     'records', 'entities', 'constants'):
            with self.subTest(name=name):
                tree = ast.parse(MODULES[name].read_text(encoding='utf-8'))
                imports = []
                for node in ast.walk(tree):
                    if isinstance(node, ast.ImportFrom):
                        imports.append(node.module)
                    elif isinstance(node, ast.Import):
                        imports.extend(alias.name for alias in node.names)
                self.assertTrue(all(not mod.startswith(('tkinter', 'PIL', 'pygame'))
                                    for mod in imports if mod))

    def test_launchers_reference_existing_main(self):
        self.assertTrue((PROJECT / 'main.py').is_file())
        for launcher in ('start_windows.bat', 'start_mac_linux.sh'):
            self.assertIn('main.py', (PROJECT / launcher).read_text(encoding='utf-8'))

    def test_main_has_an_import_guard(self):
        text = (PROJECT / 'main.py').read_text(encoding='utf-8')
        self.assertIn("if __name__ == '__main__'", text)


if __name__ == '__main__':
    unittest.main()
