"""36 independent, evidence-backed review criteria for the day07 manual.

Each criterion reloads the full HTML, all source files and the test scripts.
The report distinguishes automated criteria from human editorial checks.
"""
import ast
from collections import Counter
from contextlib import redirect_stderr, redirect_stdout
from datetime import datetime, timezone
from html.parser import HTMLParser
from io import StringIO
import hashlib
import importlib.util
import json
from pathlib import Path
import sys
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
HTML_PATH = ROOT / 'python_10_projects_day07_manual.html'
SOURCES = sorted((ROOT / 'projects').glob('*.py'))
TESTS = sorted((ROOT / 'tests').glob('test_*.py'))
if len(SOURCES) != 10:
    raise SystemExit('Expected 10 source files')
sys.path.insert(0, str(ROOT / 'tests'))
from cases import CASES


def import_source(path):
    spec = importlib.util.spec_from_file_location(path.stem, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


modules = [import_source(p) for p in SOURCES]


class Markup(HTMLParser):
    def __init__(self, text):
        super().__init__(convert_charrefs=True)
        self.ids = Counter()
        self.hrefs = []
        self.code = []
        self.active_code = None
        self.feed(text)
        self.close()

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if a.get('id'):
            self.ids[a['id']] += 1
        if tag == 'a' and a.get('href', '').startswith('#'):
            self.hrefs.append(a['href'][1:])
        if tag == 'code':
            self.active_code = []

    def handle_data(self, data):
        if self.active_code is not None:
            self.active_code.append(data)

    def handle_endtag(self, tag):
        if tag == 'code' and self.active_code is not None:
            self.code.append(''.join(self.active_code))
            self.active_code = None


def assertion(value, message):
    if not value:
        raise AssertionError(message)


def code_focus(i):
    p = modules[i]
    if i == 0:
        assertion(p.compare('%74arget=public&target=private') == (True, 'private', False), 'decoded duplicate')
    elif i == 1:
        assertion(p.apply_update(p.CASES['role'], False)['role'] == 'admin', 'unrestricted')
        assertion(p.apply_update(p.CASES['role'], True)['role'] == 'reader', 'restricted')
    elif i == 2:
        assertion(p.matches('a.b', False) == 'a.b,axb' and p.matches('a.b', True) == 'a.b', 'fullmatch')
    elif i == 3:
        token = {p.TOKEN: 'alice'}
        assertion((p.redeem(token, p.TOKEN, True), p.redeem(token, p.TOKEN, True)) == ('accept', 'reject'), 'replay')
    elif i == 4:
        assertion(p.purchase(-1, False) == ('accept', 23, 6), 'negative purchase')
        assertion(p.purchase(-1, True) == ('reject', 20, 5), 'positive guard')
    elif i == 5:
        cache = {}
        p.fetch(cache, 'red', False)
        assertion(p.fetch(cache, 'blue', False) == 'variant=red', 'weak cache key')
    elif i == 6:
        state = {p.OLD_ID: 'anonymous'}
        p.login(state, True)
        assertion(p.OLD_ID not in state and state[p.NEW_ID] == 'alice', 'rotate session')
    elif i == 7:
        assertion(p.inspect(p.CASES['global']) == ('GLOBAL', False), 'pickle global')
        assertion(p.inspect(p.CASES['trailing']) == ('(none)', True), 'suffix')
    elif i == 8:
        assertion(p.expanded_length(p.CASES['entity']) == 48, 'XML expansion length')
    elif i == 9:
        assertion(p.render('Type {user[name].__class__}', p.MINIMAL) == "Type <class 'str'>", 'attribute traversal')


def condition_from_source(i):
    src = SOURCES[i].read_text(encoding='ascii')
    needles = [
        ['strict_parsing=True', 'max_num_fields=4', 'values[-1]'],
        ['json.loads(raw)', 'BASE.copy()', 'key == "display"'],
        ['re.escape(pattern)', 're.fullmatch(', 'join(found)'],
        ['del store[token]', 'if consume:', 'redeem(store, token, consume)'],
        ['quantity <= 0', 'total > BALANCE', 'int(sys.argv[1])'],
        ['(PATH, variant) if keyed else PATH', 'key not in cache', 'fetch(cache, "blue", keyed)'],
        ['del sessions[OLD_ID]', 'sessions[NEW_ID]', 'sessions.get(OLD_ID, "invalid")'],
        ['pickletools.genops(data)', 'opcode.name == "STOP"', 'len(data)'],
        ['ElementTree.fromstring(raw)', 'DTD policy:', 'root.text or ""'],
        ['template.format_map(context)', 'except (KeyError, ValueError)', 'MINIMAL'],
    ][i]
    assertion(all(n in src for n in needles), 'expected teaching semantics missing')


def run_cases_in_process():
    total = 0
    for module, (name, cases) in zip(modules, CASES.items()):
        for args, exit_code, expected_out, expected_err in cases:
            stdout, stderr = StringIO(), StringIO()
            with patch.object(sys, 'argv', [str(ROOT / 'projects' / (name + '.py')), *args]), \
                    redirect_stdout(stdout), redirect_stderr(stderr):
                actual_code = module.main()
            assertion((actual_code, stdout.getvalue(), stderr.getvalue()) ==
                      (exit_code, expected_out, expected_err), f'case mismatch: {name}, {args}')
            total += 1
    return total


TITLES = (
    [f'{i:02d} code behavior, project {i:02d}' for i in range(1, 11)]
    + [f'{i+10:02d} documented expression inputs, project {i:02d}' for i in range(1, 11)]
    + [f'{i+20:02d} line annotation precision, project {i:02d}' for i in range(1, 11)]
    + ['31 all code chunks vs source', '32 Python ASCII and 3.10 syntax',
       '33 unique IDs and internal anchors', '34 safety caveats and no remote assets',
       '35 navigation / readability feature markers', '36 all fixture outcomes in process']
)

results = []
for number, title in enumerate(TITLES, 1):
    # Reload the complete artifact in each round, not just a cached search hit.
    page = HTML_PATH.read_text(encoding='utf-8')
    source_texts = [path.read_text(encoding='ascii') for path in SOURCES]
    test_texts = [path.read_text(encoding='ascii') for path in TESTS]
    assertion(len(page) > 300000 and len(source_texts) == 10 and len(test_texts) >= 4,
              'incomplete package')
    assertion(page.count('class="line-breakdown"') == 245, 'missing per-line explanations')
    assertion(page.count('class="worked-guide"') == 10, 'missing worked examples')
    for path, source in zip(SOURCES, source_texts):
        assertion(source.endswith('\n'), 'missing terminal newline')
        assertion('raise SystemExit(main())' in source, 'missing entry point')
        ast.parse(source, feature_version=(3, 10), filename=str(path))
    artifact_hash = hashlib.sha256(page.encode()).hexdigest()
    observed = {}
    if 1 <= number <= 10:
        i = number - 1
        code_focus(i)
        observed['project'] = SOURCES[i].name
    elif 11 <= number <= 20:
        i = number - 11
        condition_from_source(i)
        assertion('id="worked-%02d-summary"' % (i + 1) in page, 'guide not indexed')
        assertion('data-worked="%02d"' % (i + 1) in page, 'worked case missing')
        observed['worked_rows'] = page.count('id="worked-%02d-r' % (i + 1))
        assertion(observed['worked_rows'] >= 4, 'too few worked rows')
    elif 21 <= number <= 30:
        i = number - 21
        lines = [int(n) for n, line in enumerate(source_texts[i].splitlines(), 1) if line.strip()]
        assertion(len(lines) >= 15, 'unexpectedly short source')
        count = sum(1 for n in lines if ('href="#src-%02d-L%d"' % (i+1, n)) in page)
        assertion(count == len(lines), 'missing appendix row line links')
        observed['linked_nonempty_lines'] = count
        observed['deep_explanations'] = page.count('class="deep-breakdown"')
        assertion(observed['deep_explanations'] >= 50, 'new deep explanation missing')
    elif number == 31:
        # An independent reconstruction of complete source text from HTML.
        from html.parser import HTMLParser as Parser
        class Extract(Parser):
            def __init__(self, html):
                super().__init__(convert_charrefs=True)
                self.current = None
                self.values = {}
                self.feed(html)
            def handle_starttag(self, tag, attrs):
                a = dict(attrs)
                if tag == 'code' and a.get('data-kind') == 'python':
                    self.current = a.get('id')
                    self.values[self.current] = ''
            def handle_data(self, data):
                if self.current:
                    self.values[self.current] += data
            def handle_endtag(self, tag):
                if tag == 'code':
                    self.current = None
        extracted = Extract(page).values
        for i, src in enumerate(source_texts, 1):
            assembled = ''.join(extracted[f'step-{i:02d}-{j}'] for j in range(1, 5))
            assertion(assembled == src == extracted[f'src-{i:02d}'], f'code mismatch {i}')
        observed['code_chunks'] = 40
    elif number == 32:
        for txt in test_texts:
            ast.parse(txt, feature_version=(3, 10))
        page_tags = Markup(page)
        assertion(all(item.isascii() for item in page_tags.code), 'non-ascii in HTML code')
        observed['html_code_elements'] = len(page_tags.code)
    elif number == 33:
        page_tags = Markup(page)
        assertion(not [x for x,c in page_tags.ids.items() if c > 1], 'duplicate element id')
        assertion(not set(page_tags.hrefs) - set(page_tags.ids), 'broken internal anchor')
        observed['unique_ids'] = len(page_tags.ids)
    elif number == 34:
        for text in ('pickletools', 'DTD policy:', 'MINIMAL', 'XML', 'False'):
            assertion(text in page, 'safety topic missing')
        for pattern in ('<iframe', '<script src=', '<img src=', '<link rel="stylesheet"'):
            assertion(pattern not in page, 'unexpected remote asset')
    elif number == 35:
        for marker in ('ResizeObserver', 'aria-expanded', 'Ctrl+C', 'document.querySelectorAll',
                       'localStorage', 'scrollIntoView', 'max-width: 720px',
                       'class="worked-table"', 'class="worked-guide"'):
            assertion(marker in page, f'missing UI marker: {marker}')
    elif number == 36:
        observed['verified_fixture_cases'] = run_cases_in_process()
        assertion(observed['verified_fixture_cases'] >= 60, 'too few case outcomes')
    results.append({'round': number, 'focus': title, 'status': 'PASS', 'artifact_sha256': artifact_hash,
                    'sources_read': len(source_texts), 'tests_read': len(test_texts), **observed})

report = {'method': '36 distinct automated criteria, each with a complete HTML/source/test-file reread',
          'timestamp_utc': datetime.now(timezone.utc).isoformat(),
          'result': 'PASS', 'rounds': len(results), 'details': results}
folder = ROOT / 'verification'
(folder / 'second_review_36_rounds.json').write_text(json.dumps(report, indent=2, ensure_ascii=False)+'\n')
(folder / 'second_review_36_rounds.log').write_text('\n'.join(
    f"ROUND {d['round']:02d} PASS | {d['focus']}" for d in results)+'\n')
print('36/36 PASS; in-process CLI cases:', results[-1].get('verified_fixture_cases'))
