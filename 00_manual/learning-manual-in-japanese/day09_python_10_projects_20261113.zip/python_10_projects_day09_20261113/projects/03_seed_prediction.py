import random
import sys

SEED = 7


def compare(known):
    issuer = random.Random(SEED)
    observer = random.Random(SEED if known else 99)
    first = issuer.randrange(1000000)
    observer.randrange(1000000)
    actual = issuer.randrange(1000000)
    predicted = observer.randrange(1000000)
    return first, actual == predicted


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ("known", "different"):
        print("Usage: script known|different", file=sys.stderr)
        return 2
    first, matched = compare(sys.argv[1] == "known")
    print(f"Issued value in range: {0 <= first < 1000000}")
    print(f"Next prediction matches: {matched}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
