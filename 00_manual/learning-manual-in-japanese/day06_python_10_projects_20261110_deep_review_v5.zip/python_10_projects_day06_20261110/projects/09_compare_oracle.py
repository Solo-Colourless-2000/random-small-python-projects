import sys

SECRET = "4827"


def early_count(candidate):
    if len(candidate) != len(SECRET):
        raise ValueError("Length mismatch.")
    for checks, pair in enumerate(zip(candidate, SECRET), 1):
        if pair[0] != pair[1]:
            return False, checks
    return True, len(SECRET)


def full_count(candidate):
    if len(candidate) != len(SECRET):
        raise ValueError("Length mismatch.")
    mismatches = 0
    for left, right in zip(candidate, SECRET):
        mismatches += left != right
    return mismatches == 0, len(SECRET)


def main():
    if len(sys.argv) != 2:
        print("Usage: script FOUR_DIGITS", file=sys.stderr)
        return 2
    candidate = sys.argv[1]
    if len(candidate) != 4 or not candidate.isascii() or not candidate.isdecimal():
        print("Use exactly four ASCII digits.", file=sys.stderr)
        return 2
    early_match, early_steps = early_count(candidate)
    full_match, full_steps = full_count(candidate)
    print(f"Early: match={early_match}, checks={early_steps}")
    print(f"Full: match={full_match}, checks={full_steps}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
