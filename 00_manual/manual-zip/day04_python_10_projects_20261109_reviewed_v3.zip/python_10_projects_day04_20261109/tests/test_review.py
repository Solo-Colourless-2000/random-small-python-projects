"""Regression checks for the revised, beginner-facing day04 material."""
from html import unescape
import re
from pathlib import Path
import shlex
import subprocess
import sys
import tempfile
import unittest

ROOT = Path(__file__).resolve().parents[1]



class RevisedMaterial(unittest.TestCase):
    def test_05_control_separators_are_not_names(self):
        with tempfile.TemporaryDirectory() as folder:
            a = Path(folder) / "a.txt"
            b = Path(folder) / "b.txt"
            b.write_text("Ada\n", encoding="utf-8")
            for content in ["Ada\vBob\n", "Ada\fBob\n", "Ada\u2028Bob\n", "\u00a0Ada\n", "Ada\u00a0\n", "Ada\n\nBob\n"]:
                with self.subTest(content=repr(content)):
                    a.write_text(content, encoding="utf-8")
                    result = subprocess.run([sys.executable, str(ROOT/'projects/05_roster_compare.py'),str(a),str(b)],capture_output=True,text=True,timeout=8)
                    self.assertEqual((result.returncode,result.stdout,result.stderr), (2,"Error: use at most 10 names, 1-12 letters each, within 140 characters.\n",""))

    def test_05_empty_and_universal_newlines(self):
        with tempfile.TemporaryDirectory() as folder:
            a = Path(folder) / 'a.txt'
            b = Path(folder) / 'b.txt'
            b.write_bytes(b'Bob\r\n')
            for content, expected in [(b'', 'Both: (none)\nFirst only: (none)\nSecond only: bob\n'),(b'Bob\r\n', 'Both: bob\nFirst only: (none)\nSecond only: (none)\n'),(b'\tBob \n', 'Both: bob\nFirst only: (none)\nSecond only: (none)\n')]:
                with self.subTest(content=content):
                    a.write_bytes(content)
                    result=subprocess.run([sys.executable,str(ROOT/'projects/05_roster_compare.py'),str(a),str(b)],capture_output=True,text=True,timeout=8)
                    self.assertEqual((result.returncode,result.stdout,result.stderr),(0,expected,''))

    def test_ten_supplemental_lessons_have_full_components(self):
        html=(ROOT/'python_10_projects_day04_manual.html').read_text(encoding='utf-8')
        for i in range(1,11):
            with self.subTest(project=i):
                marker=f'id="deep-{i:02d}"'
                self.assertIn(marker,html)
        self.assertEqual(html.count('\u88dc\u8b1b\uff1a\u30b3\u30fc\u30c9\u3092\u982d\u306e\u4e2d\u3067\u5b9f\u884c\u3059\u308b'),10)
        self.assertEqual(html.count('\u9593\u9055\u3048\u3084\u3059\u30443\u3064\u306e\u70b9'),10)
        self.assertEqual(html.count('\u8ffd\u52a0\u306e\u5b9f\u9a13\u3068\u7b54\u3048\u5408\u308f\u305b'),10)
        self.assertEqual(html.count('\u81ea\u5206\u3067\u8aac\u660e\u3067\u304d\u308b\u304b\uff1a\u88dc\u8b1b\u306e\u78ba\u8a8d\u554f\u984c'),10)

    def test_supplemental_commands_match_actual_outputs(self):
        html=(ROOT/'python_10_projects_day04_manual.html').read_text(encoding='utf-8')
        for i in range(1,11):
            with self.subTest(project=i):
                # Use Python's standard library, not BeautifulSoup, so learners
                # can run the entire suite without installing packages.
                section=html.split(f'id="deep-{i:02d}"',1)[1].split('<h3>\u5b8c\u6210\u6761\u4ef6\u3068\u7406\u89e3\u5ea6\u78ba\u8a8d</h3>',1)[0]
                snippets=[unescape(fragment) for fragment in re.findall(r'<pre><code>(.*?)</code></pre>',section,re.DOTALL)]
                self.assertEqual(len(snippets),2)
                command, expected=snippets
                args=shlex.split(command)
                self.assertEqual(args.pop(0),'python3')
                stdin='paper\n' if i==9 else ''
                with tempfile.TemporaryDirectory() as folder:
                    if i==8:
                        tone=Path(folder)/'tone.wav'
                        create=subprocess.run([sys.executable,str(ROOT/'projects/08_tone_wav.py'),'1000','200',str(tone)],capture_output=True,text=True,timeout=8)
                        self.assertEqual(create.returncode,0)
                        args[-1]=str(tone)
                    result=subprocess.run([sys.executable,*args],cwd=ROOT,input=stdin,capture_output=True,text=True,timeout=8)
                self.assertEqual(result.returncode,0,result.stderr)
                self.assertEqual(result.stdout,expected)
                self.assertEqual(result.stderr,'')

    def test_specific_documentation_corrections(self):
        html=(ROOT/'python_10_projects_day04_manual.html').read_text(encoding='utf-8')
        self.assertNotIn('\u8868\u793a\u3057\u305f\u624b\u9806\u304c\u5408\u6cd5\u304b\u3082\u691c\u67fb\u3057\u307e\u3059\u3002',html)
        self.assertIn('\u5b8c\u6210\u30d7\u30ed\u30b0\u30e9\u30e0\u81ea\u4f53\u306f\u624b\u9806\u3092\u8868\u793a\u3059\u308b\u3060\u3051',html)
        self.assertIn('\u7279\u6b8a\u306a\u5236\u5fa1\u6587\u5b57\u30fbUnicode\u7a7a\u767d\u306f\u8a31\u53ef\u3057\u307e\u305b\u3093',html)
        self.assertIn('strip(" \\t")',html)
        self.assertIn('\u96e3\u6613\u5ea6\uff1a\u521d\u7d1a\u301c\u4e2d\u7d1a\uff08\u30d0\u30a4\u30ca\u30ea\u5f62\u5f0f\u30fb\u6b63\u5f26\u6ce2',html)
        self.assertIn('\u96e3\u6613\u5ea6\uff1a\u521d\u7d1a\u301c\u4e2d\u7d1a\uff08\u518d\u5e30\u30fb\u57fa\u5e95\u6761\u4ef6',html)


if __name__ == '__main__':
    unittest.main()
