#ifndef STEELFRONT_TANK_ENGINE_H
#define STEELFRONT_TANK_ENGINE_H

#ifdef _WIN32
#  define API __declspec(dllexport)
#else
#  define API __attribute__((visibility("default")))
#endif

#define WORLD_W 1120
#define WORLD_H 620
#define MAX_ENEMIES 80
#define MAX_BULLETS 420
#define MAX_OBSTACLES 24
#define MAX_PICKUPS 40
#define MAX_EVENTS 220
#define API_VERSION 4

enum { EVENT_SHOOT=1, EVENT_IMPACT, EVENT_KILL, EVENT_PLAYER_HIT,
       EVENT_DASH, EVENT_PULSE, EVENT_PICKUP, EVENT_COVER_HIT, EVENT_ENEMY_HIT,
       EVENT_WAVE, EVENT_PLAYER_DEAD, EVENT_SCORE };
enum { ENEMY_SCOUT=0, ENEMY_GUNNER, ENEMY_BRUISER, ENEMY_BOSS };
enum { PICKUP_REPAIR=0, PICKUP_ENERGY };
enum { UPGRADE_REPAIR=0, UPGRADE_DAMAGE, UPGRADE_ARMOR, UPGRADE_RELOAD,
       UPGRADE_DASH, UPGRADE_PULSE, UPGRADE_MOBILITY, UPGRADE_CORE,
       UPGRADE_SHIELD, UPGRADE_SALVAGE, UPGRADE_FOCUS };

typedef struct {
    float move_x, move_y, aim_x, aim_y;
    int fire, dash, pulse;
} Control;

typedef struct {
    float x, y, vx, vy, angle, turret, radius, hp, max_hp, reload, stun, flash;
    int active, type;
} Tank;

typedef struct {
    float x, y, prev_x, prev_y, vx, vy, radius, damage, lifetime;
    int active, owner, bounces;
} Bullet;

typedef struct {
    float x, y, w, h, hp;
    int active, kind;
} Obstacle;

typedef struct {
    float x, y, ttl;
    int active, kind;
} Pickup;

typedef struct {
    float x, y, value;
    int kind;
} Event;

typedef struct {
    float time, dash_energy, pulse_cooldown, pulse_cooldown_max, dash_regen;
    float shot_interval, player_damage, player_speed, armor, invulnerability;
    int wave, score, kills, combo, player_alive;
    float combo_timer, focus_timer;
    Tank player;
    Tank enemies[MAX_ENEMIES];
    Bullet bullets[MAX_BULLETS];
    Obstacle obstacles[MAX_OBSTACLES];
    Pickup pickups[MAX_PICKUPS];
    Event events[MAX_EVENTS];
    int enemy_count, bullet_count, obstacle_count, pickup_count, event_count;
} Snapshot;

API int engine_api_version(void);
API int engine_snapshot_size(void);
API void engine_reset(unsigned int seed);
API void engine_next_wave(void);
API void engine_step(const Control *ctrl, float dt);
API void engine_upgrade(int upgrade);
API void engine_snapshot(Snapshot *out);

#endif
