"""Shared dimensions, tuning, and visual palette for Neon Rift."""
from __future__ import annotations

WIDTH, HEIGHT = 1120, 720
ARENA_LEFT, ARENA_TOP = 34, 82
ARENA_RIGHT, ARENA_BOTTOM = WIDTH - 34, HEIGHT - 58
FPS = 60
MAX_DT = 1 / 30

BG = '#07121d'
PANEL = '#0b1c2a'
PANEL_EDGE = '#234254'
GRID = '#102936'
GRID_BRIGHT = '#183746'
TEXT = '#d9f3f3'
MUTED = '#708e9f'
CYAN = '#51edeb'
BLUE = '#62aaff'
GREEN = '#7ef2a3'
YELLOW = '#ffd381'
RED = '#ff6e82'
MAGENTA = '#eb81ff'
ORANGE = '#ffa665'

ENEMY_SPECS = {
    'hunter':  {'hp': 42,  'speed': 126, 'radius': 15, 'damage': 12, 'points': 110, 'color': RED},
    'runner':  {'hp': 28,  'speed': 192, 'radius': 12, 'damage': 9,  'points': 135, 'color': MAGENTA},
    'gunner':  {'hp': 54,  'speed': 88,  'radius': 17, 'damage': 10, 'points': 170, 'color': BLUE},
    'bruiser': {'hp': 152, 'speed': 66,  'radius': 24, 'damage': 21, 'points': 290, 'color': ORANGE},
    'warden':  {'hp': 850, 'speed': 53,  'radius': 43, 'damage': 24, 'points': 2500, 'color': YELLOW},
}

UPGRADES = {
    'overclock': ('OVERCLOCK', 'Shot interval -17%', CYAN),
    'tungsten': ('TUNGSTEN CORE', '+7 bullet damage', RED),
    'reinforced': ('REINFORCED HULL', '+25 max HP, heal 25', GREEN),
    'thrusters': ('ION THRUSTERS', '+12% movement speed', BLUE),
    'scatter': ('SPLIT BARREL', 'Add a projectile per shot', MAGENTA),
    'capacitor': ('FLUX CAPACITOR', '+35% energy regeneration', YELLOW),
    'medkit': ('EMERGENCY REPAIR', 'Heal 55 (or +10 hull at full HP)', GREEN),
    'phase': ('PHASE DRIVE', 'Dash cooldown -15%', BLUE),
}
