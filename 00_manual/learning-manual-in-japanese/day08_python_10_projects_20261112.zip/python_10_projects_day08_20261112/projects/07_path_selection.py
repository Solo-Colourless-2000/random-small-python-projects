import os
import shutil
import sys
from pathlib import Path
from tempfile import TemporaryDirectory


def select(prepend):
    with TemporaryDirectory() as folder:
        root = Path(folder)
        for name in ("incoming", "trusted"):
            directory = root / name
            directory.mkdir()
            tool = directory / "labtool"
            tool.write_text("#!/bin/sh\nprintf LAB\n", encoding="ascii")
            tool.chmod(0o700)
        directories = [root / "trusted"]
        if prepend:
            directories.insert(0, root / "incoming")
        parts = []
        for directory in directories:
            parts.append(str(directory))
        search_path = os.pathsep.join(parts)
        selected = shutil.which("labtool", path=search_path)
        if selected is None:
            raise OSError("No executable candidate.")
        return Path(selected).parent.name, (root / "trusted" / "labtool").parent.name


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in ("trusted", "prepend"):
        print("Usage: script trusted|prepend", file=sys.stderr)
        return 2
    try:
        selected, pinned = select(sys.argv[1] == "prepend")
    except OSError:
        print("PATH experiment failed.", file=sys.stderr)
        return 1
    print(f"Selected directory: {selected}")
    print(f"Pinned directory: {pinned}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
