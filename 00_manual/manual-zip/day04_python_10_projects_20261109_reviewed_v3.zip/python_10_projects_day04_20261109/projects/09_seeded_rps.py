import random
import sys

HANDS = ("rock", "paper", "scissors")


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 09_seeded_rps.py seed")
        return 2
    try:
        if len(sys.argv[1]) > 4:
            raise ValueError
        seed = int(sys.argv[1])
        if not 0 <= seed <= 9999:
            raise ValueError
    except ValueError:
        print("Error: seed must be an integer from 0 to 9999.")
        return 2
    try:
        raw = input("Your hand (rock/paper/scissors): ")
    except (EOFError, KeyboardInterrupt):
        print("\nStopped.")
        return 1
    hand = raw.strip().lower()
    if len(raw) > 20 or hand not in HANDS:
        print("Error: choose rock, paper or scissors within 20 characters.")
        return 2
    generator = random.Random(seed)
    computer = generator.choice(HANDS)
    difference = (HANDS.index(hand) - HANDS.index(computer)) % 3
    print(f"Computer: {computer}")
    if difference == 0:
        print("Tie")
    elif difference == 1:
        print("You win.")
    else:
        print("You lose.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
