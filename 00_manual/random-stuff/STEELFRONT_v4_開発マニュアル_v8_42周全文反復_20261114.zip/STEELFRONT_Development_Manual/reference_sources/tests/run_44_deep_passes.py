"""Run 44 distinct review scenarios in verified batches and record each result.

Usage: xvfb-run -a python tests/run_44_deep_passes.py [start=1] [end=44]
Uses a JUnit report to verify each case rather than counting dots in pytest output.
"""
from __future__ import annotations
import re
import subprocess
import sys
import tempfile
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT=Path(__file__).resolve().parents[1]
TEST=ROOT/'tests'/'test_deep_review.py'
LOG=ROOT/'tests'/'logs'/'review_44_passes.txt'

def run(start:int=1,stop:int=44)->int:
    names=re.findall(r'^def (test_deep_\d\d_[^(]+)\(',TEST.read_text(),flags=re.M)
    assert len(names)==44,len(names)
    assert 1<=start<=stop<=44
    if start==1:LOG.write_text('',encoding='utf-8')
    passed=0
    for batch_start in range(start,stop+1,7):
        batch_stop=min(stop,batch_start+6)
        selected=[]
        for index in range(batch_start,batch_stop+1):
            name=next((n for n in names if n.startswith(f'test_deep_{index:02}_')),None)
            if not name:raise ValueError(f'Missing deep review {index}')
            selected.append(name)
        with tempfile.TemporaryDirectory(prefix='steelfront-review-') as tmp:
            report=Path(tmp)/'junit.xml'
            proc=subprocess.run([sys.executable,'-m','pytest','-q','--tb=short',
                '--junitxml',str(report),*[f'tests/test_deep_review.py::{name}'
                  for name in selected]],cwd=ROOT,text=True,capture_output=True,timeout=65)
            if proc.returncode!=0 or not report.exists():
                with LOG.open('a',encoding='utf-8') as f:
                    f.write(f'FAIL batch {batch_start}-{batch_stop}\n{proc.stdout}\n{proc.stderr}\n')
                print(proc.stdout,proc.stderr,file=sys.stderr)
                return 1
            tree=ET.parse(report)
            cases={case.get('name') for case in tree.iter('testcase')
                   if case.find('failure') is None and case.find('error') is None}
            for index,name in enumerate(selected,start=batch_start):
                ok=name in cases
                status='PASS' if ok else 'FAIL'
                with LOG.open('a',encoding='utf8') as f:
                    f.write(f'{index:02d}/{44:02d} {status} {name}\n')
                print(f'{status} [{index:02d}/44] {name.removeprefix("test_deep_")}',flush=True)
                if not ok:return 1
                passed+=1
    print(f'COMPLETE {passed}/{stop-start+1} distinct review cases')
    return 0

if __name__=='__main__':
    start=int(sys.argv[1]) if len(sys.argv)>1 else 1
    stop=int(sys.argv[2]) if len(sys.argv)>2 else 44
    raise SystemExit(run(start,stop))
