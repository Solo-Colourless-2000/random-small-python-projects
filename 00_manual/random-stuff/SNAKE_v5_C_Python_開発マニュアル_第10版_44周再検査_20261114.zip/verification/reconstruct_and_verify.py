#!/usr/bin/env python3
"""Verify interleaved source edits and phase checkpoints against the v5 reference.

Pure standard-library. Does not modify any player data. Only writes on --output.
"""
from __future__ import annotations
import argparse, hashlib, html, json, re, sys, zipfile
from collections import defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent

def digest(content: bytes) -> str:
    return hashlib.sha256(content).hexdigest()

def check(workspace: Path | None = None, output: Path | None = None) -> None:
    package=json.loads((ROOT/'verification/edit_steps.json').read_text(encoding='utf8'))
    steps=package['steps']; names=list(package['file_digests']); states={name:'' for name in names}
    failures=[]; checks=0
    last_ids=set()
    for step in steps:
        path=step['file']; expected=step['sha256']; num=step['serial']
        if step['id'] in last_ids:failures.append(f'工程ID重複: {step["id"]}')
        last_ids.add(step['id'])
        if num!=checks+1:failures.append(f'工程番号の不連続: {num}')
        lines=step['code'].splitlines(keepends=True)
        if len(lines)!=step['last']-step['first']+1:failures.append(f'{step["id"]}: 行数不一致')
        if step['first']!=len(states[path].splitlines())+1:failures.append(f'{step["id"]}: 追記位置不一致')
        before=''.join(states[path].splitlines(keepends=True)[-3:])
        if before!=step['before']:failures.append(f'{step["id"]}: 編集前の文脈不一致')
        states[path]+=step['code']
        if digest(states[path].encode('utf8'))!=expected:failures.append(f'{step["id"]}: ハッシュ不一致')
        checks+=1
    for path,expected in package['file_digests'].items():
        raw=states[path].encode('utf8')
        if digest(raw)!=expected:failures.append(f'{path}: 最終ソースハッシュ不一致')
        original=(ROOT/'reference/Snake_C_Python'/path).read_bytes()
        if raw!=original:failures.append(f'{path}: 同梱の完成ソースと不一致')
        if workspace is not None:
            dest=workspace/path
            if not dest.is_file() or dest.read_bytes()!=raw:failures.append(f'{dest}: 作業ファイルが一致しません')
        if output is not None:
            dest=output/path;dest.parent.mkdir(parents=True,exist_ok=True);dest.write_bytes(raw)
    per_stage=defaultdict(list)
    for step in steps:per_stage[step['phase']].append(step)
    for phase in package['phases']:
        number=phase['number'];zpath=ROOT/'checkpoints'/f'phase-{number:02d}.zip'
        if digest(zpath.read_bytes())!=phase['checkpoint_sha256']:
            failures.append(f'phase-{number:02d}.zip: アーカイブハッシュ不一致')
        if len(per_stage[number])!=phase['steps']:
            failures.append(f'第{number}章の工程数不一致')
        snap={name:'' for name in names}
        for step in steps:
            if step['phase']<=number:snap[step['file']]+=step['code']
        with zipfile.ZipFile(zpath) as z:
            for path,content in snap.items():
                if not content:continue
                want=f'snake-lab/{path}'
                if want not in z.namelist():failures.append(f'{zpath}: {want} なし')
                elif z.read(want)!=content.encode('utf8'):failures.append(f'{zpath}: {want} 不一致')
    # HTML step snippets: line numbers and markup must not leak into copied code.
    manual=next(ROOT.glob('*.html')).read_text(encoding='utf8')
    fragments=re.findall(r'<article(?=[^>]*class="lesson-step")(?=[^>]*id="(edit-\d+)")[^>]*>.*?<h3>今回入力するコード</h3><div class="code-wrap"[^>]*><button[^>]*>.*?</button><pre><code class="source-lines">(.*?)</code></pre></div>',manual,re.S)
    html_steps={name:html.unescape(re.sub(r'</?span\b[^>]*>','',content)) for name,content in fragments}
    if len(fragments)!=len(steps):failures.append(f'HTML工程数 {len(fragments)} / {len(steps)}')
    for step in steps:
        if html_steps.get(step['id'])!=step['code']:
            failures.append(f'HTML工程 {step["id"]}: コピー内容と実コードが不一致')
    if failures:
        for x in failures[:35]:print('FAIL',x,file=sys.stderr)
        raise SystemExit(f'{len(failures)} 件の不一致')
    print(f'PASS: {len(steps)}工程・{len(names)}ファイル・{len(package["phases"])}章スナップショットを照合')
    print('PASS: HTMLコード断片・編集前の文脈・全工程SHA-256・参照ソースの内容が完全一致')
    if workspace:print('PASS: 読者の作業フォルダーの全ファイルが一致')
    if output:print('PASS: ソース再構築完了',output)

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--workspace',type=Path,help='学習者が入力した作業フォルダー（比較のみ）')
    parser.add_argument('--output',type=Path,help='完成ソースを別フォルダーに再構築（指定した場合のみ書込み）')
    args=parser.parse_args()
    check(args.workspace,args.output)
