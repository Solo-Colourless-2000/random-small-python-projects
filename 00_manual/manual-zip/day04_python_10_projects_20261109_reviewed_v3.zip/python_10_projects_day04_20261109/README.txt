Pythonミニプロジェクト教材 day04 / 2026-11-09 (Asia/Tokyo) / 再監査・レイアウト改善版
============================================================
最初に開くHTML：python_10_projects_day04_manual.html
修正版ZIP名：day04_python_10_projects_20261109_reviewed_v3.zip
元配布ZIP名：day04_python_10_projects_20261109.zip

ZIPは以前の教材とは別フォルダーへ展開してください。
このREADMEとHTMLがある教材ルートをターミナルの現在地にします。
HTMLを開く操作ではターミナルの現在地は変わりません。
本書はCSS/JavaScriptを埋め込んだ単体HTMLで、基本実習はオフラインです。

標準ライブラリのみ、Python 3.10以上を基準、Linux操作、vim使用。
元ZIPの実測：Debian GNU/Linux 13、Python 3.12.14、Linux x86_64。
修正版の実測：Linux、Python 3.13.5（一般ユーザー権限で全テスト）。
Python 3.10実機、Arch/Mint/Kali実機は未確認。
基本250分は読む・自分で入力・保存・実行・照合を含む設計上の目安。
準備・休憩・まとめを含め5〜6時間を目指しますが保証ではありません。
全解説の通読・追加問題・Python/vimの新規導入は別枠です。

教材ルートでの最初の確認：
python3 --version
pwd
ls
mkdir -p practice
vim practice/01_palindrome.py

vimの初回操作：
1. vimとファイル名で開く。
2. iで挿入モードへ。
3. HTMLのSTEP 01〜04を同じファイルへ順番に入力する。
4. Escでノーマルモードへ。
5. :wqと入力してEnter、保存・終了する。
6. ターミナルへ戻り次を実行する。
python3 practice/01_palindrome.py "Never odd or even"
echo $?

:wqはvim内の操作で、シェルコマンドやPythonコードではありません。
保存のみ:w、変更を捨てる:q!、取り消しu、末尾から再開G→o。
貼り付けの字下げが増えるならEsc→:set paste→Enter→iで貼り、
Esc→:set nopaste→Enterで戻します。Neovimならvimをnvimへ置換できます。
字下げ4スペース、タブと混ぜない、UTF-8のプレーンテキスト、拡張子.py。
.py.txtの取り違えと、説明用の行番号を入力しないことに注意。
完成版を工程の末尾へ重ねて貼りません。使うなら全体を置き換えます。

projects/は完成版、practice/は自分で入力する場所です。
以下のprojects/をpractice/へ変えると自分の完成品を実行できます。
どの作品も独立し、前の作品の生成物は不要です。

完成版の基本10コマンド（教材ルートで）：
python3 projects/01_palindrome.py 'Never odd or even'
python3 projects/02_caesar_shift.py Az-9 3
python3 projects/03_cycle_match.py 6 8
python3 projects/04_binary_search.py 42
python3 projects/05_roster_compare.py samples/roster_a.txt samples/roster_b.txt
python3 projects/06_rectangle_overlap.py 0,0,4,3 2,1,5,4
python3 projects/07_coin_combinations.py 12
python3 projects/08_tone_wav.py 1000 200 practice/tone.wav
python3 projects/09_seeded_rps.py 7 < samples/rps_input.txt
python3 projects/10_hanoi_moves.py 3

WAVを再生せず自分の保存内容を照合：
python3 tests/inspect_wav.py practice/tone.wav
Channels: 1
Width: 2 bytes
Rate: 8000 Hz
Frames: 1600

この基本例の実測サイズは3244バイト。音声装置は完成条件に不要です。
再実行するとき、作品08は未使用の出力名へ変えます。
python3 projects/08_tone_wav.py 1000 200 practice/tone_2.wav
ほかの作品は同じコマンドで再実行できます。生成ファイルを自動削除しません。

作品09を対話で使う場合：
python3 projects/09_seeded_rps.py 7
起動後にrockと入力してEnterを押します。対話の入力エコーはstdoutと別です。
この検証環境のseed7はpaper、rockは負けでも終了0です。
別実装や将来のバージョンのchoiceの系列までは同じと保証しません。
空入力や未知の手は2、EOF/Ctrl+Cは1として説明して終了します。

終了ステータスは各実行直後のecho $?で確認します。
成功0、I/Oや対話中断1、入力の問題2。見つからない・回文でないも成功0。
同梱の想定エラーメッセージはstdout、想定内ケースのstderrは空です。

全テスト（教材ルート、標準ライブラリのみ）：
python3 -m unittest discover -s tests -v

テストはprojectsとHTML工程から作る一時practice版を対象にします。
自分のpractice版は基本例とdiffで照合します。
diff -u projects/01_palindrome.py practice/01_palindrome.py

ファイル：
python_10_projects_day04_manual.html   全20章・40工程・逐行解説と10作品分の新補講
projects/                            完成Python10本
practice/                            自分の実習先（初期は空）
samples/                             名簿・対話・期待WAVヘッダーのASCII標本
tests/                               実行/教材検査、追加回帰検査、読み取り専用WAV検査道具
verification/                        元版の履歴と、v2の26パス・120画面・32追加画面・実測結果
PROJECT_HISTORY.json                 確認できた過去30題と新規10題
REVIEW_REPORT.txt                    最新の検証数・環境・制限
HANDOFF_PROMPT.txt                   次回への番号と累積台帳

ブラウザー自動検証に使うPlaywright/Chromiumは基本実習に不要です。
コピー不可なら手動欄でCtrl+A/Ctrl+C、保存不可なら紙に進捗を控えます。
JavaScript無効でも全章を続けて読めます。

検証の最終結果・未実施項目はREVIEW_REPORT.txtを参照してください。
台帳の/Daily-PJが使えない場合は/workspace/python_dailyへ保存します。
既存の実行元自動タスクだけの番号・履歴・参照を更新し、
スケジュール・タイムゾーン・有効状態は変更しません。

最終納品済み：day04（2026-11-09、日本時間）、次回：day05。
各改訂段階のテスト・点検は同梱履歴を参照。最新v3の実測結果はREVIEW_REPORT.txtを参照。
元ZIPの47関数・12観点は元の配布時点の記録で、v3の結果とは区別します。

前回の精査改訂版までの改善（元ZIPからの差分）
---------------------------------------------
・全10作品に「コードを頭の中で実行する」補講を追加。各作品に式の計算例、
  実測と照合する追加実験、注意点3件、答え付きの復習問題を収録。
・補講のコマンド/標準出力にもコピー操作と手動代替欄を追加。
・作品05のsplitlines()を改行文字での分割へ変更。垂直タブなどを
  不意に別の名前行として受け入れる問題を修正。
・作品05のstrip()を半角スペース・タブに限定し、Unicode空白の混入を拒否。
・作品10の合法性判定はテスト側の役割であることを明確化。
・作品08/10の難易度と新出語の説明、旧版の検証結果の扱いを修正。
・追加の5テストは標準ライブラリのみ。検証の実測値は修正版レポートへ。
・35項目の静的・構造的点検、4画面幅×20章の表示確認を追記。

元のHANDOFF_PROMPT.txtや旧verification記録には元配布時点の
保存先・実行環境・検証結果が記されています。教材の修正によって
自動実行タスクや保存先を変更したわけではありません。

再監査・レイアウト改善版（v2）の追加事項
------------------------------------------------
・HTMLのZIP展開コマンドを今回の実際の配布ZIP名に修正。
・画面幅600px以下で補講の3列計算表を1行ずつの縦カードへ再配置。
・モバイルの上部操作欄・文章間隔・コード表示を調整。
・各10作品に、動作の理由と仕様を区別する3項目の補足説明を追加。
・作品05のテキストモードでの改行変換、作品10のMove番号の意味を明確化。
・参考資料章の履歴記述を元ZIPの記録と今回の一次資料に区別。
・v2当時の検証結果はverification/v2_*.json/logに記載。

重要: 最新のv2検証結果・制限はREVIEW_REPORT.txtを参照。前回分の35観点・
52テスト等の記録は同じZIP内に残してある履歴であり、今回の新しい実測と区別します。


再監査版（v3）追加事項
------------------------------------------------
・10作品に、入力と標準出力を照合できる個別の追加演習と解答を追加。
・作品05の24行目の逐行解説を、実際の長さ判定に合う説明へ修正。
・作品03の周期の「回数」は時刻0を含むイベント総数ではなく、経過した周期数と明確化。
・作品06の片軸のみ重なる場合の幅・高さ・面積の関係を明確化。
・Pythonのintが全角数字や数字間アンダースコアを受理する点を解説し、
  変換と厳密な入力文字チェックの違いを明示。
・作品05用の小さな追加名簿2ファイルをsamplesへ収録。
・追加演習の実測、画面点検、新しいレビュー記録はverification/v3_へ。
・過去の記録は履歴として残し、最新の検証結果はREVIEW_REPORT.txtに記載。
