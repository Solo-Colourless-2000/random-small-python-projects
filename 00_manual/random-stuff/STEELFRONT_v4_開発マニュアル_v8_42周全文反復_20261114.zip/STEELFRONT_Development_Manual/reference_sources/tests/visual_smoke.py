"""Optional GUI smoke test: run with xvfb-run -a python tests/visual_smoke.py."""
import sys
import tempfile
import time
from pathlib import Path
from PIL import ImageGrab
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
import tkinter as tk
from main import TankArena, OX, OY

# A visual smoke run must never modify the real player's personal best.
_tempdir = tempfile.TemporaryDirectory(prefix='steelfront-visual-')
TankArena._save_path = staticmethod(lambda: Path(_tempdir.name) / 'test-save.json')
root=tk.Tk();app=TankArena(root)
root.update()
ImageGrab.grab().crop((0,0,app.w,app.h)).save(Path(__file__).resolve().parents[1]/'screenshots'/'title.png')
app.new_game();app.screen='PLAYING';app.pointer=(OX+app.engine.state.enemies[0].x,OY+app.engine.state.enemies[0].y)
app.mouse_down=True
start=time.perf_counter()
while time.perf_counter()-start<3.0:
    root.update()
root.update()
ImageGrab.grab().crop((0,0,app.w,app.h)).save(Path(__file__).resolve().parents[1]/'screenshots'/'battle.png')
app.screen='PAUSED';app.render();root.update()
ImageGrab.grab().crop((0,0,app.w,app.h)).save(Path(__file__).resolve().parents[1]/'screenshots'/'paused.png')
app.start_upgrade_screen()
# This is a staged UI preview, not a completed autonomous gameplay run.
# Remove enemies and combat effects from the presentation-only snapshot so
# the 'WAVE CLEARED' HUD is consistent with the displayed upgrade overlay.
for enemy in app.engine.state.enemies:
    enemy.active = 0
app.engine.state.enemy_count = 0
for bullet in app.engine.state.bullets:
    bullet.active = 0
app.engine.state.bullet_count = 0
app.particles.clear()
app.floats.clear()
app.render();root.update()
ImageGrab.grab().crop((0,0,app.w,app.h)).save(Path(__file__).resolve().parents[1]/'screenshots'/'upgrade.png')
print('GUI OK: ',app.w,app.h,'fps',round(app.fps,1),'enemies',app.engine.state.enemy_count,'bullets',app.engine.state.bullet_count)
app.close()
_tempdir.cleanup()
