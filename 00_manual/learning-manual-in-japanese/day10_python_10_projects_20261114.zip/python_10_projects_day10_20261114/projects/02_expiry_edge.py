import sys

EXPIRES = 100
CASES = {"before": 99, "equal": 100, "after": 101, "zero": 0}


def check_time(now):
    weak = now <= EXPIRES
    strict = now < EXPIRES
    return weak, strict


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script before|equal|after|zero", file=sys.stderr)
        return 2
    now = CASES[sys.argv[1]]
    weak, strict = check_time(now)
    print(f"Clock: {now}")
    print(f"Inclusive gate: {weak}")
    print(f"Exclusive gate: {strict}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
