import shlex
import subprocess
import sys

CASES = {"normal": "hello", "separator": "hello; printf INJECTED"}


def run_case(value, quoted):
    argument = shlex.quote(value) if quoted else value
    command = "printf '%s\\n' " + argument
    result = subprocess.run(["/bin/sh", "-c", command], capture_output=True, text=True, encoding="ascii", timeout=2, check=True)
    return result.stdout


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script normal|separator", file=sys.stderr)
        return 2
    value = CASES[sys.argv[1]]
    try:
        raw = run_case(value, False)
        quoted = run_case(value, True)
    except (OSError, subprocess.SubprocessError):
        print("Fixed shell experiment failed.", file=sys.stderr)
        return 1
    print(f"Raw output: {raw!r}")
    print(f"Quoted output: {quoted!r}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
