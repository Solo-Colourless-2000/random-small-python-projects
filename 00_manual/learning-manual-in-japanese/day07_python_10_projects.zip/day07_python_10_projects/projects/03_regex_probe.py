import re
import sys

CASES = {"literal": "alice", "wild": ".*", "dot": "a.b"}
NAMES = ("alice", "admin", "a.b", "axb")


def matches(pattern, literal):
    expression = re.escape(pattern) if literal else pattern
    found = []
    for name in NAMES:
        if re.fullmatch(expression, name) is not None:
            found.append(name)
    return ",".join(found) or "(none)"


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script literal|wild|dot", file=sys.stderr)
        return 2
    pattern = CASES[sys.argv[1]]
    print(f"Pattern input: {matches(pattern, False)}")
    print(f"Literal input: {matches(pattern, True)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
