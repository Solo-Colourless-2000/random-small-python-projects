import sys
import xml.etree.ElementTree as ET

CASES = {"foreign": '<r xmlns="urn:other"><role>admin</role></r>', "trusted": '<r xmlns="urn:lab"><role>admin</role></r>', "bare": '<r><role>admin</role></r>', "broken": '<r>'}


def inspect_xml(text):
    root = ET.fromstring(text)
    weak = False
    strict = False
    for element in root:
        local_name = element.tag.rsplit("}", 1)[-1]
        if local_name == "role" and element.text == "admin":
            weak = True
        if element.tag == "{urn:lab}role" and element.text == "admin":
            strict = True
    return weak, strict


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script foreign|trusted|bare|broken", file=sys.stderr)
        return 2
    try:
        weak, strict = inspect_xml(CASES[sys.argv[1]])
    except ET.ParseError:
        print("Invalid lab XML.", file=sys.stderr)
        return 2
    print(f"Local-name admin: {weak}")
    print(f"Expanded-name admin: {strict}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
