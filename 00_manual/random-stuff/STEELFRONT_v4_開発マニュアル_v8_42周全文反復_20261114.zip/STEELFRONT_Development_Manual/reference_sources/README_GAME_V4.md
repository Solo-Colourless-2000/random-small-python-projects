# STEELFRONT: TANK ARENA v4

**C言語の戦闘エンジンとPython/Tkinterの表示・入力を組み合わせた、見下ろし型の戦車戦ゲーム**です。完全オフラインで遊べます。v4では、以前のモジュール構成とデザインを維持しつつ、入力順序に依存するダッシュ、細かい時間刻み、制圧完了後の残弾、小さいディスプレイでのウィンドウ制限と共有ライブラリのファイル権限を修正しました。

![Linux上で実際に動作させた戦闘画面](screenshots/battle.png)

## 遊び方

車体の移動方向と砲塔の照準を独立して操作し、ウェーブごとに出現する敵戦車をすべて撃破します。遮蔽物を利用しながら戦い、クリア時には3枚の装備カードから1枚を選択して次のウェーブへ進みます。**5ウェーブごとにCOMMANDER型ボス**が登場します。最後の敵を倒すと、残った敵弾は消えて報酬選択まで安全に移行します。

- 敵：SCOUT（高速）、GUNNER（射撃）、BRUISER（重装甲）、COMMANDER（ボス・3連射）。
- 攻撃：主砲、鉄壁からの跳弾、EMP衝撃波。木箱は破壊可能で、金属壁は破壊できません。
- 防御・機動：被弾後の短い無敵時間、方向入力中のダッシュ、回復とエネルギーのドロップ。
- 成長：11種類の装備強化、スコア、コンボ、ハイスコアと最高到達ウェーブをローカル保存。

| 操作 | キー・ボタン |
| --- | --- |
| 移動 | `W A S D` または矢印キー |
| 砲塔の照準 | マウス移動 |
| 主砲 | 左クリック長押し、または `Space` 長押し |
| ダッシュ | 移動しながら `Shift`（初期消費66エネルギー）。Shiftを先に押しても移動開始時にダッシュできます |
| EMP | `E`（初期クールダウン10秒） |
| ポーズ／再開 | `P` または `Esc`。再開には `Enter` も使用可 |
| 開始／再挑戦 | `Enter`、画面内のボタン、ゲームオーバー時は `R` も可 |
| 装備強化 | `1` / `2` / `3` またはカードをクリック |

**入力の安全対策**：画面外にカーソルが出たときの射撃解除、ポーズとフォーカス喪失時のキー状態破棄、装備選択から次ウェーブへ移る際の入力破棄を実装しています。ウェーブ開始演出中にポーズしても、再開時には残りの演出が続きます。Shiftを離したときは未使用のダッシュ入力も破棄します。

## インストールと起動

追加のPythonゲームライブラリは不要です。**Python 3.9以降（`tkinter`が利用できること）**と、必要に応じてC11に対応したGCC/Clangを使用します。

### Linux

Debian/Ubuntu系の場合：

```bash
sudo apt install python3 python3-tk gcc
./run_steelfront.sh
```

Arch Linuxの場合は、Python・Tk・Cコンパイラを導入した上で `./run_steelfront.sh` を実行します。実行権限がないときは `sh run_steelfront.sh` または `python3 main.py` を使用してください。

同梱の `engine/libtank_engine.so` は **Linux x86-64の検証環境でビルドしたもの**です。別のアーキテクチャやABIでは読み込めない場合があり、その場合は利用可能なコンパイラで自動再ビルドを試みます。

### Windows

1. Python 3.9以降（Tkinterを含む構成）をインストール。
2. MinGW-w64版GCCを導入し、`gcc --version` がコマンドプロンプトで動くようPATHを設定。
3. ZIPを展開し、`Run_Steelfront.bat` を実行。起動できなければ展開先で `py -3 main.py` を実行してエラーを確認。

Windows用のDLLは初回起動時にCソースから生成します。**Windows実機での動作検証は行っていません**。

### macOS

PythonのTkinterが使えることを確認し、必要に応じて `xcode-select --install` でコンパイラを準備します。`./run_steelfront.sh` で起動します。**macOS実機での動作検証は行っていません**。

## ファイル構成・保守性

実装を無理に1つのファイルに詰め込まず、かつ細分化しすぎない構成としています。

```text
STEELFRONT_Tank_Arena/
├── main.py                   # 起動、キーとマウス、ゲームの状態遷移、固定時間更新
├── arena_visual.py           # 戦場の描画、戦車・砲弾・HPバー・HUD
├── arena_menus.py            # タイトル、ポーズ、強化、ゲームオーバーの各メニュー
├── arena_effects.py          # 爆発・命中パーティクル、正確な獲得点数表示
├── arena_config.py           # 配色、座標、強化情報、小画面向けの短い説明文
├── arena_scores.py           # 保存と復旧、破損JSONや保存失敗への対処
├── c_bridge.py               # ctypes宣言、C/Pythonの構造体とAPI整合性確認
├── build_engine.py           # GCC/Clangでの安全な共有ライブラリ生成
├── engine/
│   ├── tank_engine.h         # 公開APIとデータ構造
│   ├── engine_internal.h     # C内部モジュールの共有契約
│   ├── tank_engine.c         # 初期化、ウェーブ、入力処理、強化
│   ├── tank_enemies.c        # 敵のAI・生成・遮蔽物の局所回避
│   ├── tank_combat.c         # 砲弾とダメージ、コンボ、跳弾の残時間
│   ├── tank_geometry.c       # 線分・円と矩形の幾何判定、壁への衝突
│   └── libtank_engine.so     # 検証環境用のLinux x86-64共有ライブラリ
├── tests/
│   ├── test_engine.py        # 61件のC戦闘テスト
│   ├── test_ui.py            # 30件のGUIテスト
│   ├── test_review_regressions.py # v2の35件の回帰テスト
│   ├── test_deep_review.py   # v3の44件の独立した問題シナリオ
│   ├── run_25_pass_audit.py  # 既存25テーマの個別確認
│   ├── run_44_deep_passes.py # 44テーマを結果照合しながら実行
│   ├── test_v4_quality.py    # v4で追加した40の独立シナリオ
│   ├── run_v4_40_passes.py   # 40シナリオのJUnit結果を個別照合
│   ├── resolution_smoke.py   # 小画面を含む描画・全装備カードの文字幅検査
│   ├── native_stress.c       # Cサニタイザ負荷試験
│   ├── visual_smoke.py       # 実GUI画面の撮影
│   └── logs/                 # 実際の検査結果
├── screenshots/              # タイトル・戦闘・ポーズ・強化の実画面
├── QUALITY_AUDIT.md          # 発見した問題、修正内容、検査の証跡
└── MANIFEST_SHA256.txt       # 配布ファイルのSHA256チェックサム
```

### 設計のポイント

- Cは敵、砲弾、当たり判定を**一括で更新**し、Pythonはゲーム世界のスナップショットを取得して表示します。
- 戦闘は60Hzの固定ステップ。描画処理が遅いときは追いつく回数に上限を設けており、極端に遅いPCではゲーム速度が落ちる可能性があります。
- 砲弾は線分衝突判定。v3以降は**金属壁の角を丸い弾丸として正しく判定**し、反射後もそのフレームの残り移動時間を使います。
- 敵は局所的な回避を使用。以前の版で正面の壁に止まり続ける問題を改善しましたが、グローバルな経路探索（A*など）ではありません。
- 静的な背景と遮蔽物をキャッシュして、Tkinter Canvasの再描画回数を減らしています。
- ハイスコアは `~/.steelfront_tank_arena.json` 相当のホームディレクトリに保存します。既存ファイルの上書きは一時ファイルと置換で行います。
- Cエンジンは**プロセス内に1つのゲーム世界**を持ちます。同時に独立した複数のゲームセッションを動かす用途には対応していません。

## 検証・開発

プレイ自体には追加パッケージは不要です。テストには `pytest`、画面撮影・解像度検査には `Pillow` を使用します。

```bash
python -m pip install pytest pillow
python build_engine.py
# GUI付きLinuxではそのまま。ヘッドレスなら xvfb-run -a を付ける
python -m pytest -q tests/test_engine.py tests/test_ui.py tests/test_review_regressions.py tests/test_deep_review.py tests/test_v4_quality.py
xvfb-run -a python tests/run_44_deep_passes.py
xvfb-run -a python tests/run_v4_40_passes.py
xvfb-run -a python tests/run_25_pass_audit.py
xvfb-run -a python tests/visual_smoke.py
```

解像度確認例（LinuxのXvfb使用時）：

```bash
xvfb-run -a -s '-screen 0 640x480x24' python tests/resolution_smoke.py
```

**v4の最新実測**：基本テスト61＋GUI30＋v2回帰35＋v3回帰44＋v4追加40＝**210件PASS**。40テーマ、旧44テーマ、既存25テーマの実行記録、GCC/Clangビルド、57,600フレームのASan/UBSan試験、4解像度での実GUI表示検証を `QUALITY_AUDIT.md` と `tests/logs/v4/` に記録しています。

## 動作環境と既知の限界

- **検証済みはLinuxの仮想画面**です。Windows/macOSは実機未検証です。
- 640×480のような小さい表示環境では文字が小さくなります。以前の版で文字やカードの枠外はみ出しを修正しましたが、快適なプレイはより大きなディスプレイを推奨します。
- TkinterによるCPUベースの描画のため、環境によってFPSが低くなる可能性があります。60FPSは保証しません。
- 音声、オンライン対戦、コントローラー入力は未対応です。
- 自動テストやサニタイザですべての不具合が排除されたことを証明するものではありません。

## 参考資料

ゲームの実装上の一次資料は、このZIP内の `main.py`、`arena_*.py`、`engine/*.c`、`engine/*.h`、`tests/*.py`、`tests/*.c`、`tests/logs/` です。技術の仕様は [Python公式 ctypes](https://docs.python.org/3/library/ctypes.html)、[Python公式 tkinter](https://docs.python.org/3/library/tkinter.html)、[GCC公式ドキュメント](https://gcc.gnu.org/onlinedocs/) を参照してください。

ゲーム内の図形とソースコードは本作のために作成しています。外部画像素材、商用音源、フォントファイルは同梱していません。
