import math
import sys


def main():
    if len(sys.argv) != 2:
        print("Usage: python3 09_newton_root.py number")
        return 2
    try:
        if len(sys.argv[1]) > 20:
            raise ValueError
        number = float(sys.argv[1])
        if not math.isfinite(number) or not (number == 0 or 0.000001 <= number <= 10000):
            raise ValueError
    except ValueError:
        print("Error: use zero or a finite number from 0.000001 to 10000.")
        return 2
    if number == 0:
        print("Root: 0.000000")
        return 0
    guess = max(1.0, number)
    for step in range(1, 21):
        improved = (guess + number / guess) / 2
        difference = abs(improved - guess)
        guess = improved
        print(f"Step {step}: {guess:.8f}")
        if difference < 1e-10:
            print(f"Root: {guess:.6f}")
            return 0
    print("Error: iteration limit reached.")
    return 1


if __name__ == "__main__":
    raise SystemExit(main())
