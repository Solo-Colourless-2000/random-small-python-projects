"""Headless controller fixtures. No Tk display is needed for these tests."""
import random
from game import Game


class FakeRoot:
    def __init__(self):
        self.jobs = {}
        self.next_id = 0

    def after(self, delay, callback):
        self.next_id += 1
        self.jobs[str(self.next_id)] = callback
        return str(self.next_id)

    def after_cancel(self, job):
        self.jobs.pop(job, None)

    def after_idle(self, callback):
        return self.after(0, callback)

    def focus_get(self):
        return None

    def flush(self):
        pending = list(self.jobs.values())
        self.jobs.clear()
        for callback in pending:
            callback()

    def destroy(self):
        self.destroyed = True


def create_game(seed=9):
    game = Game.__new__(Game)
    game.root = FakeRoot()
    game.rng = random.Random(seed)
    game.fx_rng = random.Random(seed ^ 0xC0FFEE)
    game.keys = set()
    game._key_release_jobs = {}
    game.mouse_x, game.mouse_y = 900, 350
    game.state = 'menu'
    game.global_time = 0.0
    game.best = 0
    game._saved_best = 0
    game.record_save_failed = False
    game.running = True
    game._frame_debt = 0.0
    game.last_clock = 0.0
    game.reset_session()
    game.start()
    # Tests must not change the developer's own home-dir high score.
    game.save_best = lambda: None
    return game
