"""Optional Chromium interaction tests; requires playwright and a Chromium binary.
Not required to run any of the ten beginner lab scripts.
Run from the package root: python3 verification/interactive_browser_check.py
"""
import asyncio, json
from pathlib import Path
from playwright.async_api import async_playwright, Error
ROOT=Path(__file__).resolve().parents[1]
PAGE=ROOT/'python_10_projects_day06_manual.html'

def check(value, desc):
 if not value: raise AssertionError(desc)

async def main():
 records=[]
 async with async_playwright() as pw:
  browser=await pw.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox','--disable-gpu'])
  for width in (320,390,768,1440):
   page=await browser.new_page(viewport={'width':width,'height':920},device_scale_factor=1)
   errors=[]
   page.on('pageerror',lambda err: errors.append(str(err)))
   await page.set_content(PAGE.read_text(encoding='utf-8'),wait_until='load')
   await page.wait_for_timeout(80)
   geo=await page.evaluate('''() => ({viewport:innerWidth, doc: document.documentElement.scrollWidth,chapters:document.querySelectorAll('.chapter').length,explanations:document.querySelectorAll('.reasoning-lab').length,glosses:document.querySelectorAll('[id^="glossary-second-"]').length})''')
   check(geo['doc']<=width, f'horizontal overflow {width}: {geo}')
   check(geo['chapters']==20 and geo['explanations']==10 and geo['glosses']==15,'chapter glossary counts')
   # Exercise all forty source navigation links, with return to exact article, on desktop.
   links_checked=0
   for num in (range(1,11) if width==1440 else (1,5,10)):
    await page.evaluate('(i) => location.hash="#p"+String(i).padStart(2,"0")',num)
    await page.wait_for_timeout(25)
    for step in range(1,5):
     article_id=f'p{num:02}-step{step}'
     await page.locator(f'#{article_id} [data-source]').click()
     await page.wait_for_timeout(35)
     target=page.locator(f'[data-return="{num:02}"]')
     check(await target.get_attribute('href')=='#'+article_id,f'wrong return {article_id}')
     check(await page.locator('#appendix-a').is_visible(), f'appendix hidden {article_id}')
     check(await page.locator('#source-return').get_attribute('href')=='#'+article_id, f'global return {article_id}')
     await target.click()
     await page.wait_for_timeout(35)
     check(await page.locator('#'+article_id).is_visible(),f'return invisible {article_id}')
     links_checked+=1
   # Search and click a search hit inside another chapter.
   await page.locator('#search').fill('は1組目で止まる')
   count=await page.locator('#search-count').inner_text()
   check('件' in count and '0 件' not in count,'search index')
   await page.locator('#results a').first.click()
   await page.wait_for_timeout(40)
   check(await page.locator('#p09').is_visible(),'search navigation')
   # Progress reset and settings.
   box=page.locator('#p09 [data-check]')
   await box.check()
   check('1 / 20' in await page.locator('#progress').inner_text(),'progress increment')
   if width <= 850:
    await page.locator('#menu').click()
   await page.locator('#reset').click()
   if width <= 850:
    await page.locator('#menu').click()
   check('0 / 20' in await page.locator('#progress').inner_text(),'progress reset')
   await page.locator('#larger').click()
   check(float(await page.evaluate('getComputedStyle(document.documentElement).getPropertyValue("--scale")'))>1.0,'font scaling')
   await page.locator('#wrap').click()
   check(await page.locator('#wrap').get_attribute('aria-pressed')=='true','wrap')
   await page.locator('#focus').click()
   check(await page.locator('#focus').get_attribute('aria-pressed')=='true','focus')
   await page.locator('#focus').click()
   # Copy should work or provide a manual selection fallback, not throw an exception.
   await page.locator('#p09 .copy').first.click()
   await page.wait_for_timeout(60)
   status=await page.locator('#p09 .copy-status').first.inner_text()
   check('コピー' in status or '選択' in status, f'copy feedback: {status!r}')
   check(not errors,f'JS errors at {width}: {errors}')
   if width in (390,1440):
    await page.locator('#search').fill('')
    await page.screenshot(path=str(ROOT/'verification'/f'layout_72round_{width}.png'))
   records.append({'viewport':width,'document_width':geo['doc'],'chapters':geo['chapters'],'project_deep_dive_cards':geo['explanations'],'glossary_additions':geo['glosses'],'source_links_round_trip_tested':links_checked,'search_results':count,'copy_feedback':status,'javascript_errors':errors,'result':'PASS'})
   await page.close()
  # File URL opening is optional: some managed Chromium builds prohibit it.
  local=await browser.new_page(viewport={'width':1100,'height':800})
  load_errors=[]
  local.on('pageerror',lambda err:load_errors.append(str(err)))
  try:
   await local.goto(PAGE.as_uri(),wait_until='load')
   await local.wait_for_timeout(40)
   fileinfo=await local.evaluate('''() => ({protocol:location.protocol, visible:document.querySelectorAll('.chapter.active').length,head:document.title,storage:document.getElementById('storage-status').textContent})''')
   check(fileinfo['protocol']=='file:' and fileinfo['visible']==1 and not load_errors,f'file:// {fileinfo} {load_errors}')
   await local.locator('#toc a[href="#p04"]').click()
   await local.wait_for_timeout(40)
   check(await local.locator('#p04').is_visible(),'file URL chapter navigation')
   fileinfo['result']='PASS'
   records.append({'local_file_open':fileinfo})
  except Error as exc:
   if 'ERR_BLOCKED_BY_ADMINISTRATOR' not in str(exc):
    raise
   records.append({'local_file_open':{'result':'NOT_TESTED','reason':'Chromium in this container blocks file:// by administrator policy'}})
  await local.close()
  await browser.close()
 result={'browser':'Chromium headless','method':'set_content for viewport checks; file:// for direct opening','records':records}
 (ROOT/'verification'/'browser_interaction_72round.json').write_text(json.dumps(result,indent=2,ensure_ascii=False)+'\n',encoding='utf-8')
 for row in records:print(row)

if __name__=='__main__':asyncio.run(main())
