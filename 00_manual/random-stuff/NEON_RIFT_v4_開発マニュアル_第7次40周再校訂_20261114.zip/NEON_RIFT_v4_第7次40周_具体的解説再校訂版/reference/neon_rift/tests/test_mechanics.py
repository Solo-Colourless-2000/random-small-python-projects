"""Non-GUI regression tests: python -m unittest discover -s tests -v"""
import random
import sys
import unittest
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from constants import ARENA_LEFT,ARENA_TOP,ARENA_RIGHT,ARENA_BOTTOM,UPGRADES
from mechanics import clamp,unit,distance_sq,circles_touch,in_arena,boundary_spawn,wave_roster,upgrade_choices,format_seconds
from entities import Enemy,Player

class MechanicsTests(unittest.TestCase):
    def test_clamp(self):
        self.assertEqual(clamp(-3,0,10),0)
        self.assertEqual(clamp(4,0,10),4)
        self.assertEqual(clamp(99,0,10),10)

    def test_unit(self):
        x,y=unit(3,4)
        self.assertAlmostEqual(x,.6)
        self.assertAlmostEqual(y,.8)
        self.assertEqual(unit(0,0),(0.0,0.0))

    def test_distance(self):
        self.assertEqual(distance_sq(0,0,3,4),25)

    def test_circles(self):
        self.assertTrue(circles_touch(0,0,4,5,0,2))
        self.assertFalse(circles_touch(0,0,2,5,0,2))

    def test_bounds(self):
        x,y=in_arena(-200,999,20)
        self.assertEqual(x,ARENA_LEFT+20)
        self.assertEqual(y,ARENA_BOTTOM-20)

    def test_spawn_always_at_boundary(self):
        rng=random.Random(12)
        points=[boundary_spawn(rng,26) for _ in range(200)]
        for x,y in points:
            self.assertTrue(ARENA_LEFT <= x <= ARENA_RIGHT)
            self.assertTrue(ARENA_TOP <= y <= ARENA_BOTTOM)
            self.assertTrue(min(x-ARENA_LEFT,ARENA_RIGHT-x,y-ARENA_TOP,ARENA_BOTTOM-y)<=26.01)

    def test_wave_1(self):
        roster=wave_roster(1,random.Random(2))
        self.assertEqual(len(roster),8)
        self.assertEqual(set(roster),{'hunter'})

    def test_wave_5_boss(self):
        roster=wave_roster(5,random.Random(2))
        self.assertEqual(roster.count('warden'),1)
        self.assertEqual(len(roster),17)

    def test_wave_10_boss(self):
        roster=wave_roster(10,random.Random(2))
        self.assertEqual(roster.count('warden'),1)
        self.assertEqual(len(roster),27)

    def test_wave_invalid(self):
        with self.assertRaises(ValueError):
            wave_roster(0,random.Random(0))

    def test_upgrade_unique(self):
        picks=upgrade_choices(random.Random(3))
        self.assertEqual(len(picks),3)
        self.assertEqual(len(set(picks)),3)
        self.assertTrue(set(picks).issubset(UPGRADES))

    def test_upgrade_avoids_previous(self):
        prev={'overclock','tungsten','thrusters'}
        picks=upgrade_choices(random.Random(1),prev)
        self.assertFalse(prev.intersection(picks))

    def test_time_format(self):
        self.assertEqual(format_seconds(135.1),'02:15')
        self.assertEqual(format_seconds(-4),'00:00')

    def test_enemy_factory(self):
        e=Enemy('warden',200,400)
        self.assertGreater(e.hp,300)
        self.assertEqual(e.hp,e.max_hp)

    def test_player_defaults(self):
        p=Player()
        self.assertGreater(p.hp,0)
        self.assertGreaterEqual(p.energy,65)

if __name__ == '__main__':
    unittest.main()
