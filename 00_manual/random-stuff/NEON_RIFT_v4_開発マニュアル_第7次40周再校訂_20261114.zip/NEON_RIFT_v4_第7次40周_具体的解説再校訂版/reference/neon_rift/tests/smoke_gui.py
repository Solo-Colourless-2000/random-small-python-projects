"""Automated Tk window smoke test. Requires a display/Xvfb."""
import sys
import tkinter as tk
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from game import Game
from constants import WIDTH,HEIGHT
from entities import Bullet

root=tk.Tk()
try:
    game=Game(root,seed=33,auto_loop=False)
    game.save_best = lambda: None  # Never overwrite the tester's personal record.
    assert game.state=='menu'
    root.update()
    assert game.canvas.winfo_width()==WIDTH and game.canvas.winfo_height()==HEIGHT
    game.start()
    for n in range(220):
        game.mouse_x=WIDTH*.8
        game.mouse_y=HEIGHT*.45
        game.mouse_down=True
        game.keys={'d'} if n<130 else {'w'}
        if n==10: game.dash()
        if n==40: game.pulse()
        game.tick(1/60)
        game.renderer.draw(game)
        if n%30==0: root.update()
    assert game.score>=0
    assert game.wave>=1
    assert game.player.hp>=0
    # Combat invariants: firing creates friendly bullets, and pulse consumes energy.
    game.bullets.clear()
    game.fire_player()
    assert any(b.friendly for b in game.bullets)
    game.player.energy=100
    game.bullets.append(Bullet(game.player.x+30,game.player.y,0,0,5,10,2,False,'#fff'))
    game.pulse()
    assert game.player.energy==35
    assert not any(not b.friendly for b in game.bullets)
    # Boss behavior and the rendering branch for its large sprite.
    game.enemies.clear()
    game.spawn_enemy('warden')
    assert game.enemies[0].kind=='warden'
    for _ in range(140):
        game.player.invulnerable=2
        game.update_enemies(1/60)
    assert any(not b.friendly for b in game.bullets)
    game.renderer.draw(game)
    # Exercise upgrade selection (and ensure it advances the wave).
    game.enemies.clear()
    game.pending.clear()
    game.finish_wave()
    assert game.state=='upgrade'
    game.renderer.draw(game)
    game.apply_upgrade(0)
    assert game.state=='playing' and game.wave==2
    # Test the pause screen and end screen render paths.
    game.state='paused'
    game.renderer.draw(game)
    game.state='playing'  # game_over() only transitions from active play.
    game.game_over()
    assert game.state == 'gameover'
    game.renderer.draw(game)
    # Storage-error feedback must be present on the actual gameover canvas.
    game.record_save_failed = True
    game.renderer.draw(game)
    messages = [game.canvas.itemcget(item, 'text')
                for item in game.canvas.find_all()
                if game.canvas.type(item) == 'text']
    assert 'WARNING: HIGH SCORE NOT SAVED' in messages
    root.update()
    print('GUI SMOKE OK: menu, movement, shooting, dash, pulse, upgrades, pause, gameover')
finally:
    root.destroy()
