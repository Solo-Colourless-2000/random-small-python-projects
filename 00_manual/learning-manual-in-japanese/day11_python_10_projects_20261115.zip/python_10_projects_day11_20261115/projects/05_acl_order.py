import ipaddress
import sys

RULES = (("10.0.0.0/24", "allow"), ("10.0.0.7/32", "deny"))
CASES = {"blocked": "10.0.0.7", "neighbor": "10.0.0.8", "outside": "10.0.1.7", "broken": "bad"}


def decide(address, rules):
    for network, action in rules:
        if address in ipaddress.ip_network(network):
            return action
    return "deny"


def main():
    if len(sys.argv) != 2 or sys.argv[1] not in CASES:
        print("Usage: script blocked|neighbor|outside|broken", file=sys.stderr)
        return 2
    try:
        address = ipaddress.ip_address(CASES[sys.argv[1]])
    except ValueError:
        print("Invalid lab address.", file=sys.stderr)
        return 2
    broad_first = decide(address, RULES)
    exception_first = decide(address, RULES[::-1])
    print(f"Broad-first decision: {broad_first}")
    print(f"Exception-first decision: {exception_first}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
