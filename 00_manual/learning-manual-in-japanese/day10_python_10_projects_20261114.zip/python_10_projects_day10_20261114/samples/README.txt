All lab fixtures are embedded in the individual scripts. No external sample files are required.
